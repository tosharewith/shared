/**
 * IDS Web Components Configuration Utility
 *
 * Configures @ids/web components to use local icons during development,
 * avoiding CORS issues with the CDN (ids-dev.cloud.itau.com.br).
 *
 * Usage in main.jsx or App.jsx:
 *   import { setupIdsLocalIcons } from './utils/idsConfig';
 *   setupIdsLocalIcons();
 *
 * How it works:
 * - IDS icon component loads icons from: ${baseUrl}/ids/assets/icons/v2/{name}.svg
 * - When baseUrl is not set, it defaults to CDN: https://ids{env}.cloud.itau.com.br/cdn/...
 * - The CDN redirects to www.itau.com.br which causes CORS errors
 * - By setting baseUrl to empty string (''), icons load from relative paths: /ids/assets/icons/v2/{name}.svg
 * - The icons are extracted from Ids_Itau_Icons-defs.svg to public/ids/assets/icons/v2/
 */

/**
 * Setup IDS configuration for local icon loading in development.
 * Call this once at app startup before any IDS components are rendered.
 *
 * @param {Object} options - Configuration options
 * @param {string} [options.baseUrl=''] - Base URL for IDS assets. Empty string uses relative paths.
 * @param {string} [options.theme='varejo'] - IDS theme (varejo, empresas, etc.)
 * @param {string} [options.schemeTheme='light'] - Color scheme (light, dark)
 * @param {string} [options.environment='dev'] - Environment (dev, hom, prod)
 * @returns {Promise<void>}
 */
export async function setupIdsConfig(options = {}) {
  const {
    baseUrl = '',        // Empty string = use relative paths for local serving
    theme = 'varejo',
    schemeTheme = 'light',
    environment = 'dev'
  } = options;

  // Check if IDS web is available
  if (typeof window === 'undefined') {
    console.warn('[IDS Config] Window not available, skipping configuration');
    return;
  }

  try {
    // Dynamic import to handle cases where @ids/web may not be installed
    const { iDSConfig } = await import('@ids/web/tools/config');

    await iDSConfig({
      baseUrl,
      theme,
      schemeTheme,
      environment
    });

    console.log('[IDS Config] Configured successfully:', { baseUrl, theme, schemeTheme, environment });

    // Verify icon path is accessible (optional debug)
    if (import.meta.env.DEV) {
      const testIconUrl = `${baseUrl}/ids/assets/icons/v2/calendar_day.svg`;
      fetch(testIconUrl, { method: 'HEAD' })
        .then(res => {
          if (res.ok) {
            console.log('[IDS Config] Local icons verified at:', testIconUrl);
          } else {
            console.warn('[IDS Config] Icon test failed:', testIconUrl, res.status);
          }
        })
        .catch(() => {
          console.warn('[IDS Config] Could not verify local icons');
        });
    }
  } catch (err) {
    // IDS web not installed or other error - provide fallback info
    console.warn('[IDS Config] Could not configure IDS:', err.message);
    console.info('[IDS Config] If using IDS components, install @ids/web and call setupIdsConfig() at startup');
  }
}

/**
 * Shorthand for setupIdsConfig with default development settings.
 * Use this in main.jsx for quick local icon setup.
 */
export const setupIdsLocalIcons = () => setupIdsConfig({ baseUrl: '' });

/**
 * IDS icon names available locally.
 * Generated from Ids_Itau_Icons-defs.svg sprite file.
 */
export const IDS_LOCAL_ICONS = [
  'add_circle',
  'arrow_down',
  'arrow_left',
  'arrow_order_down',
  'arrow_order_up',
  'arrow_order',
  'arrow_right',
  'arrow_up',
  'bank_cash_flow',
  'bar_code_reader',
  'bar_code',
  'calendar_day',
  'calendar_month',
  'card_digital',
  'card_group',
  'card',
  'cash_box',
  'chat_dots',
  'chat_message',
  'check_circle',
  'check_small',
  'check',
  'checkbox_unchecked',
  'checkbox',
  'circle_filled',
  'clock',
  'close',
  'coin',
  'company',
  'configuration',
  'copy',
  'credit',
  'discount',
  'doc_folder',
  'doc_invoice',
  'doc',
  'dots_horizontal',
  'download',
  'edit',
  'error_circle',
  'exchange',
  'exit',
  'explore',
  'external_link',
  'extra_protection',
  'eye_closed',
  'eye_open',
  'filter',
  'food',
  'fraud_prevention',
  'heart',
  'help',
  'home',
  'ia',
  'information',
  'innovation',
  'installment',
  'investment_stocks',
  'investments',
  'itoken_app',
  'limit_bar',
  'list',
  'loan',
  'lock',
  'menu',
  'microphone',
  'mobile',
  'money',
  'notification',
  'open_finance',
  'payment_terminal',
  'phone',
  'pix',
  'plus',
  'protected_mode',
  'radio_button_checked',
  'radio_button',
  'receipt',
  'reload',
  'rewards',
  'search',
  'share',
  'shopping_bag',
  'squares',
  'star',
  'target',
  'thumbs_down',
  'thumbs_up',
  'transaction',
  'transport_car',
  'transport_flight',
  'trash',
  'user_deal',
  'user_executive',
  'user_id',
  'user',
  'video_play',
  'wallet',
  'warning'
];
