import { useState, useMemo } from 'react';
import { Tag, Button, IconButton, Toggle } from '@carbon/react';
import {
  ChevronLeft,
  ChevronRight,
  Screen,
  Api,
  DataBase,
  Terminal,
  Application,
  Document,
  Information,
  List,
  Grid as GridIcon,
  Play,
  Home,
  ArrowRight,
  Code,
  TableOfContents
} from '@carbon/icons-react';
import styles from './WireframeViewer.module.scss';

/**
 * WireframeViewer - Navigable wireframe sequence viewer
 * Shows each interaction as a mockup screen with navigation
 */
const WireframeViewer = ({ transactionData, onClose }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showDetails, setShowDetails] = useState(true);
  const [viewMode, setViewMode] = useState('sequence'); // 'sequence' or 'grid'

  // Build navigation sequence from flowGraph
  const navigationSequence = useMemo(() => {
    if (!transactionData?.flow) return [];

    const sequence = [];
    const visited = new Set();
    const flowGraph = transactionData.flow.flowGraph || {};
    const interactionMap = {};

    // Build interaction lookup
    transactionData.flow.interactions?.forEach(interaction => {
      if (interaction.path) {
        interactionMap[interaction.path] = interaction;
      }
    });

    // Add MENU as first item
    sequence.push({
      id: 'MENU',
      type: 'MENU',
      name: transactionData.menuItem?.nomeLogico || 'Menu Principal',
      path: 'MENU',
      menuItem: transactionData.menuItem,
      navigatesTo: flowGraph['MENU'] || []
    });
    visited.add('MENU');

    // BFS to build sequence
    const queue = [...(flowGraph['MENU'] || [])];

    while (queue.length > 0) {
      const path = queue.shift();
      if (visited.has(path)) continue;
      visited.add(path);

      const interaction = interactionMap[path] || {
        path,
        name: path.split('\\').pop(),
        type: 'Unknown'
      };

      sequence.push({
        id: path,
        type: interaction.type || 'Unknown',
        name: interaction.name || path.split('\\').pop(),
        path: path,
        interaction: interaction,
        xmlFile: interaction.xmlFile,
        webService: interaction.webService,
        mainframe: interaction.mainframe,
        navigatesTo: flowGraph[path] || [],
        navigations: interaction.navigations || []
      });

      // Add targets to queue
      (flowGraph[path] || []).forEach(target => {
        if (!visited.has(target)) {
          queue.push(target);
        }
      });
    }

    return sequence;
  }, [transactionData]);

  const currentScreen = navigationSequence[currentIndex];
  const canGoBack = currentIndex > 0;
  const canGoForward = currentIndex < navigationSequence.length - 1;

  const goToScreen = (index) => {
    if (index >= 0 && index < navigationSequence.length) {
      setCurrentIndex(index);
    }
  };

  const goToPath = (path) => {
    const index = navigationSequence.findIndex(s => s.path === path);
    if (index >= 0) {
      setCurrentIndex(index);
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'MENU': return <Home size={20} />;
      case 'Browser':
      case 'Formulario': return <Screen size={20} />;
      case 'WebService': return <Api size={20} />;
      case 'ADOConsulta':
      case 'ADOOperacao': return <DataBase size={20} />;
      case 'Mainframe':
      case 'MainframeGRBE':
      case 'MainframeXML': return <Terminal size={20} />;
      default: return <Application size={20} />;
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'MENU': return { bg: '#f4f4f4', border: '#8d8d8d', text: '#525252' };
      case 'Browser':
      case 'Formulario': return { bg: '#d0e2ff', border: '#0f62fe', text: '#0043ce' };
      case 'WebService': return { bg: '#a7f0ba', border: '#24a148', text: '#0e6027' };
      case 'ADOConsulta':
      case 'ADOOperacao': return { bg: '#bae6ff', border: '#0072c3', text: '#00539a' };
      case 'Mainframe':
      case 'MainframeGRBE':
      case 'MainframeXML': return { bg: '#ffb3b8', border: '#da1e28', text: '#a2191f' };
      default: return { bg: '#f4f4f4', border: '#8d8d8d', text: '#525252' };
    }
  };

  // Render wireframe based on type
  const renderWireframe = (screen) => {
    const colors = getTypeColor(screen.type);

    switch (screen.type) {
      case 'MENU':
        return <MenuWireframe screen={screen} colors={colors} onNavigate={goToPath} />;
      case 'Browser':
      case 'Formulario':
        return <BrowserWireframe screen={screen} colors={colors} onNavigate={goToPath} />;
      case 'WebService':
        return <WebServiceWireframe screen={screen} colors={colors} />;
      case 'ADOConsulta':
      case 'ADOOperacao':
        return <DatabaseWireframe screen={screen} colors={colors} />;
      case 'Mainframe':
      case 'MainframeGRBE':
      case 'MainframeXML':
        return <MainframeWireframe screen={screen} colors={colors} />;
      default:
        return <GenericWireframe screen={screen} colors={colors} onNavigate={goToPath} />;
    }
  };

  if (navigationSequence.length === 0) {
    return (
      <div className={styles.viewer}>
        <div className={styles.empty}>
          <Information size={48} />
          <p>Nenhuma tela para visualizar</p>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.viewer}>
      {/* Header */}
      <div className={styles.header}>
        <div className={styles.headerLeft}>
          <h3>Wireframes de Navegação</h3>
          <span className={styles.counter}>
            Tela {currentIndex + 1} de {navigationSequence.length}
          </span>
        </div>
        <div className={styles.headerControls}>
          <div className={styles.viewToggle}>
            <IconButton
              kind={viewMode === 'sequence' ? 'primary' : 'ghost'}
              size="sm"
              label="Sequencial"
              onClick={() => setViewMode('sequence')}
            >
              <Play size={16} />
            </IconButton>
            <IconButton
              kind={viewMode === 'grid' ? 'primary' : 'ghost'}
              size="sm"
              label="Grade"
              onClick={() => setViewMode('grid')}
            >
              <GridIcon size={16} />
            </IconButton>
          </div>
          <Toggle
            id="show-details"
            size="sm"
            labelA="Detalhes"
            labelB="Detalhes"
            toggled={showDetails}
            onToggle={() => setShowDetails(!showDetails)}
          />
        </div>
      </div>

      {viewMode === 'sequence' ? (
        <div className={styles.sequenceView}>
          {/* Navigation Bar */}
          <div className={styles.navBar}>
            <IconButton
              kind="ghost"
              size="lg"
              label="Anterior"
              disabled={!canGoBack}
              onClick={() => goToScreen(currentIndex - 1)}
            >
              <ChevronLeft size={24} />
            </IconButton>

            <div className={styles.breadcrumb}>
              {navigationSequence.slice(Math.max(0, currentIndex - 2), currentIndex + 3).map((screen, idx) => {
                const actualIndex = Math.max(0, currentIndex - 2) + idx;
                const isActive = actualIndex === currentIndex;
                return (
                  <button
                    key={screen.id}
                    className={`${styles.breadcrumbItem} ${isActive ? styles.active : ''}`}
                    onClick={() => goToScreen(actualIndex)}
                  >
                    {getTypeIcon(screen.type)}
                    <span>{screen.name?.substring(0, 15) || 'Tela'}</span>
                  </button>
                );
              })}
            </div>

            <IconButton
              kind="ghost"
              size="lg"
              label="Próximo"
              disabled={!canGoForward}
              onClick={() => goToScreen(currentIndex + 1)}
            >
              <ChevronRight size={24} />
            </IconButton>
          </div>

          {/* Main Content */}
          <div className={styles.mainContent}>
            {/* Wireframe Area */}
            <div className={styles.wireframeArea}>
              <div className={styles.screenHeader} style={{ borderColor: getTypeColor(currentScreen.type).border }}>
                {getTypeIcon(currentScreen.type)}
                <span className={styles.screenTitle}>{currentScreen.name}</span>
                <Tag type={
                  currentScreen.type === 'Browser' ? 'blue' :
                  currentScreen.type === 'WebService' ? 'green' :
                  currentScreen.type?.includes('Mainframe') ? 'red' :
                  currentScreen.type?.includes('ADO') ? 'teal' : 'gray'
                } size="sm">{currentScreen.type}</Tag>
              </div>

              <div className={styles.wireframeContent}>
                {renderWireframe(currentScreen)}
              </div>

              {/* Navigation Options */}
              {currentScreen.navigatesTo?.length > 0 && (
                <div className={styles.navigationOptions}>
                  <span className={styles.navLabel}>Navega para:</span>
                  <div className={styles.navButtons}>
                    {currentScreen.navigatesTo.map((target, idx) => {
                      const targetScreen = navigationSequence.find(s => s.path === target);
                      return (
                        <Button
                          key={idx}
                          kind="tertiary"
                          size="sm"
                          renderIcon={() => <ArrowRight size={16} />}
                          onClick={() => goToPath(target)}
                        >
                          {targetScreen?.name || target.split('\\').pop()}
                        </Button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Details Panel */}
            {showDetails && (
              <div className={styles.detailsPanel}>
                <h4><Information size={16} /> Detalhes da Interação</h4>

                <div className={styles.detailSection}>
                  <label>Caminho</label>
                  <code>{currentScreen.path}</code>
                </div>

                {currentScreen.xmlFile && (
                  <div className={styles.detailSection}>
                    <label>Arquivo XML</label>
                    <code>{currentScreen.xmlFile.split('/').pop()}</code>
                  </div>
                )}

                {currentScreen.webService && (
                  <>
                    <div className={styles.detailSection}>
                      <label>WebService URL</label>
                      <code>{currentScreen.webService.url}</code>
                    </div>
                    {currentScreen.webService.method && (
                      <div className={styles.detailSection}>
                        <label>Método</label>
                        <Tag type="purple" size="sm">{currentScreen.webService.method}</Tag>
                      </div>
                    )}
                  </>
                )}

                {currentScreen.mainframe && (
                  <>
                    {currentScreen.mainframe.trancode && (
                      <div className={styles.detailSection}>
                        <label>Trancode</label>
                        <code>{currentScreen.mainframe.trancode.trim()}</code>
                      </div>
                    )}
                    {currentScreen.mainframe.program && (
                      <div className={styles.detailSection}>
                        <label>Programa</label>
                        <code>{currentScreen.mainframe.program}</code>
                      </div>
                    )}
                  </>
                )}

                {currentScreen.interaction?.fields?.length > 0 && (
                  <div className={styles.detailSection}>
                    <label>Campos ({currentScreen.interaction.fields.length})</label>
                    <div className={styles.fieldsList}>
                      {currentScreen.interaction.fields.slice(0, 10).map((field, idx) => (
                        <div key={idx} className={styles.fieldItem}>
                          <span className={styles.fieldName}>{field.name || field.id}</span>
                          {field.type && <Tag size="sm" type="gray">{field.type}</Tag>}
                        </div>
                      ))}
                      {currentScreen.interaction.fields.length > 10 && (
                        <span className={styles.moreFields}>
                          +{currentScreen.interaction.fields.length - 10} campos
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {currentScreen.navigations?.length > 0 && (
                  <div className={styles.detailSection}>
                    <label>Navegações ({currentScreen.navigations.length})</label>
                    <div className={styles.navList}>
                      {currentScreen.navigations.map((nav, idx) => (
                        <div key={idx} className={styles.navItem}>
                          <span className={styles.navAction}>{nav.action || 'navigate'}</span>
                          <ArrowRight size={12} />
                          <span className={styles.navTarget}>{nav.target?.split('\\').pop() || 'final'}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {currentScreen.menuItem && (
                  <>
                    <div className={styles.detailSection}>
                      <label>ID MBKL</label>
                      <code>{currentScreen.menuItem.idMBkl}</code>
                    </div>
                    {currentScreen.menuItem.moduloEmpPlus && (
                      <div className={styles.detailSection}>
                        <label>Módulo</label>
                        <Tag type="purple" size="sm">{currentScreen.menuItem.moduloEmpPlus}</Tag>
                      </div>
                    )}
                    {currentScreen.menuItem.trn && (
                      <div className={styles.detailSection}>
                        <label>TRN</label>
                        <code className={styles.trnCode}>{currentScreen.menuItem.trn.full}</code>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Grid View */
        <div className={styles.gridView}>
          {navigationSequence.map((screen, idx) => (
            <div
              key={screen.id}
              className={`${styles.gridCard} ${idx === currentIndex ? styles.active : ''}`}
              onClick={() => {
                setCurrentIndex(idx);
                setViewMode('sequence');
              }}
            >
              <div className={styles.gridCardHeader} style={{ borderColor: getTypeColor(screen.type).border }}>
                {getTypeIcon(screen.type)}
                <span>{idx + 1}</span>
              </div>
              <div className={styles.gridCardBody}>
                <h5>{screen.name}</h5>
                <Tag size="sm" type={
                  screen.type === 'Browser' ? 'blue' :
                  screen.type === 'WebService' ? 'green' :
                  screen.type?.includes('Mainframe') ? 'red' :
                  screen.type?.includes('ADO') ? 'teal' : 'gray'
                }>{screen.type}</Tag>
              </div>
              {screen.navigatesTo?.length > 0 && (
                <div className={styles.gridCardFooter}>
                  <ArrowRight size={12} /> {screen.navigatesTo.length} saída(s)
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Screen Index */}
      <div className={styles.screenIndex}>
        {navigationSequence.map((screen, idx) => (
          <button
            key={screen.id}
            className={`${styles.indexDot} ${idx === currentIndex ? styles.active : ''}`}
            style={{ backgroundColor: idx === currentIndex ? getTypeColor(screen.type).border : undefined }}
            onClick={() => goToScreen(idx)}
            title={screen.name}
          />
        ))}
      </div>
    </div>
  );
};

// Wireframe Components

const MenuWireframe = ({ screen, colors, onNavigate }) => (
  <div className={styles.wireframe} style={{ backgroundColor: colors.bg }}>
    <div className={styles.menuWireframe}>
      <div className={styles.menuHeader}>
        <div className={styles.menuLogo}>BANCO</div>
        <div className={styles.menuTitle}>{screen.name}</div>
      </div>
      <div className={styles.menuContent}>
        <div className={styles.menuPath}>
          {screen.menuItem?.menuPath?.join(' > ')}
        </div>
        <div className={styles.menuInfo}>
          <div className={styles.menuInfoItem}>
            <span>ID:</span> {screen.menuItem?.idMBkl}
          </div>
          <div className={styles.menuInfoItem}>
            <span>Módulo:</span> {screen.menuItem?.moduloEmpPlus || '-'}
          </div>
        </div>
        {screen.navigatesTo?.length > 0 && (
          <div className={styles.menuOptions}>
            <h4>Opções de Navegação</h4>
            {screen.navigatesTo.map((target, idx) => (
              <button
                key={idx}
                className={styles.menuOption}
                onClick={() => onNavigate(target)}
              >
                <ArrowRight size={16} />
                {target.split('\\').pop()}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  </div>
);

const BrowserWireframe = ({ screen, colors, onNavigate }) => {
  const fields = screen.interaction?.fields || [];
  const mockFields = fields.length > 0 ? fields : [
    { name: 'Campo 1', type: 'text' },
    { name: 'Campo 2', type: 'text' },
    { name: 'Campo 3', type: 'select' },
    { name: 'Campo 4', type: 'date' }
  ];

  return (
    <div className={styles.wireframe} style={{ backgroundColor: colors.bg }}>
      <div className={styles.browserWireframe}>
        <div className={styles.browserToolbar}>
          <div className={styles.urlBar}>
            <span>https://app.banco.com.br/</span>
            {screen.path.replace(/\\/g, '/')}
          </div>
        </div>
        <div className={styles.browserContent}>
          <h3 className={styles.formTitle}>{screen.name}</h3>
          <div className={styles.formFields}>
            {mockFields.slice(0, 6).map((field, idx) => (
              <div key={idx} className={styles.formField}>
                <label>{field.name || field.id || `Campo ${idx + 1}`}</label>
                {field.type === 'select' ? (
                  <div className={styles.selectMock}>
                    <span>Selecione...</span>
                    <ChevronRight size={12} style={{ transform: 'rotate(90deg)' }} />
                  </div>
                ) : field.type === 'date' ? (
                  <div className={styles.inputMock}>
                    <span>DD/MM/AAAA</span>
                  </div>
                ) : (
                  <div className={styles.inputMock} />
                )}
              </div>
            ))}
          </div>
          <div className={styles.formActions}>
            {screen.navigatesTo?.map((target, idx) => (
              <button
                key={idx}
                className={styles.actionButton}
                onClick={() => onNavigate(target)}
              >
                {target.split('\\').pop()}
              </button>
            ))}
            {screen.navigatesTo?.length === 0 && (
              <button className={styles.actionButton}>Confirmar</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const WebServiceWireframe = ({ screen, colors }) => (
  <div className={styles.wireframe} style={{ backgroundColor: colors.bg }}>
    <div className={styles.wsWireframe}>
      <div className={styles.wsHeader}>
        <Tag type="green" size="sm">{screen.webService?.method || 'POST'}</Tag>
        <code className={styles.wsUrl}>{screen.webService?.url || '/api/service'}</code>
      </div>
      <div className={styles.wsBody}>
        <div className={styles.wsSection}>
          <h4><Code size={14} /> Request</h4>
          <pre className={styles.wsCode}>
{`{
  "operation": "${screen.name}",
  "module": "${screen.path.split('\\')[0]}",
  "params": {
    // Parâmetros da requisição
  }
}`}
          </pre>
        </div>
        <div className={styles.wsSection}>
          <h4><Code size={14} /> Response</h4>
          <pre className={styles.wsCode}>
{`{
  "status": "success",
  "data": {
    // Dados de resposta
  }
}`}
          </pre>
        </div>
      </div>
    </div>
  </div>
);

const DatabaseWireframe = ({ screen, colors }) => {
  const isConsulta = screen.type === 'ADOConsulta';

  return (
    <div className={styles.wireframe} style={{ backgroundColor: colors.bg }}>
      <div className={styles.dbWireframe}>
        <div className={styles.dbHeader}>
          <DataBase size={20} />
          <span>{isConsulta ? 'Consulta' : 'Operação'} de Banco de Dados</span>
        </div>
        <div className={styles.dbContent}>
          <div className={styles.dbQuery}>
            <h4>Query/Operação</h4>
            <pre>
{isConsulta ?
`SELECT * FROM tabela
WHERE condição = valor
ORDER BY campo` :
`INSERT INTO tabela (campo1, campo2)
VALUES (valor1, valor2)`}
            </pre>
          </div>
          <div className={styles.dbResult}>
            <h4>{isConsulta ? 'Resultado' : 'Retorno'}</h4>
            <table className={styles.dbTable}>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Campo 1</th>
                  <th>Campo 2</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>001</td>
                  <td>Valor A</td>
                  <td>Valor B</td>
                  <td>Ativo</td>
                </tr>
                <tr>
                  <td>002</td>
                  <td>Valor C</td>
                  <td>Valor D</td>
                  <td>Ativo</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

const MainframeWireframe = ({ screen, colors }) => (
  <div className={styles.wireframe} style={{ backgroundColor: '#1a1a1a' }}>
    <div className={styles.mfWireframe}>
      <div className={styles.mfScreen}>
        <div className={styles.mfHeader}>
          <span className={styles.mfTrancode}>
            {screen.mainframe?.trancode?.trim() || 'XXXX'}
          </span>
          <span className={styles.mfProgram}>
            {screen.mainframe?.program || screen.name}
          </span>
        </div>
        <div className={styles.mfContent}>
          <div className={styles.mfLine}>
            <span className={styles.mfLabel}>TRANSACAO:</span>
            <span className={styles.mfValue}>{screen.name}</span>
          </div>
          <div className={styles.mfLine}>
            <span className={styles.mfLabel}>MODULO:</span>
            <span className={styles.mfValue}>{screen.path.split('\\')[0]}</span>
          </div>
          <div className={styles.mfLine}>
            <span className={styles.mfLabel}>SUB-PROG:</span>
            <span className={styles.mfValue}>{screen.path.split('\\')[1]}</span>
          </div>
          <div className={styles.mfSeparator}>{'─'.repeat(60)}</div>
          <div className={styles.mfLine}>
            <span className={styles.mfLabel}>CAMPO 1.:</span>
            <span className={styles.mfInput}>________________</span>
          </div>
          <div className={styles.mfLine}>
            <span className={styles.mfLabel}>CAMPO 2.:</span>
            <span className={styles.mfInput}>________________</span>
          </div>
          <div className={styles.mfLine}>
            <span className={styles.mfLabel}>CAMPO 3.:</span>
            <span className={styles.mfInput}>________________</span>
          </div>
        </div>
        <div className={styles.mfFooter}>
          <span>PF1=AJUDA  PF3=SAIR  PF12=CANCELAR  ENTER=CONFIRMAR</span>
        </div>
      </div>
    </div>
  </div>
);

const GenericWireframe = ({ screen, colors, onNavigate }) => (
  <div className={styles.wireframe} style={{ backgroundColor: colors.bg }}>
    <div className={styles.genericWireframe}>
      <div className={styles.genericContent}>
        <Application size={48} />
        <h3>{screen.name}</h3>
        <p className={styles.genericPath}>{screen.path}</p>
        {screen.navigatesTo?.length > 0 && (
          <div className={styles.genericNav}>
            {screen.navigatesTo.map((target, idx) => (
              <Button
                key={idx}
                kind="tertiary"
                size="sm"
                onClick={() => onNavigate(target)}
              >
                {target.split('\\').pop()}
              </Button>
            ))}
          </div>
        )}
      </div>
    </div>
  </div>
);

export default WireframeViewer;
