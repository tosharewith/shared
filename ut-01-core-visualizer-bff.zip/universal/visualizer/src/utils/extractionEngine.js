/**
 * Extraction Engine - Context-Aware Transaction Extraction
 * =========================================================
 *
 * Browser-based port of Python context_aware_extractor.py
 * Generates JSON matching context-aware-transaction-schema.json
 *
 * This is a complete rewrite to exactly match Python behavior.
 */

import { detectBackendType, getBackendTypeName, formatBackendType } from './backendTranslations';

// =============================================================================
// FlowContext - Exact match of Python FlowContext dataclass
// =============================================================================

class FlowContext {
  constructor() {
    this.sessionVars = {};           // Dict[str, str]
    this.protectedVars = new Set();  // Set[str] - Vars set from TRN, don't overwrite
    this.trnParams = [];             // List[str] - Original TRN params
  }

  /**
   * Check if a condition matches this context.
   * Returns: true (matches), false (doesn't match), null (can't determine)
   *
   * Exact port of Python matches_condition()
   */
  matchesCondition(left, operator, right) {
    // Resolve variable references
    const leftVal = this._resolveValue(left);
    const rightVal = this._resolveValue(right);

    if (leftVal === null || rightVal === null) {
      return null; // Can't determine
    }

    const op = (operator || '').toLowerCase();

    if (op === 'igual' || op === 'equal' || op === '=') {
      return leftVal === rightVal;
    } else if (op === 'diferente' || op === 'notequal' || op === '!=') {
      return leftVal !== rightVal;
    } else if (op === 'sempre' || op === 'always') {
      return true;
    }

    return null; // Unknown operator
  }

  /**
   * Resolve a value that may be a variable reference ($Variable)
   * Exact port of Python _resolve_value()
   */
  _resolveValue(value) {
    if (!value) {
      return null;
    }

    // Handle $Variable references
    if (typeof value === 'string' && value.startsWith('$')) {
      const varName = value.substring(1);
      if (varName in this.sessionVars) {
        return this.sessionVars[varName];
      }
      return null; // Unknown variable
    }

    return value; // Literal value
  }

  /**
   * Update context from SalvaAtributo operations.
   * CRITICAL: Does NOT update protected vars (set from TRN params).
   *
   * Exact port of Python update_from_operation()
   */
  updateFromOperation(operation) {
    if (operation.function !== 'SalvaAtributo') {
      return;
    }

    const params = operation.parameters || [];
    if (params.length < 2) {
      return;
    }

    // Find variable name and value from parameters
    let varName = null;
    let varValue = null;

    for (const p of params) {
      if (p.type === 'constant') {
        if (varName === null) {
          varName = p.value || '';
        } else {
          varValue = p.value || '';
          break;
        }
      }
    }

    // IMPORTANT: Don't update protected vars (set from TRN params)
    // from XML constants - they should be immutable
    if (varName && varValue !== null && !this.protectedVars.has(varName)) {
      this.sessionVars[varName] = varValue;
    }
  }

  /**
   * Set a variable from TRN param - marks it as protected.
   * Exact port of Python set_trn_param()
   */
  setTrnParam(varName, value) {
    this.sessionVars[varName] = value;
    this.protectedVars.add(varName);
  }
}

// =============================================================================
// TRN Parsing - Exact port of Python parse_trn()
// =============================================================================

export function parseTRN(trn) {
  if (!trn || typeof trn !== 'string') {
    return null;
  }

  const parts = trn.split('@');
  const pathPart = parts[0] || '';
  const params = parts.slice(1);

  const pathComponents = pathPart.replace(/\//g, '\\').split('\\');

  const module = pathComponents[0] || '';
  const subProgram = pathComponents[1] || '';
  const interaction = pathComponents[2] || '';

  const destination = params[0] || '';
  const title = params[1] || '';

  return {
    full: trn,
    module,
    subProgram,
    interaction,
    params,
    destination,
    title
  };
}

// =============================================================================
// Interaction Map - Browser equivalent of file system lookups
// =============================================================================

export function buildInteractionMap(parsedFiles) {
  const map = new Map();

  for (const file of parsedFiles) {
    if (!file.success || !file.path) continue;

    // Store by full path (backslash)
    map.set(file.path, file);

    // Store by normalized path (forward slash)
    const normalizedPath = file.path.replace(/\\/g, '/');
    if (!map.has(normalizedPath)) {
      map.set(normalizedPath, file);
    }

    // Store by interaction name for fallback
    if (!map.has(file.name)) {
      map.set(file.name, file);
    }

    // Store by module/subProgram/name variations
    if (file.module && file.subProgram && file.name) {
      const variations = [
        `${file.module}\\${file.subProgram}\\${file.name}`,
        `${file.module}/${file.subProgram}/${file.name}`
      ];
      for (const v of variations) {
        if (!map.has(v)) map.set(v, file);
      }
    }

    if (file.subProgram && file.name) {
      const variations = [
        `${file.subProgram}\\${file.name}`,
        `${file.subProgram}/${file.name}`
      ];
      for (const v of variations) {
        if (!map.has(v)) map.set(v, file);
      }
    }

    // Also store lowercase versions for case-insensitive lookups
    const lowerPath = file.path.toLowerCase();
    if (!map.has(lowerPath)) {
      map.set(lowerPath, file);
    }
    if (file.name && !map.has(file.name.toLowerCase())) {
      map.set(file.name.toLowerCase(), file);
    }
  }

  return map;
}

/**
 * Helper to find in map with case-insensitive fallback
 */
function findInMap(map, key) {
  if (map.has(key)) return map.get(key);
  // Try lowercase
  const lowerKey = key.toLowerCase();
  if (map.has(lowerKey)) return map.get(lowerKey);
  return null;
}

/**
 * Find XML files for an interaction.
 * Returns: { base: file, finalization: file }
 *
 * NO FALLBACK: Only looks for exact subProgram specified.
 * Missing files are tracked and reported to the user.
 * Case-insensitive matching is used.
 */
function findXmlFiles(module, subProgram, interaction, interactionMap) {
  const files = {};

  // Look for base file - exact match only, no fallback variations
  const basePaths = [
    `${module}\\${subProgram}\\${interaction}`,
    `${module}/${subProgram}/${interaction}`,
    `${subProgram}\\${interaction}`,
    `${subProgram}/${interaction}`,
    interaction
  ];

  for (const path of basePaths) {
    if (!files.base) {
      const found = findInMap(interactionMap, path);
      if (found) {
        files.base = found;
        break;
      }
    }
  }

  // Look for finalization file - exact match only
  const finName = `${interaction}_OperacaoFinalizacao`;
  const finPaths = [
    `${module}\\${subProgram}\\${finName}`,
    `${module}/${subProgram}/${finName}`,
    `${subProgram}\\${finName}`,
    `${subProgram}/${finName}`,
    finName
  ];

  for (const path of finPaths) {
    if (!files.finalization) {
      const found = findInMap(interactionMap, path);
      if (found) {
        files.finalization = found;
        break;
      }
    }
  }

  return files;
}

// =============================================================================
// TRN Param Discovery - Exact port of Python _discover_trn_param_mappings()
// =============================================================================

function discoverTrnParamMappings(doc) {
  const mappings = {};

  // Find SalvaAtributo operations with OrigemCampo from Browser
  doc.querySelectorAll('Operacao[funcaoSemRetorno="SalvaAtributo"]').forEach(operacao => {
    const children = Array.from(operacao.children);
    if (children.length >= 2) {
      const varNameEl = children[0];
      const valueSourceEl = children[1];

      if (varNameEl.tagName === 'OrigemConstante' && valueSourceEl.tagName === 'OrigemCampo') {
        const varName = varNameEl.getAttribute('valor') || '';
        const tipoInteracao = valueSourceEl.getAttribute('tipoInteracao') || '';
        const posicao = valueSourceEl.getAttribute('posicao') || '';

        // Only capture variables set from Browser (TRN params)
        if (tipoInteracao === 'Browser' && /^\d+$/.test(posicao) && varName) {
          mappings[parseInt(posicao, 10)] = varName;
        }
      }
    }
  });

  return mappings;
}

// =============================================================================
// Extract Operations - Exact port of Python _extract_operations()
// =============================================================================

function extractOperations(element) {
  const operations = [];

  element.querySelectorAll('Operacao').forEach(operacao => {
    const func = operacao.getAttribute('funcaoSemRetorno') || '';
    if (func) {
      const params = [];

      // OrigemConstante - type: constant
      operacao.querySelectorAll('OrigemConstante').forEach(c => {
        params.push({
          type: 'constant',
          value: c.getAttribute('valor') || ''
        });
      });

      // OrigemCampo - type: field
      operacao.querySelectorAll('OrigemCampo').forEach(c => {
        params.push({
          type: 'field',
          name: c.getAttribute('nomeLogico') || ''
        });
      });

      // OrigemXml - type: xml
      operacao.querySelectorAll('OrigemXml').forEach(c => {
        params.push({
          type: 'xml',
          tag: c.getAttribute('nomeTag') || ''
        });
      });

      operations.push({ function: func, parameters: params });
    }
  });

  return operations;
}

// =============================================================================
// Extract Navigations with Context - Exact port of Python _extract_navigations_with_context()
// =============================================================================

function extractNavigationsWithContext(element, context) {
  const navigations = [];

  // TrocaSucessor (conditional)
  element.querySelectorAll('TrocaSucessor').forEach(troca => {
    const target = troca.getAttribute('proximaInteracao') || '';
    const nav = {
      type: 'conditional',
      target,
      condition: null,
      matchesContext: null
    };

    const funcLogica = troca.querySelector('OrigemFuncaoLogica');
    if (funcLogica) {
      const operator = funcLogica.getAttribute('funcaoLogica') || '';

      // Extract comparison values
      const constants = funcLogica.querySelectorAll('OrigemConstante');
      const left = constants[0]?.getAttribute('valor') || '';
      const right = constants[1]?.getAttribute('valor') || '';

      nav.condition = {
        function: operator,
        left,
        right
      };

      // Evaluate against context
      const matches = context.matchesCondition(left, operator, right);
      nav.matchesContext = matches;
    }

    navigations.push(nav);
  });

  // ValorizacaoFormulario (form submission)
  element.querySelectorAll('ValorizacaoFormulario').forEach(val => {
    const target = val.getAttribute('proximaInteracao') || '';
    if (target) {
      navigations.push({
        type: 'formulario',
        target,
        condition: null,
        matchesContext: true,
        formDetails: {
          nomeFisico: val.getAttribute('nomeFisico') || '',
          camposIniciais: (val.getAttribute('camposIniciais') || '').split('+').filter(Boolean),
          formularioVoltar: val.getAttribute('formularioVoltar') || ''
        }
      });
    }
  });

  // ValorizacaoEnvioWS (WebService call)
  element.querySelectorAll('ValorizacaoEnvioWS').forEach(val => {
    const target = val.getAttribute('proximaInteracao') || '';
    if (target) {
      navigations.push({
        type: 'enviows',
        target,
        condition: null,
        matchesContext: true,
        wsDetails: {
          nomeFisico: val.getAttribute('nomeFisico') || ''
        }
      });
    }
  });

  // ValorizacaoEnvio (generic send)
  element.querySelectorAll('ValorizacaoEnvio').forEach(val => {
    const target = val.getAttribute('proximaInteracao') || '';
    if (target) {
      navigations.push({
        type: 'envio',
        target,
        condition: null,
        matchesContext: true
      });
    }
  });

  // ValorizacaoEnvioMainframe
  element.querySelectorAll('ValorizacaoEnvioMainframe').forEach(val => {
    const target = val.getAttribute('proximaInteracao') || '';
    if (target) {
      navigations.push({
        type: 'enviomainframe',
        target,
        condition: null,
        matchesContext: true
      });
    }
  });

  return navigations;
}

// =============================================================================
// Filter Navigations by Context - Exact port of Python _filter_navigations_by_context()
// =============================================================================

function filterNavigationsByContext(navigations) {
  const filtered = [];
  const seenTargets = new Set();

  // First pass: collect all matching conditional navigations
  const matchedConditionals = navigations.filter(
    n => n.type === 'conditional' && n.matchesContext === true
  );

  // If we have matched conditionals, they override non-conditional navigations
  const hasOverride = matchedConditionals.length > 0;

  for (const nav of navigations) {
    const target = nav.target || '';
    const navType = nav.type || '';
    const matches = nav.matchesContext;

    // Skip navigations that explicitly don't match
    if (matches === false) {
      continue;
    }

    // For conditional navigations
    if (navType === 'conditional') {
      if (matches === true) {
        if (!seenTargets.has(target)) {
          seenTargets.add(target);
          // Clean up the navigation - only keep relevant info
          const cleanNav = {
            type: navType,
            target,
            matchesContext: true
          };
          if (nav.condition) {
            cleanNav.condition = nav.condition;
          }
          filtered.push(cleanNav);
        }
      } else if (matches === null) {
        // Unknown at extraction time - include decision logic for runtime
        if (!seenTargets.has(target)) {
          seenTargets.add(target);
          filtered.push({
            type: navType,
            target,
            matchesContext: null,
            condition: nav.condition,
            runtimeDecision: true
          });
        }
      }
    } else {
      // For non-conditional navigations (formulario, enviows, etc.)
      // If we have a conditional override, skip forward navigations
      if (hasOverride) {
        if (['formulario', 'enviows', 'envio', 'enviomainframe'].includes(navType)) {
          continue;
        }
      }

      if (target && !seenTargets.has(target)) {
        seenTargets.add(target);
        filtered.push(nav);
      }
    }
  }

  return filtered;
}

// =============================================================================
// Extract Fields - Exact port of Python _extract_fields()
// =============================================================================

function extractFields(element) {
  const fields = {
    inputs: [],
    bindings: [],
    hidden: [],
    lists: [],
    wsInputs: []
  };

  const seenInputs = new Set();
  const seenBindings = new Set();
  const seenWsInputs = new Set();

  // 1. OrigemXml - Input field references
  element.querySelectorAll('OrigemXml').forEach(origem => {
    const fieldName = origem.getAttribute('nomeCampo') || '';
    if (fieldName && !seenInputs.has(fieldName)) {
      seenInputs.add(fieldName);
      fields.inputs.push({
        name: fieldName,
        program: origem.getAttribute('nomePrograma') || '',
        subProgram: origem.getAttribute('nomeSubPrograma') || '',
        interaction: origem.getAttribute('nomeInteracao') || '',
        source: 'OrigemXml'
      });
    }
  });

  // 1b. OrigemCampo - Fields from previous screen (WS/MF inputs)
  element.querySelectorAll('OrigemCampo').forEach(origem => {
    const fieldName = origem.getAttribute('nomeLogico') || '';
    if (fieldName && !seenWsInputs.has(fieldName)) {
      seenWsInputs.add(fieldName);
      fields.wsInputs.push({
        name: fieldName,
        type: origem.getAttribute('tipoInteracao') || '',
        position: origem.getAttribute('posicao') || '',
        size: origem.getAttribute('tamanho') || '',
        source: 'OrigemCampo'
      });
    }
  });

  // 2. OrigemListaXml - List field bindings
  element.querySelectorAll('OrigemListaXml').forEach(origem => {
    const fieldName = origem.getAttribute('nomeCampo') || '';
    if (fieldName && !seenBindings.has(fieldName)) {
      seenBindings.add(fieldName);
      fields.lists.push({
        name: fieldName,
        size: origem.getAttribute('tamanhoDestino') || '',
        source: 'OrigemListaXml'
      });
    }
  });

  // 2b. ValorizacaoLista + OrigemTagListaWS
  element.querySelectorAll('ValorizacaoLista').forEach(valLista => {
    const listaName = valLista.getAttribute('nomeLista') || '';
    valLista.querySelectorAll('OrigemTagListaWS').forEach(tagWs => {
      const fieldName = tagWs.getAttribute('TextWS') || '';
      if (fieldName && !seenBindings.has(fieldName)) {
        seenBindings.add(fieldName);
        fields.lists.push({
          name: fieldName,
          size: tagWs.getAttribute('tamanhoDestino') || '',
          listSource: listaName,
          source: 'OrigemTagListaWS'
        });
      }
    });
  });

  // 3. OrigemCampoWS - WebService response field mappings
  element.querySelectorAll('OrigemCampoWS').forEach(origem => {
    const tagXML = origem.getAttribute('TagXML') || '';
    const textWS = origem.getAttribute('TextWS') || '';
    const bindingKey = `${tagXML}:${textWS}`;
    if (!seenBindings.has(bindingKey) && (tagXML || textWS)) {
      seenBindings.add(bindingKey);
      fields.bindings.push({
        tagXML,
        textWS,
        size: origem.getAttribute('tamanhoDestino') || '',
        source: 'WebService'
      });
    }
  });

  // 4. OrigemCampoMF - Mainframe field mappings
  element.querySelectorAll('OrigemCampoMF').forEach(origem => {
    const pos = origem.getAttribute('posicao') || '';
    const size = origem.getAttribute('tamanho') || '';
    const bindingKey = `MF:${pos}:${size}`;
    if (!seenBindings.has(bindingKey)) {
      seenBindings.add(bindingKey);
      fields.bindings.push({
        position: pos,
        size,
        source: 'Mainframe'
      });
    }
  });

  // 5. ValorizacaoCampo
  element.querySelectorAll('ValorizacaoCampo').forEach(campo => {
    const name = campo.getAttribute('nomeLogico') || '';
    if (name && !seenInputs.has(name)) {
      seenInputs.add(name);
      fields.inputs.push({
        name,
        size: campo.getAttribute('tamanho') || '',
        source: 'ValorizacaoCampo'
      });
    }
  });

  // Clean up empty arrays
  const result = {};
  for (const [key, value] of Object.entries(fields)) {
    if (value.length > 0) {
      result[key] = value;
    }
  }

  return result;
}

// =============================================================================
// Extract Forms - Exact port of Python _extract_forms()
// =============================================================================

function extractForms(element) {
  const forms = [];
  const seenForms = new Set();

  element.querySelectorAll('ValorizacaoFormulario').forEach(form => {
    const nomeFisico = form.getAttribute('nomeFisico') || '';
    const proxInteracao = form.getAttribute('proximaInteracao') || '';

    const formKey = `${nomeFisico}:${proxInteracao}`;
    if (seenForms.has(formKey)) return;
    seenForms.add(formKey);

    const formData = {
      name: nomeFisico,
      target: proxInteracao
    };

    const camposIniciais = form.getAttribute('camposIniciais') || '';
    if (camposIniciais) {
      formData.initialFields = camposIniciais.split('+');
    }

    const formVoltar = form.getAttribute('formularioVoltar') || '';
    if (formVoltar) {
      formData.backForm = formVoltar;
    }

    const formFields = [];
    form.querySelectorAll('OrigemXml').forEach(origem => {
      const fieldName = origem.getAttribute('nomeCampo') || '';
      if (fieldName) {
        formFields.push({
          name: fieldName,
          program: origem.getAttribute('nomePrograma') || '',
          subProgram: origem.getAttribute('nomeSubPrograma') || ''
        });
      }
    });
    if (formFields.length > 0) {
      formData.fieldMappings = formFields;
    }

    forms.push(formData);
  });

  return forms;
}

// =============================================================================
// Extract Templates - Simplified port
// =============================================================================

function extractTemplates(element) {
  const templates = {};

  // Main template
  const mainTemplate = element.querySelector('Template');
  if (mainTemplate?.textContent) {
    templates.main = mainTemplate.textContent.trim();
  }

  // Header template
  const headerTemplate = element.querySelector('TemplateCabecalho');
  if (headerTemplate?.textContent) {
    templates.header = headerTemplate.textContent.trim();
  }

  // Footer template
  const footerTemplate = element.querySelector('TemplateRodape');
  if (footerTemplate?.textContent) {
    templates.footer = footerTemplate.textContent.trim();
  }

  return Object.keys(templates).length > 0 ? templates : null;
}

// =============================================================================
// Extract Configuration - Port of Python _extract_configuration()
// =============================================================================

function extractConfiguration(element) {
  const config = {};

  // Main element attributes - keyed by element type (matches Python)
  for (const tag of ['Browser', 'Mainframe', 'MainframeGRBE', 'WebService', 'ADOConsulta', 'ADOOperacao']) {
    const mainEl = element.querySelector(tag);
    if (mainEl) {
      const attrs = {};
      for (const attr of mainEl.attributes) {
        attrs[attr.name] = attr.value;
      }
      if (Object.keys(attrs).length > 0) {
        // Use lowercase key to match Python output
        config[tag.toLowerCase()] = attrs;
      }
      break;
    }
  }

  // Configuracao element
  const configuracao = element.querySelector('Configuracao');
  if (configuracao) {
    const attrs = {};
    for (const attr of configuracao.attributes) {
      attrs[attr.name] = attr.value;
    }
    if (Object.keys(attrs).length > 0) {
      config.configuracao = attrs;
    }
  }

  return Object.keys(config).length > 0 ? config : null;
}

// =============================================================================
// Parse Interaction XML - Main parser function
// =============================================================================

export function parseInteractionXml(content, filename, relativePath = '') {
  const parser = new DOMParser();
  const doc = parser.parseFromString(content, 'text/xml');

  // Check for parse errors
  const parseError = doc.querySelector('parsererror');
  if (parseError) {
    return { success: false, error: 'Invalid XML', filename };
  }

  const root = doc.documentElement;

  // Determine interaction type
  let interactionType = 'Unknown';
  let mainElement = null;

  for (const tag of ['Browser', 'WebService', 'ADOConsulta', 'ADOOperacao',
                     'Mainframe', 'MainframeGRBE', 'MainframeGRBEPosicional', 'MainframeXML']) {
    mainElement = doc.querySelector(tag);
    if (mainElement) {
      interactionType = tag;
      break;
    }
  }

  if (!mainElement) {
    mainElement = root;
  }

  // Extract name
  const name = mainElement?.getAttribute('nomeFisico') ||
               mainElement?.getAttribute('nomeLogico') ||
               filename.replace(/\.xml$/i, '');

  // Extract path from filename/relativePath
  const skipFolders = ['xml-tests', 'xml-test', 'xmls', 'xml', 'uploads', 'data', 'files', 'test', 'tests'];
  let pathParts = (relativePath || filename).replace(/\.xml$/i, '').split(/[\\\/]/);

  while (pathParts.length > 0 && skipFolders.includes(pathParts[0].toLowerCase())) {
    pathParts = pathParts.slice(1);
  }

  let module = '';
  let subProgram = '';
  let interactionName = pathParts[pathParts.length - 1] || name;

  if (pathParts.length >= 3) {
    module = pathParts[pathParts.length - 3];
    subProgram = pathParts[pathParts.length - 2];
  } else if (pathParts.length === 2) {
    module = pathParts[0];
    subProgram = '';
  }

  // Build path
  let path;
  if (module && subProgram) {
    path = `${module}\\${subProgram}\\${interactionName}`;
  } else if (module) {
    path = `${module}\\${interactionName}`;
  } else {
    path = interactionName;
  }

  return {
    success: true,
    filename,
    path,
    module,
    subProgram,
    name: interactionName,
    type: interactionType,
    xmlFile: relativePath || filename,
    rawDoc: doc
  };
}

// =============================================================================
// Extract Interaction with Context - Port of Python extract_interaction_with_context()
// =============================================================================

function extractInteractionWithContext(parsedFile, context, filterNavs = true) {
  const doc = parsedFile.rawDoc;
  const root = doc.documentElement;

  // Get main element
  let mainElement = null;
  for (const tag of ['Browser', 'WebService', 'ADOConsulta', 'ADOOperacao',
                     'Mainframe', 'MainframeGRBE', 'MainframeGRBEPosicional', 'MainframeXML']) {
    mainElement = doc.querySelector(tag);
    if (mainElement) break;
  }
  if (!mainElement) mainElement = root;

  // Extract name
  const name = mainElement?.getAttribute('nomeFisico') ||
               mainElement?.getAttribute('nomeLogico') ||
               parsedFile.name;

  // Extract operations
  const operations = extractOperations(mainElement);

  // Update context from operations
  for (const op of operations) {
    context.updateFromOperation(op);
  }

  // Extract navigations with context evaluation
  let navigations = extractNavigationsWithContext(mainElement, context);

  // Filter navigations based on context
  if (filterNavs) {
    navigations = filterNavigationsByContext(navigations);
  }

  // Extract other data
  const fields = extractFields(mainElement);
  const forms = extractForms(mainElement);
  const templates = extractTemplates(mainElement);
  const configuration = extractConfiguration(mainElement);

  const result = {
    xmlFile: parsedFile.xmlFile,
    type: parsedFile.type,
    name,
    operations,
    navigations,
    fields
  };

  if (forms.length > 0) result.forms = forms;
  if (templates) result.templates = templates;
  if (configuration) result.configuration = configuration;

  return result;
}

// =============================================================================
// Trace Flow with Context - Port of Python trace_flow_with_context()
// =============================================================================

function traceFlowWithContext(trn, context, interactionMap, maxDepth = 15) {
  const interactions = [];
  const flowGraph = { MENU: [`${trn.module}\\${trn.subProgram}\\${trn.interaction}`] };
  const visited = new Set();
  const missingPaths = [];
  const skippedPaths = []; // Navigations skipped due to context mismatch
  const unknownPaths = []; // Navigations with unknown context (null)

  // Discover parameter mappings from entry interaction
  const entryFiles = findXmlFiles(trn.module, trn.subProgram, trn.interaction, interactionMap);
  if (entryFiles.base && context.trnParams.length > 0) {
    const mappings = discoverTrnParamMappings(entryFiles.base.rawDoc);

    // Apply discovered mappings
    for (const [posStr, varName] of Object.entries(mappings)) {
      const position = parseInt(posStr, 10);
      if (position < context.trnParams.length) {
        context.setTrnParam(varName, context.trnParams[position]);
      }
    }

    // Fallback for undiscovered params
    for (let i = 0; i < context.trnParams.length; i++) {
      if (!(i in mappings)) {
        context.setTrnParam(`_TRN_PARAM_${i}`, context.trnParams[i]);
      }
    }
  }

  // Recursive trace function - Port of Python _trace_recursive_with_context()
  function traceRecursive(module, subProgram, interaction, depth) {
    if (depth <= 0) return;

    const pathKey = `${module}\\${subProgram}\\${interaction}`;
    if (visited.has(pathKey)) return;
    visited.add(pathKey);

    // Find XML files (base + finalization)
    const xmlFiles = findXmlFiles(module, subProgram, interaction, interactionMap);
    const baseFile = xmlFiles.base;

    if (!baseFile) {
      missingPaths.push(`${module}/${subProgram}/${interaction}`);
      return;
    }

    // Extract interaction with context
    const intData = extractInteractionWithContext(baseFile, context);
    intData.path = pathKey;
    intData.module = module;
    intData.subProgram = subProgram;

    // IMPORTANT: Check OperacaoFinalizacao FIRST for navigation overrides
    // The finalization file contains TrocaSucessor conditions that override
    // the default navigation based on context
    const finFile = xmlFiles.finalization;
    let finalizationOverrideTarget = null;

    if (finFile) {
      const finData = extractInteractionWithContext(finFile, context, false);

      // Look for TrocaSucessor that matches context
      for (const nav of finData.navigations || []) {
        if (nav.type === 'conditional' && nav.matchesContext === true) {
          finalizationOverrideTarget = nav.target || '';
          break;
        }
      }

      // If we have an override, replace base navigations with the override
      if (finalizationOverrideTarget) {
        intData.navigations = [{
          type: 'conditional',
          target: finalizationOverrideTarget,
          matchesContext: true,
          source: 'OperacaoFinalizacao'
        }];
      }
    }

    interactions.push(intData);

    // Determine which targets to follow
    const matchingTargets = [];

    if (finalizationOverrideTarget) {
      // Use the overridden target from finalization
      matchingTargets.push(finalizationOverrideTarget);
    } else {
      // Use navigations from base file
      for (const nav of intData.navigations || []) {
        const target = nav.target || '';
        const matches = nav.matchesContext;

        if (!target) continue;

        // Track skipped paths for user visibility
        if (matches === false) {
          const conditionDesc = nav.condition
            ? `${nav.condition.left} ${nav.condition.function} ${nav.condition.right}`
            : 'context mismatch';
          skippedPaths.push({
            from: pathKey,
            target,
            reason: conditionDesc
          });
          continue;
        }

        // Track unknown paths
        if (matches === null && nav.condition) {
          unknownPaths.push({
            from: pathKey,
            target,
            condition: nav.condition
          });
        }

        if (matches === true || matches === null) {
          matchingTargets.push(target);
        }
      }
    }

    // Update flow graph
    if (matchingTargets.length > 0) {
      flowGraph[pathKey] = [...new Set(matchingTargets)];
    }

    // Recursively trace matching targets
    for (const target of matchingTargets) {
      if (target.includes('\\') || target.includes('/')) {
        const parts = target.replace(/\//g, '\\').split('\\');
        if (parts.length >= 3) {
          traceRecursive(parts[0], parts[1], parts[2], depth - 1);
        }
      }
    }
  }

  // Start tracing
  traceRecursive(trn.module, trn.subProgram, trn.interaction, maxDepth);

  return {
    interactions,
    flowGraph,
    missingPaths,
    skippedPaths: skippedPaths.length > 0 ? skippedPaths : undefined,
    unknownPaths: unknownPaths.length > 0 ? unknownPaths : undefined
  };
}

// =============================================================================
// Evaluate Condition (standalone) - For compatibility
// =============================================================================

export function evaluateCondition(condition, sessionVars) {
  if (!condition) return true;

  const context = new FlowContext();
  context.sessionVars = sessionVars || {};

  const { function: func, left, right } = condition;
  return context.matchesCondition(left, func, right);
}

// =============================================================================
// Generate Context-Aware JSON
// =============================================================================

function generateContextAwareJSON(trn, interactions, context, flowGraph, pathInfo) {
  const { missingPaths = [], skippedPaths, unknownPaths } = pathInfo;

  // Build flowContext with protected vars
  const flowContextDict = {};
  for (const varName of context.protectedVars) {
    flowContextDict[varName] = context.sessionVars[varName];
  }

  return {
    $schema: '../schemas/context-aware-transaction-schema.json',
    schemaType: 'transaction-context-aware',
    metadata: {
      extractionDate: new Date().toISOString(),
      version: '4.0.0-context-aware',
      transactionId: `${trn.module}/${trn.subProgram}/${trn.interaction}`,
      contextAware: true
    },
    menuItem: {
      idMBkl: 'uploaded',
      nomeLogico: trn.title || trn.interaction,
      menuPath: [],
      trn: {
        full: trn.full,
        module: trn.module,
        subProgram: trn.subProgram,
        interaction: trn.interaction,
        params: trn.params,
        destination: trn.destination,
        title: trn.title
      },
      flowContext: flowContextDict
    },
    flowContext: {
      description: 'Flow traced only for branches matching this context',
      protectedVars: Array.from(context.protectedVars),
      sessionVars: { ...context.sessionVars },
      ...flowContextDict
    },
    flow: {
      interactions,
      flowGraph,
      interactionCount: interactions.length,
      missingPaths: missingPaths.length > 0 ? missingPaths : undefined,
      skippedPaths,  // Paths skipped due to context mismatch
      unknownPaths   // Paths with unknown/undetermined context
    }
  };
}

// =============================================================================
// Main Entry Point - runExtraction()
// =============================================================================

export function runExtraction(xmlFiles, trn) {
  // Parse TRN
  const parsedTrn = parseTRN(trn);
  if (!parsedTrn || !parsedTrn.interaction) {
    throw new Error('Invalid TRN format. Expected: MODULE\\SUBPROGRAM\\INTERACTION@PARAM...');
  }

  // Parse all XML files
  const parsedFiles = xmlFiles.map(file => {
    if (file.content && file.filename) {
      return parseInteractionXml(file.content, file.filename, file.path);
    }
    return file;
  }).filter(f => f.success);

  if (parsedFiles.length === 0) {
    throw new Error('No valid XML files found');
  }

  // Build interaction map
  const interactionMap = buildInteractionMap(parsedFiles);

  // Create FlowContext
  const context = new FlowContext();
  context.trnParams = parsedTrn.params;

  // Trace flow with context
  const { interactions, flowGraph, missingPaths, skippedPaths, unknownPaths } = traceFlowWithContext(
    parsedTrn,
    context,
    interactionMap
  );

  if (interactions.length === 0) {
    const entryPath = `${parsedTrn.module}\\${parsedTrn.subProgram}\\${parsedTrn.interaction}`;
    throw new Error(`Failed to trace flow from: ${entryPath}`);
  }

  // Generate context-aware JSON with full path info
  const pathInfo = { missingPaths, skippedPaths, unknownPaths };
  return generateContextAwareJSON(parsedTrn, interactions, context, flowGraph, pathInfo);
}

// =============================================================================
// Exports for compatibility with existing code
// =============================================================================

export function traceFlow(entryPath, interactionMap, context) {
  const parts = entryPath.replace(/\//g, '\\').split('\\');
  const trn = {
    full: entryPath,
    module: parts[0] || '',
    subProgram: parts[1] || '',
    interaction: parts[2] || '',
    params: context?.trnParams || [],
    destination: '',
    title: ''
  };

  const flowContext = context instanceof FlowContext ? context : new FlowContext();
  if (context && !(context instanceof FlowContext)) {
    flowContext.sessionVars = context.sessionVars || context;
    if (context.protectedVars) {
      for (const v of context.protectedVars) {
        flowContext.protectedVars.add(v);
      }
    }
  }

  const result = traceFlowWithContext(trn, flowContext, interactionMap);
  return {
    interactions: result.interactions,
    missingPaths: result.missingPaths
  };
}

export function generateContextAwareJSON_compat(trn, interactions, sessionVars, missingPaths) {
  const parsedTrn = typeof trn === 'string' ? parseTRN(trn) : trn;
  const context = new FlowContext();
  if (sessionVars) {
    context.sessionVars = sessionVars;
  }
  const pathInfo = { missingPaths: missingPaths || [] };
  return generateContextAwareJSON(parsedTrn, interactions, context, {}, pathInfo);
}

// Re-export backend translations
export { detectBackendType, getBackendTypeName, formatBackendType } from './backendTranslations';

export default {
  parseTRN,
  parseInteractionXml,
  buildInteractionMap,
  evaluateCondition,
  traceFlow,
  generateContextAwareJSON: generateContextAwareJSON_compat,
  runExtraction,
  FlowContext
};
