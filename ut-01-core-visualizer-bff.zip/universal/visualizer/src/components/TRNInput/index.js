export { default } from './TRNInput';
