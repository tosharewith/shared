package com.itau.comex.service;

import com.itau.comex.domain.Company;
import com.itau.comex.domain.SwiftMessage;

import java.util.List;

/**
 * COMEX Service interface
 * Defines business operations for COMEX domain
 */
public interface ComexService {

    /**
     * List companies with COMEX access for a user
     * Based on: ConsultaCNPJS.xml
     */
    List<Company> getCompanies(String userCpf);

    /**
     * Get company details by CNPJ
     */
    Company getCompanyDetails(String cnpj);

    /**
     * List SWIFT messages with optional filters
     */
    List<SwiftMessage> listSwiftMessages(String status, String dateFrom, String dateTo);

    /**
     * Get SWIFT message details by UETR
     */
    SwiftMessage getSwiftMessageDetails(String uetr);
}
