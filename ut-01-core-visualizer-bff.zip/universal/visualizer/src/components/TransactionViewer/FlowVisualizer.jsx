import { useMemo, useState, useCallback, useRef, useEffect } from 'react';
import {
  Screen,
  Api,
  DataBase,
  Terminal,
  User,
  Checkmark,
  WarningAlt,
  Document,
  ArrowRight
} from '@carbon/icons-react';
import styles from './FlowVisualizer.module.scss';

// Convert transaction data to flow visualization format
const buildFlowData = (transactionData) => {
  if (!transactionData) return { nodes: [], connections: [] };

  const menuItem = transactionData.menuItem || {};
  const trn = menuItem.trn || {};
  const flowContext = menuItem.flowContext || {};
  const flow = transactionData.flow || {};
  const interactions = flow.interactions || [];
  const flowGraph = flow.flowGraph || {};

  // Build interaction map
  const interactionMap = {};
  interactions.forEach(i => {
    if (i.path) interactionMap[i.path] = i;
  });

  // Build navigation map with conditions
  const navigationMap = {};
  interactions.forEach(i => {
    if (i.navigations && i.path) {
      navigationMap[i.path] = i.navigations.map(nav => ({
        target: nav.target,
        matchesContext: nav.matchesContext,
        condition: nav.condition,
        type: nav.type
      }));
    }
  });

  const nodes = [];
  const connections = [];
  const visited = new Set();
  const destination = trn.destination || '';
  const entryModule = trn.module || '';

  // Helper: check if path is relevant
  const isRelevantPath = (path) => {
    const module = path.split('\\')[0];
    return module === entryModule || module === destination || module === 'PM01' || path.includes(destination);
  };

  // Process flow and create nodes
  let nodeIndex = 0;
  const nodePositions = {}; // Track node positions
  const maxNodes = 10;
  const horizontalSpacing = 280;
  const verticalSpacing = 180;

  // Start node (Menu/Entry)
  nodes.push({
    id: 'entry',
    type: 'node',
    title: menuItem.nomeLogico || 'Entry Point',
    icon: 'user',
    x: 60,
    y: 100,
    status: 'complete',
    fields: [
      { id: 'trn', name: 'TRN', value: trn.full || '-' },
      { id: 'module', name: 'Module', value: trn.module || '-' },
      { id: 'destination', name: 'Destination', value: destination || '-' }
    ]
  });
  nodePositions['entry'] = { x: 60, y: 100 };

  // Process flow from MENU
  const menuTargets = flowGraph['MENU'] || [];
  let lastNodeId = 'entry';
  let currentX = 60 + horizontalSpacing;
  let currentY = 100;
  let rowIndex = 0;

  const processNode = (path, fromNodeId, conditionLabel = null) => {
    if (visited.has(path) || nodeIndex >= maxNodes) return null;
    visited.add(path);

    const interaction = interactionMap[path];
    const name = interaction?.name || path.split('\\').pop();
    const nodeId = `node-${nodeIndex}`;
    nodeIndex++;

    // Determine node type and styling
    const type = interaction?.type || 'Unknown';
    let icon = 'screen';
    let status = 'pending';

    if (type === 'WebService') icon = 'api';
    else if (type?.includes('ADO')) icon = 'database';
    else if (type?.includes('Mainframe')) icon = 'terminal';

    // Extract fields - now with wsInputs for complete data flow
    const fieldsData = interaction?.fields || {};
    const inputs = fieldsData.inputs || [];
    const wsInputs = fieldsData.wsInputs || [];
    const lists = fieldsData.lists || [];
    const bindings = fieldsData.bindings || [];

    const fields = [];

    // User inputs (what user fills in)
    inputs.slice(0, 4).forEach(f => fields.push({
      id: f.name,
      name: f.name?.replace(/_/g, ' '),
      value: null,
      type: 'input',
      icon: '📝'
    }));

    // WS Inputs (data sent TO the service)
    wsInputs.slice(0, 3).forEach(f => fields.push({
      id: `ws-${f.position}`,
      name: f.name || `pos:${f.position}`,
      value: '→WS',
      type: 'wsInput',
      icon: '📤'
    }));

    // Bindings (data received FROM service)
    bindings.slice(0, 3).forEach(b => fields.push({
      id: b.textWS || b.position,
      name: b.textWS || b.tagXML?.split('/').pop() || `pos:${b.position}`,
      value: '←WS',
      type: 'binding',
      icon: '📥'
    }));

    // Lists (table columns from WS)
    lists.slice(0, 2).forEach(f => fields.push({
      id: f.name,
      name: f.name,
      value: f.tagListaWS ? '[]' : null,
      type: 'list',
      icon: '📋'
    }));

    // Calculate position
    const x = currentX;
    const y = currentY;
    currentX += horizontalSpacing;

    // If we're going too far right, move down
    if (currentX > 1400) {
      currentX = 340;
      currentY += verticalSpacing;
      rowIndex++;
    }

    nodes.push({
      id: nodeId,
      type: 'node',
      title: name.replace(/_/g, ' '),
      icon: icon,
      x: x,
      y: y,
      status: status,
      nodeType: type,
      module: interaction?.module || path.split('\\')[0],
      path: path,
      fields: fields.length > 0 ? fields : [{ id: 'path', name: 'Path', value: path.split('\\').pop() }]
    });

    nodePositions[nodeId] = { x, y };

    // Add connection from previous node
    if (fromNodeId) {
      connections.push({
        from: fromNodeId,
        to: nodeId,
        label: conditionLabel,
        state: 'active'
      });
    }

    return nodeId;
  };

  // Process navigation with conditions
  const processFlow = (path, fromNodeId) => {
    const nodeId = processNode(path, fromNodeId);
    if (!nodeId) return;

    const targets = flowGraph[path] || [];
    const navs = navigationMap[path] || [];

    // Find targets with conditions
    const contextMatching = navs.filter(n => n.matchesContext === true && targets.includes(n.target));
    const hasConditions = navs.some(n => n.condition);

    if (hasConditions && contextMatching.length > 0) {
      // Add condition diamond
      const condId = `cond-${nodeIndex}`;
      const condX = nodePositions[nodeId].x + horizontalSpacing / 2;
      const condY = nodePositions[nodeId].y;

      nodes.push({
        id: condId,
        type: 'condition',
        title: 'Context?',
        condition: `$Prog = "${destination}"`,
        x: condX,
        y: condY,
        evaluated: true
      });

      connections.push({
        from: nodeId,
        to: condId,
        state: 'complete'
      });

      // Process the matching path
      contextMatching.slice(0, 1).forEach(nav => {
        if (!visited.has(nav.target) && isRelevantPath(nav.target)) {
          currentX = condX + horizontalSpacing / 2 + 60;
          processFlow(nav.target, condId);
        }
      });
    } else {
      // No condition, follow relevant paths
      const relevantTargets = targets.filter(isRelevantPath);
      relevantTargets.slice(0, 2).forEach(target => {
        if (!visited.has(target)) {
          processFlow(target, nodeId);
        }
      });
    }
  };

  // Start processing from menu targets
  menuTargets.filter(isRelevantPath).slice(0, 2).forEach(target => {
    processFlow(target, 'entry');
  });

  // If no flow, try destination interactions directly
  if (nodes.length <= 1 && destination) {
    const destInteractions = interactions.filter(i => i.module === destination);
    destInteractions.slice(0, 4).forEach(i => {
      if (i.path) processNode(i.path, 'entry');
    });
  }

  return { nodes, connections, flowContext, trn };
};

// SVG Curved Path Component
const CurvedPath = ({ from, to, state, containerRef }) => {
  const [pathD, setPathD] = useState('');

  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    const fromEl = container.querySelector(`#${CSS.escape(from)}`);
    const toEl = container.querySelector(`#${CSS.escape(to)}`);

    if (!fromEl || !toEl) return;

    const containerRect = container.getBoundingClientRect();
    const fromRect = fromEl.getBoundingClientRect();
    const toRect = toEl.getBoundingClientRect();

    const startX = fromRect.right - containerRect.left;
    const startY = fromRect.top - containerRect.top + fromRect.height / 2;
    const endX = toRect.left - containerRect.left;
    const endY = toRect.top - containerRect.top + toRect.height / 2;

    const midX = startX + (endX - startX) / 2;
    setPathD(`M ${startX} ${startY} C ${midX} ${startY}, ${midX} ${endY}, ${endX} ${endY}`);
  }, [from, to, containerRef]);

  if (!pathD) return null;

  return (
    <path
      d={pathD}
      className={`${styles.connectionPath} ${styles[state] || ''}`}
      fill="none"
    />
  );
};

// Node Component
const FlowNode = ({ node }) => {
  const getIcon = () => {
    switch (node.icon) {
      case 'api': return <Api size={16} />;
      case 'database': return <DataBase size={16} />;
      case 'terminal': return <Terminal size={16} />;
      case 'user': return <User size={16} />;
      case 'check': return <Checkmark size={16} />;
      case 'alert': return <WarningAlt size={16} />;
      default: return <Screen size={16} />;
    }
  };

  return (
    <div
      id={node.id}
      className={`${styles.node} ${styles[node.status] || ''}`}
      style={{ left: node.x, top: node.y }}
    >
      <div className={styles.nodeBox}>
        <div className={styles.nodeHeader}>
          <div className={styles.nodeIcon}>{getIcon()}</div>
          <span className={styles.nodeTitle}>{node.title}</span>
        </div>
        {node.module && (
          <div className={styles.nodeModule}>{node.module}</div>
        )}
        {node.fields && node.fields.length > 0 && (
          <div className={styles.nodeFields}>
            {node.fields.map((field, i) => (
              <div
                key={i}
                className={`${styles.nodeField} ${styles[`fieldType_${field.type}`] || ''} ${field.value ? styles.filled : ''}`}
              >
                <span className={styles.fieldIcon}>{field.icon || '•'}</span>
                <span className={styles.fieldName}>{field.name}</span>
                {field.value && (
                  <span className={styles.fieldValue}>
                    {typeof field.value === 'string' && field.value.length > 12
                      ? field.value.substring(0, 12) + '…'
                      : field.value}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Condition Diamond Component
const ConditionDiamond = ({ node }) => (
  <div
    id={node.id}
    className={`${styles.condition} ${node.evaluated ? styles.evaluated : ''}`}
    style={{ left: node.x, top: node.y }}
  >
    <div className={styles.conditionDiamond}>
      <div className={styles.conditionContent}>
        <div className={styles.conditionLabel}>IF</div>
        <div className={styles.conditionText}>{node.title}</div>
      </div>
    </div>
    <div className={styles.conditionBranches}>
      <span className={styles.branchYes}>YES</span>
      <span className={styles.branchNo}>NO</span>
    </div>
  </div>
);

// Main Component
const FlowVisualizer = ({ transactionData }) => {
  const containerRef = useRef(null);
  const [flowData, setFlowData] = useState({ nodes: [], connections: [], flowContext: {}, trn: {} });

  useEffect(() => {
    const data = buildFlowData(transactionData);
    setFlowData(data);
  }, [transactionData]);

  const { nodes, connections, flowContext, trn } = flowData;

  if (!transactionData) {
    return (
      <div className={styles.noData}>
        <Document size={32} />
        <p>Select a transaction to visualize the flow</p>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarHeader}>
          <ArrowRight size={24} />
          <h1>Flow Visualizer</h1>
        </div>

        {/* Legend */}
        <div className={styles.legend}>
          <div className={styles.legendTitle}>Node Status</div>
          <div className={styles.legendItems}>
            <div className={styles.legendItem}>
              <div className={`${styles.legendIcon} ${styles.complete}`} />
              <span>Complete / Entry</span>
            </div>
            <div className={styles.legendItem}>
              <div className={`${styles.legendIcon} ${styles.active}`} />
              <span>Active Path</span>
            </div>
            <div className={styles.legendItem}>
              <div className={`${styles.legendIcon} ${styles.pending}`} />
              <span>Pending Step</span>
            </div>
            <div className={styles.legendItem}>
              <div className={`${styles.legendIcon} ${styles.conditionIcon}`} />
              <span>Condition</span>
            </div>
          </div>
        </div>

        {/* Data Flow Legend */}
        <div className={styles.legend}>
          <div className={styles.legendTitle}>Data Flow</div>
          <div className={styles.legendItems}>
            <div className={styles.legendItem}>
              <span className={styles.fieldLegendIcon}>📝</span>
              <span>User Input</span>
            </div>
            <div className={styles.legendItem}>
              <span className={styles.fieldLegendIcon}>📤</span>
              <span>WS Input (→WS)</span>
            </div>
            <div className={styles.legendItem}>
              <span className={styles.fieldLegendIcon}>📥</span>
              <span>WS Output (←WS)</span>
            </div>
            <div className={styles.legendItem}>
              <span className={styles.fieldLegendIcon}>📋</span>
              <span>List/Table</span>
            </div>
          </div>
        </div>

        {/* Context Info */}
        <div className={styles.contextSection}>
          <div className={styles.contextHeader}>Context Variables</div>
          {Object.entries(flowContext).map(([key, value]) => (
            <div key={key} className={styles.contextVar}>
              <span className={styles.contextKey}>${key}</span>
              <span className={styles.contextValue}>
                {String(value).length > 20 ? String(value).substring(0, 20) + '…' : value}
              </span>
            </div>
          ))}
          {Object.keys(flowContext).length === 0 && (
            <div className={styles.contextEmpty}>No context variables</div>
          )}
        </div>

        {/* TRN Info */}
        <div className={styles.trnSection}>
          <div className={styles.trnHeader}>TRN Parameters</div>
          <div className={styles.trnItem}>
            <span>Module:</span>
            <span className={styles.trnValue}>{trn.module || '-'}</span>
          </div>
          <div className={styles.trnItem}>
            <span>Destination:</span>
            <span className={`${styles.trnValue} ${styles.highlight}`}>{trn.destination || '-'}</span>
          </div>
          <div className={styles.trnItem}>
            <span>Gateway:</span>
            <span className={styles.trnValue}>{trn.interaction || '-'}</span>
          </div>
        </div>

        {/* Node List */}
        <div className={styles.nodeList}>
          <div className={styles.nodeListHeader}>
            Flow Steps <span className={styles.count}>{nodes.length}</span>
          </div>
          {nodes.filter(n => n.type === 'node').map((node, i) => (
            <div key={node.id} className={styles.nodeListItem}>
              <span className={styles.nodeListIndex}>{i + 1}</span>
              <span className={styles.nodeListName}>{node.title}</span>
              <span className={styles.nodeListType}>{node.nodeType || 'entry'}</span>
            </div>
          ))}
        </div>
      </aside>

      {/* Canvas */}
      <main className={styles.canvasWrapper}>
        <div className={styles.canvas} ref={containerRef}>
          {/* SVG Connections */}
          <svg className={styles.connections}>
            {connections.map((conn, i) => (
              <CurvedPath
                key={i}
                from={conn.from}
                to={conn.to}
                state={conn.state}
                containerRef={containerRef}
              />
            ))}
          </svg>

          {/* Nodes */}
          {nodes.map(node => (
            node.type === 'condition'
              ? <ConditionDiamond key={node.id} node={node} />
              : <FlowNode key={node.id} node={node} />
          ))}
        </div>
      </main>
    </div>
  );
};

export default FlowVisualizer;
