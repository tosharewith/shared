/**
 * Cytoscape.js style configurations
 * Matching the HTML visualizer's IBM Carbon Design System colors and styles
 */

/**
 * Node styles for different object types (from HTML visualizer)
 * Professional pastel colors with darker borders
 */
export const nodeStyles = {
  'Informix Table': { color: '#d0e2ff', borderColor: '#0043ce', shape: 'rectangle' },
  'Informix Procedure': { color: '#e8daff', borderColor: '#6929c4', shape: 'roundrectangle' },
  'Informix Function': { color: '#ffd6e8', borderColor: '#9f1853', shape: 'ellipse' },
  'Informix Trigger': { color: '#9ef0f0', borderColor: '#005d5d', shape: 'diamond' },
  // yFiles format types
  'Process': { color: '#ffd6e8', borderColor: '#9f1853', shape: 'roundrectangle' },
  'Start': { color: '#a7f0ba', borderColor: '#0e6027', shape: 'ellipse' },
  'Event': { color: '#d0e2ff', borderColor: '#0043ce', shape: 'ellipse' },
  'Data': { color: '#ffd9be', borderColor: '#ba4e00', shape: 'rectangle' },
  // Generic types (for compatibility)
  'Table': { color: '#d0e2ff', borderColor: '#0043ce', shape: 'rectangle' },
  'Procedure': { color: '#e8daff', borderColor: '#6929c4', shape: 'roundrectangle' },
  'Function': { color: '#ffd6e8', borderColor: '#9f1853', shape: 'ellipse' },
  'Trigger': { color: '#9ef0f0', borderColor: '#005d5d', shape: 'diamond' },
  'View': { color: '#a7f0ba', borderColor: '#0e6027', shape: 'round-triangle' },
  'Stored Procedure': { color: '#ffd9be', borderColor: '#ba4e00', shape: 'round-diamond' },
  'Unknown': { color: '#e0e0e0', borderColor: '#393939', shape: 'ellipse' },
};

/**
 * Edge styles for different link types (from HTML visualizer)
 * IBM Carbon Design Color System
 */
export const edgeStyles = {
  'SELECT': '#78a9ff',  // IBM Blue 40
  'INSERT': '#6fdc8c',  // IBM Green 40
  'UPDATE': '#ffb784',  // IBM Orange 40
  'DELETE': '#ff99a2',  // IBM Red 40
  'REFER': '#be95ff',   // IBM Purple 40
  'calls': '#82cfff',   // IBM Blue 30
  'CALLS': '#82cfff',   // IBM Blue 30
  'Reference': '#be95ff', // IBM Purple 40
  'Call': '#82cfff',    // IBM Blue 30
  'Execute': '#ffb784',  // IBM Orange 40
};

/**
 * Base Cytoscape styles matching HTML visualizer
 */
export const cytoscapeStyles = [
  // Node styles - matching HTML visualizer exactly
  {
    selector: 'node',
    style: {
      'background-color': 'data(color)',
      'label': 'data(label)',
      'width': 'data(width)',
      'height': 'data(height)',
      'text-valign': 'bottom',     // Text below node (not center)
      'text-halign': 'center',
      'font-family': 'IBM Plex Sans, sans-serif',
      'font-size': '11px',
      'font-weight': 500,
      'text-wrap': 'wrap',
      'text-max-width': '80px',
      'shape': 'data(shape)',
      'text-outline-width': 0,
      'color': '#000000',          // Pure black for maximum contrast (was #161616)
      'text-margin-y': 6,
      'border-width': 3,
      'border-color': 'data(borderColor)',
      'border-opacity': 1,
    },
  },

  // Selected node
  {
    selector: 'node:selected',
    style: {
      'border-width': 4,
      'border-color': '#0f62fe',
      'overlay-color': '#0f62fe',
      'overlay-opacity': 0.2,
      'overlay-padding': 10,
    },
  },

  // Highlighted node (search results)
  {
    selector: 'node.highlighted',
    style: {
      'border-width': 4,
      'border-color': '#f1c21b', // IBM Yellow for search highlight
      'border-opacity': 1,
      opacity: 1,
      'z-index': 999,
    },
  },

  // Dimmed/faded node (when others are highlighted)
  {
    selector: 'node.faded',
    style: {
      opacity: 0.3,
    },
  },

  // Hidden node (filtered out)
  {
    selector: 'node.hidden',
    style: {
      display: 'none',
    },
  },

  // Edge styles - matching HTML visualizer
  {
    selector: 'edge',
    style: {
      'width': (ele) => {
        const count = ele.data('count') || 1;
        return Math.min(2 + count * 0.5, 6);
      },
      'line-color': 'data(color)',
      'curve-style': 'bezier',
      'target-arrow-color': 'data(color)',
      'target-arrow-shape': 'triangle',
      'arrow-scale': 1,
      'label': '',  // No edge labels by default
      'font-family': 'IBM Plex Sans, sans-serif',
      'font-size': '10px',
      'font-weight': 500,
      'text-rotation': 'autorotate',
      'text-background-opacity': 1,
      'text-background-color': '#ffffff',
      'text-background-padding': '3px',
      'text-background-shape': 'roundrectangle',
      'color': '#525252',
      'opacity': (ele) => {
        const count = ele.data('count') || 1;
        return Math.min(0.7 + count * 0.05, 1);
      },
    },
  },

  // Edge with label (when enabled)
  {
    selector: 'edge.show-label',
    style: {
      'label': 'data(label)',
    },
  },

  // Selected edge
  {
    selector: 'edge:selected',
    style: {
      'width': 4,
      'overlay-color': '#0f62fe',
      'overlay-opacity': 0.2,
      'overlay-padding': 4,
    },
  },

  // Highlighted edge (connected to highlighted node)
  {
    selector: 'edge.highlighted',
    style: {
      'width': 4,
      'line-color': '#0f62fe',
      'target-arrow-color': '#0f62fe',
      opacity: 1,
      'z-index': 999,
    },
  },

  // Dimmed/faded edge
  {
    selector: 'edge.faded',
    style: {
      opacity: 0.15,
    },
  },

  // Hidden edge (filtered out)
  {
    selector: 'edge.hidden',
    style: {
      display: 'none',
    },
  },
];

/**
 * Create Cytoscape-compatible elements from Objects and Links
 * @param {Array} objects - Array of objects with properties
 * @param {Array} links - Array of links between objects
 * @returns {Object} - { nodes: [], edges: [] }
 */
export function createCytoscapeElements(objects, links) {
  // Create nodes from objects
  const nodes = objects.map(obj => {
    const type = obj["Object Type"] || "Unknown";
    const style = nodeStyles[type] || nodeStyles["Unknown"];

    // Calculate node size based on complexity
    let size = 18;
    const complexity = parseInt(obj["Cyclomatic Complexity"] || "0");
    if (complexity > 0) {
      size += Math.min(complexity * 0.5, 15);
    }

    return {
      group: 'nodes',
      data: {
        id: obj["Object ID"],
        label: obj["Object Name"],
        fullName: obj["Object Full Name"],
        type: type,
        color: style.color,
        borderColor: style.borderColor,
        shape: style.shape,
        width: size,
        height: size,
        original: obj,
      },
    };
  });

  // Create edges from links
  const edges = links.map((link, index) => {
    const source = link["Caller Object ID"];
    const target = link["Callee Object ID"];
    const type = link["Link Type"] || "Reference";
    const color = edgeStyles[type] || '#999';

    return {
      group: 'edges',
      data: {
        id: 'e' + index,
        source: source,
        target: target,
        label: type,
        type: type,
        color: color,
        original: link,
      },
    };
  });

  return { nodes, edges };
}

/**
 * Get color for node type
 * @param {string} type - Node type
 * @returns {string} Hex color
 */
export const getNodeColor = (type) => {
  return nodeStyles[type]?.color || nodeStyles["Unknown"].color;
};

/**
 * Get color for edge type
 * @param {string} type - Edge type
 * @returns {string} Hex color
 */
export const getEdgeColor = (type) => {
  return edgeStyles[type] || '#999';
};

/**
 * Filter badge pastel color schemes (matching HTML visualizer)
 * Each type has: background (light pastel), border (medium), text (dark)
 */
export const nodeFilterColors = {
  'Informix Table': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Informix Procedure': { bg: '#e8daff', border: '#be95ff', text: '#491d8b' },
  'Informix Function': { bg: '#ffd6e8', border: '#ff7eb6', text: '#740937' },
  'Informix Trigger': { bg: '#9ef0f0', border: '#3ddbd9', text: '#004144' },
  'Table': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Procedure': { bg: '#e8daff', border: '#be95ff', text: '#491d8b' },
  'Function': { bg: '#ffd6e8', border: '#ff7eb6', text: '#740937' },
  'Trigger': { bg: '#9ef0f0', border: '#3ddbd9', text: '#004144' },
  'Process': { bg: '#ffd6e8', border: '#ff7eb6', text: '#740937' },
  'Start': { bg: '#a7f0ba', border: '#6fdc8c', text: '#044317' },
  'Event': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Data': { bg: '#ffd9be', border: '#ffb784', text: '#8a3800' },
  'View': { bg: '#a7f0ba', border: '#6fdc8c', text: '#044317' },
  'Stored Procedure': { bg: '#ffd9be', border: '#ffb784', text: '#8a3800' },
  'Unknown': { bg: '#e0e0e0', border: '#a8a8a8', text: '#161616' },
};

export const edgeFilterColors = {
  'SELECT': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'INSERT': { bg: '#a7f0ba', border: '#6fdc8c', text: '#044317' },
  'UPDATE': { bg: '#ffd9be', border: '#ffb784', text: '#8a3800' },
  'DELETE': { bg: '#ffd7d9', border: '#ff99a2', text: '#750e13' },
  'REFER': { bg: '#e8daff', border: '#be95ff', text: '#491d8b' },
  'calls': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'CALLS': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Reference': { bg: '#e8daff', border: '#be95ff', text: '#491d8b' },
  'Call': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Execute': { bg: '#ffd9be', border: '#ffb784', text: '#8a3800' },
};

/**
 * Get filter badge colors for node type (pastel scheme)
 * @param {string} type - Node type
 * @returns {Object} { bg, border, text }
 */
export const getNodeFilterColors = (type) => {
  return nodeFilterColors[type] || nodeFilterColors['Unknown'];
};

/**
 * Get filter badge colors for edge type (pastel scheme)
 * @param {string} type - Edge type
 * @returns {Object} { bg, border, text }
 */
export const getEdgeFilterColors = (type) => {
  return edgeFilterColors[type] || { bg: '#e0e0e0', border: '#a8a8a8', text: '#525252' };
};

/**
 * Get all unique node types from elements
 * @param {Array} elements - Cytoscape elements (nodes and edges)
 * @returns {Array} Unique node types
 */
export const getNodeTypes = (elements) => {
  const types = new Set();
  elements.forEach((el) => {
    if (el.group === 'nodes' && el.data.type) {
      types.add(el.data.type);
    }
  });
  return Array.from(types).sort();
};

/**
 * Get all unique edge types from elements
 * @param {Array} elements - Cytoscape elements (nodes and edges)
 * @returns {Array} Unique edge types
 */
export const getEdgeTypes = (elements) => {
  const types = new Set();
  elements.forEach((el) => {
    if (el.group === 'edges' && el.data.type) {
      types.add(el.data.type);
    }
  });
  return Array.from(types).sort();
};
