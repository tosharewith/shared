import { useEffect, useRef, useState, useMemo } from 'react';
import cytoscape from 'cytoscape';
import coseBilkent from 'cytoscape-cose-bilkent';
import fcose from 'cytoscape-fcose';
import { parseGraphML } from '../utils/graphmlParser';
import './SimpleDiagramViewer.css';

cytoscape.use(coseBilkent);
cytoscape.use(fcose);

const SP1NBP_STYLES = [
  {
    selector: 'node',
    style: {
      'background-color': (ele) => {
        const type = ele.data('nodeType') || ele.data('type') || 'Unknown';
        const colors = {
          'Dispatcher': '#e1f5ff',
          'WebService': '#a7f0ba',
          'Browser_Radio': '#d0e2ff',
          'Browser_Checkbox': '#a6c8ff',
          'Browser_Form': '#d0e2ff',
          'OperacaoFinalizacao': '#e0e0e0',
          'VisaoCliente': '#ffeed4',
          'External': '#e8daff',
          'Unknown': '#f4f4f4'
        };
        return colors[type] || '#f4f4f4';
      },
      'border-color': (ele) => {
        const type = ele.data('nodeType') || ele.data('type') || 'Unknown';
        const colors = {
          'Dispatcher': '#0f62fe',
          'WebService': '#24a148',
          'Browser_Radio': '#0f62fe',
          'Browser_Checkbox': '#0043ce',
          'Browser_Form': '#0f62fe',
          'OperacaoFinalizacao': '#525252',
          'VisaoCliente': '#ec7000',
          'External': '#8a3ffc',
          'Unknown': '#8d8d8d'
        };
        return colors[type] || '#8d8d8d';
      },
      'border-width': (ele) => {
        const complexity = ele.data('complexity') || 'Medium';
        const widths = {
          'VeryHigh': 4,
          'High': 3,
          'Medium': 2,
          'Low': 2
        };
        return widths[complexity] || 2;
      },
      'shape': (ele) => {
        const type = ele.data('nodeType') || ele.data('type') || 'Unknown';
        const shapes = {
          'Dispatcher': 'diamond',
          'WebService': 'hexagon',
          'Browser_Radio': 'roundrectangle',
          'Browser_Checkbox': 'roundrectangle',
          'Browser_Form': 'roundrectangle',
          'OperacaoFinalizacao': 'rectangle',
          'VisaoCliente': 'ellipse',
          'External': 'octagon',
          'Unknown': 'ellipse'
        };
        return shapes[type] || 'ellipse';
      },
      'width': (ele) => {
        const lines = parseInt(ele.data('lines') || 100);
        if (lines > 400) return 55;
        if (lines > 200) return 40;
        if (lines > 50) return 30;
        return 20;
      },
      'height': (ele) => {
        const lines = parseInt(ele.data('lines') || 100);
        if (lines > 400) return 55;
        if (lines > 200) return 40;
        if (lines > 50) return 30;
        return 20;
      },
      'label': 'data(label)',
      'text-valign': 'center',
      'text-halign': 'center',
      'font-size': 10,
      'font-family': 'IBM Plex Sans, sans-serif',
      'text-wrap': 'wrap',
      'text-max-width': '80px'
    }
  },
  {
    selector: 'edge',
    style: {
      'width': 2,
      'line-color': '#78a9ff',
      'target-arrow-color': '#78a9ff',
      'target-arrow-shape': 'triangle',
      'curve-style': 'bezier',
      'label': 'data(label)',
      'font-size': 8,
      'text-rotation': 'autorotate'
    }
  },
  {
    selector: 'node:selected',
    style: {
      'border-width': 4,
      'border-color': '#ec7000',
      'overlay-color': '#ec7000',
      'overlay-opacity': 0.2
    }
  }
];

const SimpleDiagramViewer = ({ value, displayName }) => {
  const containerRef = useRef(null);
  const cyRef = useRef(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [layout, setLayout] = useState('fcose');

  const elements = useMemo(() => {
    if (!value) return { nodes: [], edges: [] };
    try {
      return parseGraphML(value);
    } catch (err) {
      console.error('Parse error:', err);
      return { nodes: [], edges: [] };
    }
  }, [value]);

  useEffect(() => {
    if (!containerRef.current || !elements || elements.nodes.length === 0) return;

    const cy = cytoscape({
      container: containerRef.current,
      elements: elements,
      style: SP1NBP_STYLES,
      layout: {
        name: 'fcose',
        animate: true,
        animationDuration: 1000,
        idealEdgeLength: 60,
        nodeRepulsion: 4500,
        gravity: 0.25
      }
    });

    cyRef.current = cy;

    cy.on('tap', 'node', (evt) => {
      const node = evt.target;
      setSelectedNode(node.data());
    });

    cy.on('tap', (evt) => {
      if (evt.target === cy) {
        setSelectedNode(null);
      }
    });

    return () => {
      if (cy) cy.destroy();
    };
  }, [elements]);

  const applyLayout = (layoutName) => {
    if (!cyRef.current) return;

    const layouts = {
      fcose: {
        name: 'fcose',
        animate: true,
        animationDuration: 1000,
        idealEdgeLength: 60,
        nodeRepulsion: 4500
      },
      'cose-bilkent': {
        name: 'cose-bilkent',
        animate: true,
        animationDuration: 1000,
        idealEdgeLength: 80,
        nodeRepulsion: 4500
      },
      circle: {
        name: 'circle',
        animate: true,
        radius: 300
      },
      grid: {
        name: 'grid',
        animate: true,
        rows: Math.ceil(Math.sqrt(elements.nodes.length))
      }
    };

    cyRef.current.layout(layouts[layoutName] || layouts.fcose).run();
    setLayout(layoutName);
  };

  const fitView = () => {
    if (cyRef.current) {
      cyRef.current.fit(null, 50);
    }
  };

  const exportPNG = () => {
    if (!cyRef.current) return;
    const png = cyRef.current.png({ output: 'blob', bg: '#ffffff', full: true, scale: 2 });
    const url = URL.createObjectURL(png);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'sp1nbp_graph.png';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="diagram-viewer">
      <div className="toolbar">
        <div className="toolbar-group">
          <label>Layout:</label>
          <select value={layout} onChange={(e) => applyLayout(e.target.value)}>
            <option value="fcose">Force-Directed</option>
            <option value="cose-bilkent">Hierarchical</option>
            <option value="circle">Circular</option>
            <option value="grid">Grid</option>
          </select>
        </div>
        <div className="toolbar-group">
          <button onClick={fitView}>Fit View</button>
          <button onClick={exportPNG}>Export PNG</button>
        </div>
      </div>

      <div className="diagram-container">
        <div ref={containerRef} className="cytoscape-container" />
        
        {selectedNode && (
          <div className="details-panel">
            <div className="details-header">
              <h3>{selectedNode.label || selectedNode.id}</h3>
              <button onClick={() => setSelectedNode(null)}>✕</button>
            </div>
            <div className="details-content">
              <div className="detail-item">
                <strong>Type:</strong> {selectedNode.nodeType || selectedNode.type || 'Unknown'}
              </div>
              <div className="detail-item">
                <strong>File:</strong> {selectedNode.fileName || 'N/A'}
              </div>
              <div className="detail-item">
                <strong>Lines:</strong> {selectedNode.lines || 'N/A'}
              </div>
              <div className="detail-item">
                <strong>Complexity:</strong> {selectedNode.complexity || 'N/A'}
              </div>
              <div className="detail-item">
                <strong>Has UI:</strong> {selectedNode.hasUI ? 'Yes' : 'No'}
              </div>
              <div className="detail-item">
                <strong>Has JavaScript:</strong> {selectedNode.hasJavaScript ? 'Yes' : 'No'}
              </div>
              <div className="detail-item">
                <strong>Has Validation:</strong> {selectedNode.hasValidation ? 'Yes' : 'No'}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SimpleDiagramViewer;
