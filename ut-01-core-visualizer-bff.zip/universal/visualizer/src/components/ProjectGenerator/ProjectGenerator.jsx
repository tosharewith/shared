import { useState, useCallback, useMemo, useEffect } from 'react';
import {
  Button,
  TextInput,
  NumberInput,
  Accordion,
  AccordionItem,
  Tag,
  InlineLoading
} from '@carbon/react';
import {
  Download,
  Code,
  Screen,
  Folder,
  Document,
  Copy,
  Checkmark,
  Edit,
  FolderDetails,
  Api,
  DataBase,
  Terminal,
  CloudServiceManagement
} from '@carbon/icons-react';
import JSZip from 'jszip';
import {
  BACKEND_TYPES,
  detectBackendType,
  formatBackendType,
  getBackendTypesByCategory
} from '../../utils/backendTranslations';
import styles from './ProjectGenerator.module.scss';

/**
 * ProjectGenerator Component
 * Generates Angular MFE project from parsed XML data
 */
// Available target platforms for code generation
const TARGET_PLATFORMS = {
  frontend: [
    {
      id: 'angular',
      name: 'Angular MFE',
      description: 'Microfrontend Angular 15+ com Module Federation',
      icon: 'Screen',
      color: '#dd0031',
      category: 'frontend'
    }
  ],
  backend: [
    {
      id: 'go',
      name: 'Go Service',
      description: 'Backend Go com adapters para todos os tipos de backend',
      icon: 'Terminal',
      color: '#00add8',
      category: 'backend'
    },
    {
      id: 'java',
      name: 'Java Spring Boot',
      description: 'Serviço Spring Boot com adapters e DTOs',
      icon: 'Code',
      color: '#f89820',
      category: 'backend'
    }
  ]
};

// Flatten for easy lookup
const ALL_PLATFORMS = [...TARGET_PLATFORMS.frontend, ...TARGET_PLATFORMS.backend];

const ProjectGenerator = ({ parsedData, onBack }) => {
  const [projectName, setProjectName] = useState('mfe-transacao');
  const [mfePort, setMfePort] = useState(5002);
  // Multi-selection: { angular: true, go: true } or { angular: true, java: true }
  const [selectedPlatforms, setSelectedPlatforms] = useState({
    angular: true,
    go: true,
    java: false
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [generatedCode, setGeneratedCode] = useState(null);
  const [copiedField, setCopiedField] = useState(null);
  const [editingName, setEditingName] = useState(false);
  const [templateBundles, setTemplateBundles] = useState({
    angular: null,
    go: null,
    java: null
  });
  const [templateErrors, setTemplateErrors] = useState({});

  // Load all template bundles on mount
  useEffect(() => {
    const templateConfigs = [
      { id: 'angular', url: '/templates/mfe-base-bundle.json' },
      { id: 'go', url: '/templates/go-service-bundle.json' },
      { id: 'java', url: '/templates/java-service-bundle.json' }
    ];

    Promise.all(
      templateConfigs.map(({ id, url }) =>
        fetch(url)
          .then(res => {
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            return res.json();
          })
          .then(bundle => {
            console.log(`${id} template loaded: ${bundle.fileCount} files`);
            return { id, bundle };
          })
          .catch(err => {
            console.warn(`${id} template not available:`, err.message);
            return { id, error: err.message };
          })
      )
    ).then(results => {
      const bundles = {};
      const errors = {};
      for (const result of results) {
        if (result.bundle) {
          bundles[result.id] = result.bundle;
        } else if (result.error) {
          errors[result.id] = result.error;
        }
      }
      setTemplateBundles(prev => ({ ...prev, ...bundles }));
      setTemplateErrors(errors);
    });
  }, []);

  // Alias for backward compatibility
  const templateBundle = templateBundles.angular;

  // Toggle platform selection
  const togglePlatform = (platformId, category) => {
    setSelectedPlatforms(prev => {
      const newState = { ...prev };

      if (category === 'backend') {
        // For backend: only one can be selected at a time (Go XOR Java)
        TARGET_PLATFORMS.backend.forEach(p => {
          newState[p.id] = p.id === platformId ? !prev[platformId] : false;
        });
      } else {
        // For frontend: simple toggle
        newState[platformId] = !prev[platformId];
      }

      return newState;
    });
  };

  // Get selected platforms as array
  const getSelectedPlatformsList = () => {
    return ALL_PLATFORMS.filter(p => selectedPlatforms[p.id]);
  };

  // Check if at least one platform is selected
  const hasSelectedPlatforms = Object.values(selectedPlatforms).some(v => v);

  // Helper function to get backend type icon
  const getBackendTypeIcon = (typeId) => {
    const iconMap = {
      'ADO': <DataBase size={20} />,
      'MAINFRAME': <Terminal size={20} />,
      'MAINFRAME_GRBE': <Terminal size={20} />,
      'REST_API': <Api size={20} />,
      'SOAP': <CloudServiceManagement size={20} />,
      'LEGACY_WS': <Document size={20} />,
      'MBI': <Api size={20} />,
      'CMC': <Api size={20} />,
      'BROWSER': <Screen size={20} />
    };
    return iconMap[typeId] || <Code size={20} />;
  };

  // Analyze backend types from parsed data
  const backendTypesAnalysis = useMemo(() => {
    if (!parsedData?.screens) return {};

    const analysis = {};
    parsedData.screens.forEach(screen => {
      if (screen.backendType?.id) {
        const typeId = screen.backendType.id;
        if (!analysis[typeId]) {
          analysis[typeId] = {
            id: typeId,
            name: screen.backendType.name?.pt || typeId,
            color: screen.backendType.color || '#8d8d8d',
            count: 0
          };
        }
        analysis[typeId].count++;
      } else if (screen.type) {
        // Fallback for screens without full backendType info
        const backendType = detectBackendType(screen.type, screen.configuration?.mainAttributes || {});
        if (backendType) {
          const typeId = backendType.id;
          if (!analysis[typeId]) {
            analysis[typeId] = {
              id: typeId,
              name: backendType.name?.pt || typeId,
              color: backendType.color || '#8d8d8d',
              count: 0
            };
          }
          analysis[typeId].count++;
        }
      }
    });

    return analysis;
  }, [parsedData]);

  // Helper functions
  const toKebabCase = (str) => (str || '')
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/--+/g, '-');

  const toPascalCase = (str) => (str || '')
    .split(/[-\s_]+/)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join('');

  const toCamelCase = (str) => {
    const pascal = toPascalCase(str);
    return pascal.charAt(0).toLowerCase() + pascal.slice(1);
  };

  // Map field to IDS component type
  const mapFieldToComponent = (field) => {
    const name = (field.name || '').toLowerCase();
    const type = (field.type || '').toLowerCase();
    const size = parseInt(field.size) || 0;

    // Date detection
    if (name.includes('dia') || name.includes('mes') || name.includes('ano') || name.includes('data')) {
      return { component: 'date', icon: 'Calendar', imports: ['IdsDatepickerModule'] };
    }

    // Select detection
    if (type.includes('lista') || field.source?.includes('Lista')) {
      return { component: 'select', icon: 'Select', imports: ['IdsSelectModule'] };
    }

    // Currency detection
    if (name.includes('valor') || name.includes('saldo') || name.includes('amount')) {
      return { component: 'currency', icon: 'Currency', imports: ['IdsMaskModule'] };
    }

    // CNPJ/CPF detection
    if (name.includes('cnpj') || name.includes('cpf') || name.includes('cgc')) {
      return { component: 'masked', icon: 'Identification', imports: ['IdsMaskModule'] };
    }

    // Default text
    return { component: 'text', icon: 'TextInput', imports: ['IdsInputModule'] };
  };

  // Generate Angular components from parsed screens
  const generateComponents = useCallback(() => {
    if (!parsedData?.screens) return;

    setIsGenerating(true);

    setTimeout(() => {
      const components = parsedData.screens.map(screen => {
        const componentName = toPascalCase(
          (screen.title || screen.name || screen.filename)
            .replace(/\.xml$/i, '')
            .replace(/[^a-zA-Z0-9]/g, ' ')
        );

        const fields = (screen.fields || []).map(field => ({
          ...field,
          formControlName: toCamelCase(field.name || 'field'),
          idsMapping: mapFieldToComponent(field)
        }));

        const lists = (screen.lists || []).map(list => ({
          ...list,
          columns: list.columns || []
        }));

        return {
          name: componentName,
          filename: screen.filename,
          path: screen.path,
          fields,
          lists,
          navigations: screen.navigations || [],
          template: generateTemplate(componentName, fields, lists),
          typescript: generateTypeScript(componentName, fields, lists)
        };
      });

      setGeneratedCode({
        components,
        totalFields: components.reduce((sum, c) => sum + c.fields.length, 0),
        totalLists: components.reduce((sum, c) => sum + c.lists.length, 0)
      });

      setIsGenerating(false);
    }, 500);
  }, [parsedData]);

  // Generate Angular template
  const generateTemplate = (componentName, fields, lists) => {
    const lines = [
      `<form [formGroup]="form" (ngSubmit)="onSubmit()">`,
      `  <div class="${componentName.toLowerCase()}-container">`
    ];

    // Generate field templates
    for (const field of fields) {
      const { component } = field.idsMapping || {};
      const label = field.name || 'Campo';
      const formControlName = field.formControlName || toCamelCase(label);

      switch (component) {
        case 'date':
          lines.push(`    <!-- Date: ${label} -->`);
          lines.push(`    <ids-form-field [label]="'${label}'">`);
          lines.push(`      <ids-datepicker formControlName="${formControlName}" placeholder="DD/MM/AAAA"></ids-datepicker>`);
          lines.push(`    </ids-form-field>`);
          break;

        case 'select':
          lines.push(`    <!-- Select: ${label} -->`);
          lines.push(`    <ids-form-field [label]="'${label}'">`);
          lines.push(`      <ids-select formControlName="${formControlName}" placeholder="Selecione...">`);
          lines.push(`        <ids-option *ngFor="let opt of ${formControlName}Options" [value]="opt.value">{{ opt.label }}</ids-option>`);
          lines.push(`      </ids-select>`);
          lines.push(`    </ids-form-field>`);
          break;

        case 'currency':
          lines.push(`    <!-- Currency: ${label} -->`);
          lines.push(`    <ids-form-field [label]="'${label}'">`);
          lines.push(`      <input idsInput formControlName="${formControlName}" [idsMask]="currencyMask" inputmode="decimal" />`);
          lines.push(`    </ids-form-field>`);
          break;

        case 'masked':
          lines.push(`    <!-- Masked Input: ${label} -->`);
          lines.push(`    <ids-form-field [label]="'${label}'">`);
          lines.push(`      <input idsInput formControlName="${formControlName}" [idsMask]="cpfCnpjMask" />`);
          lines.push(`    </ids-form-field>`);
          break;

        default:
          lines.push(`    <!-- Text: ${label} -->`);
          lines.push(`    <ids-form-field [label]="'${label}'">`);
          lines.push(`      <input idsInput formControlName="${formControlName}" ${field.size ? `maxlength="${field.size}"` : ''} />`);
          lines.push(`    </ids-form-field>`);
      }
      lines.push('');
    }

    // Generate list/table templates
    for (const list of lists) {
      const listName = list.name || 'Lista';
      lines.push(`    <!-- Data Table: ${listName} -->`);
      lines.push(`    <ids-table [dataSource]="${toCamelCase(listName)}Data">`);
      for (const col of list.columns || []) {
        lines.push(`      <ng-container idsColumnDef="${toCamelCase(col.name || 'col')}">`);
        lines.push(`        <th *idsHeaderCellDef>${col.name || 'Coluna'}</th>`);
        lines.push(`        <td *idsCellDef="let row">{{ row.${toCamelCase(col.name || 'col')} }}</td>`);
        lines.push(`      </ng-container>`);
      }
      lines.push(`    </ids-table>`);
      lines.push('');
    }

    // Action buttons
    lines.push(`    <div class="button-group">`);
    lines.push(`      <button idsMainButton variant="secondary" type="button" (click)="onVoltar()">Voltar</button>`);
    lines.push(`      <button idsMainButton variant="primary" type="submit" [disabled]="form.invalid">Enviar</button>`);
    lines.push(`    </div>`);

    lines.push('  </div>');
    lines.push('</form>');

    return lines.join('\n');
  };

  // Generate TypeScript component
  const generateTypeScript = (componentName, fields, lists) => {
    const lines = [
      `import { Component, OnInit, inject, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';`,
      `import { CommonModule } from '@angular/common';`,
      `import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';`,
      `import { IdsMainButtonModule, IdsFormFieldModule, IdsInputModule } from '@ids/angular';`,
      ``,
      `@Component({`,
      `  selector: 'app-${componentName.toLowerCase()}',`,
      `  standalone: true,`,
      `  imports: [CommonModule, ReactiveFormsModule, IdsMainButtonModule, IdsFormFieldModule, IdsInputModule],`,
      `  schemas: [CUSTOM_ELEMENTS_SCHEMA],`,
      `  templateUrl: './${componentName.toLowerCase()}.component.html',`,
      `  styleUrls: ['./${componentName.toLowerCase()}.component.scss']`,
      `})`,
      `export class ${componentName}Component implements OnInit {`,
      `  private fb = inject(FormBuilder);`,
      `  form!: FormGroup;`,
      ``
    ];

    // Add options for selects
    for (const field of fields) {
      if (field.idsMapping?.component === 'select') {
        lines.push(`  ${field.formControlName}Options: { value: string; label: string }[] = [];`);
      }
    }

    // Add data sources for tables
    for (const list of lists) {
      lines.push(`  ${toCamelCase(list.name || 'lista')}Data: any[] = [];`);
    }

    lines.push(``);
    lines.push(`  ngOnInit(): void {`);
    lines.push(`    this.form = this.fb.group({`);

    for (const field of fields) {
      lines.push(`      ${field.formControlName}: [''],`);
    }

    lines.push(`    });`);
    lines.push(`  }`);
    lines.push(``);
    lines.push(`  onSubmit(): void {`);
    lines.push(`    console.log('Form submitted:', this.form.value);`);
    lines.push(`  }`);
    lines.push(``);
    lines.push(`  onVoltar(): void {`);
    lines.push(`    // Navigate back`);
    lines.push(`  }`);
    lines.push(`}`);

    return lines.join('\n');
  };

  // Apply variable substitutions to template content
  const applyTemplateVars = useCallback((content, vars) => {
    let result = content;
    // Replace template variables like {{mfeName}}, {{mfePort}}, etc.
    for (const [key, value] of Object.entries(vars)) {
      const regex = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
      result = result.replace(regex, value);
    }
    // Also replace mfe-base with actual project name in common patterns
    result = result.replace(/mfe-base/g, vars.mfeName);
    result = result.replace(/MfeBase/g, vars.mfeNamePascal);
    return result;
  }, []);

  // Generate Go service variables substitution
  const applyGoTemplateVars = useCallback((content, vars) => {
    let result = content;
    // Replace Go-specific patterns
    result = result.replace(/comex-service/g, vars.serviceName);
    result = result.replace(/comex_service/g, vars.serviceNameSnake);
    result = result.replace(/ComexService/g, vars.serviceNamePascal);
    result = result.replace(/comexService/g, vars.serviceNameCamel);
    result = result.replace(/com\/itau\/comex/g, `com/itau/${vars.serviceNameSnake}`);
    return result;
  }, []);

  // Generate Java service variables substitution
  const applyJavaTemplateVars = useCallback((content, vars) => {
    let result = content;
    // Replace Java-specific patterns
    result = result.replace(/comex-service-java/g, vars.serviceName);
    result = result.replace(/com\.itau\.comex/g, `com.itau.${vars.serviceNameSnake}`);
    result = result.replace(/com\/itau\/comex/g, `com/itau/${vars.serviceNameSnake}`);
    result = result.replace(/ComexService/g, vars.serviceNamePascal);
    result = result.replace(/comexService/g, vars.serviceNameCamel);
    result = result.replace(/<artifactId>comex<\/artifactId>/g, `<artifactId>${vars.serviceNameSnake}</artifactId>`);
    result = result.replace(/<name>comex<\/name>/g, `<name>${vars.serviceName}</name>`);
    return result;
  }, []);

  // Generate and download project as ZIP (using template bundles)
  const handleDownload = useCallback(async () => {
    if (!generatedCode) return;

    setIsDownloading(true);

    try {
      const zip = new JSZip();
      const mfeName = toKebabCase(projectName);
      const mfeNamePascal = toPascalCase(projectName);
      const mfeNameCamel = mfeNamePascal.charAt(0).toLowerCase() + mfeNamePascal.slice(1);
      const serviceNameSnake = mfeName.replace(/-/g, '_');

      // Check which platforms are selected
      const hasAngular = selectedPlatforms.angular;
      const hasGo = selectedPlatforms.go;
      const hasJava = selectedPlatforms.java;
      const hasBackend = hasGo || hasJava;

      // Determine folder structure
      const frontendPrefix = hasBackend ? 'frontend/' : '';
      const backendPrefix = hasAngular ? 'backend/' : '';

      // Template variables for substitution
      const templateVars = {
        mfeName,
        mfeNamePascal,
        mfeNameCamel,
        mfePort: String(mfePort),
        transactionId: parsedData?.transactionId || 'XXXX',
        serviceName: `${mfeName}-service`,
        serviceNamePascal: `${mfeNamePascal}Service`,
        serviceNameCamel: `${mfeNameCamel}Service`,
        serviceNameSnake: serviceNameSnake
      };

      // ========================================
      // ANGULAR FRONTEND
      // ========================================
      if (hasAngular && templateBundles.angular?.files) {
        console.log(`Adding Angular frontend with ${templateBundles.angular.fileCount} files`);

        // Files to skip (we'll generate custom versions)
        const skipFiles = new Set([
          'package.json',
          'angular.json',
          'webpack.config.js',
          'src/app/app.routes.ts',
          'README.md'
        ]);

        // Copy all template files with variable substitution
        for (const [filePath, content] of Object.entries(templateBundles.angular.files)) {
          if (skipFiles.has(filePath)) continue;

          // Apply variable substitution
          const processedContent = applyTemplateVars(content, templateVars);
          zip.file(`${frontendPrefix}${filePath}`, processedContent);
        }

        // Generate/override package.json with correct dependencies
        const basePackageJson = templateBundles.angular?.files?.['package.json']
          ? JSON.parse(templateBundles.angular.files['package.json'])
          : {};

        zip.file(`${frontendPrefix}package.json`, JSON.stringify({
          ...basePackageJson,
          name: mfeName,
          version: '1.0.0',
          description: `Angular MFE - ${mfeNamePascal} (Generated from QuickWeb)`,
          scripts: {
            ...basePackageJson.scripts,
            start: `ng serve --port ${mfePort}`,
            'start:mock': `ng serve --port ${mfePort} --configuration=dev-mock`,
          }
        }, null, 2));

        // Generate/override webpack.config.js
        const webpackConfig = templateBundles.angular?.files?.['webpack.config.js'] || '';
        const updatedWebpack = webpackConfig
          ? webpackConfig
              .replace(/uniqueName:\s*["'][^"']+["']/g, `uniqueName: "${mfeName}"`)
              .replace(/name:\s*["']mfe-base["']/g, `name: "${mfeName}"`)
          : `const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
module.exports = {
  output: { uniqueName: "${mfeName}", publicPath: "auto" },
  plugins: [
    new ModuleFederationPlugin({
      name: "${mfeName}",
      filename: "remoteEntry.js",
      exposes: { "./routes": "./src/app/app.routes.ts" },
      shared: {
        "@angular/core": { singleton: true, strictVersion: true },
        "@angular/common": { singleton: true, strictVersion: true },
        "@angular/router": { singleton: true, strictVersion: true }
      }
    })
  ]
};`;
        zip.file(`${frontendPrefix}webpack.config.js`, updatedWebpack);

        // Generate/override angular.json
        const baseAngularJson = templateBundles.angular?.files?.['angular.json']
          ? JSON.parse(templateBundles.angular.files['angular.json'])
          : { $schema: './node_modules/@angular/cli/lib/config/schema.json', version: 1 };

        const angularJsonProjects = {};
        if (baseAngularJson.projects) {
          const oldProjectName = Object.keys(baseAngularJson.projects)[0];
          if (oldProjectName) {
            angularJsonProjects[mfeName] = baseAngularJson.projects[oldProjectName];
          }
        }

        zip.file(`${frontendPrefix}angular.json`, JSON.stringify({
          ...baseAngularJson,
          projects: Object.keys(angularJsonProjects).length > 0
            ? angularJsonProjects
            : { [mfeName]: { projectType: 'application', root: '', sourceRoot: 'src', prefix: 'app' } },
          defaultProject: mfeName
        }, null, 2));

        // Generate routes with generated components
        const existingRoutes = templateBundles.angular?.files?.['src/app/app.routes.ts'] || '';
        const generatedImports = generatedCode.components
          .map(c => `import { ${c.name}Component } from './features/${c.name.toLowerCase()}/${c.name.toLowerCase()}.component';`)
          .join('\n');
        const generatedRoutes = generatedCode.components
          .map((c, i) => `  { path: '${c.name.toLowerCase()}', component: ${c.name}Component }`)
          .join(',\n');

        let routesContent;
        if (existingRoutes && existingRoutes.includes('export const routes')) {
          const importSection = existingRoutes.match(/import[\s\S]*?(?=export const routes)/)?.[0] || '';
          const routesSection = existingRoutes.match(/export const routes[\s\S]*/)?.[0] || '';
          const updatedRoutes = routesSection.replace(
            /export const routes:\s*Routes\s*=\s*\[/,
            `export const routes: Routes = [\n  // Generated from QuickWeb XML\n${generatedRoutes},\n  // Existing routes`
          );
          routesContent = `${generatedImports}\n${importSection}${updatedRoutes}`;
        } else {
          routesContent = `import { Routes } from '@angular/router';\n${generatedImports}\n\nexport const routes: Routes = [\n${generatedRoutes}\n];`;
        }
        zip.file(`${frontendPrefix}src/app/app.routes.ts`, routesContent);

        // Generate component files
        for (const component of generatedCode.components) {
          const compPath = `${frontendPrefix}src/app/features/${component.name.toLowerCase()}`;
          zip.file(`${compPath}/${component.name.toLowerCase()}.component.ts`, component.typescript);
          zip.file(`${compPath}/${component.name.toLowerCase()}.component.html`, component.template);
          zip.file(`${compPath}/${component.name.toLowerCase()}.component.scss`, `// Styles for ${component.name}Component\n.${component.name.toLowerCase()}-container {\n  padding: var(--ids-spacing-md, 1rem);\n  .button-group { display: flex; gap: 0.5rem; margin-top: 1.5rem; justify-content: flex-end; }\n}\n`);
        }

        // Frontend README
        zip.file(`${frontendPrefix}README.md`, `# ${mfeNamePascal} - Frontend\n\nAngular MFE generated from QuickWeb XML.\n\n## Quick Start\n\`\`\`bash\nnpm install\nnpm start\n\`\`\`\n\nServer: http://localhost:${mfePort}\n`);
      }

      // ========================================
      // GO BACKEND
      // ========================================
      if (hasGo && templateBundles.go?.files) {
        console.log(`Adding Go backend with ${templateBundles.go.fileCount} files`);

        for (const [filePath, content] of Object.entries(templateBundles.go.files)) {
          const processedContent = applyGoTemplateVars(content, templateVars);
          zip.file(`${backendPrefix}${filePath}`, processedContent);
        }

        // Go README
        zip.file(`${backendPrefix}README.md`, `# ${mfeNamePascal} - Go Backend Service

## Overview
Go backend service with adapters for Oracle, MQ, REST APIs.

## Quick Start
\`\`\`bash
go mod download
go run cmd/main.go
\`\`\`

## Build
\`\`\`bash
go build -o bin/service cmd/main.go
\`\`\`

## Adapters
- Oracle DB adapter
- IBM MQ adapter
- REST API adapter
- Mock adapter (for testing)
`);
      }

      // ========================================
      // JAVA BACKEND
      // ========================================
      if (hasJava && templateBundles.java?.files) {
        console.log(`Adding Java backend with ${templateBundles.java.fileCount} files`);

        for (const [filePath, content] of Object.entries(templateBundles.java.files)) {
          // Rename paths for Java package structure
          let newPath = filePath;
          if (filePath.includes('com/itau/comex')) {
            newPath = filePath.replace('com/itau/comex', `com/itau/${templateVars.serviceNameSnake}`);
          }
          const processedContent = applyJavaTemplateVars(content, templateVars);
          zip.file(`${backendPrefix}${newPath}`, processedContent);
        }

        // Java README
        zip.file(`${backendPrefix}README.md`, `# ${mfeNamePascal} - Java Backend Service

## Overview
Spring Boot backend service with REST endpoints.

## Quick Start
\`\`\`bash
mvn spring-boot:run
\`\`\`

## Build
\`\`\`bash
mvn clean package
java -jar target/*.jar
\`\`\`

## Endpoints
- GET /api/health - Health check
- See controller classes for API endpoints
`);
      }

      // ========================================
      // ROOT README (for multi-project)
      // ========================================
      if (hasAngular && hasBackend) {
        const backendType = hasGo ? 'Go' : 'Java';
        zip.file('README.md', `# ${mfeNamePascal} - Full Stack Project

## Overview
Full stack project generated from QuickWeb XML files.

- **Transaction**: ${parsedData?.transactionId || 'N/A'}
- **Generated**: ${new Date().toISOString()}
- **Frontend**: Angular MFE (port ${mfePort})
- **Backend**: ${backendType} Service

## Project Structure
\`\`\`
${mfeName}/
├── frontend/          # Angular MFE
│   ├── src/
│   ├── package.json
│   └── webpack.config.js
└── backend/           # ${backendType} Service
    ${hasGo ? '├── cmd/\n    ├── internal/\n    └── go.mod' : '├── src/\n    ├── pom.xml\n    └── application.yml'}
\`\`\`

## Quick Start

### Frontend
\`\`\`bash
cd frontend
npm install
npm start
\`\`\`

### Backend
\`\`\`bash
cd backend
${hasGo ? 'go run cmd/main.go' : 'mvn spring-boot:run'}
\`\`\`

## License
Internal use only - Itaú Unibanco
`);
      }

      // Determine download filename
      let downloadName = mfeName;
      if (hasAngular && hasBackend) {
        downloadName = `${mfeName}-fullstack`;
      } else if (hasBackend && !hasAngular) {
        downloadName = `${mfeName}-service`;
      }

      // Generate ZIP blob and download
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${downloadName}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

    } catch (error) {
      console.error('Error generating ZIP:', error);
    } finally {
      setIsDownloading(false);
    }
  }, [generatedCode, projectName, mfePort, templateBundles, selectedPlatforms, applyTemplateVars, applyGoTemplateVars, applyJavaTemplateVars, parsedData]);

  // Copy to clipboard
  const handleCopy = useCallback((text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedField(id);
    setTimeout(() => setCopiedField(null), 2000);
  }, []);

  // Summary stats
  const stats = useMemo(() => ({
    screens: parsedData?.screens?.length || 0,
    services: parsedData?.services?.length || 0,
    configs: parsedData?.configs?.length || 0,
    errors: parsedData?.errors?.length || 0,
    totalFiles: parsedData?.totalFiles || 0
  }), [parsedData]);

  return (
    <div className={styles.generatorContainer}>
      {/* Header */}
      <div className={styles.header}>
        <div className={styles.headerTitle}>
          <Code size={24} />
          <div>
            <h2>Gerador de Código</h2>
            <p>Gere código fullstack a partir dos arquivos XML analisados</p>
          </div>
        </div>

        <div className={styles.projectConfig}>
          <div className={styles.configField}>
            <label>Nome do Projeto:</label>
            {editingName ? (
              <div className={styles.editRow}>
                <TextInput
                  id="project-name"
                  size="sm"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                />
                <Button
                  kind="ghost"
                  size="sm"
                  hasIconOnly
                  renderIcon={Checkmark}
                  iconDescription="Confirm"
                  onClick={() => setEditingName(false)}
                />
              </div>
            ) : (
              <div className={styles.displayRow}>
                <code>{toKebabCase(projectName)}</code>
                <Button
                  kind="ghost"
                  size="sm"
                  hasIconOnly
                  renderIcon={Edit}
                  iconDescription="Edit"
                  onClick={() => setEditingName(true)}
                />
              </div>
            )}
          </div>

          {selectedPlatforms.angular && (
            <div className={styles.configField}>
              <label>Porta MFE:</label>
              <NumberInput
                id="mfe-port"
                size="sm"
                min={5000}
                max={6000}
                value={mfePort}
                onChange={(e, { value }) => setMfePort(value)}
                hideSteppers
                className={styles.portInput}
              />
            </div>
          )}
        </div>

        {/* Platform Selector - Multi-selection */}
        <div className={styles.platformSelector}>
          <label className={styles.platformLabel}>Plataformas de Destino:</label>

          {/* Frontend Section */}
          <div className={styles.platformSection}>
            <div className={styles.platformSectionHeader}>
              <Screen size={16} />
              <span>Frontend</span>
            </div>
            <div className={styles.platformOptions}>
              {TARGET_PLATFORMS.frontend.map((platform) => (
                <button
                  key={platform.id}
                  className={`${styles.platformOption} ${selectedPlatforms[platform.id] ? styles.platformSelected : ''}`}
                  onClick={() => togglePlatform(platform.id, 'frontend')}
                  style={{
                    '--platform-color': platform.color,
                    borderColor: selectedPlatforms[platform.id] ? platform.color : undefined
                  }}
                >
                  <div className={styles.platformIcon} style={{ color: platform.color }}>
                    {platform.icon === 'Screen' && <Screen size={24} />}
                  </div>
                  <div className={styles.platformInfo}>
                    <div className={styles.platformName}>{platform.name}</div>
                    <div className={styles.platformDesc}>{platform.description}</div>
                  </div>
                  {selectedPlatforms[platform.id] && (
                    <div className={styles.platformCheck} style={{ background: platform.color }}>
                      <Checkmark size={16} />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Backend Section */}
          <div className={styles.platformSection}>
            <div className={styles.platformSectionHeader}>
              <Api size={16} />
              <span>Backend</span>
              <Tag type="gray" size="sm">Selecione um</Tag>
            </div>
            <div className={styles.platformOptions}>
              {TARGET_PLATFORMS.backend.map((platform) => (
                <button
                  key={platform.id}
                  className={`${styles.platformOption} ${selectedPlatforms[platform.id] ? styles.platformSelected : ''}`}
                  onClick={() => togglePlatform(platform.id, 'backend')}
                  style={{
                    '--platform-color': platform.color,
                    borderColor: selectedPlatforms[platform.id] ? platform.color : undefined
                  }}
                >
                  <div className={styles.platformIcon} style={{ color: platform.color }}>
                    {platform.icon === 'Terminal' && <Terminal size={24} />}
                    {platform.icon === 'Code' && <Code size={24} />}
                  </div>
                  <div className={styles.platformInfo}>
                    <div className={styles.platformName}>{platform.name}</div>
                    <div className={styles.platformDesc}>{platform.description}</div>
                  </div>
                  {selectedPlatforms[platform.id] && (
                    <div className={styles.platformCheck} style={{ background: platform.color }}>
                      <Checkmark size={16} />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Selection Summary */}
          <div className={styles.platformSummary}>
            <span>Selecionados:</span>
            {getSelectedPlatformsList().map(p => (
              <Tag key={p.id} type="blue" size="sm" style={{ borderLeft: `3px solid ${p.color}` }}>
                {p.name}
              </Tag>
            ))}
            {!hasSelectedPlatforms && (
              <Tag type="red" size="sm">Nenhuma plataforma selecionada</Tag>
            )}
          </div>
        </div>
      </div>

      {/* Stats Summary */}
      <div className={styles.statsGrid}>
        <div className={styles.statCard}>
          <Screen size={24} />
          <div className={styles.statValue}>{stats.screens}</div>
          <div className={styles.statLabel}>Screens</div>
        </div>
        <div className={styles.statCard}>
          <Api size={24} />
          <div className={styles.statValue}>{stats.services}</div>
          <div className={styles.statLabel}>Services</div>
        </div>
        <div className={styles.statCard}>
          <Folder size={24} />
          <div className={styles.statValue}>{stats.configs}</div>
          <div className={styles.statLabel}>Configs</div>
        </div>
        <div className={styles.statCard}>
          <Document size={24} />
          <div className={styles.statValue}>{stats.totalFiles}</div>
          <div className={styles.statLabel}>Total Files</div>
        </div>
      </div>

      {/* Backend Types Analysis */}
      {Object.keys(backendTypesAnalysis).length > 0 && (
        <div className={styles.backendTypesSection}>
          <h3>Tipos de Backend Detectados</h3>
          <div className={styles.backendTypesGrid}>
            {Object.values(backendTypesAnalysis).map((typeInfo) => (
              <div
                key={typeInfo.id}
                className={styles.backendTypeCard}
                style={{ borderLeftColor: typeInfo.color }}
              >
                <div className={styles.backendTypeIcon} style={{ color: typeInfo.color }}>
                  {getBackendTypeIcon(typeInfo.id)}
                </div>
                <div className={styles.backendTypeInfo}>
                  <div className={styles.backendTypeName}>{typeInfo.name}</div>
                  <div className={styles.backendTypeCount}>{typeInfo.count} arquivos</div>
                </div>
                <Tag type="gray" size="sm">{typeInfo.id}</Tag>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className={styles.actions}>
        <Button
          kind="secondary"
          onClick={onBack}
        >
          Voltar
        </Button>

        <Button
          kind="primary"
          renderIcon={isGenerating ? InlineLoading : Code}
          onClick={generateComponents}
          disabled={isGenerating || stats.screens === 0 || !hasSelectedPlatforms}
        >
          {isGenerating ? 'Gerando...' : `Gerar Código (${getSelectedPlatformsList().length} plataformas)`}
        </Button>

        {generatedCode && (
          <Button
            kind="tertiary"
            renderIcon={isDownloading ? InlineLoading : Download}
            onClick={handleDownload}
            disabled={isDownloading}
          >
            {isDownloading ? 'Baixando...' : 'Baixar Projeto (.zip)'}
          </Button>
        )}

        {/* Platform indicators */}
        <div className={styles.platformIndicator}>
          {getSelectedPlatformsList().map(p => (
            <Tag key={p.id} type="blue" size="sm" style={{ borderLeft: `3px solid ${p.color}` }}>
              {p.name}
            </Tag>
          ))}
        </div>
      </div>

      {/* Generated Components */}
      {generatedCode && (
        <div className={styles.generatedSection}>
          <h3>
            <FolderDetails size={20} />
            Componentes Gerados ({generatedCode.components.length})
          </h3>

          <Accordion>
            {generatedCode.components.map((comp, i) => (
              <AccordionItem
                key={i}
                title={
                  <div className={styles.accordionTitle}>
                    <Screen size={16} />
                    <span>{comp.name}Component</span>
                    <Tag type="gray" size="sm">{comp.filename}</Tag>
                    <Tag type="blue" size="sm">{comp.fields.length} fields</Tag>
                    {comp.lists.length > 0 && (
                      <Tag type="teal" size="sm">{comp.lists.length} lists</Tag>
                    )}
                  </div>
                }
              >
                {/* Fields Table */}
                {comp.fields.length > 0 && (
                  <div className={styles.fieldsTable}>
                    <h4>Fields Mapping</h4>
                    <div className={styles.tableGrid}>
                      <div className={styles.tableHeader}>
                        <span>Field Name</span>
                        <span>IDS Component</span>
                        <span>Form Control</span>
                      </div>
                      {comp.fields.map((field, j) => (
                        <div key={j} className={styles.tableRow}>
                          <span>{field.name}</span>
                          <span><code>{field.idsMapping?.component}</code></span>
                          <span><code>{field.formControlName}</code></span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Template Preview */}
                <div className={styles.codeSection}>
                  <div className={styles.codeSectionHeader}>
                    <span>{comp.name.toLowerCase()}.component.html</span>
                    <Button
                      kind="ghost"
                      size="sm"
                      hasIconOnly
                      renderIcon={copiedField === `html-${i}` ? Checkmark : Copy}
                      iconDescription="Copy"
                      onClick={() => handleCopy(comp.template, `html-${i}`)}
                    />
                  </div>
                  <pre className={styles.codeBlock}>{comp.template}</pre>
                </div>

                {/* TypeScript Preview */}
                <div className={styles.codeSection}>
                  <div className={styles.codeSectionHeader}>
                    <span>{comp.name.toLowerCase()}.component.ts</span>
                    <Button
                      kind="ghost"
                      size="sm"
                      hasIconOnly
                      renderIcon={copiedField === `ts-${i}` ? Checkmark : Copy}
                      iconDescription="Copy"
                      onClick={() => handleCopy(comp.typescript, `ts-${i}`)}
                    />
                  </div>
                  <pre className={styles.codeBlock}>{comp.typescript}</pre>
                </div>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      )}
    </div>
  );
};

export default ProjectGenerator;
