import { useState, useRef, useEffect } from 'react';
import styles from './DiagramDetailsPanel.module.scss';

/**
 * DiagramDetailsPanel Component
 * Shows detailed information about a selected node or edge
 */
const DiagramDetailsPanel = ({
  nodeData,
  isVisible,
  onClose,
  focusDepth,
  onFocusDepthChange,
  isFocusMode,
  onApplyFocus
}) => {
  const [moreDetailsExpanded, setMoreDetailsExpanded] = useState(false);
  const [position, setPosition] = useState({ top: 16, right: 16 }); // 1rem = 16px
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef({ startX: 0, startY: 0, startTop: 0, startRight: 0 });
  const panelRef = useRef(null);

  // Drag event handlers
  const handleDragStart = (e) => {
    e.preventDefault();
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      startTop: position.top,
      startRight: position.right,
    };
  };

  useEffect(() => {
    const handleDragMove = (e) => {
      if (!isDragging) return;

      const deltaX = dragRef.current.startX - e.clientX;
      const deltaY = e.clientY - dragRef.current.startY;

      setPosition({
        top: Math.max(0, dragRef.current.startTop + deltaY),
        right: Math.max(0, dragRef.current.startRight + deltaX),
      });
    };

    const handleDragEnd = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      document.addEventListener('mousemove', handleDragMove);
      document.addEventListener('mouseup', handleDragEnd);
    }

    return () => {
      document.removeEventListener('mousemove', handleDragMove);
      document.removeEventListener('mouseup', handleDragEnd);
    };
  }, [isDragging]);

  // Early return AFTER all hooks
  if (!isVisible || !nodeData) {
    return null;
  }

  // Detect if this is an edge (relationship) or node
  const isEdge = nodeData.source !== undefined && nodeData.target !== undefined;

  // Extract original data
  const original = nodeData.original || {};

  // Build different field sets based on whether this is an edge or node
  let basicFields = [];
  let allAdditionalFields = [];
  let panelTitle = 'Detalhes do Objeto';

  if (isEdge) {
    // EDGE (Relationship) details
    panelTitle = 'Detalhes da Relação';

    // Basic edge fields
    basicFields = [
      { label: 'Origem', value: nodeData.source },
      { label: 'Destino', value: nodeData.target },
      { label: 'Tipo', value: nodeData.type },
      { label: 'Prioridade', value: nodeData.priority || '0' },
    ];

    // Add flow step if present
    if (nodeData.flowStep && nodeData.flowStep !== '') {
      basicFields.push({
        label: 'Passo do Fluxo',
        value: `Passo ${nodeData.flowStep} (sequência de navegação)`
      });
    }

    // Condition section (if present)
    if (nodeData.conditionFull || nodeData.condition) {
      const conditionText = nodeData.conditionFull || nodeData.condition || '';
      if (conditionText && conditionText.length > 0) {
        basicFields.push({
          label: 'Condição',
          value: conditionText,
          isMultiline: true // Flag for special rendering
        });
      }
    }

    // Add all other edge attributes to additional fields
    Object.keys(nodeData).forEach(key => {
      if (!['id', 'source', 'target', 'type', 'label', 'priority', 'condition', 'conditionFull', 'color', 'original'].includes(key)) {
        if (nodeData[key] !== '' && nodeData[key] !== null && nodeData[key] !== undefined) {
          allAdditionalFields.push({
            label: key,
            value: typeof nodeData[key] === 'object' ? JSON.stringify(nodeData[key], null, 2) : String(nodeData[key]),
            isMetric: false,
          });
        }
      }
    });

    // Add original edge data if available
    if (original && Object.keys(original).length > 0) {
      Object.keys(original).forEach(key => {
        if (original[key] !== '' && original[key] !== null) {
          allAdditionalFields.push({
            label: `Original.${key}`,
            value: typeof original[key] === 'object' ? JSON.stringify(original[key], null, 2) : String(original[key]),
            isMetric: false,
          });
        }
      });
    }
  } else {
    // NODE details (existing logic)
    panelTitle = 'Detalhes do Objeto';

    basicFields = [
      { label: 'Nome', value: original['Object Name'] || nodeData.label },
      { label: 'Nome Completo', value: original['Object Full Name'] || nodeData.fullName },
      { label: 'Tipo', value: original['Object Type'] || nodeData.type },
      { label: 'ID', value: original['Object ID'] || nodeData.id },
    ];

    // Additional metrics fields (displayed in 2-column grid)
    const metricsFields = [
      { key: 'Cyclomatic Complexity', label: 'Complexidade Ciclomática' },
      { key: 'Essential Complexity', label: 'Complexidade Essencial' },
      { key: 'Integration Complexity', label: 'Complexidade de Integração' },
      { key: 'Linked Objects', label: 'Objetos Vinculados' },
      { key: 'Number of code lines', label: '# Linhas de Código' },
      { key: 'Number of heading comment lines', label: '# Comentários de Cabeçalho' },
      { key: 'Number of inner comment lines', label: '# Comentários Internos' },
    ];

    // Filter valid metrics
    const validMetrics = metricsFields.filter(
      field => original[field.key] && original[field.key] !== ''
    );

    // Get all other fields not already shown (for combined "More Details")
    const shownKeys = new Set([
      'Object Name',
      'Object Full Name',
      'Object Type',
      'Object ID',
    ]);

    const excludedKeys = new Set(['Callee', 'Caller', 'Object File Name', 'Module']);

    // Add metrics fields
    validMetrics.forEach(field => {
      allAdditionalFields.push({
        label: field.label,
        value: original[field.key],
        isMetric: true,
      });
    });

    // Add other fields
    Object.keys(original).forEach(key => {
      if (!shownKeys.has(key) &&
          !excludedKeys.has(key) &&
          !metricsFields.some(f => f.key === key) &&
          original[key] !== '' &&
          original[key] !== null) {
        allAdditionalFields.push({
          label: key,
          value: original[key],
          isMetric: false,
        });
      }
    });
  }

  return (
    <div
      ref={panelRef}
      className={`${styles.detailsPanel} ${isDragging ? styles.dragging : ''}`}
      style={{
        top: `${position.top}px`,
        right: `${position.right}px`,
      }}
    >
      <div className={styles.header}>
        <div className={styles.headerDragArea} onMouseDown={handleDragStart}>
          <h3>{panelTitle}</h3>
        </div>
        <button className={styles.closeButton} onClick={onClose} aria-label="Fechar detalhes">
          ✕
        </button>
      </div>

      <div className={styles.content}>
        {/* Basic properties - always visible */}
        {basicFields.map((field, index) => (
          <div key={index} className={field.isMultiline ? styles.detailRowColumn : styles.detailRow}>
            <div className={styles.label}>{field.label}:</div>
            <div className={field.isMultiline ? styles.valueMultiline : styles.value}>
              {field.value || 'Não definido'}
            </div>
          </div>
        ))}

        {/* More details - collapsible (contains focus control for nodes, additional fields) */}
        <hr className={styles.separator} />
        <div className={styles.moreDetailsSection}>
          <button
            className={styles.moreDetailsToggle}
            onClick={() => setMoreDetailsExpanded(!moreDetailsExpanded)}
          >
            <span className={moreDetailsExpanded ? styles.iconExpanded : ''}>▼</span>
            <span>Mais Detalhes ({allAdditionalFields.length} campo{allAdditionalFields.length !== 1 ? 's' : ''})</span>
          </button>
          {moreDetailsExpanded && (
            <div className={styles.moreDetailsContent}>
              {/* Focus Depth Control - only for nodes */}
              {!isEdge && (
                <div className={styles.focusControl}>
                  <div className={styles.focusHeader}>
                    <label className={styles.focusLabel}>Profundidade do Foco</label>
                    <span className={styles.focusValue}>{focusDepth} nível{focusDepth > 1 ? 'is' : ''}</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="4"
                    step="1"
                    value={focusDepth}
                    onChange={(e) => onFocusDepthChange(parseInt(e.target.value))}
                    className={styles.slider}
                  />
                  <button
                    className={styles.applyButton}
                    onClick={onApplyFocus}
                  >
                    {isFocusMode ? 'Atualizar Foco' : 'Aplicar Foco'}
                  </button>
                </div>
              )}

              {/* Additional fields */}
              {allAdditionalFields.length > 0 && (
                <>
                  {!isEdge && <hr className={styles.separator} />}
                  {allAdditionalFields.map((field, index) => (
                    <div key={index} className={styles.detailRow}>
                      <div className={styles.label}>{field.label}:</div>
                      <div className={styles.value}>{field.value || 'Não definido'}</div>
                    </div>
                  ))}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DiagramDetailsPanel;
