import { useCallback, useMemo, useEffect, useState } from 'react';
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  MarkerType,
  Position,
  Handle,
  useReactFlow,
  ReactFlowProvider
} from '@xyflow/react';
import dagre from '@dagrejs/dagre';
import '@xyflow/react/dist/style.css';
import { Toggle, Tag } from '@carbon/react';
import {
  Screen,
  Api,
  DataBase,
  Terminal,
  Popup,
  CheckmarkFilled,
  ArrowRight,
  Help,
  Warning,
  Logout,
  Close,
  ConnectionSignal
} from '@carbon/icons-react';
import styles from './DecisionTreeGraph.module.scss';

// Decision node (diamond shape)
const DecisionNode = ({ data }) => {
  return (
    <div className={styles.decisionNode}>
      <Handle type="target" position={Position.Top} className={styles.handle} />
      <div className={styles.decisionDiamond} style={{ borderColor: data.color || '#d12771' }}>
        <Help size={20} />
      </div>
      <div className={styles.decisionLabel}>{data.label}</div>
      <div className={styles.decisionCondition}>{data.condition || 'Condition'}</div>
      <Handle type="source" position={Position.Bottom} className={styles.handle} id="default" />
      <Handle type="source" position={Position.Left} className={styles.handle} id="left" />
      <Handle type="source" position={Position.Right} className={styles.handle} id="right" />
    </div>
  );
};

// Screen node (rectangle)
const ScreenNode = ({ data }) => {
  const getIcon = () => {
    if (data.isExit) return <Logout size={20} />;
    if (data.isFinal) return <CheckmarkFilled size={20} />;
    if (data.isPopup) return <Popup size={20} />;
    return <Screen size={20} />;
  };

  return (
    <div
      className={`${styles.screenNode} ${data.isMainFlow ? styles.mainFlowNode : ''} ${data.isExit ? styles.exitNode : ''}`}
      style={{ borderColor: data.color || '#0f62fe' }}
      title={`${data.label}\n${data.description || ''}\nMódulo: ${data.module || 'N/A'}`}
    >
      <Handle type="target" position={Position.Top} className={styles.handle} />
      <div className={styles.screenIcon} style={{ background: data.color || '#0f62fe' }}>
        {getIcon()}
      </div>
      <div className={styles.screenContent}>
        <div className={styles.screenLabel}>{data.label}</div>
        <div className={styles.screenDescription}>{data.description}</div>
        <div className={styles.screenType}>{data.type}{data.module ? ` · ${data.module}` : ''}</div>
      </div>
      <Handle type="source" position={Position.Bottom} className={styles.handle} />
    </div>
  );
};

// Service node (rounded)
const ServiceNode = ({ data }) => {
  const getIcon = () => {
    switch (data.serviceType) {
      case 'WebService': return <Api size={18} />;
      case 'Database': return <DataBase size={18} />;
      case 'Mainframe': return <Terminal size={18} />;
      default: return <Api size={18} />;
    }
  };

  const getServiceTypeLabel = () => {
    switch (data.serviceType) {
      case 'WebService': return 'Web Service';
      case 'Database': return 'Banco de Dados';
      case 'Mainframe': return 'Mainframe';
      default: return data.serviceType;
    }
  };

  return (
    <div
      className={styles.serviceNode}
      style={{ borderColor: data.color || '#6929c4' }}
      title={`${data.label}\n${data.description || getServiceTypeLabel()}\nMódulo: ${data.module || 'N/A'}`}
    >
      <Handle type="target" position={Position.Top} className={styles.handle} />
      <div className={styles.serviceIcon} style={{ background: data.color || '#6929c4' }}>
        {getIcon()}
      </div>
      <div className={styles.serviceLabel}>{data.label}</div>
      <div className={styles.serviceType}>{getServiceTypeLabel()}</div>
      <Handle type="source" position={Position.Bottom} className={styles.handle} />
    </div>
  );
};

// Entry node (circle)
const EntryNode = ({ data }) => {
  return (
    <div className={styles.entryNode}>
      <div className={styles.entryCircle} style={{ background: data.color || '#0f62fe' }}>
        <ArrowRight size={24} />
      </div>
      <div className={styles.entryLabel}>{data.label}</div>
      <Handle type="source" position={Position.Bottom} className={styles.handle} />
    </div>
  );
};

// Exit node (double circle)
const ExitNode = ({ data }) => {
  return (
    <div className={styles.exitNodeType}>
      <Handle type="target" position={Position.Top} className={styles.handle} />
      <div className={styles.exitCircle} style={{ borderColor: data.color || '#da1e28' }}>
        <Logout size={20} />
      </div>
      <div className={styles.exitLabel}>{data.label}</div>
    </div>
  );
};

const nodeTypes = {
  decision: DecisionNode,
  screen: ScreenNode,
  service: ServiceNode,
  entry: EntryNode,
  exit: ExitNode
};

// Custom edge with condition label
const ConditionEdge = ({ id, sourceX, sourceY, targetX, targetY, label, style, markerEnd }) => {
  const edgePath = `M ${sourceX} ${sourceY} L ${sourceX} ${(sourceY + targetY) / 2} L ${targetX} ${(sourceY + targetY) / 2} L ${targetX} ${targetY}`;

  return (
    <>
      <path id={id} className={styles.conditionEdgePath} d={edgePath} style={style} markerEnd={markerEnd} />
      {label && (
        <text>
          <textPath href={`#${id}`} startOffset="50%" textAnchor="middle" className={styles.conditionEdgeLabel}>
            {label}
          </textPath>
        </text>
      )}
    </>
  );
};

const edgeTypes = {
  condition: ConditionEdge
};

// Dagre layout helper
const getLayoutedElements = (nodes, edges, direction = 'TB') => {
  const dagreGraph = new dagre.graphlib.Graph();
  dagreGraph.setDefaultEdgeLabel(() => ({}));
  dagreGraph.setGraph({ rankdir: direction, ranksep: 80, nodesep: 50 });

  nodes.forEach((node) => {
    const width = node.type === 'decision' ? 120 : node.type === 'entry' || node.type === 'exit' ? 80 : 200;
    const height = node.type === 'decision' ? 100 : node.type === 'entry' || node.type === 'exit' ? 80 : 80;
    dagreGraph.setNode(node.id, { width, height });
  });

  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  const layoutedNodes = nodes.map((node) => {
    const nodeWithPosition = dagreGraph.node(node.id);
    const width = node.type === 'decision' ? 120 : node.type === 'entry' || node.type === 'exit' ? 80 : 200;
    const height = node.type === 'decision' ? 100 : node.type === 'entry' || node.type === 'exit' ? 80 : 80;

    return {
      ...node,
      position: {
        x: nodeWithPosition.x - width / 2,
        y: nodeWithPosition.y - height / 2
      }
    };
  });

  return { nodes: layoutedNodes, edges };
};

// Build decision tree from transaction data
const buildDecisionTree = (transactionData, filterByContext = true) => {
  if (!transactionData?.flow) {
    return { nodes: [], edges: [], edgeMetadata: {} };
  }

  const interactions = transactionData.flow.interactions || [];
  const flowGraph = transactionData.flow.flowGraph || {};
  const edgeMetadata = {}; // Store full edge info for click details

  const nodes = [];
  const edges = [];
  const nodeIds = new Set();

  // Helper to normalize ID
  const normalizeId = (id) => 'dt_' + (id || 'unknown').replace(/\\/g, '_').replace(/[^a-zA-Z0-9_]/g, '');

  // Helper to get interaction
  const getInteraction = (path) => interactions.find(i => i.path === path);

  // Build navigation info map: source -> target -> {condition, matchesContext, type}
  const navigationMap = {}; // source -> target -> navInfo
  const decisionPoints = new Set();

  for (const interaction of interactions) {
    const navs = interaction.navigations || [];
    const uniqueTargets = new Map(); // target -> navInfo (keep first/best match)

    for (const nav of navs) {
      const target = nav.target;
      if (!target) continue;

      // Build condition label - short version for edge display
      let conditionLabel = '';
      let conditionFull = '';
      if (nav.condition) {
        const { function: func, left, right } = nav.condition;
        // Full condition for details panel
        if (func === 'Igual' || func === 'equal') {
          conditionFull = `${left || '?'} = ${right || '?'}`;
          conditionLabel = conditionFull;
        } else if (func) {
          conditionFull = `${func}(${left || ''}, ${right || ''})`;
          // Short label: just show the key value being tested
          if (right && right !== '') {
            conditionLabel = `→ ${right}`;
          } else if (left && left !== '') {
            conditionLabel = `${left}`;
          } else {
            conditionLabel = func;
          }
        }
      } else if (nav.type === 'conditional') {
        conditionLabel = '?';
        conditionFull = 'conditional';
      }

      const navInfo = {
        condition: conditionLabel,
        conditionFull: conditionFull,
        matchesContext: nav.matchesContext,
        type: nav.type,
        formDetails: nav.formDetails,
        wsDetails: nav.wsDetails,
        rawCondition: nav.condition
      };

      // Keep track of best navigation (prefer matchesContext: true)
      if (!uniqueTargets.has(target) || nav.matchesContext === true) {
        uniqueTargets.set(target, navInfo);
      }
    }

    // Store in navigationMap
    if (uniqueTargets.size > 0) {
      navigationMap[interaction.path] = Object.fromEntries(uniqueTargets);
    }

    // Identify decision points (multiple targets with different matchesContext values)
    const hasConditionalBranches = [...uniqueTargets.values()].some(n => n.matchesContext === false);
    if (uniqueTargets.size > 1 || hasConditionalBranches) {
      decisionPoints.add(interaction.path);
    }
  }

  // Add entry node
  const entryId = normalizeId('ENTRY');
  nodes.push({
    id: entryId,
    type: 'entry',
    data: {
      label: transactionData.menuItem?.nomeLogico || 'Entry',
      color: '#0f62fe'
    },
    position: { x: 0, y: 0 }
  });
  nodeIds.add(entryId);

  // Process flow - BFS from MENU
  const visited = new Set();
  const queue = [{ path: 'MENU', parentId: entryId, depth: 0 }];

  // First pass: identify all nodes we need
  const nodesToCreate = new Map();
  const processQueue = [...queue];

  while (processQueue.length > 0) {
    const { path, depth } = processQueue.shift();
    if (visited.has(path) || depth > 10) continue;
    visited.add(path);

    const targets = flowGraph[path] || [];
    const interaction = getInteraction(path);

    // Skip MENU as a visible node
    if (path !== 'MENU' && interaction) {
      nodesToCreate.set(path, { interaction, depth });
    }

    for (const target of [...new Set(targets)]) {
      if (!visited.has(target)) {
        processQueue.push({ path: target, depth: depth + 1 });
      }
    }
  }

  // Determine which nodes are in the main flow (reachable via matchesContext: true)
  const mainFlowNodes = new Set();
  const mainFlowQueue = ['MENU'];
  const mainFlowVisited = new Set();

  while (mainFlowQueue.length > 0) {
    const current = mainFlowQueue.shift();
    if (mainFlowVisited.has(current)) continue;
    mainFlowVisited.add(current);

    const navInfo = navigationMap[current] || {};
    for (const [target, info] of Object.entries(navInfo)) {
      if (info.matchesContext === true || info.matchesContext === null) {
        mainFlowNodes.add(target);
        mainFlowQueue.push(target);
      }
    }
  }

  // Helper to create friendly screen description from name
  const getScreenDescription = (name, interactionType, fields, templates) => {
    const nameLower = (name || '').toLowerCase();
    // Infer purpose from name patterns
    if (nameLower.includes('lista') && nameLower.includes('cnpj')) return 'Lista de CNPJs';
    if (nameLower.includes('lista') && nameLower.includes('portador')) return 'Lista de Portadores';
    if (nameLower.includes('lista') && nameLower.includes('mensag')) return 'Lista de Mensagens';
    if (nameLower.includes('lista')) return 'Lista de itens';
    if (nameLower.includes('selecao') && nameLower.includes('master')) return 'Seleção Master';
    if (nameLower.includes('selecao') && nameLower.includes('empresa')) return 'Seleção de Empresa';
    if (nameLower.includes('selecao') && nameLower.includes('operador')) return 'Seleção de Operador';
    if (nameLower.includes('selecao')) return 'Seleção';
    if (nameLower.includes('filtro')) return 'Filtro de busca';
    if (nameLower.includes('detalhe') || nameLower.includes('detail')) return 'Detalhes';
    if (nameLower.includes('consulta') && nameLower.includes('cnpj')) return 'Consulta CNPJs';
    if (nameLower.includes('recebe_param') || nameLower.includes('param')) return 'Recebe Parâmetros';
    if (nameLower.includes('perfil')) return 'Perfil';
    if (nameLower.includes('inicial')) return 'Tela Inicial';
    if (nameLower.includes('sair') || nameLower.includes('exit')) return 'Saída';
    if (nameLower.includes('ws') && interactionType === 'Browser') return 'Aguardando WS';
    if (nameLower.includes('passo')) return `Processo ${name.replace('Passo_', '')}`;
    if (interactionType === 'WebService') return 'Serviço Web';
    if (interactionType === 'Mainframe') return 'Mainframe';
    return name.replace(/_/g, ' ');
  };

  // Second pass: create nodes with proper types
  visited.clear();
  const createdNodes = new Map();

  for (const [path, { interaction, depth }] of nodesToCreate) {
    const nodeId = normalizeId(path);
    const classification = interaction.classification || {};
    const rawName = interaction.name || path.split('\\').pop();
    const isInMainFlow = mainFlowNodes.has(path);
    const description = getScreenDescription(rawName, interaction.type, interaction.fields, interaction.templates);

    // Determine node type
    let nodeType = 'screen';
    let nodeData = {
      label: rawName.replace(/_/g, ' '),
      description: description,
      type: interaction.type || 'Screen',
      module: interaction.module,
      path: path,
      isMainFlow: isInMainFlow,
      isExit: classification.isExit,
      isFinal: classification.isFinal,
      fieldsCount: (interaction.fields || []).length,
      templatesCount: (interaction.templates || []).length
    };

    if (decisionPoints.has(path)) {
      nodeType = 'decision';
      nodeData.condition = 'Response condition';
      nodeData.color = '#d12771';
    } else if (classification.isExit) {
      nodeType = 'exit';
      nodeData.color = '#da1e28';
    } else if (interaction.type === 'WebService') {
      nodeType = 'service';
      nodeData.serviceType = 'WebService';
      nodeData.color = isInMainFlow ? '#24a148' : '#6929c4';
    } else if (interaction.type?.includes('ADO')) {
      nodeType = 'service';
      nodeData.serviceType = 'Database';
      nodeData.color = isInMainFlow ? '#24a148' : '#005d5d';
    } else if (interaction.type?.includes('Mainframe')) {
      nodeType = 'service';
      nodeData.serviceType = 'Mainframe';
      nodeData.color = isInMainFlow ? '#24a148' : '#8a3800';
    } else if (interaction.type === 'Browser' || interaction.type === 'Formulario') {
      nodeType = 'screen';
      nodeData.color = isInMainFlow ? '#198038' : '#0f62fe';
    }

    nodes.push({
      id: nodeId,
      type: nodeType,
      data: nodeData,
      position: { x: 0, y: depth * 120 }
    });

    createdNodes.set(path, nodeId);
  }

  // Create edges with conditions
  const edgeIds = new Set();

  // Edge from entry to first node
  const menuTargets = flowGraph['MENU'] || [];
  for (const target of [...new Set(menuTargets)]) {
    const targetId = createdNodes.get(target);
    if (targetId) {
      const edgeId = `e_${entryId}_${targetId}`;
      if (!edgeIds.has(edgeId)) {
        edges.push({
          id: edgeId,
          source: entryId,
          target: targetId,
          type: 'smoothstep',
          animated: true,
          style: { stroke: '#0f62fe', strokeWidth: 2 }
        });
        edgeIds.add(edgeId);
      }
    }
  }

  // Edges between nodes - use navigationMap for context-aware styling
  for (const [path, nodeId] of createdNodes) {
    const targets = flowGraph[path] || [];
    const navInfo = navigationMap[path] || {};
    const uniqueTargets = [...new Set(targets)];
    const sourceInt = getInteraction(path);

    for (const target of uniqueTargets) {
      const targetId = createdNodes.get(target);
      if (targetId) {
        const edgeId = `e_${nodeId}_${targetId}`;
        if (!edgeIds.has(edgeId)) {
          const nav = navInfo[target] || {};
          const condition = nav.condition || '';
          const matchesContext = nav.matchesContext;
          const targetInt = getInteraction(target);
          const isExitEdge = targetInt?.classification?.isExit;

          // When filtering by context, only show edges that match the context
          // matchesContext === true: follows context path
          // matchesContext === null: runtime decision (include)
          // matchesContext === false or undefined: not in context (exclude)
          if (filterByContext && matchesContext !== true && matchesContext !== null) {
            continue;
          }

          // Style based on matchesContext
          let strokeColor = '#525252'; // default gray
          let strokeWidth = 2;
          let strokeDasharray = 'none';
          let animated = false;

          if (matchesContext === true) {
            // Main flow - green, thick, animated
            strokeColor = '#24a148';
            strokeWidth = 3;
            animated = true;
          } else if (matchesContext === false) {
            // Skipped path - gray, dashed, thin
            strokeColor = '#a8a8a8';
            strokeWidth = 1;
            strokeDasharray = '5,5';
          } else if (matchesContext === null) {
            // Unknown/runtime - orange
            strokeColor = '#f1c21b';
            strokeWidth = 2;
          }

          // Exit edges override
          if (isExitEdge) {
            strokeColor = '#da1e28';
            strokeDasharray = '5,5';
          }

          // Store metadata for edge click details
          edgeMetadata[edgeId] = {
            sourcePath: path,
            targetPath: target,
            sourceLabel: sourceInt?.classification?.screenName || path.split('\\').pop(),
            targetLabel: targetInt?.classification?.screenName || target.split('\\').pop(),
            condition: condition,
            conditionFull: nav.conditionFull || condition,
            matchesContext: matchesContext,
            type: nav.type || 'navigation',
            rawCondition: nav.rawCondition,
            rawNavigation: nav
          };

          // Determine label color based on context
          const labelColor = matchesContext === true ? '#198038' :
                            matchesContext === null ? '#8a3800' : '#525252';
          const labelBgColor = matchesContext === true ? '#defbe6' :
                              matchesContext === null ? '#fff8e1' : '#f4f4f4';

          edges.push({
            id: edgeId,
            source: nodeId,
            target: targetId,
            type: 'smoothstep',
            animated: animated,
            label: condition || '',
            labelStyle: {
              fill: labelColor,
              fontSize: 11,
              fontWeight: 600,
              fontFamily: 'IBM Plex Mono, monospace'
            },
            labelBgStyle: {
              fill: labelBgColor,
              fillOpacity: 0.95
            },
            labelBgPadding: [6, 4],
            labelBgBorderRadius: 4,
            style: {
              stroke: strokeColor,
              strokeWidth: strokeWidth,
              strokeDasharray: strokeDasharray,
              cursor: 'pointer'
            },
            markerEnd: {
              type: MarkerType.ArrowClosed,
              color: strokeColor
            }
          });
          edgeIds.add(edgeId);
        }
      }
    }
  }

  // Build adjacency list for reachability check
  const adjacency = {};
  edges.forEach(e => {
    if (!adjacency[e.source]) adjacency[e.source] = [];
    adjacency[e.source].push(e.target);
  });

  // Find all entry node IDs
  const entryNodeIds = nodes.filter(n => n.type === 'entry').map(n => n.id);

  // BFS to find all nodes reachable from entry points
  const reachableNodes = new Set(entryNodeIds);
  const reachQueue = [...entryNodeIds];
  while (reachQueue.length > 0) {
    const current = reachQueue.shift();
    const neighbors = adjacency[current] || [];
    for (const neighbor of neighbors) {
      if (!reachableNodes.has(neighbor)) {
        reachableNodes.add(neighbor);
        reachQueue.push(neighbor);
      }
    }
  }

  // Filter nodes and edges to only include reachable ones
  const filteredNodes = nodes.filter(n => reachableNodes.has(n.id));
  const filteredEdges = edges.filter(e => reachableNodes.has(e.source) && reachableNodes.has(e.target));

  // Apply layout
  const { nodes: layoutedNodes, edges: layoutedEdges } = getLayoutedElements(filteredNodes, filteredEdges, 'TB');
  return { nodes: layoutedNodes, edges: layoutedEdges, edgeMetadata };
};

const DecisionTreeGraphInner = ({ transactionData, onNodeClick }) => {
  const { fitView } = useReactFlow();
  const [showAllPaths, setShowAllPaths] = useState(false);
  const [selectedEdge, setSelectedEdge] = useState(null);

  const { layoutedNodes, layoutedEdges, edgeMetadata } = useMemo(() => {
    const { nodes, edges, edgeMetadata } = buildDecisionTree(transactionData, !showAllPaths);
    return { layoutedNodes: nodes, layoutedEdges: edges, edgeMetadata };
  }, [transactionData, showAllPaths]);

  const [nodes, setNodes, onNodesChange] = useNodesState(layoutedNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(layoutedEdges);

  useEffect(() => {
    setNodes(layoutedNodes);
    setEdges(layoutedEdges);
    setSelectedEdge(null); // Clear selection when data changes
    setTimeout(() => fitView({ padding: 0.2 }), 100);
  }, [layoutedNodes, layoutedEdges, setNodes, setEdges, fitView]);

  const handleNodeClick = useCallback((event, node) => {
    setSelectedEdge(null); // Clear edge selection
    if (onNodeClick && node.data.path) {
      const interaction = transactionData.flow?.interactions?.find(i => i.path === node.data.path);
      if (interaction) {
        onNodeClick(interaction);
      }
    }
  }, [onNodeClick, transactionData]);

  const handleEdgeClick = useCallback((event, edge) => {
    const metadata = edgeMetadata[edge.id];
    if (metadata) {
      setSelectedEdge(metadata);
    }
  }, [edgeMetadata]);

  const getContextLabel = (matchesContext) => {
    if (matchesContext === true) return { text: 'Segue contexto', type: 'green' };
    if (matchesContext === false) return { text: 'Fora do contexto', type: 'gray' };
    if (matchesContext === null) return { text: 'Runtime (dinâmico)', type: 'purple' };
    return { text: 'Indefinido', type: 'gray' };
  };

  if (!layoutedNodes.length) {
    return (
      <div className={styles.noData}>
        <Warning size={32} />
        <p>No decision tree data available</p>
      </div>
    );
  }

  return (
    <div className={styles.flowContainer}>
      {/* Toggle for showing all paths */}
      <div className={styles.controls}>
        <Toggle
          id="show-all-paths"
          size="sm"
          labelA="Só contexto"
          labelB="Todos caminhos"
          toggled={showAllPaths}
          onToggle={() => setShowAllPaths(!showAllPaths)}
        />
        <span className={styles.controlsHint}>
          {showAllPaths ? 'Mostrando todos os caminhos' : 'Mostrando só fluxo do contexto'}
        </span>
      </div>

      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onNodeClick={handleNodeClick}
        onEdgeClick={handleEdgeClick}
        nodeTypes={nodeTypes}
        fitView
        minZoom={0.2}
        maxZoom={2}
        defaultViewport={{ x: 0, y: 0, zoom: 0.8 }}
      >
        <Controls />
        <MiniMap
          nodeColor={(node) => {
            if (node.type === 'decision') return '#d12771';
            if (node.type === 'exit') return '#da1e28';
            if (node.type === 'service') return '#6929c4';
            if (node.type === 'entry') return '#0f62fe';
            return node.data?.color || '#0f62fe';
          }}
        />
        <Background variant="dots" gap={16} size={1} />
      </ReactFlow>

      {/* Edge Details Panel */}
      {selectedEdge && (
        <div className={styles.edgeDetails}>
          <div className={styles.edgeDetailsHeader}>
            <ConnectionSignal size={20} />
            <span>Detalhes da Conexão</span>
            <button className={styles.closeButton} onClick={() => setSelectedEdge(null)}>
              <Close size={16} />
            </button>
          </div>
          <div className={styles.edgeDetailsContent}>
            <div className={styles.edgeDetailRow}>
              <span className={styles.edgeDetailLabel}>De:</span>
              <span className={styles.edgeDetailValue}>{selectedEdge.sourceLabel}</span>
            </div>
            <div className={styles.edgeDetailRow}>
              <span className={styles.edgeDetailLabel}>Para:</span>
              <span className={styles.edgeDetailValue}>{selectedEdge.targetLabel}</span>
            </div>
            {(selectedEdge.conditionFull || selectedEdge.condition) && (
              <div className={styles.edgeDetailRow}>
                <span className={styles.edgeDetailLabel}>Condição:</span>
                <code className={styles.edgeDetailCode}>{selectedEdge.conditionFull || selectedEdge.condition}</code>
              </div>
            )}
            <div className={styles.edgeDetailRow}>
              <span className={styles.edgeDetailLabel}>Contexto:</span>
              <Tag type={getContextLabel(selectedEdge.matchesContext).type} size="sm">
                {getContextLabel(selectedEdge.matchesContext).text}
              </Tag>
            </div>
            {selectedEdge.rawCondition && (
              <div className={styles.conditionDetails}>
                <h5>Detalhes da Condição</h5>
                <div className={styles.conditionCode}>
                  <div><strong>Função:</strong> {selectedEdge.rawCondition.function || 'N/A'}</div>
                  <div><strong>Esquerda:</strong> {selectedEdge.rawCondition.left || '(vazio)'}</div>
                  <div><strong>Direita:</strong> {selectedEdge.rawCondition.right || '(vazio)'}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Legend */}
      <div className={styles.legend}>
        <h4>Nós</h4>
        <div className={styles.legendItem}>
          <div className={styles.legendIcon} style={{ background: '#0f62fe', borderRadius: '50%' }}></div>
          <span>Entrada</span>
        </div>
        <div className={styles.legendItem}>
          <div className={styles.legendIcon} style={{ background: '#d12771', transform: 'rotate(45deg)' }}></div>
          <span>Decisão</span>
        </div>
        <div className={styles.legendItem}>
          <div className={styles.legendIcon} style={{ background: '#198038' }}></div>
          <span>Tela (contexto)</span>
        </div>
        <div className={styles.legendItem}>
          <div className={styles.legendIcon} style={{ background: '#0f62fe' }}></div>
          <span>Tela (outro)</span>
        </div>
        <div className={styles.legendItem}>
          <div className={styles.legendIcon} style={{ background: '#24a148', borderRadius: '8px' }}></div>
          <span>Serviço (contexto)</span>
        </div>
        <div className={styles.legendItem}>
          <div className={styles.legendIcon} style={{ background: '#6929c4', borderRadius: '8px' }}></div>
          <span>Serviço (outro)</span>
        </div>
        <div className={styles.legendItem}>
          <div className={styles.legendIcon} style={{ background: '#da1e28', borderRadius: '50%', border: '2px double white' }}></div>
          <span>Saída</span>
        </div>
        <h4 style={{ marginTop: '12px' }}>Conexões</h4>
        <div className={styles.legendItem}>
          <div className={styles.legendLine} style={{ background: '#24a148', height: '3px' }}></div>
          <span>Fluxo contexto</span>
        </div>
        <div className={styles.legendItem}>
          <div className={styles.legendLine} style={{ background: '#a8a8a8', height: '1px', borderStyle: 'dashed' }}></div>
          <span>Caminho não usado</span>
        </div>
        <div className={styles.legendItem}>
          <div className={styles.legendLine} style={{ background: '#f1c21b', height: '2px' }}></div>
          <span>Runtime</span>
        </div>
        <p className={styles.legendHint}>Clique em uma conexão para ver detalhes</p>
      </div>

      {/* Context Algorithm Panel */}
      {transactionData?.menuItem?.flowContext && (
        <div className={styles.contextPanel}>
          <h4>Contexto da Navegação</h4>
          <div className={styles.contextVars}>
            {Object.entries(transactionData.menuItem.flowContext).map(([key, value]) => (
              <div key={key} className={styles.contextVar}>
                <span className={styles.contextKey}>{key}</span>
                <span className={styles.contextValue}>{String(value).substring(0, 30)}{String(value).length > 30 ? '...' : ''}</span>
              </div>
            ))}
          </div>
          <div className={styles.algorithmNote}>
            <strong>Destino:</strong> {transactionData.menuItem.trn?.destination || 'N/A'}
            <br />
            <small>Caminhos verdes seguem este contexto</small>
          </div>
        </div>
      )}
    </div>
  );
};

const DecisionTreeGraph = (props) => {
  return (
    <ReactFlowProvider>
      <DecisionTreeGraphInner {...props} />
    </ReactFlowProvider>
  );
};

export default DecisionTreeGraph;
