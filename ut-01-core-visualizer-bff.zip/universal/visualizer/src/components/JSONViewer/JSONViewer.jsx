import { useState, useCallback, useMemo } from 'react';
import { Button, Tag, Tabs, TabList, Tab, TabPanels, TabPanel, CopyButton } from '@carbon/react';
import {
  Download,
  View,
  Copy,
  Checkmark,
  CheckmarkFilled,
  Document,
  Flow,
  DataTable,
  Code,
  WarningAlt
} from '@carbon/icons-react';
import styles from './JSONViewer.module.scss';

/**
 * JSONViewer Component
 * Preview, download, and visualize generated transaction JSON
 * @param {boolean} compact - Reduced UI for modal display
 */
const JSONViewer = ({ jsonData, onVisualize, onDownload, onDownloadSchema, compact = false }) => {
  const [copiedSection, setCopiedSection] = useState(null);

  // Extract summary stats
  const stats = useMemo(() => {
    if (!jsonData) return null;

    const interactions = jsonData.flow?.interactions || [];
    const flowGraph = jsonData.flow?.flowGraph || {};
    const missingPaths = jsonData.flow?.missingPaths || [];

    return {
      interactionCount: interactions.length,
      browserCount: interactions.filter(i => i.type === 'Browser').length,
      wsCount: interactions.filter(i => i.type === 'WebService').length,
      mfCount: interactions.filter(i => ['Mainframe', 'MainframeGRBE'].includes(i.type)).length,
      adoCount: interactions.filter(i => ['ADOConsulta', 'ADOOperacao'].includes(i.type)).length,
      totalFields: interactions.reduce((sum, i) => sum + (i.fields?.inputs?.length || 0), 0),
      totalNavigations: interactions.reduce((sum, i) => sum + (i.navigations?.length || 0), 0),
      flowConnections: Object.values(flowGraph).flat().length,
      missingPathsCount: missingPaths.length,
      missingPaths
    };
  }, [jsonData]);

  // Format JSON for display
  const formattedJson = useMemo(() => {
    if (!jsonData) return '';
    return JSON.stringify(jsonData, null, 2);
  }, [jsonData]);

  // Handle copy
  const handleCopy = useCallback((text, section) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  }, []);

  // Handle download
  const handleDownload = useCallback(() => {
    if (!jsonData) return;

    const filename = `${jsonData.metadata?.transactionId?.replace(/[\\\/]/g, '-') || 'transaction'}.json`;
    const blob = new Blob([formattedJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (onDownload) onDownload(filename);
  }, [jsonData, formattedJson, onDownload]);

  // Handle schema download
  const handleDownloadSchema = useCallback(() => {
    const schemaUrl = '/extractions/schemas/context-aware-transaction-schema.json';
    const a = document.createElement('a');
    a.href = schemaUrl;
    a.download = 'context-aware-transaction-schema.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    if (onDownloadSchema) onDownloadSchema();
  }, [onDownloadSchema]);

  // Handle missing paths download
  const handleDownloadMissingPaths = useCallback(() => {
    const missingPaths = jsonData?.flow?.missingPaths || [];
    if (missingPaths.length === 0) return;

    const content = [
      '# Missing Paths Report',
      `# Generated: ${new Date().toISOString()}`,
      `# Transaction: ${jsonData?.metadata?.transactionId || 'N/A'}`,
      `# TRN: ${jsonData?.menuItem?.trn?.full || 'N/A'}`,
      `# Total Missing: ${missingPaths.length}`,
      '',
      '# These interaction paths were referenced but not found:',
      '',
      ...missingPaths.map((p, i) => `${i + 1}. ${p}`)
    ].join('\n');

    const filename = `missing-paths-${jsonData?.menuItem?.trn?.module || 'export'}.txt`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [jsonData]);

  if (!jsonData) {
    return (
      <div className={styles.emptyState}>
        <Document size={48} />
        <p>Nenhum JSON gerado ainda</p>
      </div>
    );
  }

  return (
    <div className={`${styles.jsonViewerContainer} ${compact ? styles.compact : ''}`}>
      {/* Header */}
      <div className={styles.header}>
        <div className={styles.headerInfo}>
          <h3>{jsonData.menuItem?.nomeLogico || jsonData.metadata?.transactionId}</h3>
          <div className={styles.headerMeta}>
            <Tag type="purple" size="sm">
              {jsonData.menuItem?.trn?.destination || 'N/A'}
            </Tag>
            {!compact && (
              <span className={styles.timestamp}>
                Gerado em: {new Date(jsonData.metadata?.extractionDate).toLocaleString('pt-BR')}
              </span>
            )}
          </div>
        </div>

        {!compact && (
          <div className={styles.headerActions}>
            <Button
              kind="ghost"
              size="sm"
              renderIcon={Code}
              onClick={handleDownloadSchema}
            >
              Baixar Schema
            </Button>
            <Button
              kind="secondary"
              size="sm"
              renderIcon={Download}
              onClick={handleDownload}
            >
              Baixar JSON
            </Button>
            {onVisualize && (
              <Button
                kind="primary"
                size="sm"
                renderIcon={View}
                onClick={() => onVisualize(jsonData)}
              >
                Visualizar
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Tabs */}
      <Tabs>
        <TabList aria-label="JSON Views">
          <Tab>Resumo</Tab>
          <Tab>JSON Completo</Tab>
          <Tab>Fluxo</Tab>
          <Tab>Contexto</Tab>
        </TabList>

        <TabPanels>
          {/* Summary Tab */}
          <TabPanel>
            <div className={styles.summaryPanel}>
              {/* Stats Grid - Compact inline */}
              {stats && (
                <div className={styles.statsGridInline}>
                  <div className={styles.statItem}>
                    <Flow size={16} />
                    <span className={styles.statValue}>{stats.interactionCount}</span>
                    <span className={styles.statLabel}>Interações</span>
                  </div>
                  <div className={styles.statItem}>
                    <Document size={16} />
                    <span className={styles.statValue}>{stats.browserCount}</span>
                    <span className={styles.statLabel}>Telas</span>
                  </div>
                  <div className={styles.statItem}>
                    <Code size={16} />
                    <span className={styles.statValue}>{stats.wsCount}</span>
                    <span className={styles.statLabel}>WebServices</span>
                  </div>
                  <div className={styles.statItem}>
                    <DataTable size={16} />
                    <span className={styles.statValue}>{stats.totalFields}</span>
                    <span className={styles.statLabel}>Campos</span>
                  </div>
                </div>
              )}

              {/* TRN Info - Compact */}
              <div className={styles.trnCompact}>
                <span className={styles.trnLabel}>TRN:</span>
                <code>{jsonData.menuItem?.trn?.full}</code>
                <CopyButton
                  onClick={() => handleCopy(jsonData.menuItem?.trn?.full, 'trn')}
                  feedback={copiedSection === 'trn' ? 'Copiado!' : 'Copiar'}
                />
                <Tag type="gray" size="sm">{jsonData.menuItem?.trn?.module}</Tag>
                <Tag type="gray" size="sm">{jsonData.menuItem?.trn?.subProgram}</Tag>
                <Tag type="gray" size="sm">{jsonData.menuItem?.trn?.interaction}</Tag>
              </div>

              {/* Missing Paths Section - Always visible */}
              {stats?.missingPathsCount > 0 ? (
                <div className={`${styles.pathsSection} ${styles.pathsWarning}`}>
                  <div className={styles.pathsSectionHeader}>
                    <WarningAlt size={16} />
                    <span>{stats.missingPathsCount} caminho(s) não encontrado(s)</span>
                    <Button
                      kind="ghost"
                      size="sm"
                      renderIcon={Download}
                      onClick={handleDownloadMissingPaths}
                    >
                      Baixar
                    </Button>
                  </div>
                  <div className={styles.pathsList}>
                    {stats.missingPaths.slice(0, 5).map((path, i) => (
                      <Tag key={i} type="warm-gray" size="sm" title={path}>
                        {path.split(/[/\\]/).pop()}
                      </Tag>
                    ))}
                    {stats.missingPathsCount > 5 && (
                      <Tag type="gray" size="sm">+{stats.missingPathsCount - 5}</Tag>
                    )}
                  </div>
                </div>
              ) : (
                <div className={`${styles.pathsSection} ${styles.pathsSuccess}`}>
                  <CheckmarkFilled size={16} />
                  <span>Todos os caminhos referenciados foram encontrados</span>
                </div>
              )}

              {/* Interactions List */}
              <div className={styles.summarySection}>
                <h4>Interações Traçadas ({jsonData.flow?.interactions?.length})</h4>
                <div className={styles.interactionsList}>
                  {jsonData.flow?.interactions?.map((interaction, i) => (
                    <div key={i} className={styles.interactionItem}>
                      <Tag type="gray" size="sm" title="Trace order">
                        #{interaction._traceOrder || i + 1}
                      </Tag>
                      <Tag type={getTypeColor(interaction.type)} size="sm">
                        {interaction.type}
                      </Tag>
                      <span className={styles.interactionName}>{interaction.name}</span>
                      <span className={styles.interactionPath}>{interaction.path}</span>
                      <div className={styles.interactionMeta}>
                        {interaction.fields?.inputs?.length > 0 && (
                          <Tag type="blue" size="sm">{interaction.fields.inputs.length} campos</Tag>
                        )}
                        {interaction.navigations?.length > 0 && (
                          <Tag type="teal" size="sm">{interaction.navigations.length} navs</Tag>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabPanel>

          {/* Full JSON Tab */}
          <TabPanel>
            <div className={styles.jsonPanel}>
              <div className={styles.jsonHeader}>
                <span>{formattedJson.length.toLocaleString()} caracteres</span>
                <Button
                  kind="ghost"
                  size="sm"
                  hasIconOnly
                  renderIcon={copiedSection === 'json' ? Checkmark : Copy}
                  iconDescription="Copiar JSON"
                  onClick={() => handleCopy(formattedJson, 'json')}
                />
              </div>
              <pre className={styles.jsonCode}>{formattedJson}</pre>
            </div>
          </TabPanel>

          {/* Flow Tab */}
          <TabPanel>
            <div className={styles.flowPanel}>
              <h4>Grafo de Navegação</h4>
              <div className={styles.flowGraph}>
                {Object.entries(jsonData.flow?.flowGraph || {}).map(([source, targets]) => (
                  <div key={source} className={styles.flowEdge}>
                    <code className={styles.flowSource}>{source.split('\\').pop()}</code>
                    <span className={styles.flowArrow}>→</span>
                    <div className={styles.flowTargets}>
                      {targets.map((target, i) => (
                        <code key={i} className={styles.flowTarget}>
                          {target.split('\\').pop()}
                        </code>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabPanel>

          {/* Context Tab */}
          <TabPanel>
            <div className={styles.contextPanel}>
              <h4>Variáveis de Contexto</h4>
              <p className={styles.contextDescription}>
                {jsonData.flowContext?.description}
              </p>

              <div className={styles.contextSection}>
                <h5>Variáveis Protegidas (do TRN)</h5>
                <div className={styles.varsList}>
                  {jsonData.flowContext?.protectedVars?.map((v, i) => (
                    <Tag key={i} type="purple" size="sm">{v}</Tag>
                  ))}
                </div>
              </div>

              <div className={styles.contextSection}>
                <h5>Variáveis de Sessão</h5>
                <div className={styles.varsTable}>
                  {Object.entries(jsonData.flowContext?.sessionVars || {})
                    .filter(([k]) => !k.startsWith('_'))
                    .slice(0, 20)
                    .map(([key, value]) => (
                      <div key={key} className={styles.varRow}>
                        <code className={styles.varKey}>{key}</code>
                        <code className={styles.varValue}>{value}</code>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </TabPanel>
        </TabPanels>
      </Tabs>
    </div>
  );
};

// Helper to get tag color by interaction type
function getTypeColor(type) {
  switch (type) {
    case 'Browser': return 'blue';
    case 'WebService': return 'teal';
    case 'Mainframe':
    case 'MainframeGRBE': return 'magenta';
    case 'ADOConsulta':
    case 'ADOOperacao': return 'cyan';
    case 'Formulario': return 'purple';
    default: return 'gray';
  }
}

export default JSONViewer;
