/**
 * COMEX Domain Types
 *
 * These types mirror the Go domain types in the business service.
 * The BFF passes these through to the frontend.
 */

// =============================================================================
// ENUMS
// =============================================================================

export type DateType = 'R' | 'V' | 'L'; // Registro, Vencimento, Liquidação
export type CompanyType = ' ' | 'N' | 'S'; // All, Normal, OffShore
export type OperationStatus = 'OPEN' | 'CLOSED' | 'CANCELLED' | 'PENDING' | 'LIQUIDATED';
export type FXStatus = '0' | '2' | '3' | '5'; // Aguardando, Parcial, Editada, Todas
export type LCStatus = 'DRAFT' | 'ISSUED' | 'NEGOTIATED' | 'EXPIRED';

// =============================================================================
// COMPANY
// =============================================================================

export interface Company {
  cnpj: string;
  name: string;
  type?: CompanyType;
  active?: boolean;
}

export interface CompanyListResponse {
  companies: Company[];
  totalCount: number;
}

// =============================================================================
// BILLING OPERATIONS (BAL1)
// =============================================================================

export interface BillingQuery {
  cnpj: string;
  dateFrom?: string;
  dateTo?: string;
  invoiceNumber?: string;
  dateType?: DateType;
  companyType?: CompanyType;
}

export interface BillingOperation {
  id: string;
  cnpj: string;
  companyName: string;
  registrationDate: string;
  maturityDate: string;
  invoiceNumber: string;
  amount: number;
  currency: string;
  status: OperationStatus;
}

export interface BillingSummary {
  totalAmount: number;
  currency: string;
}

export interface BillingQueryResponse {
  operations: BillingOperation[];
  totalCount: number;
  summary?: BillingSummary;
}

// =============================================================================
// PAYMENT ORDERS (BAL3)
// =============================================================================

export interface PaymentOrderQuery {
  cnpj: string;
  dateFrom?: string;
  dateTo?: string;
  dateType: DateType;
  status?: string;
}

export interface PaymentOrder {
  id: string;
  cnpj: string;
  companyName: string;
  orderDate: string;
  liquidationDate?: string;
  amount: number;
  currency: string;
  beneficiary: string;
  status: OperationStatus;
}

export interface PaymentOrdersResponse {
  orders: PaymentOrder[];
  totalCount: number;
}

// =============================================================================
// LETTERS OF CREDIT (BAL7)
// =============================================================================

export interface LCQuery {
  cnpj: string;
  dateFrom?: string;
  dateTo?: string;
  dateType?: DateType;
  companyType?: CompanyType;
}

export interface LetterOfCredit {
  id: string;
  cnpj: string;
  companyName: string;
  issueDate: string;
  expiryDate: string;
  amount: number;
  currency: string;
  beneficiary: string;
  status: LCStatus;
}

export interface LCQueryResponse {
  letters: LetterOfCredit[];
  totalCount: number;
}

// =============================================================================
// FX QUOTATIONS (BAEI)
// =============================================================================

export interface FXQuery {
  cnpj: string;
  dateFrom?: string;
  dateTo?: string;
  status?: string;
}

export interface FXQuotation {
  id: string;
  cnpj: string;
  companyName: string;
  quoteDate: string;
  currencyPair: string;
  rate: number;
  amount: number;
  status: FXStatus;
}

export interface FXQueryResponse {
  quotations: FXQuotation[];
  totalCount: number;
}

export interface ExchangeRate {
  currencyPair: string;
  bid: number;
  ask: number;
  timestamp: string;
}

export interface ExchangeSimulation {
  fromCurrency: string;
  toCurrency: string;
  amount: number;
  rate: number;
  result: number;
  fee?: number;
  validUntil: string;
}

export interface ExchangeSimulationRequest {
  fromCurrency: string;
  toCurrency: string;
  amount: number;
}

// =============================================================================
// SWIFT
// =============================================================================

export interface SWIFTMessage {
  uetr: string;
  messageType: string;
  senderBIC: string;
  receiverBIC: string;
  amount: number;
  currency: string;
  beneficiary: string;
  reference: string;
  status: string;
  createdAt: string;
  deliveredAt?: string;
}

export interface SWIFTMessageRequest {
  messageType: string;
  beneficiaryName: string;
  beneficiaryAccount: string;
  beneficiaryBank: string;
  amount: number;
  currency: string;
  reference?: string;
}

export interface SWIFTMessageResponse {
  uetr: string;
  status: string;
  message?: string;
}

// =============================================================================
// HEALTH
// =============================================================================

export interface HealthStatus {
  service: string;
  healthy: boolean;
  timestamp: string;
  details?: Record<string, string>;
}

// =============================================================================
// ERROR
// =============================================================================

export interface ApiError {
  code: string;
  message: string;
}
