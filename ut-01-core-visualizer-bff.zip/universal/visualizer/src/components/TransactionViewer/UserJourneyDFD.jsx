import { useMemo, useState, useCallback, useRef, useEffect } from 'react';
import {
  ReactFlow,
  Controls,
  Background,
  MiniMap,
  MarkerType,
  Position,
  Handle,
  ReactFlowProvider,
  useReactFlow,
  Panel
} from '@xyflow/react';
import dagre from '@dagrejs/dagre';
import '@xyflow/react/dist/style.css';
import { Toggle, Button, IconButton } from '@carbon/react';
import {
  User,
  Menu,
  ArrowRight,
  ArrowDown,
  Code,
  Screen,
  Flow,
  DataBase,
  Terminal,
  Api,
  Document,
  Information,
  DecisionTree,
  WarningAlt,
  CloudApp,
  Application,
  ZoomIn,
  ZoomOut,
  FitToScreen,
  Download,
  TreeViewAlt,
  Rotate,
  CenterCircle,
  Move,
  Edit,
  Table,
  Cube,
  DocumentBlank
} from '@carbon/icons-react';
import { toPng } from 'html-to-image';

// Color palette for different node/path types
const COLORS = {
  browser: { border: '#0f62fe', bg: '#f4f4f4', text: '#161616', icon: '#0f62fe' },
  webservice: { border: '#24a148', bg: '#defbe6', text: '#044317', icon: '#24a148' },
  database: { border: '#0072c3', bg: '#e5f6ff', text: '#003a6d', icon: '#0072c3' },
  mainframe: { border: '#8a3ffc', bg: '#f6f2ff', text: '#491d8b', icon: '#8a3ffc' },
  entry: { border: '#198038', bg: '#a7f0ba', text: '#0e6027', icon: '#198038' },
  decision: { border: '#ff832b', bg: '#fff2e8', text: '#8a3800', icon: '#ff832b' },
  error: { border: '#da1e28', bg: '#fff1f1', text: '#750e13', icon: '#da1e28' },
  menu: { border: '#0f62fe', bg: '#0f62fe', text: '#ffffff', icon: '#ffffff' }
};
import styles from './UserJourneyDFD.module.scss';

/**
 * Groups date fields (Dia/Mes/Ano) into DatePicker components for visualization
 * Also handles date range detection (Inicial + Final pairs)
 */
const groupFieldsForVisualization = (fields) => {
  if (!fields || !Array.isArray(fields) || fields.length === 0) return fields;

  const grouped = [];
  const processed = new Set();

  // Find date field groups
  for (const field of fields) {
    if (processed.has(field.name)) continue;

    const name = (field.name || '').toLowerCase();

    // Check if this is a date component (Dia, Mes, Ano)
    if (name.includes('dia') || name.includes('mes') || name.includes('ano')) {
      // Extract suffix (e.g., "Inicial", "Final", "_de", "_ate")
      const suffixMatch = name.match(/(inicial|final|inicio|fim|_de|_ate|\d+)$/i);
      const suffix = suffixMatch ? suffixMatch[0] : '';

      // Find related date fields with same suffix
      const relatedFields = fields.filter(f => {
        const fName = (f.name || '').toLowerCase();
        const hasSameSuffix = suffix ? fName.endsWith(suffix.toLowerCase()) : true;
        return (fName.includes('dia') || fName.includes('mes') || fName.includes('ano')) &&
               hasSameSuffix &&
               !processed.has(f.name);
      });

      // If we have at least 2 related fields (Dia+Mes or Dia+Mes+Ano), group them
      if (relatedFields.length >= 2) {
        relatedFields.forEach(f => processed.add(f.name));

        // Determine label based on suffix
        let label = '📅 DatePicker';
        if (suffix.toLowerCase().includes('inicial') || suffix.toLowerCase().includes('inicio') || suffix.toLowerCase().includes('_de')) {
          label = '📅 Data Inicial';
        } else if (suffix.toLowerCase().includes('final') || suffix.toLowerCase().includes('fim') || suffix.toLowerCase().includes('_ate')) {
          label = '📅 Data Final';
        }

        grouped.push({
          name: label,
          _isDateGroup: true,
          _groupedFields: relatedFields.map(f => f.name),
          _fieldCount: relatedFields.length
        });
        continue;
      }
    }

    // Not a date group, add as regular field
    if (!processed.has(field.name)) {
      processed.add(field.name);
      grouped.push(field);
    }
  }

  // Check for date range pairs and combine them
  const inicialIdx = grouped.findIndex(f => f._isDateGroup && f.name.includes('Inicial'));
  const finalIdx = grouped.findIndex(f => f._isDateGroup && f.name.includes('Final'));

  if (inicialIdx !== -1 && finalIdx !== -1) {
    const inicialGroup = grouped[inicialIdx];
    const finalGroup = grouped[finalIdx];

    // Replace with combined DateRange
    const dateRangeField = {
      name: '📅 DateRange (Período)',
      _isDateRange: true,
      _groupedFields: [...(inicialGroup._groupedFields || []), ...(finalGroup._groupedFields || [])],
      _fieldCount: (inicialGroup._fieldCount || 0) + (finalGroup._fieldCount || 0)
    };

    // Remove individual groups and add combined
    grouped.splice(Math.max(inicialIdx, finalIdx), 1);
    grouped.splice(Math.min(inicialIdx, finalIdx), 1, dateRangeField);
  }

  return grouped;
};

// Menu Node - Starting point
const MenuNode = ({ data }) => (
  <div className={styles.menuNode}>
    <Handle type="source" position={Position.Bottom} className={styles.handle} />
    <div className={styles.menuIcon}>
      <Menu size={24} />
    </div>
    <div className={styles.menuContent}>
      <div className={styles.menuPath}>{data.menuPath?.join(' > ')}</div>
      <div className={styles.menuItem}>{data.label}</div>
      <div className={styles.menuId}>ID: {data.idMBkl}</div>
    </div>
  </div>
);

// TRN Parameters Node
const TRNNode = ({ data }) => (
  <div className={styles.trnNode}>
    <Handle type="target" position={Position.Top} className={styles.handle} />
    <Handle type="source" position={Position.Bottom} className={styles.handle} />
    <div className={styles.trnHeader}>
      <Code size={20} />
      <span>TRN Parameters</span>
    </div>
    <div className={styles.trnContent}>
      <code className={styles.trnFull}>{data.trnFull}</code>
      <div className={styles.trnParsed}>
        <div><strong>Módulo:</strong> {data.module}</div>
        <div><strong>SubPrograma:</strong> {data.subProgram}</div>
        <div><strong>Gateway:</strong> {data.interaction}</div>
        <div><strong>Destino:</strong> <span className={styles.highlight}>{data.destination}</span></div>
      </div>
    </div>
  </div>
);

// Context Variables Node
const ContextNode = ({ data }) => (
  <div className={styles.contextNode}>
    <Handle type="target" position={Position.Top} className={styles.handle} />
    <Handle type="source" position={Position.Bottom} className={styles.handle} />
    <div className={styles.contextHeader}>
      <DataBase size={20} />
      <span>Session Variables</span>
    </div>
    <div className={styles.contextContent}>
      {Object.entries(data.variables || {}).map(([key, value]) => (
        <div key={key} className={styles.contextVar}>
          <span className={styles.varName}>{key}</span>
          <span className={styles.varValue}>{value}</span>
        </div>
      ))}
    </div>
  </div>
);

// Gateway Node
const GatewayNode = ({ data }) => (
  <div className={styles.gatewayNode}>
    <Handle type="target" position={Position.Top} className={styles.handle} />
    <Handle type="source" position={Position.Bottom} className={styles.handle} />
    <div className={styles.gatewayIcon}>
      <Flow size={24} />
    </div>
    <div className={styles.gatewayContent}>
      <div className={styles.gatewayLabel}>{data.label}</div>
      <div className={styles.gatewayType}>Gateway Entry Point</div>
    </div>
  </div>
);

// Expandable Field Item component
const ExpandableFieldItem = ({ field, allFields }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const isGrouped = field._isDateRange || field._isDateGroup;

  // Find the original fields if this is a grouped item
  const groupedFieldDetails = isGrouped && field._groupedFields
    ? field._groupedFields.map(name => allFields.find(f => f.name === name)).filter(Boolean)
    : [];

  const handleClick = (e) => {
    if (isGrouped) {
      e.stopPropagation();
      setIsExpanded(!isExpanded);
    }
  };

  return (
    <div className={styles.expandableFieldContainer}>
      <div
        className={`${styles.fieldItem} ${field._isDateRange ? styles.fieldItemDateRange : ''} ${field._isDateGroup ? styles.fieldItemDateGroup : ''} ${isGrouped ? styles.fieldItemClickable : ''}`}
        title={field._groupedFields ? `Clique para expandir: ${field._groupedFields.join(', ')}` : undefined}
        onClick={handleClick}
      >
        {isGrouped && (
          <span className={styles.expandIcon}>{isExpanded ? '▼' : '▶'}</span>
        )}
        {field.name?.replace(/_/g, ' ')}
        {field._fieldCount && <span className={styles.fieldGroupCount}>({field._fieldCount})</span>}
      </div>
      {isExpanded && groupedFieldDetails.length > 0 && (
        <div className={styles.expandedFieldDetails}>
          {groupedFieldDetails.map((f, idx) => (
            <div key={idx} className={styles.fieldDetailRow}>
              <span className={styles.fieldDetailName}>{f.name}</span>
              <div className={styles.fieldDetailMeta}>
                {f.size && <span className={styles.fieldDetailTag}>size: {f.size}</span>}
                {f.type && <span className={styles.fieldDetailTag}>type: {f.type}</span>}
                {f.source && <span className={styles.fieldDetailTag}>src: {f.source}</span>}
                {f.format && <span className={styles.fieldDetailTag}>fmt: {f.format}</span>}
              </div>
            </div>
          ))}
          <div className={styles.fieldDetailSummary}>
            → Renderiza como: <strong>{field._isDateRange ? 'DateRangePicker' : 'DatePicker'}</strong>
          </div>
        </div>
      )}
    </div>
  );
};

// Screen Wireframe Node - DFD style with grouped fields
const ScreenWireframeNode = ({ data }) => {
  const hasInputs = data.inputs && data.inputs.length > 0;
  const hasLists = data.lists && data.lists.length > 0;
  const hasBindings = data.bindings && data.bindings.length > 0;
  const hasWsInputs = data.wsInputs && data.wsInputs.length > 0;
  const hasForms = data.forms && data.forms.length > 0;

  const isBrowser = data.type === 'Browser';
  const isService = data.type === 'WebService' || data.type?.includes('ADO');
  const isMainframe = data.type?.includes('Mainframe');
  const isError = data.isError;

  // Store raw fields for expansion details
  const rawFields = data._rawFields || [];

  // Check if this is a display-only screen (no fields, just renders content)
  const isDisplayOnly = isBrowser && !hasInputs && !hasLists && !hasBindings;
  const hasAnyContent = hasInputs || hasLists || hasBindings || hasWsInputs;

  return (
    <div className={styles.screenNodeContainer}>
      <Handle type="target" position={Position.Left} className={styles.handle} />
      <Handle type="source" position={Position.Right} className={styles.handle} />
      <Handle type="source" position={Position.Bottom} className={styles.handle} id="fields" />

      {/* Main screen box with header */}
      <div className={`${styles.screenBox} ${isService ? styles.serviceBox : ''} ${isMainframe ? styles.mainframeBox : ''} ${isError ? styles.errorBox : ''}`}>
        <div className={styles.screenBoxHeader}>
          <div className={styles.screenBoxIcon}>
            {isService ? <CloudApp size={20} /> :
             isMainframe ? <Terminal size={20} /> :
             <Application size={20} />}
          </div>
          <div className={styles.dotPattern}>
            {[...Array(12)].map((_, i) => (
              <div key={i} className={styles.dot} />
            ))}
          </div>
        </div>
        <div className={styles.screenBoxName}>
          {data.label}
          {data.storedProcedures?.length > 0 && (
            <span className={styles.spBadge} title={`${data.storedProcedures.length} stored procedures`}>
              SP:{data.storedProcedures.length}
            </span>
          )}
          {data.operations?.length > 0 && (
            <span className={styles.opBadge} title={`${data.operations.length} operações`}>
              {data.operations.length} ops
            </span>
          )}
        </div>
        {(data.wsMethod || data.mainframeCode) && (
          <div className={styles.screenBoxMeta}>
            {data.wsMethod && <span className={styles.wsMethodBadge}>WS: {data.wsMethod}</span>}
            {data.mainframeCode && <span className={styles.mfCodeBadge}>MF: {data.mainframeCode}</span>}
          </div>
        )}
      </div>

      {/* Fields grouped by type */}
      <div className={styles.fieldsGrouped}>
        {/* wsInputs for WebServices - what data they RECEIVE */}
        {isService && hasWsInputs && (
          <div className={`${styles.fieldSection} ${styles.fieldSectionWsInput}`}>
            <div className={styles.fieldSectionHeader}>
              <ArrowRight size={12} className={styles.fieldSectionIconSvg} />
              <span>Recebe ({data.wsInputs.length})</span>
            </div>
            <div className={styles.fieldSectionItems}>
              {(data.showAllFields ? data.wsInputs : data.wsInputs.slice(0, 3)).map((f, i) => (
                <div key={i} className={styles.fieldItemWsInput}>
                  {f.name?.replace(/_/g, ' ')}
                </div>
              ))}
              {!data.showAllFields && data.wsInputs.length > 3 && (
                <div className={styles.fieldItemMore}>+{data.wsInputs.length - 3} mais</div>
              )}
            </div>
          </div>
        )}

        {/* Input Fields Section */}
        {hasInputs && (
          <div className={`${styles.fieldSection} ${styles.fieldSectionInput}`}>
            <div className={styles.fieldSectionHeader}>
              <Edit size={12} className={styles.fieldSectionIconSvg} />
              <span>{isService ? 'Define' : 'Campos'} ({data.inputs.length})</span>
            </div>
            <div className={styles.fieldSectionItems}>
              {(data.showAllFields ? data.inputs : data.inputs.slice(0, 3)).map((f, i) => (
                <ExpandableFieldItem key={i} field={f} allFields={rawFields} />
              ))}
              {!data.showAllFields && data.inputs.length > 3 && (
                <div className={styles.fieldItemMore}>+{data.inputs.length - 3} mais</div>
              )}
            </div>
          </div>
        )}

        {/* List Fields Section */}
        {hasLists && (
          <div className={`${styles.fieldSection} ${styles.fieldSectionList}`}>
            <div className={styles.fieldSectionHeader}>
              <Table size={12} className={styles.fieldSectionIconSvg} />
              <span>Lista ({data.lists.length} cols)</span>
            </div>
            <div className={styles.fieldSectionItems}>
              {(data.showAllFields ? data.lists : data.lists.slice(0, 2)).map((f, i) => (
                <div key={i} className={styles.fieldItemList}>
                  {f.name}
                </div>
              ))}
              {!data.showAllFields && data.lists.length > 2 && (
                <div className={styles.fieldItemMore}>+{data.lists.length - 2} mais</div>
              )}
            </div>
          </div>
        )}

        {/* Binding Fields Section - data from WebService */}
        {hasBindings && (
          <div className={`${styles.fieldSection} ${styles.fieldSectionBinding}`}>
            <div className={styles.fieldSectionHeader}>
              <ArrowDown size={12} className={styles.fieldSectionIconSvg} />
              <span>Dados WS ({data.bindings.length})</span>
            </div>
            <div className={styles.fieldSectionItems}>
              {(data.showAllFields ? data.bindings : data.bindings.slice(0, 2)).map((b, i) => (
                <div key={i} className={styles.fieldItemBinding}>
                  {b.textWS || b.tagXML?.split('/').pop() || `pos:${b.position}`}
                </div>
              ))}
              {!data.showAllFields && data.bindings.length > 2 && (
                <div className={styles.fieldItemMore}>+{data.bindings.length - 2} mais</div>
              )}
            </div>
          </div>
        )}

        {/* Display-only screen indicator with WebService response structure */}
        {isDisplayOnly && data.previousWsData && (
          <div className={`${styles.fieldSection} ${styles.fieldSectionDynamic}`}>
            <div className={styles.fieldSectionHeader}>
              <DocumentBlank size={12} className={styles.fieldSectionIconSvg} />
              <span>Exibe de {data.previousWsData.name}</span>
            </div>
            <div className={styles.fieldSectionItems}>
              {(data.showAllFields ? data.previousWsData.inputs : data.previousWsData.inputs?.slice(0, 2))?.map((f, i) => (
                <div key={`inp-${i}`} className={styles.fieldItemDynamic}>
                  ✓ {f.name?.replace(/_/g, ' ')}
                </div>
              ))}
              {(data.showAllFields ? data.previousWsData.bindings : data.previousWsData.bindings?.slice(0, 2))?.map((b, i) => (
                <div key={`bind-${i}`} className={styles.fieldItemDynamic}>
                  ✓ {b.textWS || b.tagXML?.split('/').pop()}
                </div>
              ))}
              {!data.showAllFields && (data.previousWsData.inputs?.length > 2 || data.previousWsData.bindings?.length > 2) && (
                <div className={styles.fieldItemMore}>+mais campos</div>
              )}
            </div>
          </div>
        )}
        {isDisplayOnly && !data.previousWsData && (
          <div className={`${styles.fieldSection} ${styles.fieldSectionDynamic}`}>
            <div className={styles.fieldSectionHeader}>
              <DocumentBlank size={12} className={styles.fieldSectionIconSvg} />
              <span>Conteúdo</span>
            </div>
            <div className={styles.fieldSectionItems}>
              <div className={styles.fieldItemDynamic}>
                Exibe dados dinâmicos
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Form buttons at bottom */}
      {hasForms && (
        <div className={styles.formButtons}>
          {data.forms.slice(0, 2).map((f, i) => (
            <div key={i} className={styles.formButtonBox}>
              [{f.name?.replace('Formulario', '').replace('Voltar', 'voltar') || 'submit'}]
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// Action Button Node - for showing form buttons that lead to next screen
const ActionButtonNode = ({ data }) => (
  <div className={styles.actionButton}>
    <Handle type="target" position={Position.Top} className={styles.handle} />
    <Handle type="source" position={Position.Bottom} className={styles.handle} />
    <span>{data.label}</span>
  </div>
);

// Legacy Screen Node - keeping for compatibility
const ScreenJourneyNode = ({ data }) => {
  const hasInputs = data.inputs && data.inputs.length > 0;
  const hasForms = data.forms && data.forms.length > 0;
  const hasLists = data.lists && data.lists.length > 0;

  return (
    <div className={`${styles.screenJourneyNode} ${data.isMainFlow ? styles.mainFlow : ''}`}>
      <Handle type="target" position={Position.Top} className={styles.handle} />
      <Handle type="source" position={Position.Bottom} className={styles.handle} />
      <div className={styles.screenIcon} style={{ background: data.color || '#0f62fe' }}>
        {data.type === 'WebService' ? <Api size={18} /> :
         data.type?.includes('ADO') ? <DataBase size={18} /> :
         data.type?.includes('Mainframe') ? <Terminal size={18} /> :
         <Screen size={18} />}
      </div>
      <div className={styles.screenContent}>
        <div className={styles.screenLabel}>{data.label}</div>
        {data.description && <div className={styles.screenDesc}>{data.description}</div>}
        <div className={styles.screenType}>{data.type}{data.module ? ` · ${data.module}` : ''}</div>
        {hasInputs && (
          <div className={styles.screenFields}>
            📝 {data.inputs.slice(0, 3).map(f => f.name).join(', ')}
            {data.inputs.length > 3 && ` +${data.inputs.length - 3}`}
          </div>
        )}
        {hasLists && (
          <div className={styles.screenFields}>
            📋 {data.lists.slice(0, 2).map(f => f.name).join(', ')}
          </div>
        )}
        {hasForms && (
          <div className={styles.screenForms}>
            {data.forms.slice(0, 2).map((f, i) => (
              <span key={i} className={styles.formButton}>
                🔘 {f.name}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Algorithm Step Node
const AlgorithmNode = ({ data }) => (
  <div className={styles.algorithmNode}>
    <Handle type="target" position={Position.Top} className={styles.handle} />
    <Handle type="source" position={Position.Bottom} className={styles.handle} id="yes" />
    <Handle type="source" position={Position.Right} className={styles.handle} id="no" />
    <div className={styles.algorithmDiamond}>
      <Document size={20} />
    </div>
    <div className={styles.algorithmContent}>
      <div className={styles.algorithmCondition}>{data.condition}</div>
      <div className={styles.algorithmResult}>
        <span className={styles.yes}>✓ {data.yesPath}</span>
        <span className={styles.no}>✗ {data.noPath}</span>
      </div>
    </div>
  </div>
);

// Decision Diamond Node - for conditional paths
const DecisionNode = ({ data }) => {
  const colors = COLORS.decision;
  return (
    <div className={styles.decisionContainer}>
      <Handle type="target" position={Position.Top} className={styles.handle} />
      <Handle type="source" position={Position.Bottom} className={styles.handle} id="yes" />
      <Handle type="source" position={Position.Right} className={styles.handle} id="no" />
      <div
        className={styles.diamond}
        style={{ borderColor: colors.border, background: colors.bg }}
      >
        <DecisionTree size={20} style={{ color: colors.icon }} />
      </div>
      <div className={styles.decisionLabel} style={{ color: colors.text }}>
        {data.label}
      </div>
      {data.condition && (
        <div className={styles.decisionConditionText}>{data.condition}</div>
      )}
    </div>
  );
};

// Data Binding Node - shows field mappings
const DataBindingNode = ({ data }) => (
  <div className={styles.dataBindingNode}>
    <Handle type="target" position={Position.Top} className={styles.handle} />
    <Handle type="source" position={Position.Bottom} className={styles.handle} />
    <div className={styles.bindingHeader}>🔗 Data Binding</div>
    <div className={styles.bindingContent}>
      {data.bindings?.slice(0, 4).map((b, i) => (
        <div key={i} className={styles.bindingRow}>
          <span className={styles.bindingFrom}>{b.from}</span>
          <ArrowRight size={12} />
          <span className={styles.bindingTo}>{b.to}</span>
        </div>
      ))}
    </div>
  </div>
);

const nodeTypes = {
  menu: MenuNode,
  trn: TRNNode,
  context: ContextNode,
  gateway: GatewayNode,
  screenJourney: ScreenJourneyNode,
  screenWireframe: ScreenWireframeNode,
  actionButton: ActionButtonNode,
  algorithm: AlgorithmNode,
  decision: DecisionNode,
  dataBinding: DataBindingNode
};

// Layout helper - supports both horizontal (LR) and vertical (TB) layouts
const getLayoutedElements = (nodes, edges, direction = 'LR') => {
  const dagreGraph = new dagre.graphlib.Graph();
  dagreGraph.setDefaultEdgeLabel(() => ({}));
  dagreGraph.setGraph({
    rankdir: direction,
    ranksep: direction === 'LR' ? 100 : 80,
    nodesep: direction === 'LR' ? 40 : 50
  });

  // Node dimensions based on type
  const getNodeDimensions = (node) => {
    switch (node.type) {
      case 'trn':
      case 'context':
        return { width: 280, height: 120 };
      case 'algorithm':
        return { width: 250, height: 100 };
      case 'screenWireframe':
        // Calculate height based on number of fields
        const fieldCount = (node.data?.inputs?.length || 0) +
                          (node.data?.lists?.length || 0) +
                          (node.data?.bindings?.length || 0);
        const baseHeight = 80; // Header + name
        const fieldHeight = Math.min(fieldCount, 8) * 24; // 24px per field, max 8
        const formHeight = node.data?.forms?.length > 0 ? 30 : 0;
        return { width: 160, height: baseHeight + fieldHeight + formHeight };
      case 'decision':
        return { width: 100, height: 100 };
      case 'dataBinding':
        return { width: 160, height: 80 };
      case 'actionButton':
        return { width: 100, height: 30 };
      case 'menu':
        return { width: 200, height: 70 };
      case 'gateway':
        return { width: 160, height: 50 };
      default:
        return { width: 160, height: 80 };
    }
  };

  nodes.forEach((node) => {
    const { width, height } = getNodeDimensions(node);
    dagreGraph.setNode(node.id, { width, height });
  });

  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  const layoutedNodes = nodes.map((node) => {
    const nodeWithPosition = dagreGraph.node(node.id);
    const { width, height } = getNodeDimensions(node);
    return {
      ...node,
      position: {
        x: nodeWithPosition.x - width / 2,
        y: nodeWithPosition.y - height / 2
      }
    };
  });

  return { nodes: layoutedNodes, edges };
};

// Build the user journey DFD - dynamically from JSON data
const buildUserJourneyDFD = (transactionData, showAllPaths = false, layoutDirection = 'LR', showAllFields = false) => {
  if (!transactionData) return { nodes: [], edges: [], flowSteps: [] };

  const nodes = [];
  const edges = [];
  const flowSteps = []; // For algorithm panel
  const menuItem = transactionData.menuItem || {};
  const trn = menuItem.trn || {};
  const flowContext = menuItem.flowContext || {};
  // Get the primary routing variable name (first key in flowContext, dynamically discovered)
  const routingVarName = Object.keys(flowContext)[0] || '_TRN_PARAM_0';
  const flow = transactionData.flow || {};
  const interactions = flow.interactions || [];
  const flowGraph = flow.flowGraph || {};

  // Build interaction map for quick lookup
  const interactionMap = {};
  interactions.forEach(i => {
    if (i.path) interactionMap[i.path] = i;
  });

  // Build navigation map with matchesContext info
  const navigationMap = {}; // source -> [{target, matchesContext, condition}]
  interactions.forEach(i => {
    if (i.navigations && i.path) {
      navigationMap[i.path] = i.navigations.map(nav => ({
        target: nav.target,
        matchesContext: nav.matchesContext,
        condition: nav.condition,
        type: nav.type
      }));
    }
  });

  // 1. Menu Node (User starts here)
  nodes.push({
    id: 'menu',
    type: 'menu',
    data: {
      label: menuItem.nomeLogico || 'Menu Item',
      menuPath: menuItem.menuPath || [],
      idMBkl: menuItem.idMBkl
    },
    position: { x: 0, y: 0 }
  });

  // 2. TRN Parameters Node
  nodes.push({
    id: 'trn',
    type: 'trn',
    data: {
      trnFull: trn.full || '',
      module: trn.module || '',
      subProgram: trn.subProgram || '',
      interaction: trn.interaction || '',
      destination: trn.destination || '',
      params: trn.params || []
    },
    position: { x: 0, y: 100 }
  });

  edges.push({
    id: 'e-menu-trn',
    source: 'menu',
    target: 'trn',
    type: 'smoothstep',
    style: { stroke: '#161616', strokeWidth: 2 }
  });

  // 3. Context Variables Node (if we have flowContext)
  if (Object.keys(flowContext).length > 0) {
    nodes.push({
      id: 'context',
      type: 'context',
      data: {
        variables: flowContext
      },
      position: { x: 0, y: 200 }
    });

    edges.push({
      id: 'e-trn-context',
      source: 'trn',
      target: 'context',
      type: 'smoothstep',
      label: 'Define variáveis',
      labelStyle: { fontSize: 10, fill: '#525252' },
      style: { stroke: '#6929c4', strokeWidth: 2 },
      markerEnd: { type: MarkerType.ArrowClosed, color: '#6929c4' }
    });
  }

  // 4. Gateway Node
  const gatewayId = 'gateway';
  nodes.push({
    id: gatewayId,
    type: 'gateway',
    data: {
      label: trn.interaction || 'Gateway',
      module: trn.module
    },
    position: { x: 0, y: 300 }
  });

  edges.push({
    id: 'e-context-gateway',
    source: Object.keys(flowContext).length > 0 ? 'context' : 'trn',
    target: gatewayId,
    type: 'smoothstep',
    label: 'Inicia fluxo',
    labelStyle: { fontSize: 10, fill: '#525252' },
    style: { stroke: '#198038', strokeWidth: 2 },
    markerEnd: { type: MarkerType.ArrowClosed, color: '#198038' }
  });

  // 5. Follow the deterministic path for this specific context (PM04, etc.)
  // The destination module is the key - prioritize paths leading to it
  const destination = trn.destination || '';
  const entryModule = trn.module || '';
  const visited = new Set();
  const menuTargets = flowGraph['MENU'] || [];
  let screenIndex = 0;
  const maxScreens = 30; // Increased to show more traced interactions

  // Helper: check if a path is relevant to the context
  const isRelevantPath = (path) => {
    const module = path.split('\\')[0];

    // For multi-digit destination codes (PM04, MJD201, etc.), check if path contains it
    if (destination && destination.length > 2) {
      return module === entryModule ||
             module === destination ||
             path.includes(destination) ||
             module === 'PM01';
    }

    // For short codes like "1", "090", show all paths from flowGraph
    // (these are routing parameters, not module names)
    return true;
  };

  // Helper: check if a screen is internal/mechanism (not user-facing)
  const isInternalScreen = (path, interaction) => {
    const name = interaction?.name || path.split('\\').pop() || '';
    const nameLower = name.toLowerCase();
    // Skip parameter receivers, auxiliary screens, internal mechanisms
    return nameLower.includes('recebe') ||
           nameLower.includes('param') && nameLower.includes('recebe') ||
           nameLower.includes('_aux') ||
           nameLower.includes('auxiliar') ||
           nameLower.includes('passo_') && !interaction?.fields; // Skip empty step screens
  };

  // Helper: check if path leads to destination module
  const leadsToDestination = (path) => {
    const targets = flowGraph[path] || [];
    return targets.some(t => t.includes(destination));
  };

  // Helper: get previous WebService data for display screens
  const getPreviousWsData = (currentPath) => {
    // Look backwards in flowGraph to find the WebService that leads here
    for (const [sourcePath, targets] of Object.entries(flowGraph)) {
      if (targets.includes(currentPath)) {
        const sourceInteraction = interactionMap[sourcePath];
        if (sourceInteraction?.type === 'WebService') {
          return {
            name: sourceInteraction.name,
            inputs: sourceInteraction.fields?.inputs || [],
            bindings: sourceInteraction.fields?.bindings || [],
            lists: sourceInteraction.fields?.lists || []
          };
        }
      }
    }
    return null;
  };

  // Helper: create a node for the flow
  const createFlowNode = (path, parentNodeId, edgeLabel = null) => {
    if (visited.has(path) || screenIndex >= maxScreens) return null;
    visited.add(path);

    const interaction = interactionMap[path];
    const name = interaction?.name || path.split('\\').pop();

    // Skip internal/mechanism screens - they're not user-facing
    if (isInternalScreen(path, interaction)) {
      console.log('Skipping internal screen:', name);
      return null; // Skip but allow flow to continue
    }
    const nodeId = `node-${screenIndex}`;
    screenIndex++;

    // Determine node type and color based on interaction type
    let color = '#198038';
    let type = interaction?.type || 'Unknown';

    if (!interaction) {
      if (path.includes('WS') || path.toLowerCase().includes('webservice')) type = 'WebService';
      else if (path.toLowerCase().includes('tela')) type = 'Browser';
    }

    if (type === 'WebService') color = '#24a148';
    else if (type?.includes('ADO')) color = '#0072c3';
    else if (type?.includes('Mainframe')) color = '#da1e28';
    else if (type === 'Browser') color = '#0f62fe';

    const classification = interaction?.classification || {};
    const description = classification.categoryLabel || getScreenDescription(name, type);

    // Extract fields and forms
    const fieldsData = interaction?.fields || {};
    const rawInputs = fieldsData.inputs || [];
    // Group date fields (Dia/Mes/Ano) into DatePicker components for visualization
    const nodeInputs = groupFieldsForVisualization(rawInputs);
    const nodeLists = fieldsData.lists || [];
    const nodeBindings = fieldsData.bindings || [];
    const nodeWsInputs = fieldsData.wsInputs || [];
    const nodeForms = interaction?.forms || [];

    // Get operations and configuration
    const operations = interaction?.operations || [];
    const config = interaction?.configuration || {};
    const storedProcs = config.database?.storedProcedures || [];
    const wsMethod = config.webService?.nomeFisico || null;
    const mainframeCode = config.mainframe?.transactionCode || null;

    // Determine if node has inputs/lists/bindings
    const hasInputs = nodeInputs.length > 0;
    const hasLists = nodeLists.length > 0;
    const hasBindings = nodeBindings.length > 0;

    // For display-only screens, get the previous WebService response structure
    const previousWsData = (!hasInputs && !hasLists && !hasBindings && type === 'Browser')
      ? getPreviousWsData(path)
      : null;

    nodes.push({
      id: nodeId,
      type: 'screenWireframe',
      data: {
        label: name.replace(/_/g, ' '),
        description: description,
        type: type,
        color: color,
        isMainFlow: true,
        path: path,
        module: interaction?.module || path.split('\\')[0],
        inputs: nodeInputs,
        _rawFields: rawInputs, // Original fields for expandable details
        lists: nodeLists,
        bindings: nodeBindings,
        wsInputs: nodeWsInputs,
        forms: nodeForms,
        templates: interaction?.templates,
        operations: operations,
        storedProcedures: storedProcs,
        wsMethod: wsMethod,
        mainframeCode: mainframeCode,
        previousWsData: previousWsData,
        showAllFields: showAllFields
      },
      position: { x: 0, y: 400 + screenIndex * 100 }
    });

    // Check if this is a service node
    const isServiceType = type === 'WebService' || type?.includes('ADO');
    const isMainframeType = type?.includes('Mainframe');

    // Get navigation type from navigationMap - use parent path to find nav info
    const parentPath = Object.entries(interactionMap).find(([k, v]) =>
      flowGraph[k]?.includes(path)
    )?.[0];
    const nav = navigationMap[parentPath]?.find(n => n.target === path);
    const navType = nav?.type;
    const navLabel = navType === 'enviows' ? '🌐 WebService' :
                     navType === 'enviomainframe' ? '💻 Mainframe' :
                     navType === 'formulario' ? '📝 Form' :
                     navType === 'conditional' ? '⚡ Conditional' :
                     edgeLabel;

    // Create edge from parent to this node
    edges.push({
      id: `e-${parentNodeId}-${nodeId}`,
      source: parentNodeId,
      target: nodeId,
      type: 'smoothstep',
      animated: isServiceType || isMainframeType,
      label: navLabel,
      labelStyle: { fontSize: 9, fill: '#525252', fontWeight: 500 },
      labelBgStyle: { fill: 'white', fillOpacity: 0.9 },
      labelBgPadding: [4, 2],
      labelBgBorderRadius: 3,
      style: {
        stroke: isServiceType ? '#24a148' : isMainframeType ? '#da1e28' : '#161616',
        strokeWidth: isServiceType || isMainframeType ? 2 : 2,
        strokeDasharray: navType === 'conditional' ? '5,5' : undefined
      },
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color: isServiceType ? '#24a148' : isMainframeType ? '#da1e28' : '#161616'
      }
    });

    // Record for algorithm panel with user journey narrative
    const userAction = type === 'Browser'
      ? (nodeForms.length > 0 ? `Usuário preenche e clica "${nodeForms[0]?.name}"` : 'Usuário visualiza tela')
      : (type === 'WebService' ? 'Sistema processa requisição' : 'Sistema executa');

    flowSteps.push({
      step: screenIndex,
      name: name,
      path: path,
      type: type,
      description: description,
      module: interaction?.module || path.split('\\')[0],
      inputs: nodeInputs.slice(0, 8),
      lists: nodeLists.slice(0, 5),
      bindings: nodeBindings.slice(0, 5),
      forms: nodeForms,
      templates: interaction?.templates,
      userAction: userAction
    });

    return nodeId;
  };

  // Process the flow following the destination context
  const processContextFlow = (path, parentNodeId) => {
    if (visited.has(path) || screenIndex >= maxScreens) return null;

    // Track if we create a decision node for branching
    let decisionNodeId = null;

    // Try to create node - createFlowNode handles visited marking and internal screen skipping
    const nodeId = createFlowNode(path, parentNodeId);

    // Even if node was skipped (internal screen), we still process its targets
    // Mark as visited if not already (for internal screens that were skipped)
    if (!visited.has(path)) {
      visited.add(path);
    }

    // Get navigation targets from flowGraph
    const targets = flowGraph[path] || [];
    const navs = navigationMap[path] || [];

    if (targets.length === 0) return;

    // Strategy: prioritize paths leading to destination module (PM04, etc.)
    let nextTargets = [];

    // 1. First look for direct paths to destination module
    const destPaths = targets.filter(t => t.includes(destination));
    if (destPaths.length > 0) {
      nextTargets = destPaths;
    }

    // 2. If no direct destination paths, look for paths that LEAD to destination
    if (nextTargets.length === 0) {
      const leadsToDestPaths = targets.filter(t => {
        const subTargets = flowGraph[t] || [];
        return subTargets.some(st => st.includes(destination));
      });
      if (leadsToDestPaths.length > 0) {
        nextTargets = leadsToDestPaths;
      }
    }

    // 3. Then look for context-matching navigations
    if (nextTargets.length === 0 && navs.length > 0) {
      const contextMatching = navs
        .filter(n => n.matchesContext === true && targets.includes(n.target))
        .filter(n => isRelevantPath(n.target))
        .map(n => n.target);

      if (contextMatching.length > 0) {
        nextTargets = contextMatching;
      }
    }

    // 4. Fall back to relevant paths in flowGraph
    if (nextTargets.length === 0 && showAllPaths) {
      nextTargets = targets.filter(isRelevantPath);
    }

    // 5. If still nothing, take any relevant path
    if (nextTargets.length === 0) {
      const relevant = targets.filter(isRelevantPath);
      if (relevant.length > 0) nextTargets = [relevant[0]];
    }

    // Add decision node if there are multiple meaningful choices (fork in the road)
    const uniqueTargets = [...new Set(nextTargets)];
    const meaningfulTargets = uniqueTargets.filter(t => !isInternalScreen(t, interactionMap[t]));

    if (meaningfulTargets.length > 1 && nodeId) {
      // Check if these lead to different destinations or modules
      const targetDestinations = meaningfulTargets.map(t => {
        if (t.includes(destination)) return destination;
        const mod = t.split('\\')[0];
        return mod;
      });
      const uniqueDestinations = [...new Set(targetDestinations)];

      if (uniqueDestinations.length > 1) {
        // Get condition info from navigations if available
        const destNav = navs.find(n => n.target.includes(destination));
        const conditionLogic = destNav?.condition;

        // Build condition text
        let conditionText = `$${routingVarName} == "${destination}"?`;
        if (conditionLogic?.function === 'Igual') {
          conditionText = `${conditionLogic.left} == "${conditionLogic.right}"`;
        } else if (conditionLogic?.function) {
          conditionText = `${conditionLogic.function}(${conditionLogic.left || ''}, ${conditionLogic.right || ''})`;
        }

        // Add a decision node
        const decisionId = `decision-${path}-${screenIndex}`;
        nodes.push({
          id: decisionId,
          type: 'decision',
          data: {
            label: 'Decisão',
            condition: conditionText,
            branches: meaningfulTargets.map(t => ({
              target: t,
              destination: t.includes(destination) ? destination : t.split('\\')[0],
              matches: t.includes(destination)
            }))
          },
          position: { x: 0, y: 400 + screenIndex * 100 }
        });

        edges.push({
          id: `e-${nodeId}-${decisionId}`,
          source: nodeId,
          target: decisionId,
          type: 'smoothstep',
          label: 'Condição',
          labelStyle: { fontSize: 9, fill: '#ff832b', fontWeight: 600 },
          style: { stroke: '#ff832b', strokeWidth: 2 },
          markerEnd: { type: MarkerType.ArrowClosed, color: '#ff832b' }
        });

        // Use decision node as parent for child nodes
        decisionNodeId = decisionId;
      }
    }

    // Process next targets - prioritize destination paths
    // Use decision node if created, otherwise current node, otherwise parent
    const currentParentId = decisionNodeId || nodeId || parentNodeId;

    const sortedTargets = uniqueTargets.sort((a, b) => {
      const aHasDest = a.includes(destination) ? 0 : 1;
      const bHasDest = b.includes(destination) ? 0 : 1;
      return aHasDest - bHasDest;
    });

    sortedTargets.slice(0, showAllPaths ? 3 : 2).forEach(target => {
      if (!visited.has(target)) {
        processContextFlow(target, currentParentId);
      }
    });

    return nodeId;
  };

  // Start from MENU targets - gateway is the parent
  menuTargets.forEach(target => processContextFlow(target, gatewayId));

  // If still no flow but we have destination, try to find path to it
  if (screenIndex === 0 && destination) {
    // Find any interaction in the destination module
    const destInteractions = interactions.filter(i => i.module === destination);
    if (destInteractions.length > 0) {
      destInteractions.slice(0, 3).forEach(i => {
        if (i.path) createFlowNode(i.path, gatewayId);
      });
    }
  }

  // Apply layout based on direction (LR = horizontal, TB = vertical)
  const layoutResult = getLayoutedElements(nodes, edges, layoutDirection);

  return {
    nodes: layoutResult.nodes,
    edges: layoutResult.edges,
    flowSteps
  };
};

// Helper to get screen description from name and type
const getScreenDescription = (name, type) => {
  const nameLower = (name || '').toLowerCase();
  // Infer from name patterns
  if (nameLower.includes('lista') && nameLower.includes('cnpj')) return 'Lista de CNPJs';
  if (nameLower.includes('lista') && nameLower.includes('portador')) return 'Lista de Portadores';
  if (nameLower.includes('lista') && nameLower.includes('msg') || nameLower.includes('swift')) return 'Lista de Mensagens SWIFT';
  if (nameLower.includes('lista')) return 'Lista de itens';
  if (nameLower.includes('selecao') && nameLower.includes('empresa')) return 'Seleção de Empresa';
  if (nameLower.includes('selecao') && nameLower.includes('master')) return 'Seleção Master';
  if (nameLower.includes('selecao') && nameLower.includes('operador')) return 'Seleção de Operador';
  if (nameLower.includes('selecao')) return 'Seleção';
  if (nameLower.includes('recebe_param') || nameLower.includes('param')) return 'Recebe Parâmetros';
  if (nameLower.includes('inicial')) return 'Tela Inicial';
  if (nameLower.includes('retorno')) return 'Tela de Resultado';
  if (nameLower.includes('perfil')) return 'Perfil';
  if (nameLower.includes('filtro')) return 'Filtro de Busca';
  if (nameLower.includes('consulta') && nameLower.includes('cnpj')) return 'Consulta por CNPJ';
  if (nameLower.includes('consulta')) return 'Consulta';
  if (nameLower.includes('detalhe') || nameLower.includes('detail')) return 'Detalhes';
  if (nameLower.includes('sair') || nameLower.includes('exit')) return 'Saída';
  if (nameLower.includes('passo')) return 'Passo do Processo';
  // By type
  if (type === 'WebService') return 'Serviço Web';
  if (type?.includes('ADO')) return type === 'ADOConsulta' ? 'Consulta DB' : 'Operação DB';
  if (type?.includes('Mainframe')) return 'Gateway Mainframe';
  return '';
};

const UserJourneyDFDInner = ({ transactionData }) => {
  const [showAllPaths, setShowAllPaths] = useState(false);
  const [showAllFields, setShowAllFields] = useState(false);
  const [layoutDirection, setLayoutDirection] = useState('LR'); // 'LR' horizontal or 'TB' vertical
  const [showMinimap, setShowMinimap] = useState(true);
  const [selectedNode, setSelectedNode] = useState(null);
  const [flowNodes, setFlowNodes] = useState([]);
  const reactFlowWrapper = useRef(null);
  const { fitView, zoomIn, zoomOut, getNodes } = useReactFlow();

  const { nodes: initialNodes, edges, flowSteps } = useMemo(() => {
    return buildUserJourneyDFD(transactionData, showAllPaths, layoutDirection, showAllFields);
  }, [transactionData, showAllPaths, layoutDirection, showAllFields]);

  // Initialize flow nodes from layout
  useEffect(() => {
    setFlowNodes(initialNodes);
  }, [initialNodes]);

  // Handle node position changes for dragging
  const onNodesChange = useCallback((changes) => {
    setFlowNodes((nds) => {
      return nds.map((node) => {
        const change = changes.find((c) => c.id === node.id);
        if (change && change.type === 'position' && change.position) {
          return { ...node, position: change.position };
        }
        return node;
      });
    });
  }, []);

  // Handle node click to show details
  const onNodeClick = useCallback((event, node) => {
    setSelectedNode(node);
  }, []);

  // Use flowNodes for rendering (allows dragging)
  const nodes = flowNodes.length > 0 ? flowNodes : initialNodes;

  // Export to PNG
  const handleExport = useCallback(() => {
    if (reactFlowWrapper.current === null) return;

    toPng(reactFlowWrapper.current, {
      backgroundColor: '#ffffff',
      width: reactFlowWrapper.current.offsetWidth * 2,
      height: reactFlowWrapper.current.offsetHeight * 2,
      style: {
        transform: 'scale(2)',
        transformOrigin: 'top left'
      }
    }).then((dataUrl) => {
      const link = document.createElement('a');
      link.download = `dfd_${transactionData?.menuItem?.idMBkl || 'flow'}.png`;
      link.href = dataUrl;
      link.click();
    }).catch((err) => {
      console.error('Export failed:', err);
    });
  }, [transactionData]);

  // Toggle layout direction
  const toggleLayout = useCallback(() => {
    setLayoutDirection(prev => prev === 'LR' ? 'TB' : 'LR');
  }, []);

  if (!nodes.length) {
    return (
      <div className={styles.noData}>
        <User size={32} />
        <p>Selecione uma transação para ver o fluxo do usuário</p>
      </div>
    );
  }

  // Extract TRN info for display
  const trn = transactionData?.menuItem?.trn || {};
  const destination = trn.destination || '';

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div className={styles.headerLeft}>
          <h4>Jornada do Usuário - DFD</h4>
          {trn.full && (
            <div className={styles.trnInfo}>
              <code>{trn.full}</code>
              <span className={styles.trnDestination}>Destino: <strong>{destination}</strong></span>
            </div>
          )}
        </div>
        <div className={styles.headerControls}>
          <Toggle
            id="show-all-dfd-paths"
            size="sm"
            labelA="Só contexto"
            labelB="Todos caminhos"
            toggled={showAllPaths}
            onToggle={() => setShowAllPaths(!showAllPaths)}
          />
        </div>
      </div>
      <div className={styles.flowContainer} ref={reactFlowWrapper}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          onNodesChange={onNodesChange}
          onNodeClick={onNodeClick}
          fitView
          minZoom={0.2}
          maxZoom={2}
          nodesDraggable={true}
          nodesConnectable={false}
          elementsSelectable={true}
          panOnDrag={true}
          zoomOnScroll={true}
          panOnScroll={true}
          selectNodesOnDrag={false}
        >
          {/* Custom Toolbar Panel */}
          <Panel position="top-left" className={styles.toolbar}>
            <div className={styles.toolbarGroup}>
              <IconButton
                kind="ghost"
                size="sm"
                label="Zoom In"
                onClick={() => zoomIn()}
                className={styles.toolbarBtn}
              >
                <ZoomIn size={16} />
              </IconButton>
              <IconButton
                kind="ghost"
                size="sm"
                label="Zoom Out"
                onClick={() => zoomOut()}
                className={styles.toolbarBtn}
              >
                <ZoomOut size={16} />
              </IconButton>
              <IconButton
                kind="ghost"
                size="sm"
                label="Ajustar à Tela"
                onClick={() => fitView({ padding: 0.2 })}
                className={styles.toolbarBtn}
              >
                <FitToScreen size={16} />
              </IconButton>
              <IconButton
                kind="ghost"
                size="sm"
                label="Exportar PNG"
                onClick={handleExport}
                className={styles.toolbarBtn}
              >
                <Download size={16} />
              </IconButton>
            </div>
            <div className={styles.toolbarDivider} />
            <div className={styles.toolbarGroup}>
              <span className={styles.toolbarLabel}>Layout:</span>
              <Button
                kind={layoutDirection === 'LR' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setLayoutDirection('LR')}
                renderIcon={ArrowRight}
                className={styles.layoutBtn}
                title="Fluxo horizontal - mostra o fluxo da esquerda para direita"
              >
                Fluxo
              </Button>
              <Button
                kind={layoutDirection === 'TB' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setLayoutDirection('TB')}
                renderIcon={TreeViewAlt}
                className={styles.layoutBtn}
                title="Hierárquico - mostra a hierarquia de cima para baixo"
              >
                Hierárquico
              </Button>
            </div>
            <div className={styles.toolbarDivider} />
            <div className={styles.toolbarGroup}>
              <Toggle
                id="show-all-fields"
                size="sm"
                labelA="Resumo"
                labelB="Todos campos"
                toggled={showAllFields}
                onToggle={() => setShowAllFields(!showAllFields)}
              />
            </div>
            <div className={styles.toolbarDivider} />
            <div className={styles.toolbarGroup}>
              <Toggle
                id="show-minimap"
                size="sm"
                labelA=""
                labelB="Minimapa"
                toggled={showMinimap}
                onToggle={() => setShowMinimap(!showMinimap)}
              />
            </div>
          </Panel>

          {/* Drag hint */}
          <Panel position="bottom-left" className={styles.dragHint}>
            <Move size={14} />
            <span>Arraste para mover nós • Use scroll para zoom</span>
          </Panel>

          <Controls showInteractive={false} />
          <Background variant="dots" gap={16} size={1} color="#e0e0e0" />
          {showMinimap && (
            <MiniMap
              nodeColor={(node) => {
                if (node.type === 'menu') return '#0f62fe';
                if (node.type === 'trn') return '#8a3ffc';
                if (node.type === 'context') return '#009d9a';
                if (node.type === 'gateway') return '#198038';
                if (node.type === 'screenWireframe') return '#161616';
                if (node.type === 'decision') return '#ff832b';
                return '#697077';
              }}
              nodeStrokeWidth={3}
              maskColor="rgba(0, 0, 0, 0.1)"
              pannable
              zoomable
              style={{
                background: '#f4f4f4',
                border: '1px solid #e0e0e0',
                borderRadius: '4px'
              }}
            />
          )}
        </ReactFlow>
      </div>

      {/* Selected Node Details Panel */}
      {selectedNode && (
        <div className={styles.nodeDetailsPanel}>
          <div className={styles.nodeDetailsPanelHeader}>
            <h5>Detalhes: {selectedNode.data.label}</h5>
            <button onClick={() => setSelectedNode(null)} className={styles.closeBtn}>×</button>
          </div>
          <div className={styles.nodeDetailsPanelContent}>
            <div className={styles.detailSection}>
              <strong>Tipo:</strong> {selectedNode.data.type}
            </div>
            <div className={styles.detailSection}>
              <strong>Path:</strong> <code>{selectedNode.data.path}</code>
            </div>
            <div className={styles.detailSection}>
              <strong>Módulo:</strong> {selectedNode.data.module}
            </div>

            {selectedNode.data.description && (
              <div className={styles.detailSection}>
                <strong>Descrição:</strong> {selectedNode.data.description}
              </div>
            )}

            {selectedNode.data.wsMethod && (
              <div className={styles.detailSection}>
                <strong>Método WebService:</strong> <code>{selectedNode.data.wsMethod}</code>
              </div>
            )}

            {selectedNode.data.mainframeCode && (
              <div className={styles.detailSection}>
                <strong>Código Mainframe:</strong> <code>{selectedNode.data.mainframeCode}</code>
              </div>
            )}

            {selectedNode.data.storedProcedures?.length > 0 && (
              <div className={styles.detailSection}>
                <strong>Stored Procedures ({selectedNode.data.storedProcedures.length}):</strong>
                <ul>
                  {selectedNode.data.storedProcedures.map((sp, i) => (
                    <li key={i}><code>{sp}</code></li>
                  ))}
                </ul>
              </div>
            )}

            {selectedNode.data.operations?.length > 0 && (
              <div className={styles.detailSection}>
                <strong>Operações ({selectedNode.data.operations.length}):</strong>
                <ul>
                  {selectedNode.data.operations.map((op, i) => (
                    <li key={i}>
                      <code>{op.function}</code>
                      {op.parameters?.length > 0 && (
                        <span> ({op.parameters.map(p => p.value || p.type).join(', ')})</span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {selectedNode.data.inputs?.length > 0 && (
              <div className={styles.detailSection}>
                <strong>Campos de Entrada ({selectedNode.data.inputs.length}):</strong>
                <ul>
                  {selectedNode.data.inputs.map((f, i) => (
                    <li key={i}>{f.name}</li>
                  ))}
                </ul>
              </div>
            )}

            {selectedNode.data.wsInputs?.length > 0 && (
              <div className={styles.detailSection}>
                <strong>Recebe do WebService ({selectedNode.data.wsInputs.length}):</strong>
                <ul>
                  {selectedNode.data.wsInputs.map((f, i) => (
                    <li key={i}>{f.name} (pos: {f.position}, size: {f.size})</li>
                  ))}
                </ul>
              </div>
            )}

            {selectedNode.data.lists?.length > 0 && (
              <div className={styles.detailSection}>
                <strong>Colunas de Lista ({selectedNode.data.lists.length}):</strong>
                <ul>
                  {selectedNode.data.lists.map((f, i) => (
                    <li key={i}>{f.name} {f.size ? `(${f.size})` : ''}</li>
                  ))}
                </ul>
              </div>
            )}

            {selectedNode.data.bindings?.length > 0 && (
              <div className={styles.detailSection}>
                <strong>Bindings WS ({selectedNode.data.bindings.length}):</strong>
                <ul>
                  {selectedNode.data.bindings.map((b, i) => (
                    <li key={i}>{b.textWS || b.tagXML || `pos:${b.position}`}</li>
                  ))}
                </ul>
              </div>
            )}

            {selectedNode.data.forms?.length > 0 && (
              <div className={styles.detailSection}>
                <strong>Formulários/Ações ({selectedNode.data.forms.length}):</strong>
                <ul>
                  {selectedNode.data.forms.map((f, i) => (
                    <li key={i}>{f.name} → {f.target || '(sem destino)'}</li>
                  ))}
                </ul>
              </div>
            )}

            {selectedNode.data.templates?.main && (
              <div className={styles.detailSection}>
                <strong>Template HTML:</strong>
                <pre className={styles.templateCode}>
                  {selectedNode.data.templates.main.substring(0, 500)}
                  {selectedNode.data.templates.main.length > 500 ? '...' : ''}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const UserJourneyDFD = (props) => {
  return (
    <ReactFlowProvider>
      <UserJourneyDFDInner {...props} />
    </ReactFlowProvider>
  );
};

export default UserJourneyDFD;
