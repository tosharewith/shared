/**
 * COMEX Routes
 *
 * REST API routes for COMEX operations.
 * These routes proxy requests to the Go business service.
 *
 * XML → REST Endpoint Mapping:
 * | XML                      | HTTP Method | Endpoint                              |
 * |--------------------------|-------------|---------------------------------------|
 * | ConsultaCNPJS.xml        | GET         | /api/v1/comex/companies               |
 * | Tela_Entrada_Dados.xml   | POST        | /api/v1/comex/export/billing/query    |
 * | Tela_Entrada_OPRE.xml    | POST        | /api/v1/comex/payment-orders/query    |
 * | Tela_Lista_CNPJ_BAL7.xml | POST        | /api/v1/comex/letters-of-credit/query |
 * | TelaListaCNPJCambio.xml  | POST        | /api/v1/comex/fx/quotations/query     |
 */

import { Router, Request, Response, NextFunction } from 'express';
import { comexService } from '../services/comex.proxy';
import { authMiddleware, requirePermission } from '../middleware/auth';
import {
  BillingQuery,
  PaymentOrderQuery,
  LCQuery,
  FXQuery,
  ExchangeSimulationRequest,
  SWIFTMessageRequest,
} from '../types/comex.types';

const router = Router();

// Apply auth middleware to all routes
router.use(authMiddleware);

// Error handler wrapper
const asyncHandler = (fn: (req: Request, res: Response, next: NextFunction) => Promise<void>) => {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

// =============================================================================
// COMPANIES (ConsultaCNPJS.xml)
// =============================================================================

/**
 * GET /api/v1/comex/companies
 * List companies with COMEX access for the authenticated user
 */
router.get(
  '/companies',
  requirePermission('comex:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const userCPF = req.user!.cpf;
    const result = await comexService.getCompanies(userCPF);
    res.json(result);
  })
);

/**
 * GET /api/v1/comex/companies/:cnpj
 * Get details of a specific company
 */
router.get(
  '/companies/:cnpj',
  requirePermission('comex:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const { cnpj } = req.params;
    const result = await comexService.getCompanyDetails(cnpj);
    res.json(result);
  })
);

// =============================================================================
// EXPORT BILLING (Tela_Entrada_Dados.xml → BAL1)
// =============================================================================

/**
 * POST /api/v1/comex/export/billing/query
 * Query export billing operations (Cobrança e Remessa de Exportação)
 */
router.post(
  '/export/billing/query',
  requirePermission('comex:billing:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const query: BillingQuery = req.body;
    const result = await comexService.queryBillingOperations(query);
    res.json(result);
  })
);

/**
 * GET /api/v1/comex/export/billing/:id
 * Get billing operation details
 */
router.get(
  '/export/billing/:id',
  requirePermission('comex:billing:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params;
    const result = await comexService.getBillingOperationDetails(id);
    res.json(result);
  })
);

// =============================================================================
// LETTERS OF CREDIT (Tela_Lista_CNPJ_BAL7.xml → BAL7)
// =============================================================================

/**
 * POST /api/v1/comex/export/letters-of-credit/query
 * Query negotiated letters of credit
 */
router.post(
  '/export/letters-of-credit/query',
  requirePermission('comex:lc:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const query: LCQuery = req.body;
    const result = await comexService.queryLettersOfCredit(query);
    res.json(result);
  })
);

/**
 * GET /api/v1/comex/export/letters-of-credit/:id
 * Get letter of credit details
 */
router.get(
  '/export/letters-of-credit/:id',
  requirePermission('comex:lc:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params;
    const result = await comexService.getLetterOfCreditDetails(id);
    res.json(result);
  })
);

/**
 * POST /api/v1/comex/export/received-letters/query
 * Query received letters of credit (C9RT)
 */
router.post(
  '/export/received-letters/query',
  requirePermission('comex:lc:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const query: LCQuery = req.body;
    const result = await comexService.queryReceivedLetters(query);
    res.json(result);
  })
);

// =============================================================================
// PAYMENT ORDERS (Tela_Entrada_OPRE.xml → BAL3)
// =============================================================================

/**
 * POST /api/v1/comex/payment-orders/query
 * Query payment orders from abroad (OPRE)
 */
router.post(
  '/payment-orders/query',
  requirePermission('comex:payment:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const query: PaymentOrderQuery = req.body;
    const result = await comexService.queryPaymentOrders(query);
    res.json(result);
  })
);

/**
 * GET /api/v1/comex/payment-orders/:id
 * Get payment order details
 */
router.get(
  '/payment-orders/:id',
  requirePermission('comex:payment:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params;
    const result = await comexService.getPaymentOrderDetails(id);
    res.json(result);
  })
);

/**
 * GET /api/v1/comex/payment-orders/:id/status
 * Get payment order status
 */
router.get(
  '/payment-orders/:id/status',
  requirePermission('comex:payment:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params;
    const result = await comexService.getPaymentOrderStatus(id);
    res.json(result);
  })
);

// =============================================================================
// FX QUOTATIONS (TelaListaCNPJCambio.xml → BAEI)
// =============================================================================

/**
 * POST /api/v1/comex/fx/quotations/query
 * Query FX quotations
 */
router.post(
  '/fx/quotations/query',
  requirePermission('comex:fx:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const query: FXQuery = req.body;
    const result = await comexService.queryFXQuotations(query);
    res.json(result);
  })
);

/**
 * GET /api/v1/comex/fx/quotations/:id
 * Get quotation details
 */
router.get(
  '/fx/quotations/:id',
  requirePermission('comex:fx:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params;
    const result = await comexService.getQuotationDetails(id);
    res.json(result);
  })
);

/**
 * GET /api/v1/comex/fx/rates
 * Get current exchange rates
 */
router.get(
  '/fx/rates',
  requirePermission('comex:fx:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const currencies = req.query.currencies
      ? (req.query.currencies as string).split(',')
      : undefined;
    const result = await comexService.getExchangeRates(currencies);
    res.json(result);
  })
);

/**
 * POST /api/v1/comex/fx/simulate
 * Simulate exchange operation
 */
router.post(
  '/fx/simulate',
  requirePermission('comex:fx:simulate'),
  asyncHandler(async (req: Request, res: Response) => {
    const request: ExchangeSimulationRequest = req.body;
    const result = await comexService.simulateExchange(request);
    res.json(result);
  })
);

// =============================================================================
// SWIFT
// =============================================================================

/**
 * GET /api/v1/comex/swift/messages
 * List SWIFT messages
 */
router.get(
  '/swift/messages',
  requirePermission('comex:swift:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const { status, dateFrom, dateTo } = req.query;
    const result = await comexService.listSWIFTMessages(
      status as string,
      dateFrom as string,
      dateTo as string
    );
    res.json(result);
  })
);

/**
 * GET /api/v1/comex/swift/messages/:uetr
 * Get SWIFT message details
 */
router.get(
  '/swift/messages/:uetr',
  requirePermission('comex:swift:read'),
  asyncHandler(async (req: Request, res: Response) => {
    const { uetr } = req.params;
    const result = await comexService.getSWIFTMessageDetails(uetr);
    res.json(result);
  })
);

/**
 * POST /api/v1/comex/swift/messages
 * Send SWIFT message
 */
router.post(
  '/swift/messages',
  requirePermission('comex:swift:write'),
  asyncHandler(async (req: Request, res: Response) => {
    const request: SWIFTMessageRequest = req.body;
    const result = await comexService.sendSWIFTMessage(request);
    res.status(201).json(result);
  })
);

// =============================================================================
// HEALTH CHECK
// =============================================================================

/**
 * GET /api/v1/comex/health
 * Health check endpoint (no auth required for this specific endpoint)
 */
router.get('/health', async (_req: Request, res: Response) => {
  try {
    const result = await comexService.healthCheck();
    res.json(result);
  } catch (error) {
    res.status(503).json({
      service: 'COMEX-BFF',
      healthy: false,
      timestamp: new Date().toISOString(),
      details: { error: 'Business service unavailable' },
    });
  }
});

export default router;
