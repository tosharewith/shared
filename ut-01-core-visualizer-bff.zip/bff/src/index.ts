/**
 * COMEX BFF - Backend for Frontend
 *
 * This is the bridge layer between the React frontend and the Go business services.
 *
 * Architecture:
 *   Frontend (React) → BFF (Node.js/TypeScript) → Business Service (Go) → Adapters → Backends
 *
 * Responsibilities:
 * - Authentication/Authorization (JWT validation)
 * - Rate limiting
 * - Request aggregation
 * - Response transformation
 * - Caching strategies
 * - Security headers
 */

import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';

import comexRoutes from './routes/comex.routes';
import projectRoutes from './routes/project.routes';
import { requestLogger, logger } from './middleware/logger';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// =============================================================================
// MIDDLEWARE
// =============================================================================

// Security headers
app.use(helmet());

// CORS configuration - allow visualizer and other local ports
app.use(
  cors({
    origin: process.env.CORS_ORIGIN || ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:3002'],
    credentials: true,
  })
);

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Request logging
app.use(requestLogger);

// Rate limiting
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute
  message: {
    code: 'RATE_LIMIT',
    message: 'Too many requests, please try again later.',
  },
});
app.use('/api/', limiter);

// =============================================================================
// ROUTES
// =============================================================================

// Health check for BFF itself
app.get('/health', (_req: Request, res: Response) => {
  res.json({
    service: 'COMEX-BFF',
    healthy: true,
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version || '1.0.0',
  });
});

// COMEX API routes
app.use('/api/v1/comex', comexRoutes);

// Project generation routes (no auth required for now)
app.use('/api/v1/project', projectRoutes);

// =============================================================================
// ERROR HANDLING
// =============================================================================

// 404 handler
app.use((_req: Request, res: Response) => {
  res.status(404).json({
    code: 'NOT_FOUND',
    message: 'Resource not found',
  });
});

// Global error handler
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  logger.error('Unhandled error', { error: err.message, stack: err.stack });

  // Check if it's an Axios error (from business service)
  if ((err as any).response) {
    const axiosError = err as any;
    res.status(axiosError.response.status || 500).json({
      code: 'SERVICE_ERROR',
      message: axiosError.response.data?.message || 'Business service error',
    });
    return;
  }

  res.status(500).json({
    code: 'INTERNAL_ERROR',
    message: 'Internal server error',
  });
});

// =============================================================================
// START SERVER
// =============================================================================

app.listen(PORT, () => {
  logger.info(`COMEX BFF started`, {
    port: PORT,
    environment: process.env.NODE_ENV || 'development',
    comexServiceUrl: process.env.COMEX_SERVICE_URL || 'http://localhost:8081',
  });
});

export default app;
