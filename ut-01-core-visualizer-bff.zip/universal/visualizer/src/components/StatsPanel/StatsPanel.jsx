import { useMemo } from 'react';
import styles from './StatsPanel.module.scss';

/**
 * StatsPanel Component
 * Dashboard statistics cards showing graph metrics
 * Based on Angular sp1nbp-viewer dashboard
 */
const StatsPanel = ({ graphData }) => {
  const stats = useMemo(() => {
    if (!graphData || !graphData.nodes || !graphData.edges) {
      return {
        totalNodes: 0,
        screenNodes: 0,
        serviceNodes: 0,
        totalEdges: 0,
        flowEdges: 0
      };
    }

    const screenNodes = graphData.nodes.filter(n =>
      n.data?.type === 'component' || n.data?.type === 'screen'
    ).length;

    const serviceNodes = graphData.nodes.filter(n =>
      n.data?.type === 'valorizacao' || n.data?.type === 'service'
    ).length;

    const flowEdges = graphData.edges.filter(e =>
      e.data?.flowStep && e.data.flowStep !== ''
    ).length;

    return {
      totalNodes: graphData.nodes.length,
      screenNodes,
      serviceNodes,
      totalEdges: graphData.edges.length,
      flowEdges
    };
  }, [graphData]);

  return (
    <div className={styles.statsPanel}>
      <div className={styles.statsGrid}>
        {/* Total Components */}
        <div className={`${styles.statCard} ${styles.orange}`}>
          <div className={styles.statIcon}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <path d="M3 9h18M9 21V9"/>
            </svg>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>{stats.totalNodes}</span>
            <span className={styles.statLabel}>Total Components</span>
          </div>
        </div>

        {/* Screen Components */}
        <div className={`${styles.statCard} ${styles.blue}`}>
          <div className={styles.statIcon}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="2" y="3" width="20" height="14" rx="2"/>
              <path d="M8 21h8M12 17v4"/>
            </svg>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>{stats.screenNodes}</span>
            <span className={styles.statLabel}>Screen Components</span>
          </div>
        </div>

        {/* Service Calls */}
        <div className={`${styles.statCard} ${styles.green}`}>
          <div className={styles.statIcon}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/>
            </svg>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>{stats.serviceNodes}</span>
            <span className={styles.statLabel}>Service Calls</span>
          </div>
        </div>

        {/* Navigation Flows */}
        <div className={`${styles.statCard} ${styles.purple}`}>
          <div className={styles.statIcon}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
            </svg>
          </div>
          <div className={styles.statContent}>
            <span className={styles.statValue}>{stats.flowEdges}</span>
            <span className={styles.statLabel}>Navigation Flows</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsPanel;
