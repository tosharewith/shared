# XML Extraction to JSON Feature - Implementation Plan

## Overview
Enhance the XML upload feature to run context-aware extraction and generate transaction JSON files that can be visualized or downloaded.

## User Flow

```
1. User selects "Upload XMLs" mode
2. User uploads a folder with XML files
3. User enters TRN string (e.g., "PM01\SP1NB\ConsultaCNPJs@PM04@Cópias dos Swift OPE")
4. System parses TRN and extracts: module, subProgram, interaction, params, destination, title
5. System runs extraction engine to trace flow from entry interaction
6. User can:
   - Preview generated JSON
   - Download JSON file
   - View in visualizer directly
7. Alternative: User can upload existing JSON file for direct visualization
```

## TRN String Format

```
MODULE\SUBPROGRAM\INTERACTION@PARAM0@PARAM1@PARAM2...

Example: "PM01\SP1NB\ConsultaCNPJs@PM04@Cópias dos Swift OPE - Ordens de Pagamento Enviadas"

Parsed:
- module: "PM01"
- subProgram: "SP1NB"
- interaction: "ConsultaCNPJs"
- params: ["PM04", "Cópias dos Swift OPE - Ordens de Pagamento Enviadas"]
- destination: "PM04" (params[0])
- title: "Cópias dos Swift OPE - Ordens de Pagamento Enviadas" (params[1])
```

## Components to Create/Modify

### 1. TRNInput Component (NEW)
- Text input for TRN string
- Real-time parsing and preview
- Validation feedback
- Shows parsed breakdown (module, SP, interaction, destination, title)

### 2. ExtractionEngine Utility (NEW)
File: `src/utils/extractionEngine.js`
- Browser-based extraction engine
- Parses XML files to build interaction graph
- Traces navigation from entry point
- Handles conditional branches (TrocaSucessor)
- Tracks session variables (SalvaAtributo)
- Generates context-aware JSON

Key functions:
- `parseMenuItemFromTRN(trnString)` - Parse TRN string
- `buildInteractionMap(xmlFiles)` - Build map of all interactions
- `traceFlow(entryPath, xmlMap, flowContext)` - Trace flow from entry
- `extractInteractionData(xmlDoc)` - Extract fields, navigations, operations
- `generateContextAwareJSON(menuItem, interactions)` - Generate final JSON

### 3. XMLUploader Enhancement
- Add TRN input step after file upload
- Add "Run Extraction" button
- Show extraction progress
- Display generated JSON preview

### 4. JSONViewer Component (NEW)
- Preview generated JSON
- Syntax highlighting
- Download button
- "View in Visualizer" button

### 5. MainLayout Updates
- Support JSON upload alongside XML upload
- Route JSON uploads directly to TransactionViewer
- Handle extraction results

### 6. TransactionViewer Updates
- Accept raw JSON data (not just from menu)
- Handle uploaded JSON visualization

## Extraction Engine Logic

### Step 1: Parse TRN String
```javascript
function parseTRN(trn) {
  // "PM01\SP1NB\ConsultaCNPJs@PM04@Title"
  const [path, ...params] = trn.split('@');
  const [module, subProgram, interaction] = path.split('\\');
  return {
    full: trn,
    module,
    subProgram,
    interaction,
    params,
    destination: params[0] || '',
    title: params[1] || ''
  };
}
```

### Step 2: Build Interaction Map
```javascript
function buildInteractionMap(xmlFiles) {
  const map = new Map();
  for (const file of xmlFiles) {
    const parsed = parseXmlFile(file);
    const path = `${parsed.module}\\${parsed.subProgram}\\${parsed.interaction}`;
    map.set(path, parsed);
  }
  return map;
}
```

### Step 3: Trace Flow
```javascript
function traceFlow(entryPath, xmlMap, sessionVars, visited = new Set()) {
  if (visited.has(entryPath)) return [];
  visited.add(entryPath);

  const interaction = xmlMap.get(entryPath);
  if (!interaction) return [];

  const traced = [interaction];

  // Process operations (SalvaAtributo updates sessionVars)
  for (const op of interaction.operations) {
    if (op.function === 'SalvaAtributo') {
      sessionVars[op.params[0]] = op.params[1];
    }
  }

  // Follow navigations
  for (const nav of interaction.navigations) {
    // Evaluate condition against sessionVars
    const matches = evaluateCondition(nav.condition, sessionVars);
    nav.matchesContext = matches;

    if (matches !== false) {
      const childTraces = traceFlow(nav.target, xmlMap, sessionVars, visited);
      traced.push(...childTraces);
    }
  }

  return traced;
}
```

### Step 4: Generate JSON
Following the context-aware-transaction-schema.json structure.

## File Changes Summary

| File | Action | Description |
|------|--------|-------------|
| `src/components/TRNInput/TRNInput.jsx` | CREATE | TRN string input and parser |
| `src/components/TRNInput/TRNInput.module.scss` | CREATE | Styles |
| `src/utils/extractionEngine.js` | CREATE | Browser extraction engine |
| `src/components/JSONViewer/JSONViewer.jsx` | CREATE | JSON preview/download |
| `src/components/JSONViewer/JSONViewer.module.scss` | CREATE | Styles |
| `src/components/XMLUploader/XMLUploader.jsx` | MODIFY | Add TRN input, extraction |
| `src/components/MainLayout/MainLayout.jsx` | MODIFY | Support JSON upload |

## Implementation Order

1. Create `extractionEngine.js` utility
2. Create `TRNInput` component
3. Create `JSONViewer` component
4. Modify `XMLUploader` to integrate extraction flow
5. Modify `MainLayout` to support JSON upload
6. Update `TransactionViewer` to accept raw JSON
