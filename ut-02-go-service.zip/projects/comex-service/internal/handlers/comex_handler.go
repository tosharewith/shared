// Package handlers contains HTTP handlers for COMEX BFF
//
// Handlers are thin - they only:
// 1. Parse and validate request
// 2. Call service layer
// 3. Format and return response
//
// NO business logic here - that's in the service layer.
package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"comex-service/internal/domain"
	"comex-service/internal/services"
)

// COMEXHandler handles all COMEX HTTP requests
type COMEXHandler struct {
	service services.COMEXService
}

// NewCOMEXHandler creates a new handler with the given service
func NewCOMEXHandler(svc services.COMEXService) *COMEXHandler {
	return &COMEXHandler{service: svc}
}

// =============================================================================
// REQUEST DTOs
// =============================================================================

// BillingQueryRequest represents the request for billing operations query
// Mapped from: Tela_Entrada_Dados.xml form fields
type BillingQueryRequest struct {
	CNPJ          string `json:"cnpj" binding:"required,len=14"`
	DateFrom      string `json:"dateFrom,omitempty"`      // ISO date
	DateTo        string `json:"dateTo,omitempty"`        // ISO date
	InvoiceNumber string `json:"invoiceNumber,omitempty"` // FATURA
	DateType      string `json:"dateType,omitempty"`      // R=Registro, V=Vencimento
	CompanyType   string `json:"companyType,omitempty"`   // " "=All, N=Normal, S=OffShore
}

// PaymentOrdersQueryRequest represents the request for payment orders query
// Mapped from: Tela_Entrada_OPRE.xml form fields
type PaymentOrdersQueryRequest struct {
	CNPJ     string `json:"cnpj" binding:"required,len=14"`
	DateFrom string `json:"dateFrom,omitempty"`
	DateTo   string `json:"dateTo,omitempty"`
	DateType string `json:"dateType" binding:"required,oneof=R L"` // R=Registro, L=Liquidação
	Status   string `json:"status,omitempty"`                      // 01=Abertas, 02=Liquidadas
}

// LettersOfCreditQueryRequest represents the request for letters of credit query
// Mapped from: Tela_Lista_CNPJ_BAL7.xml form fields
type LettersOfCreditQueryRequest struct {
	CNPJ        string `json:"cnpj" binding:"required,len=14"`
	DateFrom    string `json:"dateFrom,omitempty"`
	DateTo      string `json:"dateTo,omitempty"`
	DateType    string `json:"dateType,omitempty"`    // R=Registro, V=Vencimento
	CompanyType string `json:"companyType,omitempty"` // " "=All, N=Normal, S=OffShore
}

// FXQuotationsQueryRequest represents the request for FX quotations query
// Mapped from: TelaListaCNPJCambio.xml form fields
type FXQuotationsQueryRequest struct {
	CNPJ     string `json:"cnpj" binding:"required,len=14"`
	DateFrom string `json:"dateFrom,omitempty"`
	DateTo   string `json:"dateTo,omitempty"`
	Status   string `json:"status,omitempty"` // 0=Aguardando, 2=Parcial, 3=Editada, 5=Todas
}

// =============================================================================
// COMPANIES HANDLERS (ConsultaCNPJS.xml)
// =============================================================================

// GetCompanies lists all companies the user has COMEX access to
//
//	@Summary      List companies with COMEX access
//	@Description  Returns list of companies (CNPJs) the authenticated user can operate
//	@Tags         companies
//	@Accept       json
//	@Produce      json
//	@Success      200  {object}  domain.CompanyListResponse
//	@Failure      401  {object}  ErrorResponse
//	@Failure      500  {object}  ErrorResponse
//	@Security     BearerAuth
//	@Router       /api/v1/comex/companies [get]
func (h *COMEXHandler) GetCompanies(c *gin.Context) {
	// Get user CPF from auth context
	userCPF := c.GetString("user_cpf")
	if userCPF == "" {
		c.JSON(http.StatusUnauthorized, ErrorResponse{
			Code:    "AUTH_001",
			Message: "User CPF not found in context",
		})
		return
	}

	// Call service
	companies, err := h.service.GetCompanies(c.Request.Context(), userCPF)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, companies)
}

// GetCompanyDetails returns details of a specific company
func (h *COMEXHandler) GetCompanyDetails(c *gin.Context) {
	cnpj := c.Param("cnpj")

	company, err := h.service.GetCompanyDetails(c.Request.Context(), cnpj)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, company)
}

// =============================================================================
// EXPORT BILLING HANDLERS (Tela_Entrada_Dados.xml → BAL1)
// =============================================================================

// QueryBillingOperations queries export billing operations
//
//	@Summary      Query export billing operations
//	@Description  Query Cobrança e Remessa de Exportação
//	@Tags         export
//	@Accept       json
//	@Produce      json
//	@Param        request  body      BillingQueryRequest  true  "Query parameters"
//	@Success      200      {object}  domain.BillingQueryResponse
//	@Failure      400      {object}  ErrorResponse
//	@Failure      401      {object}  ErrorResponse
//	@Failure      500      {object}  ErrorResponse
//	@Security     BearerAuth
//	@Router       /api/v1/comex/export/billing/query [post]
func (h *COMEXHandler) QueryBillingOperations(c *gin.Context) {
	var req BillingQueryRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Code:    "VALIDATION_001",
			Message: "Invalid request: " + err.Error(),
		})
		return
	}

	// Convert to domain query
	query := domain.BillingQuery{
		CNPJ:          req.CNPJ,
		DateFrom:      req.DateFrom,
		DateTo:        req.DateTo,
		InvoiceNumber: req.InvoiceNumber,
		DateType:      domain.DateType(req.DateType),
		CompanyType:   domain.CompanyType(req.CompanyType),
	}

	result, err := h.service.QueryBillingOperations(c.Request.Context(), query)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

// GetBillingOperationDetails returns details of a specific billing operation
func (h *COMEXHandler) GetBillingOperationDetails(c *gin.Context) {
	id := c.Param("id")

	operation, err := h.service.GetBillingOperationDetails(c.Request.Context(), id)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, operation)
}

// =============================================================================
// PAYMENT ORDERS HANDLERS (Tela_Entrada_OPRE.xml → BAL3)
// =============================================================================

// QueryPaymentOrders queries payment orders received from abroad
//
//	@Summary      Query payment orders from abroad
//	@Description  Query Ordens de Pagamento Recebidas do Exterior (OPRE)
//	@Tags         payment-orders
//	@Accept       json
//	@Produce      json
//	@Param        request  body      PaymentOrdersQueryRequest  true  "Query parameters"
//	@Success      200      {object}  domain.PaymentOrdersResponse
//	@Failure      400      {object}  ErrorResponse
//	@Failure      401      {object}  ErrorResponse
//	@Failure      500      {object}  ErrorResponse
//	@Security     BearerAuth
//	@Router       /api/v1/comex/payment-orders/query [post]
func (h *COMEXHandler) QueryPaymentOrders(c *gin.Context) {
	var req PaymentOrdersQueryRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Code:    "VALIDATION_001",
			Message: "Invalid request: " + err.Error(),
		})
		return
	}

	query := domain.PaymentOrderQuery{
		CNPJ:     req.CNPJ,
		DateFrom: req.DateFrom,
		DateTo:   req.DateTo,
		DateType: domain.DateType(req.DateType),
		Status:   req.Status,
	}

	result, err := h.service.QueryPaymentOrders(c.Request.Context(), query)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

// GetPaymentOrderDetails returns details of a specific payment order
func (h *COMEXHandler) GetPaymentOrderDetails(c *gin.Context) {
	id := c.Param("id")

	order, err := h.service.GetPaymentOrderDetails(c.Request.Context(), id)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, order)
}

// GetPaymentOrderStatus returns status of a payment order
func (h *COMEXHandler) GetPaymentOrderStatus(c *gin.Context) {
	id := c.Param("id")

	status, err := h.service.GetPaymentOrderStatus(c.Request.Context(), id)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, gin.H{"status": status})
}

// =============================================================================
// LETTERS OF CREDIT HANDLERS (Tela_Lista_CNPJ_BAL7.xml → BAL7)
// =============================================================================

// QueryLettersOfCredit queries negotiated letters of credit
func (h *COMEXHandler) QueryLettersOfCredit(c *gin.Context) {
	var req LettersOfCreditQueryRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Code:    "VALIDATION_001",
			Message: "Invalid request: " + err.Error(),
		})
		return
	}

	query := domain.LCQuery{
		CNPJ:        req.CNPJ,
		DateFrom:    req.DateFrom,
		DateTo:      req.DateTo,
		DateType:    domain.DateType(req.DateType),
		CompanyType: domain.CompanyType(req.CompanyType),
	}

	result, err := h.service.QueryLettersOfCredit(c.Request.Context(), query)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

// GetLetterOfCreditDetails returns details of a specific letter of credit
func (h *COMEXHandler) GetLetterOfCreditDetails(c *gin.Context) {
	id := c.Param("id")

	lc, err := h.service.GetLetterOfCreditDetails(c.Request.Context(), id)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, lc)
}

// QueryReceivedLetters queries received letters of credit
func (h *COMEXHandler) QueryReceivedLetters(c *gin.Context) {
	var req LettersOfCreditQueryRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Code:    "VALIDATION_001",
			Message: "Invalid request: " + err.Error(),
		})
		return
	}

	query := domain.LCQuery{
		CNPJ:     req.CNPJ,
		DateFrom: req.DateFrom,
		DateTo:   req.DateTo,
	}

	result, err := h.service.QueryReceivedLetters(c.Request.Context(), query)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

// =============================================================================
// FX HANDLERS (TelaListaCNPJCambio.xml → BAEI)
// =============================================================================

// QueryFXQuotations queries FX quotations
func (h *COMEXHandler) QueryFXQuotations(c *gin.Context) {
	var req FXQuotationsQueryRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Code:    "VALIDATION_001",
			Message: "Invalid request: " + err.Error(),
		})
		return
	}

	query := domain.FXQuery{
		CNPJ:     req.CNPJ,
		DateFrom: req.DateFrom,
		DateTo:   req.DateTo,
		Status:   req.Status,
	}

	result, err := h.service.QueryFXQuotations(c.Request.Context(), query)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

// GetQuotationDetails returns details of a specific quotation
func (h *COMEXHandler) GetQuotationDetails(c *gin.Context) {
	id := c.Param("id")

	quotation, err := h.service.GetQuotationDetails(c.Request.Context(), id)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, quotation)
}

// GetExchangeRates returns current exchange rates
func (h *COMEXHandler) GetExchangeRates(c *gin.Context) {
	currencies := c.QueryArray("currencies")

	rates, err := h.service.GetExchangeRates(c.Request.Context(), currencies)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, rates)
}

// SimulateExchange simulates an exchange operation
func (h *COMEXHandler) SimulateExchange(c *gin.Context) {
	var req struct {
		FromCurrency string  `json:"fromCurrency" binding:"required"`
		ToCurrency   string  `json:"toCurrency" binding:"required"`
		Amount       float64 `json:"amount" binding:"required,gt=0"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Code:    "VALIDATION_001",
			Message: "Invalid request: " + err.Error(),
		})
		return
	}

	result, err := h.service.SimulateExchange(c.Request.Context(), req.FromCurrency, req.ToCurrency, req.Amount)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

// =============================================================================
// SWIFT HANDLERS
// =============================================================================

// ListSWIFTMessages lists SWIFT messages
func (h *COMEXHandler) ListSWIFTMessages(c *gin.Context) {
	status := c.Query("status")
	dateFrom := c.Query("dateFrom")
	dateTo := c.Query("dateTo")

	messages, err := h.service.ListSWIFTMessages(c.Request.Context(), status, dateFrom, dateTo)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, messages)
}

// GetSWIFTMessageDetails returns details of a SWIFT message
func (h *COMEXHandler) GetSWIFTMessageDetails(c *gin.Context) {
	uetr := c.Param("uetr")

	message, err := h.service.GetSWIFTMessageDetails(c.Request.Context(), uetr)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusOK, message)
}

// SendSWIFTMessage sends a new SWIFT message
func (h *COMEXHandler) SendSWIFTMessage(c *gin.Context) {
	var req domain.SWIFTMessageRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{
			Code:    "VALIDATION_001",
			Message: "Invalid request: " + err.Error(),
		})
		return
	}

	result, err := h.service.SendSWIFTMessage(c.Request.Context(), req)
	if err != nil {
		handleServiceError(c, err)
		return
	}

	c.JSON(http.StatusCreated, result)
}

// =============================================================================
// HEALTH CHECK
// =============================================================================

// HealthCheck returns the health status of the COMEX services
func (h *COMEXHandler) HealthCheck(c *gin.Context) {
	status, err := h.service.HealthCheck(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusServiceUnavailable, ErrorResponse{
			Code:    "HEALTH_001",
			Message: "Service unhealthy: " + err.Error(),
		})
		return
	}

	c.JSON(http.StatusOK, status)
}

// =============================================================================
// ERROR HANDLING
// =============================================================================

// ErrorResponse represents an API error response
type ErrorResponse struct {
	Code    string `json:"code"`
	Message string `json:"message"`
}

func handleServiceError(c *gin.Context, err error) {
	// TODO: Map domain errors to HTTP status codes
	c.JSON(http.StatusInternalServerError, ErrorResponse{
		Code:    "SERVICE_001",
		Message: err.Error(),
	})
}
