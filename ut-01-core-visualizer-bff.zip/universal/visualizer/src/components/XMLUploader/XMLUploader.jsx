import { useState, useCallback, useRef } from 'react';
import { Button, InlineLoading, Tag, ProgressIndicator, ProgressStep } from '@carbon/react';
import {
  Upload,
  FolderAdd,
  Document,
  CheckmarkFilled,
  ErrorFilled,
  TrashCan,
  Code,
  Folder,
  ArrowRight,
  ArrowLeft,
  DocumentBlank
} from '@carbon/icons-react';
import TRNInput from '../TRNInput';
import JSONViewer from '../JSONViewer';
import { runExtraction, parseInteractionXml } from '../../utils/extractionEngine';
import styles from './XMLUploader.module.scss';

/**
 * XMLUploader Component
 * Multi-step workflow: Upload XMLs → Enter TRN → Run Extraction → View/Download JSON
 * Also supports direct JSON upload for visualization
 */
const XMLUploader = ({ onFilesProcessed, onReset, onVisualize }) => {
  // State
  const [currentStep, setCurrentStep] = useState(0); // 0: upload, 1: TRN, 2: results
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [parsedXmlFiles, setParsedXmlFiles] = useState([]);
  const [parseResults, setParseResults] = useState(null);
  const [parsedTRN, setParsedTRN] = useState(null);
  const [extractedJSON, setExtractedJSON] = useState(null);
  const [error, setError] = useState(null);

  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);
  const jsonInputRef = useRef(null);

  // Parse XML content using extraction engine
  const parseXML = useCallback((content, filename, relativePath) => {
    return parseInteractionXml(content, filename, relativePath);
  }, []);

  // Process uploaded files
  const processFiles = async (files) => {
    setIsProcessing(true);
    setError(null);

    const results = {
      screens: [],
      services: [],
      configs: [],
      errors: [],
      totalFiles: 0,
      structure: {}
    };

    const xmlFilesData = [];
    const fileList = [];

    for (const file of files) {
      if (file.name.endsWith('.xml') || file.name.endsWith('.XML')) {
        results.totalFiles++;

        try {
          const content = await file.text();
          const relativePath = file.webkitRelativePath || file.name;
          const parsed = parseXML(content, file.name, relativePath);

          // Store raw content for extraction engine
          xmlFilesData.push({
            filename: file.name,
            path: relativePath,
            content,
            ...parsed
          });

          fileList.push({
            name: file.name,
            path: relativePath,
            size: file.size,
            parsed: parsed.success,
            data: parsed,
            error: parsed.error
          });

          if (parsed.success) {
            // Categorize by type
            if (parsed.type === 'Browser' || parsed.fields?.inputs?.length > 0) {
              results.screens.push({
                filename: file.name,
                path: relativePath,
                ...parsed
              });
            } else if (parsed.type === 'WebService') {
              results.services.push({
                filename: file.name,
                path: relativePath,
                ...parsed
              });
            } else {
              results.configs.push({
                filename: file.name,
                path: relativePath,
                ...parsed
              });
            }
          } else {
            results.errors.push({
              filename: file.name,
              path: relativePath,
              error: parsed.error
            });
          }
        } catch (err) {
          results.errors.push({
            filename: file.name,
            error: err.message
          });
        }
      }
    }

    setUploadedFiles(fileList);
    setParsedXmlFiles(xmlFilesData);
    setParseResults(results);
    setIsProcessing(false);

    // Auto-advance to TRN step if files were uploaded successfully
    if (results.screens.length > 0 || results.services.length > 0) {
      setCurrentStep(1);
    }
  };

  // Handle JSON file upload for direct visualization
  const processJsonFile = async (file) => {
    setIsProcessing(true);
    setError(null);

    try {
      const content = await file.text();
      const json = JSON.parse(content);

      // Validate it's a context-aware transaction JSON
      if (json.schemaType !== 'transaction-context-aware') {
        throw new Error('JSON deve ser do tipo "transaction-context-aware"');
      }

      setExtractedJSON(json);
      setCurrentStep(2);
    } catch (err) {
      setError(`Erro ao processar JSON: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle extraction
  const handleRunExtraction = useCallback((trn) => {
    setIsProcessing(true);
    setError(null);

    try {
      const trnString = trn.full || `${trn.module}\\${trn.subProgram}\\${trn.interaction}@${trn.params.join('@')}`;
      const json = runExtraction(parsedXmlFiles, trnString);
      setExtractedJSON(json);
      setCurrentStep(2);

      if (onFilesProcessed) {
        onFilesProcessed(json);
      }
    } catch (err) {
      setError(`Erro na extração: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  }, [parsedXmlFiles, onFilesProcessed]);

  // Handle TRN parsed
  const handleTRNParsed = useCallback((trn) => {
    setParsedTRN(trn);
  }, []);

  // Handle drag events
  const handleDragEnter = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  // Handle file drop
  const handleDrop = useCallback(async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const items = e.dataTransfer.items;
    const files = [];

    // Function to recursively read directory
    const readDirectory = async (entry, path = '') => {
      if (entry.isFile) {
        return new Promise((resolve) => {
          entry.file((file) => {
            Object.defineProperty(file, 'webkitRelativePath', {
              value: path + file.name,
              writable: false
            });
            files.push(file);
            resolve();
          });
        });
      } else if (entry.isDirectory) {
        const dirReader = entry.createReader();
        return new Promise((resolve) => {
          const readEntries = () => {
            dirReader.readEntries(async (entries) => {
              if (entries.length === 0) {
                resolve();
              } else {
                for (const childEntry of entries) {
                  await readDirectory(childEntry, path + entry.name + '/');
                }
                readEntries();
              }
            });
          };
          readEntries();
        });
      }
    };

    const promises = [];
    for (const item of items) {
      const entry = item.webkitGetAsEntry?.();
      if (entry) {
        promises.push(readDirectory(entry));
      }
    }

    await Promise.all(promises);

    // Check if any JSON files
    const jsonFiles = files.filter(f => f.name.endsWith('.json'));
    const xmlFiles = files.filter(f => f.name.endsWith('.xml') || f.name.endsWith('.XML'));

    if (jsonFiles.length > 0 && xmlFiles.length === 0) {
      // Direct JSON upload
      processJsonFile(jsonFiles[0]);
    } else if (xmlFiles.length > 0) {
      processFiles(xmlFiles);
    }
  }, []);

  // Handle file input change
  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) {
      processFiles(files);
    }
  };

  // Handle folder input change
  const handleFolderChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) {
      processFiles(files);
    }
  };

  // Handle JSON input change
  const handleJsonChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) {
      processJsonFile(files[0]);
    }
  };

  // Reset uploader
  const handleReset = () => {
    setCurrentStep(0);
    setUploadedFiles([]);
    setParsedXmlFiles([]);
    setParseResults(null);
    setParsedTRN(null);
    setExtractedJSON(null);
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (folderInputRef.current) folderInputRef.current.value = '';
    if (jsonInputRef.current) jsonInputRef.current.value = '';
    if (onReset) onReset();
  };

  // Navigate steps
  const goToStep = (step) => {
    if (step >= 0 && step <= 2) {
      setCurrentStep(step);
    }
  };

  // Handle visualize
  const handleVisualize = useCallback((json) => {
    if (onVisualize) {
      onVisualize(json);
    }
  }, [onVisualize]);

  return (
    <div className={styles.uploaderContainer}>
      {/* Progress Indicator */}
      <ProgressIndicator currentIndex={currentStep} className={styles.progressIndicator}>
        <ProgressStep
          label="Upload XMLs"
          description="Carregar arquivos"
          onClick={() => currentStep > 0 && goToStep(0)}
        />
        <ProgressStep
          label="Definir TRN"
          description="Ponto de entrada"
          disabled={parsedXmlFiles.length === 0}
          onClick={() => currentStep > 1 && goToStep(1)}
        />
        <ProgressStep
          label="Resultado"
          description="JSON extraído"
          disabled={!extractedJSON}
        />
      </ProgressIndicator>

      {/* Step 0: Upload */}
      {currentStep === 0 && (
        <>
          <div
            className={`${styles.dropZone} ${isDragging ? styles.dragging : ''}`}
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          >
            {isProcessing ? (
              <div className={styles.processing}>
                <InlineLoading description="Processando arquivos..." />
              </div>
            ) : (
              <>
                <FolderAdd size={48} className={styles.uploadIcon} />
                <h3>Arraste uma pasta com XMLs ou um arquivo JSON</h3>
                <p>ou use os botões abaixo para selecionar</p>

                <div className={styles.uploadButtons}>
                  <input
                    ref={folderInputRef}
                    type="file"
                    webkitdirectory="true"
                    directory="true"
                    multiple
                    onChange={handleFolderChange}
                    style={{ display: 'none' }}
                    id="folder-input"
                  />
                  <Button
                    kind="primary"
                    renderIcon={Folder}
                    onClick={() => folderInputRef.current?.click()}
                  >
                    Pasta de XMLs
                  </Button>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xml,.XML"
                    multiple
                    onChange={handleFileChange}
                    style={{ display: 'none' }}
                    id="file-input"
                  />
                  <Button
                    kind="secondary"
                    renderIcon={Document}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    Arquivos XML
                  </Button>

                  <input
                    ref={jsonInputRef}
                    type="file"
                    accept=".json"
                    onChange={handleJsonChange}
                    style={{ display: 'none' }}
                    id="json-input"
                  />
                  <Button
                    kind="tertiary"
                    renderIcon={DocumentBlank}
                    onClick={() => jsonInputRef.current?.click()}
                  >
                    Upload JSON
                  </Button>
                </div>

                <div className={styles.expectedFormat}>
                  <h4>Formatos aceitos:</h4>
                  <pre>
{`Pasta com XMLs QuickWeb:
├── MODULE/
│   ├── SUBPROGRAM/
│   │   ├── Interaction.xml
│   │   └── ...

Ou JSON extraído anteriormente:
└── transaction.json`}
                  </pre>
                </div>
              </>
            )}
          </div>

          {error && (
            <div className={styles.errorMessage}>
              <ErrorFilled size={20} />
              <span>{error}</span>
            </div>
          )}
        </>
      )}

      {/* Step 1: TRN Input */}
      {currentStep === 1 && (
        <div className={styles.trnStep}>
          {/* Files Summary */}
          <div className={styles.filesSummary}>
            <div className={styles.summaryHeader}>
              <CheckmarkFilled size={20} className={styles.successIcon} />
              <div>
                <h4>{parseResults?.totalFiles} arquivos XML carregados</h4>
                <p>{parseResults?.screens?.length} telas, {parseResults?.services?.length} serviços</p>
              </div>
              <Button kind="ghost" size="sm" onClick={handleReset}>
                Alterar
              </Button>
            </div>
          </div>

          {/* TRN Input */}
          <TRNInput
            onTRNParsed={handleTRNParsed}
            onRunExtraction={handleRunExtraction}
            disabled={isProcessing}
          />

          {isProcessing && (
            <div className={styles.extractionProgress}>
              <InlineLoading description="Executando extração do fluxo..." />
            </div>
          )}

          {error && (
            <div className={styles.errorMessage}>
              <ErrorFilled size={20} />
              <span>{error}</span>
            </div>
          )}

          <div className={styles.stepNavigation}>
            <Button
              kind="secondary"
              renderIcon={ArrowLeft}
              onClick={() => goToStep(0)}
            >
              Voltar
            </Button>
          </div>
        </div>
      )}

      {/* Step 2: Results */}
      {currentStep === 2 && extractedJSON && (
        <div className={styles.resultsStep}>
          <JSONViewer
            jsonData={extractedJSON}
            onVisualize={handleVisualize}
            onDownload={() => console.log('JSON downloaded')}
          />

          <div className={styles.stepNavigation}>
            <Button
              kind="secondary"
              renderIcon={ArrowLeft}
              onClick={() => goToStep(parsedXmlFiles.length > 0 ? 1 : 0)}
            >
              Voltar
            </Button>
            <Button
              kind="ghost"
              renderIcon={TrashCan}
              onClick={handleReset}
            >
              Nova Extração
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default XMLUploader;
