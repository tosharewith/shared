import { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import cytoscape from 'cytoscape';
import coseBilkent from 'cytoscape-cose-bilkent';
import fcose from 'cytoscape-fcose';
import { Maximize, Minimize, Close as CloseIcon } from '@carbon/icons-react';
import { parseGraphML } from './utils/graphmlParser';
import { layoutConfigs } from './utils/layoutConfigs';
import { clearHighlights } from './utils/cytoscapeConfig';
import { createCytoscapeElements, cytoscapeStyles } from './utils/styleConfigs';
import DiagramSidebar from './DiagramSidebar/DiagramSidebar';
import DiagramControls from './DiagramControls/DiagramControls';
import DiagramDetailsPanel from './DiagramDetailsPanel/DiagramDetailsPanel';
import styles from './DiagramViewer.module.scss';

// Register Cytoscape extensions
cytoscape.use(coseBilkent);
cytoscape.use(fcose);

/**
 * DiagramViewer Component
 * Full-featured diagram viewer with sidebar, controls, and filtering
 * Shows navigation flows with labeled edges
 */
const DiagramViewer = ({ value, displayName, onClose }) => {
  const containerRef = useRef(null);
  const cyRef = useRef(null);
  const handleNodeFocusRef = useRef(null);

  // State management
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLayout, setSelectedLayout] = useState('hierarchical');
  const [pendingLayout, setPendingLayout] = useState('hierarchical'); // Layout to apply on button click
  const [nodeTypeFilters, setNodeTypeFilters] = useState({});
  const [edgeTypeFilters, setEdgeTypeFilters] = useState({});
  const [showSequentialFlowOnly, setShowSequentialFlowOnly] = useState(false); // Sequential flow filter
  const [stats, setStats] = useState({ nodes: 0, edges: 0 });
  const [parseError, setParseError] = useState(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedNodeData, setSelectedNodeData] = useState(null);
  const [showDetailsPanel, setShowDetailsPanel] = useState(false);
  const [focusDepth, setFocusDepth] = useState(1); // 1 or 2 levels for focus mode
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [isAreaSelectMode, setIsAreaSelectMode] = useState(false);

  // Load saved layout parameters from localStorage
  const [layoutParams, setLayoutParams] = useState(() => {
    try {
      const saved = localStorage.getItem('diagram-layout-params');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (err) {
      // console.error('Error loading saved layout params:', err);
    }
    // Default values
    return {
      edgeLength: 60,
      nodeSpacing: 1.0,
      gravity: 50,
      nodeRepulsion: 3500
    };
  });

  // Parse and process data
  const elements = useMemo(() => {
    console.log('DiagramViewer: value received:', value ? `${value.length} chars` : 'null');
    if (!value) return { nodes: [], edges: [] };

    setParseError(null);

    try {
      // Parse GraphML directly to Cytoscape elements with styling
      const data = parseGraphML(value);
      console.log('DiagramViewer: parsed data:', {
        nodes: data.nodes.length,
        edges: data.edges.length
      });
      return data;
    } catch (err) {
      console.error('DiagramViewer: parse error:', err);
      setParseError(err.message);
      return { nodes: [], edges: [] };
    }
  }, [value]);

  // Calculate available filter types from elements (only recalculates when elements change)
  const availableTypes = useMemo(() => {
    if (!elements || !elements.nodes || !elements.edges) {
      return { nodeTypes: [], edgeTypes: [] };
    }

    // Get all unique node types
    const nodeTypes = [...new Set(
      elements.nodes
        .map(node => node.data?.type)
        .filter(Boolean)
    )];

    // Get all unique edge types
    const edgeTypes = [...new Set(
      elements.edges
        .map(edge => edge.data?.type)
        .filter(Boolean)
    )];

    return { nodeTypes, edgeTypes };
  }, [elements]);

  // Initialize filters only when data first loads or file changes
  useEffect(() => {
    const { nodeTypes, edgeTypes } = availableTypes;

    // Only initialize if we have types
    if (nodeTypes.length === 0 && edgeTypes.length === 0) {
      setNodeTypeFilters({});
      setEdgeTypeFilters({});
      return;
    }

    // Initialize node filters - all types checked by default
    setNodeTypeFilters(prev => {
      const existingTypes = Object.keys(prev);

      // Check if this is a completely different dataset
      const isNewDataset = existingTypes.length > 0 &&
        nodeTypes.length > 0 &&
        !existingTypes.some(type => nodeTypes.includes(type));

      // Reset filters if new dataset or first load
      if (existingTypes.length === 0 || isNewDataset) {
        const newFilters = {};
        nodeTypes.forEach(type => {
          newFilters[type] = true;
        });
        return newFilters;
      }

      // Keep existing filters unchanged (don't recalculate)
      return prev;
    });

    // Initialize edge filters - all types checked by default
    setEdgeTypeFilters(prev => {
      const existingTypes = Object.keys(prev);

      // Check if this is a completely different dataset
      const isNewDataset = existingTypes.length > 0 &&
        edgeTypes.length > 0 &&
        !existingTypes.some(type => edgeTypes.includes(type));

      // Reset filters if new dataset or first load
      if (existingTypes.length === 0 || isNewDataset) {
        const newFilters = {};
        edgeTypes.forEach(type => {
          newFilters[type] = true;
        });
        return newFilters;
      }

      // Keep existing filters unchanged (don't recalculate)
      return prev;
    });
  }, [availableTypes]);

  // Filter elements based on search and filters
  const filteredElements = useMemo(() => {
    if (!elements || !elements.nodes || !elements.edges) return { nodes: [], edges: [] };

    let { nodes, edges } = elements;

    // Ensure we have valid arrays
    if (!Array.isArray(nodes)) nodes = [];
    if (!Array.isArray(edges)) edges = [];

    // Apply search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      nodes = nodes.filter(node => {
        const label = node.data.label || node.data.id || '';
        return label.toLowerCase().includes(searchLower);
      });

      // Filter edges to only show those connected to visible nodes
      const visibleNodeIds = new Set(nodes.map(n => n.data.id));
      edges = edges.filter(edge =>
        visibleNodeIds.has(edge.data.source) &&
        visibleNodeIds.has(edge.data.target)
      );
    }

    // Apply node type filters
    const activeNodeFilters = Object.entries(nodeTypeFilters).filter(([_, active]) => active).map(([type]) => type);
    if (activeNodeFilters.length > 0) {
      nodes = nodes.filter(node => {
        if (!node?.data) return false; // Invalid node
        if (!node.data.type) return true; // Keep nodes without type
        return activeNodeFilters.includes(node.data.type); // Check if type is active
      });

      const visibleNodeIds = new Set(nodes.map(n => n?.data?.id).filter(Boolean));
      edges = edges.filter(edge => {
        if (!edge?.data?.source || !edge?.data?.target) return false;
        return visibleNodeIds.has(edge.data.source) && visibleNodeIds.has(edge.data.target);
      });
    }

    // Apply edge type filters
    const activeEdgeFilters = Object.entries(edgeTypeFilters).filter(([_, active]) => active).map(([type]) => type);
    if (activeEdgeFilters.length > 0) {
      edges = edges.filter(edge => {
        if (!edge?.data) return false; // Invalid edge
        if (!edge.data.type) return true; // Keep edges without type
        return activeEdgeFilters.includes(edge.data.type); // Check if type is active
      });
    }

    // Apply sequential flow filter
    if (showSequentialFlowOnly) {
      edges = edges.filter(edge => {
        if (!edge?.data) return false;
        // Keep only edges with flowStep (sequential flow edges)
        return edge.data.flowStep && edge.data.flowStep !== '';
      });

      // Filter nodes to only show those connected to sequential flow edges
      const connectedNodeIds = new Set();
      edges.forEach(edge => {
        connectedNodeIds.add(edge.data.source);
        connectedNodeIds.add(edge.data.target);
      });
      nodes = nodes.filter(node => connectedNodeIds.has(node.data.id));
    }

    return { nodes, edges };
  }, [elements, searchTerm, nodeTypeFilters, edgeTypeFilters, showSequentialFlowOnly]);

  // Focus node handler - defined early so it can be used in event handlers
  const handleNodeFocus = useCallback((node) => {
    if (!cyRef.current || !node) return;

    // Get neighborhood at specified depth
    let neighborhood = node;

    // Build neighborhood iteratively for each depth level
    for (let i = 0; i < focusDepth; i++) {
      if (i === 0) {
        neighborhood = node.closedNeighborhood();
      } else {
        // Get next level of neighbors
        neighborhood = neighborhood.nodes().closedNeighborhood();
      }
    }

    // Hide all elements
    cyRef.current.elements().addClass('hidden');

    // Show only the neighborhood
    neighborhood.removeClass('hidden');

    // Highlight the focused node
    cyRef.current.elements().removeClass('highlighted faded');
    node.addClass('highlighted');

    // Fit the view to the visible neighborhood
    cyRef.current.fit(neighborhood, 50);

    // Set focus mode active
    setIsFocusMode(true);

    // Show details panel
    setSelectedNodeData(node.data());
    setShowDetailsPanel(true);
  }, [focusDepth]);

  // Keep ref updated with latest handleNodeFocus
  useEffect(() => {
    handleNodeFocusRef.current = handleNodeFocus;
  }, [handleNodeFocus]);

  // Initialize Cytoscape and update elements
  useEffect(() => {
    if (!containerRef.current) {
      return;
    }

    // Initialize Cytoscape if not already initialized
    if (!cyRef.current) {
      try {
        cyRef.current = cytoscape({
          container: containerRef.current,
          style: cytoscapeStyles,
          minZoom: 0.1,
          maxZoom: 3,
          boxSelectionEnabled: true,
          autounselectify: false,
          autoungrabify: false,
        });

        // Add click event handler for node highlighting and details
        cyRef.current.on('tap', 'node', (event) => {
          const node = event.target;
          const allElements = cyRef.current.elements();

          // Show details panel with node data
          setSelectedNodeData(node.data());
          setShowDetailsPanel(true);

          if (node.hasClass('highlighted') && !node.hasClass('faded')) {
            clearHighlights(cyRef.current);
            return;
          }

          allElements.removeClass('highlighted faded');
          const neighborhood = node.closedNeighborhood();
          neighborhood.addClass('highlighted');
          allElements.not(neighborhood).addClass('faded');
        });

        // Click on background clears highlights
        cyRef.current.on('tap', (event) => {
          if (event.target === cyRef.current) {
            clearHighlights(cyRef.current);
          }
        });

        // Double-click on node to focus on its neighborhood
        cyRef.current.on('dbltap', 'node', (event) => {
          const node = event.target;
          // Use ref to always call the latest version of handleNodeFocus
          if (handleNodeFocusRef.current) {
            handleNodeFocusRef.current(node);
          }
        });
      } catch (err) {
        // Silently handle initialization errors
        return;
      }
    }

    // Update graph elements
    if (!filteredElements || filteredElements.nodes.length === 0) {
      cyRef.current.elements().remove();
      setStats({ nodes: 0, edges: 0, selectedNodes: 0 });
      return;
    }

    cyRef.current.elements().remove();
    cyRef.current.add([...filteredElements.nodes, ...filteredElements.edges]);

    // Fit the graph initially (but only if NOT in focus mode)
    if (!isFocusMode) {
      setTimeout(() => {
        if (cyRef.current) {
          cyRef.current.fit(undefined, 50);
        }
      }, 100);
    } else {
      // If in focus mode, re-apply the focus after elements are updated
      if (selectedNodeData) {
        setTimeout(() => {
          const node = cyRef.current.nodes().filter(n => n.data('id') === selectedNodeData.id);
          if (node.length > 0) {
            // Re-apply focus with current depth (inline logic to avoid dependency issues)
            let neighborhood = node;

            // Build neighborhood iteratively for each depth level
            for (let i = 0; i < focusDepth; i++) {
              if (i === 0) {
                neighborhood = node.closedNeighborhood();
              } else {
                // Get next level of neighbors
                neighborhood = neighborhood.nodes().closedNeighborhood();
              }
            }

            // Hide all elements
            cyRef.current.elements().addClass('hidden');

            // Show only the neighborhood
            neighborhood.removeClass('hidden');

            // Highlight the focused node
            cyRef.current.elements().removeClass('highlighted faded');
            node.addClass('highlighted');

            // Fit the view to the visible neighborhood
            cyRef.current.fit(neighborhood, 50);
          }
        }, 100);
      }
    }

    setStats({
      nodes: filteredElements.nodes.length,
      edges: filteredElements.edges.length,
      selectedNodes: 0
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filteredElements]);

  // Track selected nodes count (only visible nodes)
  useEffect(() => {
    if (!cyRef.current) return;

    const updateSelectedCount = () => {
      // Only count selected nodes that are visible (not hidden by filters)
      const selectedCount = cyRef.current.$(':selected').nodes().not('.hidden').length;
      setStats(prev => ({
        ...prev,
        selectedNodes: selectedCount
      }));
    };

    // Listen to selection events
    cyRef.current.on('select unselect', updateSelectedCount);

    return () => {
      if (cyRef.current) {
        cyRef.current.off('select unselect', updateSelectedCount);
      }
    };
  }, []);

  // Save layout parameters to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem('diagram-layout-params', JSON.stringify(layoutParams));
    } catch (err) {
      // console.error('Error saving layout params:', err);
    }
  }, [layoutParams]);

  // Clear selections when filters or search changes
  useEffect(() => {
    if (!cyRef.current) return;

    // Unselect all nodes when filters change
    cyRef.current.$(':selected').unselect();

    // Update the count immediately
    setStats(prev => ({
      ...prev,
      selectedNodes: 0
    }));
  }, [nodeTypeFilters, edgeTypeFilters, searchTerm]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (cyRef.current) {
        cyRef.current.destroy();
        cyRef.current = null;
      }
    };
  }, []);

  // Apply layout when selectedLayout changes
  useEffect(() => {
    if (!cyRef.current || !filteredElements) return;

    // Ensure there are actual elements in the graph before applying layout
    const elements = cyRef.current.elements();
    if (elements.length === 0) return;

    // Ensure elements have valid data before running layout
    const hasValidElements = elements.every(el => el.data() && el.data('id'));
    if (!hasValidElements) return;

    try {
      // Exit focus mode and make sure all elements are visible
      setIsFocusMode(false);
      cyRef.current.elements().removeClass('hidden highlighted faded');

      // Ensure Cytoscape has correct container dimensions
      cyRef.current.resize();

      // Get current viewport dimensions
      const width = cyRef.current.width();
      const height = cyRef.current.height();

      // Prepare layout config
      const baseConfig = { ...layoutConfigs[selectedLayout] };

      // Apply custom layout parameters if available
      if (layoutParams) {
        // Apply edge length (idealEdgeLength for force-directed layouts)
        if (baseConfig.idealEdgeLength !== undefined) {
          baseConfig.idealEdgeLength = layoutParams.edgeLength;
        }

        // Apply node spacing (spacingFactor for grid/hierarchical layouts)
        if (baseConfig.spacingFactor !== undefined) {
          baseConfig.spacingFactor = layoutParams.nodeSpacing;
        }

        // Apply gravity for force-directed layouts
        if (baseConfig.gravity !== undefined) {
          // Different layouts use different gravity scales
          if (selectedLayout === 'cose') {
            baseConfig.gravity = layoutParams.gravity;
          } else if (selectedLayout === 'cose-bilkent' || selectedLayout === 'fcose') {
            // These use 0-1 scale, convert from 0-100
            baseConfig.gravity = layoutParams.gravity / 100;
          }
        }

        // Apply node repulsion
        if (baseConfig.nodeRepulsion !== undefined) {
          baseConfig.nodeRepulsion = layoutParams.nodeRepulsion;
        }
      }

      // Constrain all layouts to viewport with boundingBox
      baseConfig.boundingBox = {
        x1: 50,
        y1: 50,
        x2: width - 50,
        y2: height - 50
      };
      baseConfig.fit = true;
      baseConfig.padding = 50;

      const layout = cyRef.current.layout(baseConfig);

      layout.on('layoutstop', () => {
        // Ensure final fit after layout completes
        setTimeout(() => {
          if (cyRef.current) {
            cyRef.current.fit(undefined, 50);
          }
        }, 100);
      });

      layout.run();
    } catch (err) {
      // Silently handle layout errors during transitions
    }
  }, [selectedLayout, filteredElements]);

  // Handlers
  const handleSearch = useCallback((term) => {
    setSearchTerm(term);
  }, []);

  const handleLayoutChange = useCallback((layout) => {
    setPendingLayout(layout); // Don't apply immediately
  }, []);

  const handleApplyLayout = useCallback(() => {
    // Force re-trigger layout by setting to null first if layout hasn't changed
    if (selectedLayout === pendingLayout) {
      setSelectedLayout(null);
      setTimeout(() => setSelectedLayout(pendingLayout), 0);
    } else {
      setSelectedLayout(pendingLayout);
    }
  }, [pendingLayout, selectedLayout]);

  const handleFullscreenToggle = useCallback(() => {
    setIsFullscreen(prev => !prev);
  }, []);

  const handleNodeTypeFilterChange = useCallback((type, checked) => {
    setNodeTypeFilters(prev => ({ ...prev, [type]: checked }));
  }, []);

  const handleEdgeTypeFilterChange = useCallback((type, checked) => {
    setEdgeTypeFilters(prev => ({ ...prev, [type]: checked }));
  }, []);

  const handleSearchResultSelect = useCallback((nodeId) => {
    if (!cyRef.current) return;

    // Find node by filtering all nodes with matching ID
    const node = cyRef.current.nodes().filter(n => n.data('id') === nodeId);

    if (node.length > 0) {
      // Apply focus mode (same as double-click)
      handleNodeFocus(node);
    }
  }, [handleNodeFocus]);

  const handleApplyFocus = useCallback(() => {
    if (!cyRef.current || !selectedNodeData) return;

    // Find the currently focused node
    const node = cyRef.current.nodes().filter(n => n.data('id') === selectedNodeData.id);

    if (node.length > 0) {
      // Re-apply focus with new depth
      handleNodeFocus(node);
    }
  }, [selectedNodeData, handleNodeFocus]);

  const handleToggleDetails = useCallback(() => {
    setShowDetailsPanel(prev => !prev);
  }, []);

  const handleCloseDetails = useCallback(() => {
    setShowDetailsPanel(false);
  }, []);

  const handleShowAll = useCallback(() => {
    if (!cyRef.current) return;

    // Show all elements
    cyRef.current.elements().removeClass('hidden highlighted faded');

    // Fit view to show all nodes
    setTimeout(() => {
      if (cyRef.current) {
        cyRef.current.fit(undefined, 50);
      }
    }, 50);

    // Exit focus mode
    setIsFocusMode(false);
  }, []);

  const handleFocusDepthChange = useCallback((depth) => {
    setFocusDepth(depth);
  }, []);

  const handleToggleAreaSelect = useCallback(() => {
    setIsAreaSelectMode(prev => !prev);

    // Clear any existing selection when toggling off
    if (isAreaSelectMode && cyRef.current) {
      cyRef.current.$(':selected').unselect();
    }
  }, [isAreaSelectMode]);

  const handleFocusSelected = useCallback(() => {
    if (!cyRef.current) return;

    // Get all selected nodes
    const selectedNodes = cyRef.current.$(':selected').nodes();

    if (selectedNodes.length === 0) {
      return;
    }

    // Build neighborhood for all selected nodes at specified depth
    let neighborhood = selectedNodes;

    // Build neighborhood iteratively for each depth level
    for (let i = 0; i < focusDepth; i++) {
      if (i === 0) {
        neighborhood = selectedNodes.closedNeighborhood();
      } else {
        // Get next level of neighbors
        neighborhood = neighborhood.nodes().closedNeighborhood();
      }
    }

    // Hide all elements
    cyRef.current.elements().addClass('hidden');

    // Show only the neighborhood
    neighborhood.removeClass('hidden');

    // Highlight the selected nodes
    cyRef.current.elements().removeClass('highlighted faded');
    selectedNodes.addClass('highlighted');

    // Fit the view to the visible neighborhood
    cyRef.current.fit(neighborhood, 50);

    // Set focus mode active and disable area select mode
    setIsFocusMode(true);
    setIsAreaSelectMode(false);

    // Show details panel for first selected node
    if (selectedNodes.length > 0) {
      setSelectedNodeData(selectedNodes[0].data());
      setShowDetailsPanel(true);
    }
  }, [focusDepth]);

  // Control Cytoscape interaction mode for area selection
  useEffect(() => {
    if (!cyRef.current) return;

    if (isAreaSelectMode) {
      // Disable panning and node dragging to make box selection easier
      cyRef.current.userPanningEnabled(false);
      cyRef.current.autoungrabify(true);

      // Change cursor to crosshair
      cyRef.current.container().style.cursor = 'crosshair';
    } else {
      // Re-enable panning and node dragging
      cyRef.current.userPanningEnabled(true);
      cyRef.current.autoungrabify(false);

      // Reset cursor
      cyRef.current.container().style.cursor = 'default';
    }
  }, [isAreaSelectMode]);

  // Auto-focus when nodes are selected in area select mode
  useEffect(() => {
    if (!cyRef.current || !isAreaSelectMode) return;

    const handleSelection = () => {
      // Small delay to ensure selection is complete
      setTimeout(() => {
        const selectedNodes = cyRef.current.$(':selected').nodes();
        if (selectedNodes.length > 0) {
          handleFocusSelected();
        }
      }, 100);
    };

    cyRef.current.on('boxend', handleSelection);

    return () => {
      if (cyRef.current) {
        cyRef.current.off('boxend', handleSelection);
      }
    };
  }, [isAreaSelectMode, handleFocusSelected]);

  // Render states
  if (parseError) {
    return (
      <div className={styles.error}>
        <h3>Erro ao processar GraphML</h3>
        <p>{parseError}</p>
        <p>Formato esperado: GraphML XML</p>
      </div>
    );
  }

  if (!value) {
    return (
      <div className={styles.empty}>
        <p>Nenhum dado disponível</p>
      </div>
    );
  }

  return (
    <div className={`${styles.diagramViewer} ${isFullscreen ? styles.fullscreen : ''}`}>
      {/* Top Toolbar */}
      <div className={styles.topToolbar}>
        <h2 className={styles.title}>{displayName || 'Visualizador de Diagramas'}</h2>
        <div className={styles.toolbarActions}>
          <button
            className={styles.toolbarButton}
            onClick={handleFullscreenToggle}
            title={isFullscreen ? 'Sair de tela cheia' : 'Tela cheia'}
          >
            {isFullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
          </button>
          {onClose && (
            <button
              className={styles.toolbarButton}
              onClick={onClose}
              title="Fechar"
            >
              <CloseIcon size={20} />
            </button>
          )}
        </div>
      </div>

      <div className={styles.viewerContent}>
        <DiagramSidebar
          elements={elements}
          searchTerm={searchTerm}
          onSearch={handleSearch}
          onSearchResultSelect={handleSearchResultSelect}
          nodeTypeFilters={nodeTypeFilters}
          edgeTypeFilters={edgeTypeFilters}
          onNodeTypeFilterChange={handleNodeTypeFilterChange}
          onEdgeTypeFilterChange={handleEdgeTypeFilterChange}
          showSequentialFlowOnly={showSequentialFlowOnly}
          onSequentialFlowFilterChange={setShowSequentialFlowOnly}
          selectedLayout={pendingLayout}
          onLayoutChange={handleLayoutChange}
          onApplyLayout={handleApplyLayout}
          stats={stats}
          layoutParams={layoutParams}
          onLayoutParamsChange={setLayoutParams}
        />

        <div className={styles.diagramContainer}>
          <DiagramControls
            cy={cyRef.current}
            displayName={displayName}
            showDetailsPanel={showDetailsPanel}
            onToggleDetails={handleToggleDetails}
            isFocusMode={isFocusMode}
            onShowAll={handleShowAll}
            isAreaSelectMode={isAreaSelectMode}
            onToggleAreaSelect={handleToggleAreaSelect}
          />
          <DiagramDetailsPanel
            nodeData={selectedNodeData}
            isVisible={showDetailsPanel}
            onClose={handleCloseDetails}
            focusDepth={focusDepth}
            onFocusDepthChange={handleFocusDepthChange}
            isFocusMode={isFocusMode}
            onApplyFocus={handleApplyFocus}
          />
          <div className={styles.graphContainer} ref={containerRef} />
        </div>
      </div>
    </div>
  );
};

export default DiagramViewer;
