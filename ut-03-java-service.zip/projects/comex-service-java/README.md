# COMEX Service (Java Spring Boot)

Java Spring Boot backend service for COMEX operations. Provides REST API endpoints for companies, billing, payments, letters of credit, FX quotations, and SWIFT messages.

## Quick Start

### Prerequisites

- Java 17+
- Maven 3.9+ (or use included Maven wrapper)
- Docker (optional, for containerization)
- kubectl (optional, for Kubernetes deployment)

### Local Development

```bash
# Using Maven wrapper
./mvnw spring-boot:run

# Or with Maven installed
mvn spring-boot:run

# With specific profile
./mvnw spring-boot:run -Dspring-boot.run.profiles=dev
```

Service runs at: http://localhost:8080

### Build

```bash
# Build JAR
./mvnw package

# Skip tests
./mvnw package -DskipTests

# JAR location: target/comex-service-1.0.0-SNAPSHOT.jar
```

### Test

```bash
# Run tests
./mvnw test

# Run with coverage
./mvnw test jacoco:report
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/actuator/health` | Health check |
| GET | `/api/v1/comex/companies` | List companies |
| GET | `/api/v1/comex/companies/{cnpj}` | Get company details |
| POST | `/api/v1/comex/export/billing/query` | Query billing operations |
| POST | `/api/v1/comex/payment-orders/query` | Query payment orders |
| POST | `/api/v1/comex/export/letters-of-credit/query` | Query letters of credit |
| POST | `/api/v1/comex/fx/quotations/query` | Query FX quotations |
| GET | `/api/v1/comex/fx/rates` | Get exchange rates |
| GET | `/api/v1/comex/swift/messages` | List SWIFT messages |
| GET | `/api/v1/comex/swift/messages/{uetr}` | Get SWIFT message details |

## Configuration

Application properties (application.yml):

| Property | Default | Description |
|----------|---------|-------------|
| `server.port` | `8080` | Server port |
| `adapter.default` | `MOCK` | Backend adapter (MOCK, ORACLE, AWS, MQ) |
| `oracle.ws.url` | - | Oracle wsBankline URL |
| `oracle.username` | - | Oracle username |
| `oracle.password` | - | Oracle password |
| `aws.region` | - | AWS region |
| `aws.lambda.function` | - | AWS Lambda function name |

## Docker

```bash
# Build image
docker build -t comex-service-java .

# Run container
docker run -p 8080:8080 comex-service-java

# With environment variables
docker run -p 8080:8080 \
    -e SPRING_PROFILES_ACTIVE=prod \
    -e ADAPTER_DEFAULT=ORACLE \
    comex-service-java
```

## Kubernetes Deployment

```bash
# Apply manifests with kustomize
kubectl apply -k k8s/

# Check status
kubectl get pods -l app=comex-service-java

# View logs
kubectl logs -l app=comex-service-java -f

# Delete resources
kubectl delete -k k8s/
```

## Project Structure

```
.
├── pom.xml                           # Maven configuration
├── src/
│   ├── main/
│   │   ├── java/com/itau/comex/
│   │   │   ├── ComexServiceApplication.java
│   │   │   ├── config/
│   │   │   │   └── WebConfig.java
│   │   │   ├── controller/
│   │   │   │   └── ComexController.java
│   │   │   ├── domain/
│   │   │   │   ├── Company.java
│   │   │   │   └── SwiftMessage.java
│   │   │   ├── dto/
│   │   │   │   ├── CompanyListResponse.java
│   │   │   │   └── EmpresaResponse.java
│   │   │   └── service/
│   │   │       ├── ComexService.java
│   │   │       └── MockComexService.java
│   │   └── resources/
│   │       └── application.yml
│   └── test/
├── k8s/                              # Kubernetes manifests
├── Dockerfile
└── README.md
```

## Actuator Endpoints

Spring Boot Actuator provides production-ready features:

| Endpoint | Description |
|----------|-------------|
| `/actuator/health` | Application health |
| `/actuator/info` | Application info |
| `/actuator/metrics` | Application metrics |
| `/actuator/env` | Environment properties |

## License

Internal use only - Itau Unibanco
