import { useState, useRef, useEffect } from 'react';
import {
  ZoomIn,
  ZoomOut,
  FitToScreen,
  Reset,
  Download,
  Save,
  FolderOpen,
  Close,
  Information,
  CropTool,
  View
} from '@carbon/icons-react';
import { fitGraph, resetZoom, exportAsPNG, exportAsJSON, clearHighlights } from '../utils/cytoscapeConfig';
import styles from './DiagramControls.module.scss';

/**
 * DiagramControls Component
 * Floating draggable toolbar for diagram controls
 *
 * @param {Object} props
 * @param {Object} props.cy - Cytoscape instance
 * @param {string} props.displayName - File name for exports
 * @param {boolean} props.showDetailsPanel - Whether details panel is visible
 * @param {Function} props.onToggleDetails - Handler to toggle details panel
 * @param {boolean} props.isFocusMode - Whether in focus mode
 * @param {Function} props.onShowAll - Handler to show all nodes
 * @param {boolean} props.isAreaSelectMode - Whether in area select mode
 * @param {Function} props.onToggleAreaSelect - Handler to toggle area select mode
 */
const DiagramControls = ({
  cy,
  displayName,
  showDetailsPanel,
  onToggleDetails,
  isFocusMode,
  onShowAll,
  isAreaSelectMode,
  onToggleAreaSelect
}) => {
  const [position, setPosition] = useState({ bottom: 24, right: 24 }); // 1.5rem = 24px
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef({ startX: 0, startY: 0, startBottom: 0, startRight: 0 });
  const toolbarRef = useRef(null);

  // Drag event handlers
  const handleDragStart = (e) => {
    e.preventDefault();
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      startBottom: position.bottom,
      startRight: position.right,
    };
  };

  useEffect(() => {
    const handleDragMove = (e) => {
      if (!isDragging) return;

      const deltaX = dragRef.current.startX - e.clientX;
      const deltaY = dragRef.current.startY - e.clientY;

      setPosition({
        bottom: Math.max(0, dragRef.current.startBottom + deltaY),
        right: Math.max(0, dragRef.current.startRight + deltaX),
      });
    };

    const handleDragEnd = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      document.addEventListener('mousemove', handleDragMove);
      document.addEventListener('mouseup', handleDragEnd);

      return () => {
        document.removeEventListener('mousemove', handleDragMove);
        document.removeEventListener('mouseup', handleDragEnd);
      };
    }
  }, [isDragging, position.bottom, position.right]);

  const handleZoomIn = () => {
    if (cy) {
      const currentZoom = cy.zoom();
      cy.zoom({
        level: currentZoom * 1.2,
        renderedPosition: { x: cy.width() / 2, y: cy.height() / 2 },
      });
    }
  };

  const handleZoomOut = () => {
    if (cy) {
      const currentZoom = cy.zoom();
      cy.zoom({
        level: currentZoom * 0.8,
        renderedPosition: { x: cy.width() / 2, y: cy.height() / 2 },
      });
    }
  };

  const handleFit = () => {
    if (cy) {
      fitGraph(cy);
    }
  };

  const handleReset = () => {
    if (cy) {
      resetZoom(cy);
      clearHighlights(cy);
    }
  };

  const handleExportPNG = () => {
    if (cy) {
      const filename = displayName?.replace(/\.[^/.]+$/, '') || 'diagram';
      exportAsPNG(cy, `${filename}.png`);
    }
  };

  const handleExportJSON = () => {
    if (cy) {
      const filename = displayName?.replace(/\.[^/.]+$/, '') || 'diagram';
      exportAsJSON(cy, `${filename}.json`);
    }
  };

  const handleSaveLayout = () => {
    if (!cy) return;

    // Save current positions of all nodes
    const layout = {};
    cy.nodes().forEach((node) => {
      layout[node.id()] = node.position();
    });

    // Store in localStorage
    const layoutKey = `diagram-layout-${displayName || 'default'}`;
    localStorage.setItem(layoutKey, JSON.stringify(layout));
  };

  const handleRestoreLayout = () => {
    if (!cy) return;

    // Retrieve from localStorage
    const layoutKey = `diagram-layout-${displayName || 'default'}`;
    const savedLayout = localStorage.getItem(layoutKey);

    if (!savedLayout) {
      return;
    }

    try {
      const layout = JSON.parse(savedLayout);

      // Restore positions
      cy.nodes().forEach((node) => {
        if (layout[node.id()]) {
          node.position(layout[node.id()]);
        }
      });

      // Fit the graph after restoring
      cy.fit();
    } catch (err) {
      // console.error('Error restoring layout:', err);
    }
  };

  if (!cy) return null;

  return (
    <div
      ref={toolbarRef}
      className={`${styles.toolbar} ${isDragging ? styles.dragging : ''}`}
      style={{
        bottom: `${position.bottom}px`,
        right: `${position.right}px`,
      }}
    >
      {/* Drag handle */}
      <div
        className={styles.dragHandle}
        onMouseDown={handleDragStart}
      >
        <svg width="16" height="8" viewBox="0 0 16 8" fill="currentColor">
          <rect x="4" y="2" width="8" height="1" rx="0.5"/>
          <rect x="4" y="5" width="8" height="1" rx="0.5"/>
        </svg>
      </div>

      {/* Toolbar buttons in 2-column grid */}
      <button
        title="Aumentar zoom"
        className={styles.toolbarBtn}
        onClick={handleZoomIn}
      >
        <ZoomIn size={20} />
      </button>

      <button
        title="Diminuir zoom"
        className={styles.toolbarBtn}
        onClick={handleZoomOut}
      >
        <ZoomOut size={20} />
      </button>

      <button
        title="Ajustar à tela"
        className={styles.toolbarBtn}
        onClick={handleFit}
      >
        <FitToScreen size={20} />
      </button>

      <button
        title="Resetar visualização"
        className={styles.toolbarBtn}
        onClick={handleReset}
      >
        <Reset size={20} />
      </button>

      <button
        title="Exportar como PNG"
        className={styles.toolbarBtn}
        onClick={handleExportPNG}
      >
        <Download size={20} />
      </button>

      <button
        title="Salvar layout"
        className={styles.toolbarBtn}
        onClick={handleSaveLayout}
      >
        <Save size={20} />
      </button>

      <button
        title="Restaurar layout"
        className={styles.toolbarBtn}
        onClick={handleRestoreLayout}
      >
        <FolderOpen size={20} />
      </button>

      <button
        title="Limpar destaques"
        className={styles.toolbarBtn}
        onClick={() => clearHighlights(cy)}
      >
        <Close size={20} />
      </button>

      <button
        title={showDetailsPanel ? "Ocultar detalhes" : "Mostrar detalhes"}
        className={styles.toolbarBtn}
        onClick={onToggleDetails}
      >
        <Information size={20} />
      </button>

      <button
        title={isAreaSelectMode ? "Seleção de área ON (Arraste para selecionar)" : "Alternar modo de seleção de área"}
        className={`${styles.toolbarBtn} ${isAreaSelectMode ? styles.active : ''}`}
        onClick={onToggleAreaSelect}
      >
        <CropTool size={20} />
      </button>

      {isFocusMode && (
        <button
          title="Mostrar todos os nós"
          className={styles.toolbarBtn}
          onClick={onShowAll}
        >
          <View size={20} />
        </button>
      )}
    </div>
  );
};

export default DiagramControls;
