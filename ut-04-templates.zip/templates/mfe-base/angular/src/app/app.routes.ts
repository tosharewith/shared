// {{MFE_TITLE}} - Application Routes

import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./components/{{COMPONENT_PATH}}/{{COMPONENT_NAME}}.component')
      .then(m => m.{{COMPONENT_CLASS}})
  },
  {
    path: '**',
    redirectTo: ''
  }
];
