// Package adapters contains adapter implementations for external services
//
// The adapter layer is the ONLY place that knows about:
// - Oracle connection details
// - XML request/response formats
// - Legacy wsBankline.asmx
// - IBM MQ queues
// - AWS Lambda functions
// - CICS transactions
//
// The rest of the application uses the COMEXAdapter interface.
package adapters

import (
	"context"

	"comex-service/internal/domain"
)

// =============================================================================
// ADAPTER INTERFACE
// =============================================================================

// COMEXAdapter defines the interface for COMEX backend operations
//
// This interface is implemented by:
// - OracleAdapter: Legacy Oracle/wsBankline.asmx (co-existence)
// - AWSAdapter: AWS Lambda/RDS (target state)
// - MQAdapter: IBM MQ for async operations
// - MockAdapter: Development/testing
//
// The business service layer only knows this interface.
type COMEXAdapter interface {
	// Companies (ConsultaCNPJS.xml)
	ListCompanies(ctx context.Context, userCPF string) ([]domain.Company, error)
	GetCompanyDetails(ctx context.Context, cnpj string) (*domain.Company, error)

	// Export Billing (Tela_Entrada_Dados.xml → BAL1)
	QueryBillingOperations(ctx context.Context, query domain.BillingQuery) (*domain.BillingQueryResponse, error)
	GetBillingOperationDetails(ctx context.Context, id string) (*domain.BillingOperation, error)

	// Payment Orders (Tela_Entrada_OPRE.xml → BAL3)
	QueryPaymentOrders(ctx context.Context, query domain.PaymentOrderQuery) (*domain.PaymentOrdersResponse, error)
	GetPaymentOrderDetails(ctx context.Context, id string) (*domain.PaymentOrder, error)
	GetPaymentOrderStatus(ctx context.Context, id string) (string, error)

	// Letters of Credit (Tela_Lista_CNPJ_BAL7.xml → BAL7)
	QueryLettersOfCredit(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error)
	GetLetterOfCreditDetails(ctx context.Context, id string) (*domain.LetterOfCredit, error)

	// Received Letters (Tela_Lista_CNPJ_C9RT.xml → C9RT)
	QueryReceivedLetters(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error)

	// FX Quotations (TelaListaCNPJCambio.xml → BAEI)
	QueryFXQuotations(ctx context.Context, query domain.FXQuery) (*domain.FXQueryResponse, error)
	GetQuotationDetails(ctx context.Context, id string) (*domain.FXQuotation, error)
	GetExchangeRates(ctx context.Context, currencies []string) ([]domain.ExchangeRate, error)
	SimulateExchange(ctx context.Context, from, to string, amount float64) (*domain.ExchangeSimulation, error)

	// SWIFT
	ListSWIFTMessages(ctx context.Context, status, dateFrom, dateTo string) ([]domain.SWIFTMessage, error)
	GetSWIFTMessageDetails(ctx context.Context, uetr string) (*domain.SWIFTMessage, error)
	SendSWIFTMessage(ctx context.Context, req domain.SWIFTMessageRequest) (*domain.SWIFTMessageResponse, error)

	// Health
	Ping(ctx context.Context) error
}

// =============================================================================
// ADAPTER TYPE
// =============================================================================

// AdapterType represents the type of adapter
type AdapterType string

const (
	AdapterTypeOracle    AdapterType = "ORACLE"
	AdapterTypeAWS       AdapterType = "AWS"
	AdapterTypeMQ        AdapterType = "MQ"
	AdapterTypeMainframe AdapterType = "MAINFRAME"
	AdapterTypeMock      AdapterType = "MOCK"
)

// =============================================================================
// ADAPTER FACTORY
// =============================================================================

// AdapterConfig holds configuration for adapter selection
type AdapterConfig struct {
	// Default adapter type
	Default AdapterType

	// Per-service adapter overrides
	Services map[string]AdapterType

	// Oracle configuration
	Oracle OracleConfig

	// AWS configuration
	AWS AWSConfig

	// MQ configuration
	MQ MQConfig
}

// OracleConfig holds Oracle/Legacy configuration
type OracleConfig struct {
	WSURL    string
	Timeout  int
	Username string
	Password string
}

// AWSConfig holds AWS configuration
type AWSConfig struct {
	Region         string
	LambdaFunction string
}

// MQConfig holds IBM MQ configuration
type MQConfig struct {
	QueueManager string
	RequestQueue string
	ReplyQueue   string
	Timeout      int
}

// AdapterFactory creates adapters based on configuration
type AdapterFactory struct {
	config        AdapterConfig
	oracleAdapter COMEXAdapter
	awsAdapter    COMEXAdapter
	mqAdapter     COMEXAdapter
	mockAdapter   COMEXAdapter
}

// NewAdapterFactory creates a new adapter factory
func NewAdapterFactory(config AdapterConfig) *AdapterFactory {
	factory := &AdapterFactory{config: config}

	// Initialize adapters lazily
	return factory
}

// GetAdapter returns the appropriate adapter for a service
func (f *AdapterFactory) GetAdapter(service string) COMEXAdapter {
	// Check for service-specific override
	adapterType := f.config.Default
	if override, ok := f.config.Services[service]; ok {
		adapterType = override
	}

	switch adapterType {
	case AdapterTypeOracle:
		return f.getOracleAdapter()
	case AdapterTypeAWS:
		return f.getAWSAdapter()
	case AdapterTypeMQ:
		return f.getMQAdapter()
	case AdapterTypeMock:
		return f.getMockAdapter()
	default:
		return f.getOracleAdapter()
	}
}

func (f *AdapterFactory) getOracleAdapter() COMEXAdapter {
	if f.oracleAdapter == nil {
		f.oracleAdapter = NewOracleAdapter(f.config.Oracle)
	}
	return f.oracleAdapter
}

func (f *AdapterFactory) getAWSAdapter() COMEXAdapter {
	if f.awsAdapter == nil {
		f.awsAdapter = NewAWSAdapter(f.config.AWS)
	}
	return f.awsAdapter
}

func (f *AdapterFactory) getMQAdapter() COMEXAdapter {
	if f.mqAdapter == nil {
		f.mqAdapter = NewMQAdapter(f.config.MQ)
	}
	return f.mqAdapter
}

func (f *AdapterFactory) getMockAdapter() COMEXAdapter {
	if f.mockAdapter == nil {
		f.mockAdapter = NewMockAdapter()
	}
	return f.mockAdapter
}

// GetAdapterType returns the adapter type for a service
func (f *AdapterFactory) GetAdapterType(service string) AdapterType {
	if override, ok := f.config.Services[service]; ok {
		return override
	}
	return f.config.Default
}
