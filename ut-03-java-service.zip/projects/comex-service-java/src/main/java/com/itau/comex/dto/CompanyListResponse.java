package com.itau.comex.dto;

import com.itau.comex.domain.Company;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response DTO for company list (v1 API format)
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompanyListResponse {
    private List<Company> companies;
    private int totalCount;

    public static CompanyListResponse from(List<Company> companies) {
        return CompanyListResponse.builder()
                .companies(companies)
                .totalCount(companies.size())
                .build();
    }
}
