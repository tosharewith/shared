// {{MFE_TITLE}} - Application Entry Point
// Design System: IDS (Itaú Design System) - Segment: empresas

import { bootstrapApplication } from '@angular/platform-browser';
import { importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { IdsConfigModule } from '@ids/angular';

import { AppComponent } from './app/app.component';
import { routes } from './app/app.routes';

bootstrapApplication(AppComponent, {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptorsFromDi()),
    provideAnimations(),
    importProvidersFrom(
      IdsConfigModule.forRoot({
        segment: 'empresas',
      })
    )
  ]
}).catch((err) => console.error(err));
