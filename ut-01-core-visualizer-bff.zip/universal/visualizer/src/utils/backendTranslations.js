/**
 * Backend Types Translation Module
 * Professional translations for all backend integration types
 * Used across visualizer, code generator, and documentation
 */

/**
 * Backend Type Definitions with full metadata
 */
export const BACKEND_TYPES = {
  // Database Operations
  ADO: {
    id: 'ADO',
    name: {
      en: 'SQL Database (ADO)',
      pt: 'Banco de Dados SQL (ADO)'
    },
    description: {
      en: 'ActiveX Data Objects - SQL database operations via stored procedures and queries',
      pt: 'ActiveX Data Objects - Operações em banco de dados SQL via procedures e consultas'
    },
    xmlElement: ['ADOConsulta', 'ADOOperacao'],
    identifier: 'bancoDados',
    databases: ['DBWN01', 'DBWN02', 'DBWN03', 'DBWN04', 'DBWN05'],
    operations: ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'EXEC'],
    icon: 'Database',
    color: '#0f62fe'
  },

  // Mainframe CICS
  MAINFRAME: {
    id: 'MAINFRAME',
    name: {
      en: 'Mainframe (CICS)',
      pt: 'Mainframe (CICS)'
    },
    description: {
      en: 'IBM CICS transaction processing - Position-based field mapping with EBCDIC encoding',
      pt: 'Processamento de transações IBM CICS - Mapeamento de campos posicionais com codificação EBCDIC'
    },
    xmlElement: ['Mainframe', 'MainframeGRBE'],
    identifier: 'trancode',
    icon: 'Terminal',
    color: '#6929c4'
  },

  // Mainframe GRBE (variant)
  MAINFRAME_GRBE: {
    id: 'MAINFRAME_GRBE',
    name: {
      en: 'Mainframe (GRBE)',
      pt: 'Mainframe (GRBE)'
    },
    description: {
      en: 'GRBE protocol - Enhanced mainframe integration with structured field definitions',
      pt: 'Protocolo GRBE - Integração aprimorada com mainframe com definições estruturadas de campos'
    },
    xmlElement: ['MainframeGRBE'],
    identifier: 'trancode',
    icon: 'Terminal',
    color: '#8a3ffc'
  },

  // Modern REST APIs
  REST_API: {
    id: 'REST_API',
    name: {
      en: 'REST API',
      pt: 'API REST'
    },
    description: {
      en: 'Modern REST APIs - HTTP methods (GET/POST/PUT/DELETE) with JSON/XML responses',
      pt: 'APIs REST modernas - Métodos HTTP (GET/POST/PUT/DELETE) com respostas JSON/XML'
    },
    xmlElement: ['WebService'],
    xmlAttribute: { tipoWS: 'API' },
    baseUrl: 'ibank-api.raiapp.itau',
    headers: ['itau-chave', 'Accept: application/vnd.itau.v1+xml'],
    icon: 'Api',
    color: '#198038'
  },

  // SOAP WebServices
  SOAP: {
    id: 'SOAP',
    name: {
      en: 'SOAP WebService',
      pt: 'WebService SOAP'
    },
    description: {
      en: 'SOAP protocol - XML envelope with WSDL contract definition',
      pt: 'Protocolo SOAP - Envelope XML com definição de contrato WSDL'
    },
    xmlElement: ['WebService'],
    xmlAttribute: { tipoWS: 'SOAP' },
    identifier: 'wsdl',
    icon: 'CloudServiceManagement',
    color: '#1192e8'
  },

  // Legacy ASMX WebServices
  LEGACY_WS: {
    id: 'LEGACY_WS',
    name: {
      en: 'Legacy WebService (.asmx)',
      pt: 'WebService Legado (.asmx)'
    },
    description: {
      en: 'Legacy ASP.NET ASMX services - ProcessaXML endpoint with stored procedure calls',
      pt: 'Serviços ASP.NET ASMX legados - Endpoint ProcessaXML com chamadas de procedures'
    },
    xmlElement: ['WebService'],
    xmlAttribute: { tipoWS: 'Normal' },
    baseUrl: 'wsBankline.asmx',
    endpoint: '/ProcessaXML',
    icon: 'DocumentExport',
    color: '#9f1853'
  },

  // MBI - Multi-channel Banking Interface
  MBI: {
    id: 'MBI',
    name: {
      en: 'MBI (Multi-channel Banking Interface)',
      pt: 'MBI (Interface Bancária Multicanal)'
    },
    description: {
      en: 'API Gateway integration - OAuth authenticated banking APIs with rate limiting',
      pt: 'Integração via API Gateway - APIs bancárias autenticadas via OAuth com controle de taxa'
    },
    xmlElement: ['WebService'],
    xmlAttribute: { tipoWS: 'MBI' },
    baseUrl: 'apigateway',
    authentication: 'OAuth2',
    icon: 'Gateway',
    color: '#005d5d'
  },

  // CMC - Controlador Multicanal (Private Banking)
  CMC: {
    id: 'CMC',
    name: {
      en: 'CMC (Multi-channel Controller)',
      pt: 'CMC (Controlador Multicanal)'
    },
    description: {
      en: 'Private Banking SOAP service - Investment portfolio, positions, and rentability queries',
      pt: 'Serviço SOAP de Private Banking - Consultas de carteira de investimentos, posições e rentabilidade'
    },
    xmlElement: ['WebService'],
    xmlAttribute: { tipoWS: 'CMC' },
    baseUrl: 'controladormulticanal.raiapp.itau',
    namespace: 'Itau.CMC',
    operations: [
      'ConsultarStatusPosicao',
      'ConsultarResumoPortfolio',
      'ConsultarRentabilidade',
      'ConsultarDetPosicao',
      'ExtratoMensal'
    ],
    icon: 'ChartLine',
    color: '#fa4d56'
  },

  // Browser/Form interactions
  BROWSER: {
    id: 'BROWSER',
    name: {
      en: 'Browser Form',
      pt: 'Formulário Browser'
    },
    description: {
      en: 'Client-side form interaction - User input collection and validation',
      pt: 'Interação de formulário no cliente - Coleta e validação de entrada do usuário'
    },
    xmlElement: ['Browser', 'Formulario'],
    icon: 'Screen',
    color: '#24a148'
  }
};

/**
 * Get backend type definition by ID
 */
export function getBackendType(typeId) {
  return BACKEND_TYPES[typeId?.toUpperCase()] || null;
}

/**
 * Get localized name for a backend type
 */
export function getBackendTypeName(typeId, locale = 'pt') {
  const type = getBackendType(typeId);
  return type?.name?.[locale] || type?.name?.en || typeId;
}

/**
 * Get localized description for a backend type
 */
export function getBackendTypeDescription(typeId, locale = 'pt') {
  const type = getBackendType(typeId);
  return type?.description?.[locale] || type?.description?.en || '';
}

/**
 * Detect backend type from XML element and attributes
 */
export function detectBackendType(xmlElement, attributes = {}) {
  // Check ADO types
  if (['ADOConsulta', 'ADOOperacao'].includes(xmlElement)) {
    return BACKEND_TYPES.ADO;
  }

  // Check Mainframe types
  if (xmlElement === 'MainframeGRBE') {
    return BACKEND_TYPES.MAINFRAME_GRBE;
  }
  if (xmlElement === 'Mainframe') {
    return BACKEND_TYPES.MAINFRAME;
  }

  // Check WebService variants
  if (xmlElement === 'WebService') {
    const tipoWS = attributes.tipoWS || attributes.tipows || '';

    switch (tipoWS.toUpperCase()) {
      case 'API':
        return BACKEND_TYPES.REST_API;
      case 'SOAP':
        return BACKEND_TYPES.SOAP;
      case 'MBI':
        return BACKEND_TYPES.MBI;
      case 'CMC':
        return BACKEND_TYPES.CMC;
      case 'NORMAL':
      default:
        return BACKEND_TYPES.LEGACY_WS;
    }
  }

  // Check Browser types
  if (['Browser', 'Formulario'].includes(xmlElement)) {
    return BACKEND_TYPES.BROWSER;
  }

  return null;
}

/**
 * Get all backend types as array
 */
export function getAllBackendTypes() {
  return Object.values(BACKEND_TYPES);
}

/**
 * Get backend types grouped by category
 */
export function getBackendTypesByCategory() {
  return {
    database: [BACKEND_TYPES.ADO],
    mainframe: [BACKEND_TYPES.MAINFRAME, BACKEND_TYPES.MAINFRAME_GRBE],
    webservice: [
      BACKEND_TYPES.REST_API,
      BACKEND_TYPES.SOAP,
      BACKEND_TYPES.LEGACY_WS,
      BACKEND_TYPES.MBI,
      BACKEND_TYPES.CMC
    ],
    frontend: [BACKEND_TYPES.BROWSER]
  };
}

/**
 * Format backend type for display in UI
 */
export function formatBackendType(typeId, options = {}) {
  const { locale = 'pt', showDescription = false, showIcon = true } = options;
  const type = getBackendType(typeId);

  if (!type) {
    return { name: typeId, description: '', icon: 'Unknown', color: '#8d8d8d' };
  }

  return {
    name: type.name[locale] || type.name.en,
    description: showDescription ? (type.description[locale] || type.description.en) : '',
    icon: showIcon ? type.icon : null,
    color: type.color,
    id: type.id
  };
}

/**
 * Common operation translations
 */
export const OPERATION_TRANSLATIONS = {
  // ADO Operations
  SELECT: { en: 'Query', pt: 'Consulta' },
  INSERT: { en: 'Insert', pt: 'Inclusão' },
  UPDATE: { en: 'Update', pt: 'Alteração' },
  DELETE: { en: 'Delete', pt: 'Exclusão' },
  EXEC: { en: 'Execute Procedure', pt: 'Executar Procedure' },

  // Mainframe Operations
  SEND: { en: 'Send Transaction', pt: 'Enviar Transação' },
  RECEIVE: { en: 'Receive Response', pt: 'Receber Resposta' },

  // WebService Operations
  GET: { en: 'GET Request', pt: 'Requisição GET' },
  POST: { en: 'POST Request', pt: 'Requisição POST' },
  PUT: { en: 'PUT Request', pt: 'Requisição PUT' },
  PATCH: { en: 'PATCH Request', pt: 'Requisição PATCH' },

  // Form Operations
  SUBMIT: { en: 'Submit Form', pt: 'Enviar Formulário' },
  VALIDATE: { en: 'Validate', pt: 'Validar' },
  NAVIGATE: { en: 'Navigate', pt: 'Navegar' }
};

/**
 * Get operation translation
 */
export function getOperationName(operation, locale = 'pt') {
  const op = OPERATION_TRANSLATIONS[operation?.toUpperCase()];
  return op?.[locale] || op?.en || operation;
}

/**
 * Field type translations
 */
export const FIELD_TYPE_TRANSLATIONS = {
  string: { en: 'Text', pt: 'Texto' },
  number: { en: 'Number', pt: 'Número' },
  date: { en: 'Date', pt: 'Data' },
  datetime: { en: 'Date/Time', pt: 'Data/Hora' },
  boolean: { en: 'Boolean', pt: 'Booleano' },
  currency: { en: 'Currency', pt: 'Moeda' },
  cpf: { en: 'CPF', pt: 'CPF' },
  cnpj: { en: 'CNPJ', pt: 'CNPJ' },
  email: { en: 'Email', pt: 'Email' },
  phone: { en: 'Phone', pt: 'Telefone' }
};

/**
 * Get field type translation
 */
export function getFieldTypeName(fieldType, locale = 'pt') {
  const ft = FIELD_TYPE_TRANSLATIONS[fieldType?.toLowerCase()];
  return ft?.[locale] || ft?.en || fieldType;
}

export default {
  BACKEND_TYPES,
  getBackendType,
  getBackendTypeName,
  getBackendTypeDescription,
  detectBackendType,
  getAllBackendTypes,
  getBackendTypesByCategory,
  formatBackendType,
  OPERATION_TRANSLATIONS,
  getOperationName,
  FIELD_TYPE_TRANSLATIONS,
  getFieldTypeName
};
