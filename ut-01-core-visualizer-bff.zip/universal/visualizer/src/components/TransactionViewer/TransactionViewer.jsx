import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import cytoscape from 'cytoscape';
import dagre from 'cytoscape-dagre';
import nodeHtmlLabel from 'cytoscape-node-html-label';
import { Tag, Button, Tabs, TabList, Tab, TabPanels, TabPanel, IconButton } from '@carbon/react';
import {
  ZoomIn,
  ZoomOut,
  FitToScreen,
  Download,
  Close,
  Application,
  DataBase,
  Api,
  Terminal,
  Screen,
  Document,
  Code,
  Information,
  Maximize,
  Minimize,
  ChevronRight,
  Filter,
  DiagramReference,
  TreeViewAlt,
  Popup,
  Help,
  CheckmarkFilled,
  ArrowRight,
  Settings
} from '@carbon/icons-react';
import {
  BACKEND_TYPES,
  detectBackendType,
  getBackendTypeName,
  getBackendTypeDescription,
  formatBackendType
} from '../../utils/backendTranslations';

// Category styling configuration
const CATEGORY_STYLES = {
  page: { color: '#0f62fe', icon: Screen, label: 'Tela Principal' },
  auxiliary: { color: '#8a3ffc', icon: Settings, label: 'Componente Auxiliar' },
  popup: { color: '#ff832b', icon: Popup, label: 'Popup/Modal' },
  step: { color: '#0072c3', icon: ArrowRight, label: 'Passo de Processo' },
  confirmation: { color: '#24a148', icon: CheckmarkFilled, label: 'Confirmação' },
  decision: { color: '#d12771', icon: Help, label: 'Decisão/Condição' },
  backend: { color: '#6929c4', icon: Api, label: 'Backend/Serviço' },
  final: { color: '#da1e28', icon: CheckmarkFilled, label: 'Tela Final' }
};
import AngularArchitecture from './AngularArchitecture';
import UserJourneyDFD from './UserJourneyDFD';
import styles from './TransactionViewer.module.scss';

// Register extensions
cytoscape.use(dagre);
nodeHtmlLabel(cytoscape);

// Swimlane configuration with professional translations
const SWIMLANES = [
  {
    id: 'browser',
    label: BACKEND_TYPES.BROWSER?.name?.pt || 'Formulário Browser',
    types: ['Browser', 'MENU', 'Formulario'],
    color: BACKEND_TYPES.BROWSER?.color || '#0f62fe',
    bg: '#d0e2ff'
  },
  {
    id: 'webservice',
    label: 'Web Services',
    types: ['WebService', 'WebService_API', 'WebService_SOAP', 'WebService_Normal', 'WebService_MBI', 'WebService_CMC'],
    color: BACKEND_TYPES.REST_API?.color || '#24a148',
    bg: '#a7f0ba'
  },
  {
    id: 'ado',
    label: BACKEND_TYPES.ADO?.name?.pt || 'Banco de Dados SQL (ADO)',
    types: ['ADOConsulta', 'ADOOperacao'],
    color: BACKEND_TYPES.ADO?.color || '#0072c3',
    bg: '#bae6ff'
  },
  {
    id: 'mainframe',
    label: BACKEND_TYPES.MAINFRAME?.name?.pt || 'Mainframe (CICS)',
    types: ['Mainframe', 'MainframeGRBE', 'MainframeXML'],
    color: BACKEND_TYPES.MAINFRAME?.color || '#da1e28',
    bg: '#ffb3b8'
  },
  { id: 'other', label: 'Outros', types: ['Unknown'], color: '#8d8d8d', bg: '#f4f4f4' }
];

// Get swimlane for a node type
const getSwimlane = (type) => {
  for (const lane of SWIMLANES) {
    if (lane.types.includes(type)) return lane;
  }
  return SWIMLANES[SWIMLANES.length - 1]; // 'other'
};

// SVG icons as HTML for node-html-label
const getTypeIconSvg = (type) => {
  const color = getSwimlane(type).color;
  const icons = {
    Browser: `<svg width="20" height="20" viewBox="0 0 32 32" fill="${color}"><path d="M28 4H4a2 2 0 0 0-2 2v20a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 2v4H4V6zM4 26V12h24v14z"/><circle cx="7" cy="8" r="1"/><circle cx="10" cy="8" r="1"/><circle cx="13" cy="8" r="1"/></svg>`,
    WebService: `<svg width="20" height="20" viewBox="0 0 32 32" fill="${color}"><path d="M26 14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2v4.1a5 5 0 0 0-3.9 3.9H14v-2a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-2h4.1a5 5 0 1 0 5.9-5.9V14zM6 18h6v6H6zm17 6a3 3 0 1 1 3-3 3 3 0 0 1-3 3zM20 6h6v6h-6z"/></svg>`,
    ADO: `<svg width="20" height="20" viewBox="0 0 32 32" fill="${color}"><path d="M24 3H8a2 2 0 0 0-2 2v22a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm0 2v4H8V5zm-8 18a4 4 0 1 1 4-4 4 4 0 0 1-4 4zm0-6a2 2 0 1 0 2 2 2 2 0 0 0-2-2zM8 27v-2h16v2zm16-6h-2v-2h2zm0-4h-2v-2h2zm0-4h-2V9h2z"/></svg>`,
    Mainframe: `<svg width="20" height="20" viewBox="0 0 32 32" fill="${color}"><path d="M28 6H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h24a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zM4 24V8h24v16z"/><path d="M6 10h20v2H6zm0 4h20v2H6zm0 4h12v2H6z"/></svg>`,
    MENU: `<svg width="20" height="20" viewBox="0 0 32 32" fill="${color}"><path d="M4 6h24v2H4zm0 6h24v2H4zm0 6h24v2H4zm0 6h24v2H4z"/></svg>`,
    default: `<svg width="20" height="20" viewBox="0 0 32 32" fill="${color}"><path d="M16 4A12 12 0 1 0 28 16 12 12 0 0 0 16 4zm0 22A10 10 0 1 1 26 16 10 10 0 0 1 16 26z"/><circle cx="16" cy="16" r="4"/></svg>`
  };

  if (type === 'Browser') return icons.Browser;
  if (type === 'WebService') return icons.WebService;
  if (type?.includes('ADO')) return icons.ADO;
  if (type?.includes('Mainframe')) return icons.Mainframe;
  if (type === 'MENU') return icons.MENU;
  return icons.default;
};

// Node styles - sized to match HTML label cards
const TRANSACTION_STYLES = [
  {
    selector: 'node',
    style: {
      'background-color': '#ffffff',
      'background-opacity': 0,
      'border-width': 0,
      'shape': 'roundrectangle',
      'width': 220,
      'height': 80,
      'label': '',
      'overlay-opacity': 0
    }
  },
  {
    selector: 'edge',
    style: {
      'width': 2,
      'line-color': '#78a9ff',
      'target-arrow-color': '#0f62fe',
      'target-arrow-shape': 'triangle',
      'curve-style': 'bezier',
      'arrow-scale': 1
    }
  },
  {
    selector: 'node:selected',
    style: {
      'overlay-color': '#8a3ffc',
      'overlay-opacity': 0.15,
      'overlay-padding': 4
    }
  },
  {
    selector: 'node[type = "MENU"]',
    style: {
      'width': 220,
      'height': 85
    }
  }
];

const TransactionViewer = ({ transaction, onClose }) => {
  const containerRef = useRef(null);
  const cyRef = useRef(null);
  const [transactionData, setTransactionData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [layoutMode, setLayoutMode] = useState('dagre'); // 'dagre', 'grid', 'cose'
  const [typeFilters, setTypeFilters] = useState({
    browser: true,
    webservice: true,
    ado: true,
    mainframe: true,
    other: true
  });
  const [showFilters, setShowFilters] = useState(false);

  // Load transaction data
  useEffect(() => {
    if (transaction) {
      loadTransactionData(transaction);
    }
  }, [transaction]);

  const loadTransactionData = async (txn) => {
    try {
      setLoading(true);
      setLoadError(null);

      // Check if raw JSON data was provided (from upload/extraction)
      if (txn._rawJSON) {
        const data = txn._rawJSON;
        // Ensure entryPoints exists
        if (!data.flow?.entryPoints || data.flow.entryPoints.length === 0) {
          if (!data.flow) data.flow = {};
          data.flow.entryPoints = [{
            idMBkl: data.menuItem?.idMBkl || 'uploaded',
            nomeLogico: data.menuItem?.nomeLogico || txn.name,
            menuPath: data.menuItem?.menuPath || [],
            moduloEmpPlus: data.menuItem?.moduloEmpPlus || '',
            channels: ['uploaded']
          }];
        }
        setTransactionData(data);
        setLoading(false);
        return;
      }

      if (txn.transactionFile) {
        try {
          const response = await fetch(`/extractions/${txn.transactionFile}`);
          if (response.ok) {
            const data = await response.json();
            // Ensure entryPoints always has at least the menu item entry
            if (!data.flow?.entryPoints || data.flow.entryPoints.length === 0) {
              if (!data.flow) data.flow = {};
              data.flow.entryPoints = [{
                idMBkl: txn.idMBkl,
                nomeLogico: txn.nomeLogico,
                menuPath: txn.menuPath || [],
                moduloEmpPlus: txn.moduloEmpPlus || '',
                channels: txn.channels || [txn.channel]
              }];
            }
            setTransactionData(data);
            setLoading(false);
            return;
          }
        } catch (e) {
          console.warn('Transaction file not found, using menu item data');
        }
      }

      const menuItemData = buildFromMenuItem(txn);
      setTransactionData(menuItemData);
      setLoadError('Arquivo de transação não encontrado. Mostrando dados do menu.');
    } catch (error) {
      console.error('Error loading transaction:', error);
      setLoadError('Erro ao carregar dados da transação');
      setTransactionData(null);
    } finally {
      setLoading(false);
    }
  };

  const buildFromMenuItem = (txn) => {
    const menuPath = txn.menuPath || [];
    let trnInfo = null;
    if (txn.trn) {
      const trnMatch = txn.trn.match(/^([^\\]+)\\([^\\]+)\\([^@]+)(?:@(.*))?$/);
      if (trnMatch) {
        trnInfo = {
          module: trnMatch[1],
          subProgram: trnMatch[2],
          interaction: trnMatch[3],
          params: trnMatch[4] ? trnMatch[4].split('@') : []
        };
      }
    }

    return {
      schemaType: 'transaction',
      metadata: { sourceFile: 'menu-item', version: '2.0.0', transactionId: txn.idMBkl },
      menuItem: {
        idMBkl: txn.idMBkl,
        nomeLogico: txn.nomeLogico,
        menuPath: menuPath,
        moduloEmpPlus: txn.moduloEmpPlus || '',
        trn: txn.trn ? {
          full: txn.trn,
          module: trnInfo?.module || '',
          sub_program: trnInfo?.subProgram || '',
          interaction: trnInfo?.interaction || '',
          params: trnInfo?.params || []
        } : null,
        channels: txn.channels || [txn.channel]
      },
      flow: {
        entryPoints: [{
          idMBkl: txn.idMBkl,
          nomeLogico: txn.nomeLogico,
          menuPath: menuPath,
          moduloEmpPlus: txn.moduloEmpPlus || '',
          channels: txn.channels || [txn.channel]
        }],
        interactions: [],
        flowGraph: {}
      }
    };
  };

  // Build graph elements with sequence ordering
  const graphElements = useMemo(() => {
    if (!transactionData) return { nodes: [], edges: [] };

    const nodes = [];
    const edges = [];
    const nodeSet = new Set();
    const edgeSet = new Set();

    const interactionMap = {};
    transactionData.flow?.interactions?.forEach((interaction) => {
      if (interaction.path) interactionMap[interaction.path] = interaction;
    });

    const flowGraph = transactionData.flow?.flowGraph || {};

    // Calculate sequence numbers using BFS from MENU
    const sequenceMap = new Map();
    sequenceMap.set('MENU', 0);

    if (Object.keys(flowGraph).length > 0) {
      const queue = [{ id: 'MENU', seq: 0 }];
      const visited = new Set(['MENU']);

      while (queue.length > 0) {
        const { id, seq } = queue.shift();
        const targets = flowGraph[id] || [];

        targets.forEach((target, idx) => {
          if (!visited.has(target)) {
            visited.add(target);
            const targetSeq = seq + 1;
            sequenceMap.set(target, targetSeq);
            queue.push({ id: target, seq: targetSeq });
          }
        });
      }
    }

    // Add MENU node
    nodes.push({
      data: {
        id: 'MENU',
        label: transactionData.menuItem?.nomeLogico || 'MENU',
        type: 'MENU',
        fullLabel: transactionData.menuItem?.nomeLogico || 'MENU',
        sequence: 0
      }
    });
    nodeSet.add('MENU');

    if (Object.keys(flowGraph).length > 0) {
      // Add all nodes with sequence
      Object.entries(flowGraph).forEach(([source, targets]) => {
        if (!nodeSet.has(source) && source !== 'MENU') {
          const interaction = interactionMap[source];
          const label = source.split('\\').pop();
          const seq = sequenceMap.get(source) || 999;
          nodes.push({
            data: {
              id: source,
              label: label,
              fullLabel: interaction?.name || label,
              type: interaction?.type || 'Unknown',
              module: source.split('\\')[0],
              subProgram: source.split('\\')[1],
              xmlFile: interaction?.xmlFile,
              webService: interaction?.webService,
              mainframe: interaction?.mainframe,
              sequence: seq
            }
          });
          nodeSet.add(source);
        }

        targets.forEach((target) => {
          if (!nodeSet.has(target)) {
            const interaction = interactionMap[target];
            const label = target.split('\\').pop();
            const seq = sequenceMap.get(target) || 999;
            nodes.push({
              data: {
                id: target,
                label: label,
                fullLabel: interaction?.name || label,
                type: interaction?.type || 'Unknown',
                module: target.split('\\')[0],
                subProgram: target.split('\\')[1],
                xmlFile: interaction?.xmlFile,
                webService: interaction?.webService,
                mainframe: interaction?.mainframe,
                sequence: seq
              }
            });
            nodeSet.add(target);
          }
        });
      });

      // Add edges
      Object.entries(flowGraph).forEach(([source, targets]) => {
        const uniqueTargets = [...new Set(targets)];
        uniqueTargets.forEach((target) => {
          const edgeId = `${source}->${target}`;
          if (!edgeSet.has(edgeId)) {
            edges.push({ data: { id: edgeId, source, target } });
            edgeSet.add(edgeId);
          }
        });
      });
    } else if (transactionData.menuItem?.trn) {
      const trn = transactionData.menuItem.trn;
      const trnPath = `${trn.module}\\${trn.sub_program}\\${trn.interaction}`;
      nodes.push({
        data: {
          id: trnPath,
          label: trn.interaction,
          fullLabel: trn.interaction,
          type: 'Browser',
          module: trn.module,
          subProgram: trn.sub_program,
          sequence: 1
        }
      });
      edges.push({ data: { id: `MENU->${trnPath}`, source: 'MENU', target: trnPath } });
    }

    // Filter nodes based on type filters
    const isTypeVisible = (type) => {
      const lane = getSwimlane(type);
      return typeFilters[lane.id] !== false;
    };

    const filteredNodes = nodes.filter(n => isTypeVisible(n.data.type));
    const filteredNodeIds = new Set(filteredNodes.map(n => n.data.id));

    // Only keep edges where both source and target are visible
    const filteredEdges = edges.filter(e =>
      filteredNodeIds.has(e.data.source) && filteredNodeIds.has(e.data.target)
    );

    return { nodes: filteredNodes, edges: filteredEdges };
  }, [transactionData, typeFilters]);

  // Grid layout - groups nodes by type in rows, sorted by sequence
  const applyGridLayout = useCallback((cy) => {
    if (!cy || cy.nodes().length === 0) return;

    const nodeWidth = 180;
    const nodeHeight = 70;
    const rowGap = 80;
    const colGap = 30;
    const startX = 50;
    const startY = 50;
    const maxNodesPerRow = 6;

    // Group nodes by swimlane
    const laneGroups = {};
    SWIMLANES.forEach(lane => {
      laneGroups[lane.id] = [];
    });

    cy.nodes().forEach(node => {
      const type = node.data('type') || 'Unknown';
      const lane = getSwimlane(type);
      laneGroups[lane.id].push(node);
    });

    let currentY = startY;

    SWIMLANES.forEach(lane => {
      const nodes = laneGroups[lane.id];
      if (nodes.length === 0) return;

      // Sort nodes by sequence (BFS order from MENU)
      nodes.sort((a, b) => {
        const seqA = a.data('sequence') ?? 999;
        const seqB = b.data('sequence') ?? 999;
        return seqA - seqB;
      });

      // Arrange in rows
      nodes.forEach((node, idx) => {
        const row = Math.floor(idx / maxNodesPerRow);
        const col = idx % maxNodesPerRow;
        node.position({
          x: startX + col * (nodeWidth + colGap),
          y: currentY + row * nodeHeight
        });
      });

      // Move to next lane section
      const rowsForLane = Math.ceil(nodes.length / maxNodesPerRow);
      currentY += rowsForLane * nodeHeight + rowGap;
    });

    cy.fit(null, 30);
  }, []);

  // Initialize Cytoscape
  useEffect(() => {
    if (!containerRef.current || graphElements.nodes.length === 0) return;

    const cy = cytoscape({
      container: containerRef.current,
      elements: [...graphElements.nodes, ...graphElements.edges],
      style: TRANSACTION_STYLES,
      layout: { name: 'preset' },
      wheelSensitivity: 0.3,
      minZoom: 0.3,
      maxZoom: 3
    });

    // Add HTML labels to nodes with rich descriptions
    cy.nodeHtmlLabel([
      {
        query: 'node',
        halign: 'center',
        valign: 'center',
        halignBox: 'center',
        valignBox: 'center',
        tpl: (data) => {
          const lane = getSwimlane(data.type);
          const iconSvg = getTypeIconSvg(data.type);

          // Use professional backend translations for type labels
          const getTypeDescription = (type) => {
            // Map XML element types to backend type IDs
            const typeMapping = {
              'MENU': { label: 'Ponto de Entrada', desc: 'Menu de navegação' },
              'Browser': BACKEND_TYPES.BROWSER ? { label: BACKEND_TYPES.BROWSER.name.pt, desc: BACKEND_TYPES.BROWSER.description.pt } : { label: 'Formulário Browser', desc: 'Interface do usuário' },
              'Formulario': BACKEND_TYPES.BROWSER ? { label: BACKEND_TYPES.BROWSER.name.pt, desc: BACKEND_TYPES.BROWSER.description.pt } : { label: 'Formulário', desc: 'Entrada de dados' },
              'WebService': BACKEND_TYPES.REST_API ? { label: 'Web Service', desc: BACKEND_TYPES.REST_API.description.pt } : { label: 'Web Service', desc: 'Chamada de API' },
              'WebService_API': BACKEND_TYPES.REST_API ? { label: BACKEND_TYPES.REST_API.name.pt, desc: BACKEND_TYPES.REST_API.description.pt } : { label: 'API REST', desc: 'APIs modernas' },
              'WebService_SOAP': BACKEND_TYPES.SOAP ? { label: BACKEND_TYPES.SOAP.name.pt, desc: BACKEND_TYPES.SOAP.description.pt } : { label: 'WebService SOAP', desc: 'Protocolo SOAP' },
              'WebService_Normal': BACKEND_TYPES.LEGACY_WS ? { label: BACKEND_TYPES.LEGACY_WS.name.pt, desc: BACKEND_TYPES.LEGACY_WS.description.pt } : { label: 'WebService Legado', desc: 'Serviço .asmx' },
              'WebService_MBI': BACKEND_TYPES.MBI ? { label: BACKEND_TYPES.MBI.name.pt, desc: BACKEND_TYPES.MBI.description.pt } : { label: 'MBI', desc: 'API Gateway' },
              'WebService_CMC': BACKEND_TYPES.CMC ? { label: BACKEND_TYPES.CMC.name.pt, desc: BACKEND_TYPES.CMC.description.pt } : { label: 'CMC', desc: 'Controlador Multicanal' },
              'ADOConsulta': BACKEND_TYPES.ADO ? { label: 'Consulta SQL', desc: BACKEND_TYPES.ADO.description.pt } : { label: 'Consulta DB', desc: 'Leitura de dados' },
              'ADOOperacao': BACKEND_TYPES.ADO ? { label: 'Operação SQL', desc: BACKEND_TYPES.ADO.description.pt } : { label: 'Operação DB', desc: 'Escrita de dados' },
              'Mainframe': BACKEND_TYPES.MAINFRAME ? { label: BACKEND_TYPES.MAINFRAME.name.pt, desc: BACKEND_TYPES.MAINFRAME.description.pt } : { label: 'Mainframe', desc: 'Sistema legado' },
              'MainframeGRBE': BACKEND_TYPES.MAINFRAME_GRBE ? { label: BACKEND_TYPES.MAINFRAME_GRBE.name.pt, desc: BACKEND_TYPES.MAINFRAME_GRBE.description.pt } : { label: 'Mainframe GRBE', desc: 'Gateway GRBE' },
              'MainframeXML': { label: 'Mainframe XML', desc: 'Gateway XML' },
              'Unknown': { label: 'Componente', desc: 'Tipo desconhecido' }
            };
            return typeMapping[type] || typeMapping['Unknown'];
          };

          const typeInfo = getTypeDescription(data.type);

          // Build context info
          let contextInfo = '';
          if (data.module && data.subProgram) {
            contextInfo = `${data.module} › ${data.subProgram}`;
          } else if (data.module) {
            contextInfo = data.module;
          }

          // Additional details based on type
          let detailInfo = '';
          if (data.webService?.url) {
            const url = data.webService.url;
            const shortUrl = url.length > 30 ? '...' + url.slice(-27) : url;
            detailInfo = `<div style="font-size:9px;color:#525252;margin-top:2px;">🔗 ${shortUrl}</div>`;
          } else if (data.mainframe?.trancode) {
            detailInfo = `<div style="font-size:9px;color:#525252;margin-top:2px;">📟 ${data.mainframe.trancode}</div>`;
          }

          // Sequence badge
          const seqBadge = data.sequence !== undefined && data.sequence > 0
            ? `<div style="position:absolute;top:-8px;left:-8px;width:20px;height:20px;background:${lane.color};color:white;border-radius:50%;font-size:10px;font-weight:600;display:flex;align-items:center;justify-content:center;">${data.sequence}</div>`
            : '';

          return `
            <div class="cy-node-card" style="
              position: relative;
              display: flex;
              flex-direction: column;
              padding: 10px 12px;
              background: linear-gradient(135deg, ${lane.bg} 0%, white 100%);
              border: 2px solid ${lane.color};
              border-radius: 8px;
              min-width: 180px;
              max-width: 220px;
              box-shadow: 0 2px 8px rgba(0,0,0,0.12);
              cursor: pointer;
              font-family: 'IBM Plex Sans', sans-serif;
            ">
              ${seqBadge}
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
                <div style="
                  flex-shrink: 0;
                  width: 36px;
                  height: 36px;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  background: white;
                  border-radius: 6px;
                  border: 1px solid ${lane.color}30;
                  box-shadow: 0 1px 2px rgba(0,0,0,0.05);
                ">
                  ${iconSvg}
                </div>
                <div style="flex:1;min-width:0;">
                  <div style="
                    font-size: 12px;
                    font-weight: 600;
                    color: #161616;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    line-height: 1.3;
                  ">${data.label || data.id}</div>
                  <div style="
                    font-size: 10px;
                    color: ${lane.color};
                    font-weight: 500;
                  ">${typeInfo.label}</div>
                </div>
              </div>
              ${contextInfo ? `<div style="font-size:9px;color:#697077;border-top:1px solid ${lane.color}20;padding-top:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">📁 ${contextInfo}</div>` : ''}
              ${detailInfo}
            </div>
          `;
        }
      }
    ]);

    cyRef.current = cy;

    // Apply layout
    if (layoutMode === 'grid') {
      applyGridLayout(cy);
    } else {
      // Dagre hierarchical layout (default)
      cy.layout({
        name: 'dagre',
        rankDir: 'TB',
        nodeSep: 60,
        rankSep: 100,
        edgeSep: 30,
        animate: false,
        fit: true,
        padding: 40
      }).run();
    }

    cy.on('tap', 'node', (evt) => {
      setSelectedNode(evt.target.data());
    });

    cy.on('tap', (evt) => {
      if (evt.target === cy) setSelectedNode(null);
    });

    return () => { if (cy) cy.destroy(); };
  }, [graphElements, layoutMode, applyGridLayout]);

  const handleZoomIn = () => cyRef.current?.zoom(cyRef.current.zoom() * 1.3);
  const handleZoomOut = () => cyRef.current?.zoom(cyRef.current.zoom() / 1.3);
  const handleFit = () => cyRef.current?.fit(null, 40);

  const handleExport = () => {
    if (!cyRef.current) return;
    const png = cyRef.current.png({ output: 'blob', bg: '#ffffff', full: true, scale: 2 });
    const url = URL.createObjectURL(png);
    const link = document.createElement('a');
    link.href = url;
    link.download = `transaction_${transactionData?.menuItem?.idMBkl || 'flow'}.png`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const toggleFullscreen = () => setIsFullscreen(!isFullscreen);

  const getTypeIcon = (type) => {
    switch (type) {
      case 'Browser': return <Screen size={16} />;
      case 'WebService': return <Api size={16} />;
      case 'ADOConsulta':
      case 'ADOOperacao': return <DataBase size={16} />;
      case 'Mainframe':
      case 'MainframeGRBE':
      case 'MainframeXML': return <Terminal size={16} />;
      default: return <Application size={16} />;
    }
  };

  if (loading) {
    return (
      <div className={`${styles.viewer} ${isFullscreen ? styles.fullscreen : ''}`}>
        <div className={styles.loading}>Carregando transação...</div>
      </div>
    );
  }

  if (!transactionData) {
    return (
      <div className={`${styles.viewer} ${isFullscreen ? styles.fullscreen : ''}`}>
        <div className={styles.error}>Transação não encontrada</div>
      </div>
    );
  }

  return (
    <div className={`${styles.viewer} ${isFullscreen ? styles.fullscreen : ''}`}>
      {/* Header */}
      <div className={styles.header}>
        <div className={styles.headerInfo}>
          <h2>{transactionData.menuItem?.nomeLogico || 'Transação'}</h2>
          <div className={styles.headerMeta}>
            {transactionData.menuItem?.trn?.destination && (
              <Tag type="purple" size="sm" title="Código de destino (contexto)">
                {transactionData.menuItem.trn.destination}
              </Tag>
            )}
            {transactionData.menuItem?.moduloEmpPlus && (
              <Tag type="teal" size="sm">{transactionData.menuItem.moduloEmpPlus}</Tag>
            )}
            <Tag type="blue" size="sm">ID: {transactionData.menuItem?.idMBkl}</Tag>
            <Tag type="gray" size="sm">{graphElements.nodes.length} nós</Tag>
            <Tag type="gray" size="sm">{graphElements.edges.length} conexões</Tag>
          </div>
        </div>
        <div className={styles.headerActions}>
          <IconButton
            kind="ghost"
            size="sm"
            label={isFullscreen ? 'Restaurar' : 'Maximizar'}
            onClick={toggleFullscreen}
          >
            {isFullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
          </IconButton>
          <IconButton kind="ghost" size="sm" label="Fechar" onClick={onClose}>
            <Close size={20} />
          </IconButton>
        </div>
      </div>

      {/* Tabs */}
      <Tabs selectedIndex={activeTab} onChange={({ selectedIndex }) => setActiveTab(selectedIndex)}>
        <TabList aria-label="Transaction views" contained>
          <Tab>Navegação</Tab>
          <Tab>Fluxo Cytoscape</Tab>
          <Tab>Angular Architecture</Tab>
          <Tab>Interações ({transactionData.flow?.interactions?.length || 0})</Tab>
          <Tab>Entry Points ({transactionData.flow?.entryPoints?.length || 0})</Tab>
        </TabList>

        <TabPanels>
          {/* Navigation Flow Tab - User Journey DFD + Step by step UI flow */}
          <TabPanel>
            {/* User Journey DFD */}
            <UserJourneyDFD transactionData={transactionData} />

            {/* Step by Step Navigation */}
            <div className={styles.navigationFlow}>
              {(() => {
                // Build navigation steps from interactions
                const interactions = transactionData.flow?.interactions || [];
                const flowGraph = transactionData.flow?.flowGraph || {};
                const mainPath = transactionData.flow?.mainPath || [];

                // Get UI screens (Browser type) in sequence order
                const screens = interactions
                  .filter(i => i.type === 'Browser' || i.type === 'Formulario')
                  .map(screen => {
                    const screenPath = screen.path;
                    const targetPaths = flowGraph[screenPath] || [];

                    // Get all targets and categorize them
                    const allTargets = targetPaths
                      .map(targetPath => interactions.find(i => i.path === targetPath))
                      .filter(Boolean);

                    // Separate navigations (to other screens) from backend calls
                    const navigatesTo = allTargets.filter(t => t.type === 'Browser' || t.type === 'Formulario');
                    const backendCalls = allTargets.filter(t => t.type !== 'Browser' && t.type !== 'Formulario');

                    // Deduplicate and count backend calls
                    const callCounts = {};
                    backendCalls.forEach(call => {
                      const key = call.name;
                      if (!callCounts[key]) {
                        callCounts[key] = { ...call, count: 0 };
                      }
                      callCounts[key].count++;
                    });
                    const uniqueCalls = Object.values(callCounts);

                    // Group calls by type
                    const groupedCalls = {
                      webservices: uniqueCalls.filter(c => c.type === 'WebService'),
                      database: uniqueCalls.filter(c => c.type?.includes('ADO')),
                      mainframe: uniqueCalls.filter(c => c.type?.includes('Mainframe')),
                      other: uniqueCalls.filter(c => !['WebService'].includes(c.type) && !c.type?.includes('ADO') && !c.type?.includes('Mainframe'))
                    };

                    // Get classification data
                    const classification = screen.classification || {};

                    return {
                      ...screen,
                      navigatesTo,
                      groupedCalls,
                      totalCalls: backendCalls.length,
                      // Classification fields
                      category: classification.category || 'page',
                      categoryLabel: classification.categoryLabel || null,
                      isPopup: classification.isPopup || false,
                      isAuxiliary: classification.isAuxiliary || false,
                      isStep: classification.isStep || false,
                      isFinal: classification.isFinal || false,
                      isConditional: classification.isConditional || false
                    };
                  });

                // Add MENU as first step with its navigations
                const menuTargets = (flowGraph['MENU'] || [])
                  .map(p => interactions.find(i => i.path === p))
                  .filter(Boolean);

                const steps = [
                  {
                    path: 'MENU',
                    name: transactionData.menuItem?.nomeLogico || 'Menu',
                    type: 'MENU',
                    isEntry: true,
                    navigatesTo: menuTargets.filter(t => t.type === 'Browser' || t.type === 'Formulario'),
                    groupedCalls: { webservices: [], database: [], mainframe: [], other: [] },
                    totalCalls: 0
                  },
                  ...screens
                ];

                if (steps.length <= 1) {
                  return (
                    <div className={styles.noData}>
                      <Information size={32} />
                      <p>Nenhum fluxo de navegação disponível</p>
                    </div>
                  );
                }

                // Helper to get category icon
                const getCategoryIcon = (step) => {
                  if (step.isConditional) return <Help size={16} />;
                  if (step.isPopup) return <Popup size={16} />;
                  if (step.isFinal) return <CheckmarkFilled size={16} />;
                  if (step.isStep) return <ArrowRight size={16} />;
                  if (step.isAuxiliary) return <Settings size={16} />;
                  return getTypeIcon(step.type);
                };

                // Helper to get category color
                const getCategoryColor = (step) => {
                  if (step.isConditional) return CATEGORY_STYLES.decision.color;
                  if (step.isPopup) return CATEGORY_STYLES.popup.color;
                  if (step.isFinal) return CATEGORY_STYLES.final.color;
                  if (step.isStep) return CATEGORY_STYLES.step.color;
                  if (step.isAuxiliary) return CATEGORY_STYLES.auxiliary.color;
                  const cat = CATEGORY_STYLES[step.category];
                  return cat ? cat.color : getSwimlane(step.type).color;
                };

                // Helper to get category label
                const getCategoryLabel = (step) => {
                  if (step.categoryLabel) return step.categoryLabel;
                  if (step.type === 'MENU') return 'Ponto de Entrada';
                  if (step.type === 'Browser') return 'Tela do Usuário';
                  if (step.type === 'Formulario') return 'Formulário';
                  return step.type;
                };

                return (
                  <div className={styles.stepsContainer}>
                    {steps.map((step, idx) => {
                      const categoryColor = getCategoryColor(step);
                      const stepClasses = [
                        styles.navStep,
                        step.isConditional ? styles.conditionalStep : '',
                        step.isPopup ? styles.popupStep : '',
                        step.isFinal ? styles.finalStep : '',
                        step.isAuxiliary ? styles.auxiliaryStep : ''
                      ].filter(Boolean).join(' ');

                      return (
                      <div key={idx} className={stepClasses}>
                        <div className={styles.stepNumber} style={{ background: categoryColor }}>
                          <span>{idx + 1}</span>
                        </div>
                        <div className={styles.stepConnector} style={{ borderColor: categoryColor }} />
                        <div className={styles.stepContent} style={{ borderLeftColor: categoryColor }}>
                          <div className={styles.stepHeader}>
                            <div className={styles.stepIcon} style={{ background: getSwimlane(step.type).bg, borderColor: categoryColor }}>
                              {getCategoryIcon(step)}
                            </div>
                            <div className={styles.stepInfo}>
                              <h4>{step.name}</h4>
                              <span className={styles.stepType} style={{ color: categoryColor }}>
                                {getCategoryLabel(step)}
                              </span>
                            </div>
                            {/* Category badges */}
                            <div className={styles.stepBadges}>
                              {step.isConditional && (
                                <Tag type="magenta" size="sm" title="Decisão/Condição">?</Tag>
                              )}
                              {step.isPopup && (
                                <Tag type="warm-gray" size="sm" title="Popup/Modal">◫</Tag>
                              )}
                              {step.isFinal && (
                                <Tag type="red" size="sm" title="Tela Final">✓</Tag>
                              )}
                              {step.isStep && (
                                <Tag type="cyan" size="sm" title="Passo de Processo">→</Tag>
                              )}
                              {step.isAuxiliary && (
                                <Tag type="purple" size="sm" title="Componente Auxiliar">⚙</Tag>
                              )}
                            </div>
                            {step.path !== 'MENU' && (
                              <code className={styles.stepPath}>{step.path}</code>
                            )}
                          </div>

                          {/* Navigation paths - where can user go from here */}
                          {step.navigatesTo && step.navigatesTo.length > 0 && (
                            <div className={styles.stepNavigations}>
                              <span className={styles.navLabel}>
                                <ChevronRight size={14} />
                                Navega para ({step.navigatesTo.length} {step.navigatesTo.length === 1 ? 'tela' : 'telas'}):
                              </span>
                              <div className={styles.navTargets}>
                                {step.navigatesTo.map((target, tidx) => (
                                  <span key={tidx} className={styles.navTarget}>
                                    {target.name}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Backend calls grouped by type */}
                          {step.totalCalls > 0 && (
                            <div className={styles.stepCalls}>
                              <span className={styles.callsLabel}>
                                Processamento interno ({step.totalCalls} {step.totalCalls === 1 ? 'chamada' : 'chamadas'}):
                              </span>

                              {/* WebServices */}
                              {step.groupedCalls.webservices.length > 0 && (
                                <div className={styles.callGroup}>
                                  <div className={styles.callGroupHeader} style={{ color: getSwimlane('WebService').color }}>
                                    <Api size={14} /> Web Services ({step.groupedCalls.webservices.length})
                                  </div>
                                  <div className={styles.callGroupItems}>
                                    {step.groupedCalls.webservices.map((call, cidx) => (
                                      <div key={cidx} className={styles.callItem} style={{ borderLeftColor: getSwimlane(call.type).color }}>
                                        <span className={styles.callName}>
                                          {call.name}
                                          {call.count > 1 && <span className={styles.callCount}>×{call.count}</span>}
                                        </span>
                                        {call.webService?.url && (
                                          <code className={styles.callDetail}>{call.webService.url}</code>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {/* Database */}
                              {step.groupedCalls.database.length > 0 && (
                                <div className={styles.callGroup}>
                                  <div className={styles.callGroupHeader} style={{ color: getSwimlane('ADOConsulta').color }}>
                                    <DataBase size={14} /> Database ({step.groupedCalls.database.length})
                                  </div>
                                  <div className={styles.callGroupItems}>
                                    {step.groupedCalls.database.map((call, cidx) => (
                                      <div key={cidx} className={styles.callItem} style={{ borderLeftColor: getSwimlane(call.type).color }}>
                                        <span className={styles.callName}>
                                          {call.name}
                                          {call.count > 1 && <span className={styles.callCount}>×{call.count}</span>}
                                        </span>
                                        <span className={styles.callType}>{call.type === 'ADOConsulta' ? 'Consulta' : 'Operação'}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {/* Mainframe */}
                              {step.groupedCalls.mainframe.length > 0 && (
                                <div className={styles.callGroup}>
                                  <div className={styles.callGroupHeader} style={{ color: getSwimlane('Mainframe').color }}>
                                    <Terminal size={14} /> Mainframe ({step.groupedCalls.mainframe.length})
                                  </div>
                                  <div className={styles.callGroupItems}>
                                    {step.groupedCalls.mainframe.map((call, cidx) => (
                                      <div key={cidx} className={styles.callItem} style={{ borderLeftColor: getSwimlane(call.type).color }}>
                                        <span className={styles.callName}>
                                          {call.name}
                                          {call.count > 1 && <span className={styles.callCount}>×{call.count}</span>}
                                        </span>
                                        {call.mainframe?.trancode && (
                                          <code className={styles.callDetail}>Trancode: {call.mainframe.trancode}</code>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {/* Other */}
                              {step.groupedCalls.other.length > 0 && (
                                <div className={styles.callGroup}>
                                  <div className={styles.callGroupHeader} style={{ color: '#697077' }}>
                                    <Application size={14} /> Outros ({step.groupedCalls.other.length})
                                  </div>
                                  <div className={styles.callGroupItems}>
                                    {step.groupedCalls.other.map((call, cidx) => (
                                      <div key={cidx} className={styles.callItem}>
                                        <span className={styles.callName}>
                                          {call.name}
                                          {call.count > 1 && <span className={styles.callCount}>×{call.count}</span>}
                                        </span>
                                        <span className={styles.callType}>{call.type}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
          </TabPanel>

          {/* Cytoscape Flow Graph Tab */}
          <TabPanel className={styles.graphTabPanel}>
            <div className={styles.graphWrapper}>
              {/* Graph Container */}
              <div className={styles.graphContainer}>
                {/* Toolbar */}
                <div className={styles.toolbar}>
                  <div className={styles.toolbarGroup}>
                    <IconButton kind="ghost" size="sm" label="Zoom In" onClick={handleZoomIn}>
                      <ZoomIn size={16} />
                    </IconButton>
                    <IconButton kind="ghost" size="sm" label="Zoom Out" onClick={handleZoomOut}>
                      <ZoomOut size={16} />
                    </IconButton>
                    <IconButton kind="ghost" size="sm" label="Ajustar" onClick={handleFit}>
                      <FitToScreen size={16} />
                    </IconButton>
                    <IconButton kind="ghost" size="sm" label="Exportar PNG" onClick={handleExport}>
                      <Download size={16} />
                    </IconButton>
                  </div>

                  {/* Layout Options */}
                  <div className={styles.toolbarGroup}>
                    <span className={styles.toolbarLabel}>Layout:</span>
                    <Button
                      kind={layoutMode === 'dagre' ? 'primary' : 'ghost'}
                      size="sm"
                      onClick={() => setLayoutMode('dagre')}
                      renderIcon={TreeViewAlt}
                    >
                      Hierárquico
                    </Button>
                    <Button
                      kind={layoutMode === 'grid' ? 'primary' : 'ghost'}
                      size="sm"
                      onClick={() => setLayoutMode('grid')}
                      renderIcon={DiagramReference}
                    >
                      Por Tipo
                    </Button>
                  </div>

                  {/* Filter Toggle */}
                  <div className={styles.toolbarGroup}>
                    <IconButton
                      kind={showFilters ? 'primary' : 'ghost'}
                      size="sm"
                      label="Filtros"
                      onClick={() => setShowFilters(!showFilters)}
                    >
                      <Filter size={16} />
                    </IconButton>
                  </div>
                </div>

                {/* Filter Panel */}
                {showFilters && (
                  <div className={styles.filterPanel}>
                    <span className={styles.filterLabel}>Mostrar tipos:</span>
                    {SWIMLANES.slice(0, -1).map((lane) => (
                      <label
                        key={lane.id}
                        className={styles.filterOption}
                        style={{ borderColor: lane.color }}
                      >
                        <input
                          type="checkbox"
                          checked={typeFilters[lane.id] !== false}
                          onChange={(e) => setTypeFilters(prev => ({
                            ...prev,
                            [lane.id]: e.target.checked
                          }))}
                        />
                        <span
                          className={styles.filterColor}
                          style={{ background: lane.bg, borderColor: lane.color }}
                        />
                        {lane.label}
                      </label>
                    ))}
                  </div>
                )}

                {/* Cytoscape with scroll */}
                <div ref={containerRef} className={styles.cytoscapeContainer} />

                {/* Legend - clickable to filter */}
                <div className={styles.legend}>
                  {SWIMLANES.slice(0, -1).map((lane) => (
                    <button
                      key={lane.id}
                      className={`${styles.legendItem} ${typeFilters[lane.id] === false ? styles.legendDisabled : ''}`}
                      onClick={() => setTypeFilters(prev => ({
                        ...prev,
                        [lane.id]: !prev[lane.id]
                      }))}
                      title={`Clique para ${typeFilters[lane.id] === false ? 'mostrar' : 'ocultar'} ${lane.label}`}
                    >
                      <span
                        className={styles.legendColor}
                        style={{ background: lane.bg, borderColor: lane.color }}
                      />
                      {lane.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Node Details Panel */}
              {selectedNode && (
                <div className={styles.nodeDetailsPanel}>
                  <div className={styles.nodeDetailsHeader}>
                    {getTypeIcon(selectedNode.type)}
                    <h4>{selectedNode.fullLabel || selectedNode.label}</h4>
                  </div>
                  <div className={styles.nodeDetailsContent}>
                    <div className={styles.detailRow}>
                      <span className={styles.detailLabel}>Tipo</span>
                      <Tag type={
                        selectedNode.type === 'Browser' ? 'blue' :
                        selectedNode.type === 'WebService' ? 'green' :
                        selectedNode.type === 'Mainframe' ? 'red' :
                        selectedNode.type?.includes('ADO') ? 'teal' : 'gray'
                      } size="sm">{selectedNode.type}</Tag>
                    </div>
                    {selectedNode.module && (
                      <div className={styles.detailRow}>
                        <span className={styles.detailLabel}>Módulo</span>
                        <span className={styles.detailValue}>{selectedNode.module}</span>
                      </div>
                    )}
                    {selectedNode.subProgram && (
                      <div className={styles.detailRow}>
                        <span className={styles.detailLabel}>SubPrograma</span>
                        <span className={styles.detailValue}>{selectedNode.subProgram}</span>
                      </div>
                    )}
                    {selectedNode.xmlFile && (
                      <div className={styles.detailRow}>
                        <span className={styles.detailLabel}>Arquivo</span>
                        <code className={styles.detailCode}>{selectedNode.xmlFile.split('/').pop()}</code>
                      </div>
                    )}
                    {selectedNode.webService?.url && (
                      <div className={styles.detailRow}>
                        <span className={styles.detailLabel}>URL</span>
                        <code className={styles.detailCode}>{selectedNode.webService.url}</code>
                      </div>
                    )}
                    {selectedNode.mainframe?.trancode && (
                      <div className={styles.detailRow}>
                        <span className={styles.detailLabel}>Trancode</span>
                        <code className={styles.detailCode}>{selectedNode.mainframe.trancode}</code>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </TabPanel>

          {/* Dynamic Angular Architecture Tab */}
          <TabPanel>
            <AngularArchitecture transactionData={transactionData} />
          </TabPanel>

          {/* Interactions Tab */}
          <TabPanel>
            <div className={styles.interactionsGrid}>
              {transactionData.flow?.interactions?.map((interaction, idx) => (
                <div key={idx} className={styles.interactionCard}>
                  <div className={styles.cardHeader} style={{ borderLeftColor: getSwimlane(interaction.type).color }}>
                    {getTypeIcon(interaction.type)}
                    <span className={styles.cardTitle}>{interaction.name}</span>
                    <Tag type={
                      interaction.type === 'Browser' ? 'blue' :
                      interaction.type === 'WebService' ? 'green' :
                      interaction.type === 'Mainframe' ? 'red' :
                      interaction.type?.includes('ADO') ? 'teal' : 'gray'
                    } size="sm">{interaction.type}</Tag>
                  </div>
                  <div className={styles.cardBody}>
                    <code className={styles.pathCode}>{interaction.path}</code>
                    {interaction.xmlFile && (
                      <div className={styles.cardMeta}>
                        <Document size={14} />
                        <span>{interaction.xmlFile.split('/').pop()}</span>
                      </div>
                    )}
                    {interaction.webService?.url && (
                      <div className={styles.cardMeta}>
                        <Api size={14} />
                        <span>{interaction.webService.url}</span>
                      </div>
                    )}
                    {interaction.mainframe?.trancode && (
                      <div className={styles.cardMeta}>
                        <Terminal size={14} />
                        <span>Trancode: {interaction.mainframe.trancode.trim()}</span>
                      </div>
                    )}
                    {interaction.navigations?.length > 0 && (
                      <div className={styles.cardNavigations}>
                        <strong>{interaction.navigations.length} navegações</strong>
                        {interaction.navigations.slice(0, 3).map((nav, i) => (
                          <div key={i} className={styles.navItem}>
                            <ChevronRight size={12} />
                            <span>{nav.target?.split('\\').pop() || 'final'}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </TabPanel>

          {/* Entry Points Tab */}
          <TabPanel>
            <div className={styles.entryPointsGrid}>
              {transactionData.flow?.entryPoints?.map((ep, idx) => (
                <div key={idx} className={styles.entryPointCard}>
                  <div className={styles.epHeader}>
                    <Tag type="purple" size="sm">#{ep.idMBkl}</Tag>
                    <span className={styles.epName}>{ep.nomeLogico}</span>
                  </div>
                  <div className={styles.epPath}>
                    {ep.menuPath?.join(' > ')}
                  </div>
                  <div className={styles.epMeta}>
                    {ep.moduloEmpPlus && <Tag type="blue" size="sm">{ep.moduloEmpPlus}</Tag>}
                    {ep.channels?.slice(0, 3).map((ch, i) => (
                      <Tag key={i} type="gray" size="sm">{ch}</Tag>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </TabPanel>
        </TabPanels>
      </Tabs>
    </div>
  );
};

export default TransactionViewer;
