import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { ContainedList, ContainedListItem, Search, Tag, Button } from '@carbon/react';
import {
  Folder,
  Document,
  ChevronRight,
  ChevronLeft,
  Store,
  Flow,
  ArrowRight,
  Search as SearchIcon,
  Menu,
  Upload,
  Add,
  TrashCan,
  Star,
  StarFilled
} from '@carbon/icons-react';
import UploadModal from '../UploadModal';
import styles from './MenuExplorer.module.scss';

/**
 * MenuExplorer Component
 * Navigation for browsing channels and selecting transactions
 * Loads data from extractions/index.json and channels/*.json
 */
const CUSTOM_TRANSACTIONS_KEY = 'universal-visualizer-custom-transactions';

const MenuExplorer = ({ onTransactionSelect, isCollapsed, onToggleCollapse }) => {
  const [globalIndex, setGlobalIndex] = useState(null);
  const [channels, setChannels] = useState([]);
  const [channelsData, setChannelsData] = useState({}); // Cache all loaded channel data
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedPaths, setExpandedPaths] = useState({});
  const [width, setWidth] = useState(320); // Default width in pixels
  const [isResizing, setIsResizing] = useState(false);
  const explorerRef = useRef(null);

  // Custom uploads state
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [customTransactions, setCustomTransactions] = useState([]);
  const [isCustomExpanded, setIsCustomExpanded] = useState(true);

  // Load custom transactions from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(CUSTOM_TRANSACTIONS_KEY);
      if (stored) {
        setCustomTransactions(JSON.parse(stored));
      }
    } catch (e) {
      console.warn('Failed to load custom transactions:', e);
    }
  }, []);

  // Save custom transactions to localStorage
  const saveCustomTransactions = useCallback((transactions) => {
    setCustomTransactions(transactions);
    try {
      localStorage.setItem(CUSTOM_TRANSACTIONS_KEY, JSON.stringify(transactions));
    } catch (e) {
      console.warn('Failed to save custom transactions:', e);
    }
  }, []);

  // Handle new transaction extracted
  const handleTransactionExtracted = useCallback((jsonData) => {
    const newTransaction = {
      id: `custom-${Date.now()}`,
      name: jsonData.menuItem?.nomeLogico || jsonData.metadata?.transactionId || 'Custom Transaction',
      trn: jsonData.menuItem?.trn?.full || '',
      extractedAt: new Date().toISOString(),
      interactionCount: jsonData.flow?.interactions?.length || 0,
      _rawJSON: jsonData
    };

    saveCustomTransactions([newTransaction, ...customTransactions]);
  }, [customTransactions, saveCustomTransactions]);

  // Delete custom transaction
  const handleDeleteCustomTransaction = useCallback((id, e) => {
    e.stopPropagation();
    saveCustomTransactions(customTransactions.filter(t => t.id !== id));
  }, [customTransactions, saveCustomTransactions]);

  // Select custom transaction
  const handleCustomTransactionClick = useCallback((transaction) => {
    onTransactionSelect({
      id: transaction.id,
      name: transaction.name,
      channel: '_custom',
      trn: transaction.trn,
      _rawJSON: transaction._rawJSON
    });
  }, [onTransactionSelect]);

  // Handle resize
  const handleMouseDown = useCallback((e) => {
    e.preventDefault();
    setIsResizing(true);
  }, []);

  const handleMouseMove = useCallback((e) => {
    if (!isResizing) return;
    const newWidth = e.clientX;
    if (newWidth >= 200 && newWidth <= 600) {
      setWidth(newWidth);
    }
  }, [isResizing]);

  const handleMouseUp = useCallback(() => {
    setIsResizing(false);
  }, []);

  useEffect(() => {
    if (isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isResizing, handleMouseMove, handleMouseUp]);

  // Load global index on mount
  useEffect(() => {
    loadGlobalIndex();
  }, []);

  // Load ALL channel data when user starts searching (to enable variant search)
  useEffect(() => {
    if (searchTerm && searchTerm.length >= 2 && channels.length > 0) {
      // Load all channels to enable variant search
      channels.forEach(channel => {
        if (!channelsData[channel.name]) {
          loadChannelData(channel);
        }
      });
    }
  }, [searchTerm, channels]);

  const loadGlobalIndex = async () => {
    try {
      setLoading(true);
      // Add cache-busting to ensure fresh data
      const response = await fetch(`/extractions/index.json?t=${Date.now()}`);
      if (response.ok) {
        const data = await response.json();
        setGlobalIndex(data);
        setChannels(data.channels || []);
      } else {
        console.warn('Global index not found');
        setChannels([]);
      }
    } catch (error) {
      console.error('Error loading global index:', error);
      setChannels([]);
    } finally {
      setLoading(false);
    }
  };

  // Load channel data when selected
  const loadChannelData = async (channel) => {
    // Check cache first
    if (channelsData[channel.name]) {
      return channelsData[channel.name];
    }

    try {
      const response = await fetch(`/extractions/${channel.indexFile}?t=${Date.now()}`);
      if (response.ok) {
        const data = await response.json();
        setChannelsData(prev => ({ ...prev, [channel.name]: data }));
        return data;
      } else {
        console.warn('Channel data not found:', channel.indexFile);
        return null;
      }
    } catch (error) {
      console.error('Error loading channel data:', error);
      return null;
    }
  };

  // Filter transactions from global index - supports multiple words (AND search)
  // Note: Global index only has basic info, variants are in channel JSONs
  const filteredTransactions = useMemo(() => {
    if (!globalIndex?.transactions || !searchTerm) return null;

    // Split search term into words and filter by all of them (AND logic)
    const terms = searchTerm.toLowerCase().split(/\s+/).filter(t => t.length > 0);
    if (terms.length === 0) return null;

    return globalIndex.transactions.filter(t => {
      const searchableText = [
        t.nomeLogico,
        t.idMBkl,
        t.moduloEmpPlus,
        t.trnPath,
        t.file // Global index uses 'file' not 'transactionFile'
      ].filter(Boolean).join(' ').toLowerCase();

      // All terms must match
      return terms.every(term => searchableText.includes(term));
    });
  }, [globalIndex, searchTerm]);

  // Get filtered channels with counts
  const filteredChannels = useMemo(() => {
    if (!searchTerm) {
      return channels.map(ch => ({ ...ch, filteredCount: null }));
    }

    // Count matching transactions per channel from global index
    const channelCounts = {};
    if (filteredTransactions) {
      filteredTransactions.forEach(t => {
        t.channels?.forEach(chName => {
          channelCounts[chName] = (channelCounts[chName] || 0) + 1;
        });
      });
    }

    // Also check loaded channel data for variants (for searching PM04, etc.)
    // Count each matching variant as a separate result
    const terms = searchTerm.toLowerCase().split(/\s+/).filter(t => t.length > 0);
    Object.entries(channelsData).forEach(([channelName, data]) => {
      if (!data?.menuTree) return;
      let count = 0;
      data.menuTree.forEach(section => {
        section.items?.forEach(item => {
          const baseSearchText = [
            item.nomeLogico,
            item.idMBkl,
            item.moduloEmpPlus
          ].filter(Boolean).join(' ').toLowerCase();

          const variants = item.transactionVariants || [];
          if (variants.length > 0) {
            // Count each matching variant
            variants.forEach(v => {
              const variantText = (baseSearchText + ' ' + v).toLowerCase();
              if (terms.every(term => variantText.includes(term))) {
                count++;
              }
            });
          } else if (item.transactionFile) {
            // No variants, check base item
            const fullText = (baseSearchText + ' ' + item.transactionFile).toLowerCase();
            if (terms.every(term => fullText.includes(term))) {
              count++;
            }
          }
        });
      });
      if (count > 0) {
        channelCounts[channelName] = Math.max(channelCounts[channelName] || 0, count);
      }
    });

    return channels
      .map(ch => ({
        ...ch,
        filteredCount: channelCounts[ch.name] || 0
      }))
      .filter(ch => ch.filteredCount > 0 || !searchTerm);
  }, [channels, searchTerm, filteredTransactions]);

  // Get total filtered count
  const totalFilteredCount = useMemo(() => {
    if (!filteredTransactions) return null;
    return filteredTransactions.length;
  }, [filteredTransactions]);

  const handleChannelClick = async (channel) => {
    if (selectedChannel?.name === channel.name) {
      // Toggle collapse
      setSelectedChannel(null);
    } else {
      setSelectedChannel(channel);
      await loadChannelData(channel);
    }
  };

  const handleTransactionClick = (item, channelName, menuPath) => {
    // Look up transaction in global index to get TRN info
    const globalTxn = globalIndex?.transactions?.find(t => t.idMBkl === item.idMBkl);

    // Always allow click - we'll show what data we have
    onTransactionSelect({
      ...item,
      channel: channelName,
      channelData: channelsData[channelName],
      menuPath: menuPath,
      trn: globalTxn?.trnPath ? globalTxn.trnPath.replace(/\//g, '\\') : null,
      channels: globalTxn?.channels || [channelName]
    });
  };

  const togglePath = (pathKey) => {
    setExpandedPaths(prev => ({
      ...prev,
      [pathKey]: !prev[pathKey]
    }));
  };

  // Filter menu tree by search term for selected channel - supports multi-word search
  // When variants match, expands to show each matching variant as separate item
  const getFilteredMenuTree = (channelName) => {
    const channelData = channelsData[channelName];
    if (!channelData?.menuTree) return [];
    if (!searchTerm) return channelData.menuTree;

    // Split search term into words (AND logic)
    const terms = searchTerm.toLowerCase().split(/\s+/).filter(t => t.length > 0);
    if (terms.length === 0) return channelData.menuTree;

    return channelData.menuTree
      .map(section => {
        const expandedItems = [];

        section.items.forEach(item => {
          const variants = item.transactionVariants || [];
          const baseSearchText = [
            item.nomeLogico,
            item.idMBkl,
            item.moduloEmpPlus
          ].filter(Boolean).join(' ').toLowerCase();

          // Check if base item matches (without variants)
          const baseMatches = terms.every(term => baseSearchText.includes(term));

          // Find ALL matching variants
          const matchingVariants = variants.filter(v => {
            const variantText = (baseSearchText + ' ' + v).toLowerCase();
            return terms.every(term => variantText.includes(term));
          });

          if (matchingVariants.length > 0) {
            // Sort matching variants to prioritize better matches
            // Extract destination code from filename and sort by relevance to search terms
            const sortedVariants = matchingVariants.sort((a, b) => {
              const getCode = (v) => {
                const match = v.match(/-([^-.]+)\.json$/);
                return match ? match[1].toLowerCase() : '';
              };
              const codeA = getCode(a);
              const codeB = getCode(b);

              // Prioritize variants where the code STARTS with any search term
              const aStartsWithTerm = terms.some(t => codeA.startsWith(t));
              const bStartsWithTerm = terms.some(t => codeB.startsWith(t));

              if (aStartsWithTerm && !bStartsWithTerm) return -1;
              if (!aStartsWithTerm && bStartsWithTerm) return 1;

              // Then sort alphabetically by code
              return codeA.localeCompare(codeB);
            });

            // Add one item per matching variant (sorted)
            sortedVariants.forEach(variant => {
              expandedItems.push({
                ...item,
                transactionFile: variant,
                originalFile: item.transactionFile,
                _variantKey: variant // Unique key for React
              });
            });
          } else if (baseMatches && item.transactionFile) {
            // No variants match but base item matches
            expandedItems.push(item);
          } else if (!variants.length && item.transactionFile) {
            // No variants at all, check if item itself matches
            const fullText = (baseSearchText + ' ' + (item.transactionFile || '')).toLowerCase();
            if (terms.every(term => fullText.includes(term))) {
              expandedItems.push(item);
            }
          }
        });

        return { ...section, items: expandedItems };
      })
      .filter(section => section.items.length > 0);
  };

  if (loading) {
    return (
      <div className={styles.explorer}>
        <div className={styles.header}>
          <h3>Menu Explorer</h3>
        </div>
        <div className={styles.loading}>Carregando menus...</div>
      </div>
    );
  }

  const displayChannels = searchTerm ? filteredChannels.filter(ch => ch.filteredCount > 0) : filteredChannels;

  return (
    <div
      ref={explorerRef}
      className={`${styles.explorer} ${isCollapsed ? styles.collapsed : ''} ${isResizing ? styles.resizing : ''}`}
      style={!isCollapsed ? { width: `${width}px`, minWidth: `${width}px` } : undefined}
    >
      {/* Collapsed View - Show Icons */}
      {isCollapsed && (
        <div className={styles.collapsedView}>
          <button
            className={styles.collapsedButton}
            onClick={onToggleCollapse}
            title="Expandir Menu"
          >
            <Menu size={20} />
          </button>
          <button
            className={styles.collapsedButton}
            onClick={() => { onToggleCollapse(); }}
            title="Buscar"
          >
            <SearchIcon size={20} />
          </button>
          <div className={styles.collapsedChannels}>
            {displayChannels.slice(0, 8).map((channel, idx) => (
              <button
                key={idx}
                className={`${styles.collapsedChannel} ${selectedChannel?.name === channel.name ? styles.active : ''}`}
                onClick={() => { onToggleCollapse(); handleChannelClick(channel); }}
                title={channel.name}
              >
                <Store size={16} />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Expanded View */}
      {!isCollapsed && (
        <>
          <div className={styles.header}>
            <div className={styles.headerContent}>
              <h3>Menu Explorer</h3>
              <p className={styles.subtitle}>
                {searchTerm && totalFilteredCount !== null
                  ? `${totalFilteredCount} resultados em ${displayChannels.length} canais`
                  : `${channels.length} canais · ${globalIndex?.metadata?.contextAwareFlows || channels.reduce((sum, ch) => sum + (ch.transactionCount || 0), 0)} transações`
                }
              </p>
            </div>
            <button
              className={styles.collapseButton}
              onClick={onToggleCollapse}
              title="Recolher"
            >
              <ChevronLeft size={20} />
            </button>
          </div>

          {/* Search */}
          <div className={styles.searchContainer}>
            <Search
              size="sm"
              placeholder="Buscar (ex: swift, OPE, PM04)..."
              labelText="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            {searchTerm && (
              <div className={styles.searchHint}>
                Expanda um canal para buscar variantes como PM04
              </div>
            )}
          </div>

          {/* Channels List */}
          <div className={styles.listContainer}>
            <ContainedList className={styles.column}>
              {/* _Custom Section */}
              <div className={styles.customSection}>
                <ContainedListItem
                  className={`${styles.row} ${styles.customRow} ${isCustomExpanded ? styles.expanded : ''}`}
                  renderIcon={StarFilled}
                  onClick={() => setIsCustomExpanded(!isCustomExpanded)}
                  action={
                    <span
                      role="button"
                      tabIndex={0}
                      className={styles.actionButton}
                      onClick={(e) => { e.stopPropagation(); setIsUploadModalOpen(true); }}
                      onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); setIsUploadModalOpen(true); }}}
                      title="Upload XMLs"
                    >
                      <Add size={16} />
                    </span>
                  }
                >
                  <span className={styles.listItemContent}>
                    <span className={styles.name}>_Custom</span>
                    <span className={styles.metadata}>
                      <Tag type="purple" size="sm">{customTransactions.length}</Tag>
                      <ChevronRight className={isCustomExpanded ? styles.chevronExpanded : ''} />
                    </span>
                  </span>
                </ContainedListItem>

                {isCustomExpanded && (
                  <div className={styles.customContent}>
                    {/* Upload Button */}
                    <div className={styles.uploadAction}>
                      <Button
                        kind="tertiary"
                        size="sm"
                        renderIcon={Upload}
                        onClick={() => setIsUploadModalOpen(true)}
                        className={styles.uploadButton}
                      >
                        Upload XMLs / JSON
                      </Button>
                    </div>

                    {/* Custom Transactions List */}
                    {customTransactions.length > 0 ? (
                      customTransactions.map((transaction) => (
                        <ContainedListItem
                          key={transaction.id}
                          className={`${styles.row} ${styles.itemRow} ${styles.clickable} ${styles.customItem}`}
                          renderIcon={Flow}
                          onClick={() => handleCustomTransactionClick(transaction)}
                          action={
                            <span
                              role="button"
                              tabIndex={0}
                              className={styles.actionButton}
                              onClick={(e) => handleDeleteCustomTransaction(transaction.id, e)}
                              onKeyDown={(e) => { if (e.key === 'Enter') handleDeleteCustomTransaction(transaction.id, e); }}
                              title="Remover"
                            >
                              <TrashCan size={16} />
                            </span>
                          }
                        >
                          <span className={styles.listItemContent}>
                            <span className={styles.itemName}>
                              {transaction.name}
                              <Tag type="teal" size="sm" className={styles.destTag}>
                                {transaction.interactionCount} int
                              </Tag>
                            </span>
                            <span className={styles.itemMeta}>
                              <ArrowRight size={16} />
                            </span>
                          </span>
                        </ContainedListItem>
                      ))
                    ) : (
                      <div className={styles.emptyCustom}>
                        <p>Nenhuma transação customizada</p>
                        <p className={styles.hint}>Use o botão acima para fazer upload</p>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Separator */}
              <div className={styles.sectionDivider}>
                <span>Canais</span>
              </div>

              {displayChannels.map((channel) => {
                const filteredMenuTree = getFilteredMenuTree(channel.name);
                const displayCount = channel.filteredCount !== null ? channel.filteredCount : (channel.transactionCount || channel.itemCount || 0);

                return (
                  <div key={channel.name}>
                    {/* Channel Row */}
                    <ContainedListItem
                      className={`${styles.row} ${styles.channelRow} ${selectedChannel?.name === channel.name ? styles.expanded : ''}`}
                      renderIcon={Store}
                      onClick={() => handleChannelClick(channel)}
                    >
                      <span className={styles.listItemContent}>
                        <span className={styles.name}>{channel.name}</span>
                        <span className={styles.metadata}>
                          <Tag type={channel.filteredCount !== null ? 'purple' : 'gray'} size="sm">
                            {displayCount}
                          </Tag>
                          <ChevronRight className={selectedChannel?.name === channel.name ? styles.chevronExpanded : ''} />
                        </span>
                      </span>
                    </ContainedListItem>

                    {/* Channel Content */}
                    {selectedChannel?.name === channel.name && channelsData[channel.name] && (
                      <div className={styles.expandedContent}>
                        {/* Menu Tree */}
                        {filteredMenuTree.map((section, sectionIdx) => {
                          const pathKey = `${channel.name}-${section.path.join(' > ')}`;
                          const isExpanded = expandedPaths[pathKey] || (searchTerm && filteredMenuTree.length <= 5);

                          return (
                            <div key={`section-${sectionIdx}`}>
                              {/* Path Header */}
                              <ContainedListItem
                                className={`${styles.row} ${styles.pathRow} ${isExpanded ? styles.expanded : ''}`}
                                renderIcon={Folder}
                                onClick={() => togglePath(pathKey)}
                              >
                                <span className={styles.listItemContent}>
                                  <span className={styles.pathName}>
                                    {section.path.length > 0 ? section.path[section.path.length - 1] : 'Root'}
                                  </span>
                                  <span className={styles.metadata}>
                                    <span className={styles.itemCount}>({section.items.length})</span>
                                    <ChevronRight className={isExpanded ? styles.chevronExpanded : ''} />
                                  </span>
                                </span>
                              </ContainedListItem>

                              {/* Items in Path */}
                              {isExpanded && section.items.map((item, itemIdx) => {
                                // Extract destination code from transaction file name
                                const getDestinationCode = (txFile) => {
                                  if (!txFile) return null;
                                  const match = txFile.match(/transactions\/[^/]+-([^.]+)\.json$/);
                                  return match ? match[1] : null;
                                };
                                const destCode = getDestinationCode(item.transactionFile);
                                // Use variant key if available for unique React key
                                const itemKey = item._variantKey || `${item.idMBkl}-${itemIdx}`;

                                return (
                                  <ContainedListItem
                                    key={`item-${sectionIdx}-${itemKey}`}
                                    className={`${styles.row} ${styles.itemRow} ${styles.clickable}`}
                                    renderIcon={item.transactionFile ? Flow : Document}
                                    onClick={() => handleTransactionClick(item, channel.name, section.path)}
                                  >
                                    <span className={styles.listItemContent}>
                                      <span className={styles.itemName}>
                                        {item.nomeLogico}
                                        {destCode && (
                                          <Tag type="purple" size="sm" className={styles.destTag}>{destCode}</Tag>
                                        )}
                                      </span>
                                      <span className={styles.itemMeta}>
                                        {item.moduloEmpPlus && (
                                          <Tag type="blue" size="sm">{item.moduloEmpPlus}</Tag>
                                        )}
                                        <ArrowRight size={16} />
                                      </span>
                                    </span>
                                  </ContainedListItem>
                                );
                              })}
                            </div>
                          );
                        })}

                        {filteredMenuTree.length === 0 && searchTerm && (
                          <div className={styles.noResults}>
                            Nenhuma transação encontrada para "{searchTerm}"
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}

              {displayChannels.length === 0 && searchTerm && (
                <div className={styles.noResults}>
                  Nenhum canal encontrado com transações para "{searchTerm}"
                </div>
              )}
            </ContainedList>
          </div>

          {/* Stats Footer */}
          <div className={styles.footer}>
            <div className={styles.stats}>
              {searchTerm && totalFilteredCount !== null ? (
                <div className={styles.stat}>
                  <span className={styles.statValue}>{totalFilteredCount}</span>
                  <span className={styles.statLabel}>Resultados</span>
                </div>
              ) : globalIndex?.metadata && (
                <div className={styles.stat}>
                  <span className={styles.statValue}>{globalIndex.metadata.contextAwareFlows || globalIndex.metadata.uniqueTrnDestinations || 0}</span>
                  <span className={styles.statLabel}>Fluxos únicos</span>
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {/* Resize Handle */}
      {!isCollapsed && (
        <div
          className={styles.resizeHandle}
          onMouseDown={handleMouseDown}
          title="Arrastar para redimensionar"
        />
      )}

      {/* Upload Modal */}
      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onTransactionExtracted={handleTransactionExtracted}
      />
    </div>
  );
};

export default MenuExplorer;
