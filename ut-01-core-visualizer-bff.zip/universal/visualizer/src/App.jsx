import MainLayout from './components/MainLayout/MainLayout';

/**
 * Main App Component
 * Menu-based transaction flow visualizer
 */
function App() {
  return <MainLayout />;
}

export default App;
