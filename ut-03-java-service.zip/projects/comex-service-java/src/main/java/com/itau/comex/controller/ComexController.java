package com.itau.comex.controller;

import com.itau.comex.domain.Company;
import com.itau.comex.domain.SwiftMessage;
import com.itau.comex.dto.CompanyListResponse;
import com.itau.comex.dto.EmpresaResponse;
import com.itau.comex.service.ComexService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * COMEX REST Controller
 *
 * Provides both:
 * - Angular-compatible endpoints (/api/comex/empresas)
 * - v1 API endpoints (/api/v1/comex/*)
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ComexController {

    private final ComexService comexService;

    // =========================================================================
    // ANGULAR COMPATIBILITY ENDPOINTS
    // These match the format expected by the Angular MFE
    // =========================================================================

    /**
     * GET /api/comex/empresas
     * Angular-compatible endpoint for listing companies
     * Returns RESPOSTA/DADOS/ListaEmpresas/Item format
     */
    @GetMapping("/api/comex/empresas")
    public ResponseEntity<EmpresaResponse> getEmpresasAngular(
            @RequestHeader(value = "x-cpf-operador", defaultValue = "12345678900") String cpfOperador,
            @RequestHeader(value = "x-cnpj-empresa", required = false) String cnpjEmpresa) {

        log.info("GET /api/comex/empresas - CPF: {}", cpfOperador);

        List<Company> companies = comexService.getCompanies(cpfOperador);

        List<EmpresaResponse.EmpresaItem> items = companies.stream()
                .map(c -> EmpresaResponse.EmpresaItem.builder()
                        .cnpj(c.getCnpj())
                        .nome(c.getName())
                        .build())
                .collect(Collectors.toList());

        return ResponseEntity.ok(EmpresaResponse.from(items));
    }

    /**
     * GET /api/comex/swift/messages
     * Angular-compatible endpoint for SWIFT messages
     */
    @GetMapping("/api/comex/swift/messages")
    public ResponseEntity<List<SwiftMessage>> getSwiftMessagesAngular(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String dateFrom,
            @RequestParam(required = false) String dateTo) {

        log.info("GET /api/comex/swift/messages - status: {}", status);

        List<SwiftMessage> messages = comexService.listSwiftMessages(status, dateFrom, dateTo);
        return ResponseEntity.ok(messages);
    }

    // =========================================================================
    // V1 API ENDPOINTS
    // RESTful API format
    // =========================================================================

    /**
     * GET /api/v1/comex/companies
     * List companies with COMEX access
     */
    @GetMapping("/api/v1/comex/companies")
    public ResponseEntity<CompanyListResponse> getCompanies(
            @RequestHeader(value = "x-cpf-operador", defaultValue = "12345678900") String cpfOperador) {

        log.info("GET /api/v1/comex/companies - CPF: {}", cpfOperador);

        List<Company> companies = comexService.getCompanies(cpfOperador);
        return ResponseEntity.ok(CompanyListResponse.from(companies));
    }

    /**
     * GET /api/v1/comex/companies/{cnpj}
     * Get company details
     */
    @GetMapping("/api/v1/comex/companies/{cnpj}")
    public ResponseEntity<Company> getCompanyDetails(@PathVariable String cnpj) {
        log.info("GET /api/v1/comex/companies/{}", cnpj);

        Company company = comexService.getCompanyDetails(cnpj);
        return ResponseEntity.ok(company);
    }

    /**
     * GET /api/v1/comex/swift/messages
     * List SWIFT messages
     */
    @GetMapping("/api/v1/comex/swift/messages")
    public ResponseEntity<List<SwiftMessage>> listSwiftMessages(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String dateFrom,
            @RequestParam(required = false) String dateTo) {

        log.info("GET /api/v1/comex/swift/messages - status: {}", status);

        List<SwiftMessage> messages = comexService.listSwiftMessages(status, dateFrom, dateTo);
        return ResponseEntity.ok(messages);
    }

    /**
     * GET /api/v1/comex/swift/messages/{uetr}
     * Get SWIFT message details
     */
    @GetMapping("/api/v1/comex/swift/messages/{uetr}")
    public ResponseEntity<SwiftMessage> getSwiftMessageDetails(@PathVariable String uetr) {
        log.info("GET /api/v1/comex/swift/messages/{}", uetr);

        SwiftMessage message = comexService.getSwiftMessageDetails(uetr);
        return ResponseEntity.ok(message);
    }

    // =========================================================================
    // HEALTH CHECK
    // =========================================================================

    /**
     * GET /health
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "healthy",
                "service", "comex-service-java",
                "adapter", "MOCK"
        ));
    }

    /**
     * GET /api/v1/comex/health
     * Health check endpoint (v1 API)
     */
    @GetMapping("/api/v1/comex/health")
    public ResponseEntity<Map<String, Object>> healthV1() {
        return health();
    }
}
