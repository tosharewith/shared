import { useEffect, useRef, useState, useMemo } from 'react';
import cytoscape from 'cytoscape';
import coseBilkent from 'cytoscape-cose-bilkent';
import fcose from 'cytoscape-fcose';
import { parseGraphML } from '../utils/graphmlParser';
import './DiagramViewer.css';

// Register Cytoscape extensions
cytoscape.use(coseBilkent);
cytoscape.use(fcose);

// SP1NBP-specific styles
const SP1NBP_STYLES = [
  {
    selector: 'node',
    style: {
      'background-color': (ele) => {
        const type = ele.data('nodeType') || ele.data('type') || 'Unknown';
        const colors = {
          'Dispatcher': '#e1f5ff',
          'WebService': '#a7f0ba',
          'Browser_Radio': '#d0e2ff',
          'Browser_Checkbox': '#a6c8ff',
          'Browser_Form': '#d0e2ff',
          'OperacaoFinalizacao': '#e0e0e0',
          'VisaoCliente': '#ffeed4',
          'External': '#e8daff',
          'Unknown': '#f4f4f4'
        };
        return colors[type] || '#f4f4f4';
      },
      'border-color': (ele) => {
        const type = ele.data('nodeType') || ele.data('type') || 'Unknown';
        const colors = {
          'Dispatcher': '#0f62fe',
          'WebService': '#24a148',
          'Browser_Radio': '#0f62fe',
          'Browser_Checkbox': '#0043ce',
          'Browser_Form': '#0f62fe',
          'OperacaoFinalizacao': '#525252',
          'VisaoCliente': '#ec7000',
          'External': '#8a3ffc',
          'Unknown': '#8d8d8d'
        };
        return colors[type] || '#8d8d8d';
      },
      'border-width': (ele) => {
        const complexity = ele.data('complexity') || 'Medium';
        const widths = { 'VeryHigh': 4, 'High': 3, 'Medium': 2, 'Low': 2 };
        return widths[complexity] || 2;
      },
      'shape': (ele) => {
        const type = ele.data('nodeType') || ele.data('type') || 'Unknown';
        const shapes = {
          'Dispatcher': 'diamond',
          'WebService': 'hexagon',
          'Browser_Radio': 'roundrectangle',
          'Browser_Checkbox': 'roundrectangle',
          'Browser_Form': 'roundrectangle',
          'OperacaoFinalizacao': 'rectangle',
          'VisaoCliente': 'ellipse',
          'External': 'octagon',
          'Unknown': 'ellipse'
        };
        return shapes[type] || 'ellipse';
      },
      'width': (ele) => {
        const lines = parseInt(ele.data('lines') || 100);
        if (lines > 400) return 60;
        if (lines > 200) return 45;
        if (lines > 50) return 32;
        return 24;
      },
      'height': (ele) => {
        const lines = parseInt(ele.data('lines') || 100);
        if (lines > 400) return 60;
        if (lines > 200) return 45;
        if (lines > 50) return 32;
        return 24;
      },
      'label': 'data(label)',
      'text-valign': 'center',
      'text-halign': 'center',
      'font-size': 11,
      'font-family': 'IBM Plex Sans, sans-serif',
      'text-wrap': 'wrap',
      'text-max-width': '90px',
      'overlay-padding': '6px',
      'z-index': 10
    }
  },
  {
    selector: 'edge',
    style: {
      'width': 2,
      'line-color': '#78a9ff',
      'target-arrow-color': '#78a9ff',
      'target-arrow-shape': 'triangle',
      'curve-style': 'bezier',
      'label': 'data(label)',
      'font-size': 9,
      'text-rotation': 'autorotate',
      'text-margin-y': -8
    }
  },
  {
    selector: 'node:selected',
    style: {
      'border-width': 5,
      'border-color': '#ec7000',
      'overlay-color': '#ec7000',
      'overlay-opacity': 0.25
    }
  },
  {
    selector: 'node.highlighted',
    style: {
      'border-width': 4,
      'border-color': '#ec7000',
      'z-index': 999
    }
  },
  {
    selector: 'node.dimmed',
    style: { 'opacity': 0.3 }
  },
  {
    selector: 'edge.dimmed',
    style: { 'opacity': 0.15 }
  }
];

const DiagramViewer = ({ graphmlData, fileName }) => {
  const containerRef = useRef(null);
  const cyRef = useRef(null);

  const [selectedNode, setSelectedNode] = useState(null);
  const [layout, setLayout] = useState('fcose');
  const [searchTerm, setSearchTerm] = useState('');
  const [stats, setStats] = useState({ nodes: 0, edges: 0 });

  // Parse GraphML
  const elements = useMemo(() => {
    if (!graphmlData) return { nodes: [], edges: [] };
    try {
      const parsed = parseGraphML(graphmlData);
      return parsed;
    } catch (err) {
      console.error('Parse error:', err);
      return { nodes: [], edges: [] };
    }
  }, [graphmlData]);

  // Update stats
  useEffect(() => {
    if (elements) {
      setStats({
        nodes: elements.nodes?.length || 0,
        edges: elements.edges?.length || 0
      });
    }
  }, [elements]);

  // Initialize Cytoscape
  useEffect(() => {
    if (!containerRef.current || !elements || elements.nodes.length === 0) return;

    const cy = cytoscape({
      container: containerRef.current,
      elements: elements,
      style: SP1NBP_STYLES,
      layout: {
        name: 'fcose',
        animate: true,
        animationDuration: 1000,
        idealEdgeLength: 70,
        nodeRepulsion: 5000,
        gravity: 0.3,
        numIter: 2500
      },
      wheelSensitivity: 0.2,
      minZoom: 0.1,
      maxZoom: 3
    });

    cyRef.current = cy;

    // Click on node
    cy.on('tap', 'node', (evt) => {
      const node = evt.target;
      setSelectedNode(node.data());
    });

    // Click on background
    cy.on('tap', (evt) => {
      if (evt.target === cy) {
        setSelectedNode(null);
      }
    });

    return () => {
      if (cy) cy.destroy();
    };
  }, [elements]);

  // Search functionality
  useEffect(() => {
    if (!cyRef.current) return;

    const cy = cyRef.current;

    if (!searchTerm) {
      cy.elements().removeClass('highlighted dimmed');
      return;
    }

    const term = searchTerm.toLowerCase();

    cy.nodes().forEach(node => {
      const label = (node.data('label') || '').toLowerCase();
      const fileName = (node.data('fileName') || '').toLowerCase();
      const type = (node.data('nodeType') || node.data('type') || '').toLowerCase();

      const matches = label.includes(term) || fileName.includes(term) || type.includes(term);

      if (matches) {
        node.removeClass('dimmed').addClass('highlighted');
      } else {
        node.removeClass('highlighted').addClass('dimmed');
      }
    });

    cy.edges().forEach(edge => {
      const source = edge.source();
      const target = edge.target();
      if (source.hasClass('dimmed') || target.hasClass('dimmed')) {
        edge.addClass('dimmed');
      } else {
        edge.removeClass('dimmed');
      }
    });
  }, [searchTerm]);

  const applyLayout = (layoutName) => {
    if (!cyRef.current) return;

    const layouts = {
      fcose: {
        name: 'fcose',
        animate: true,
        animationDuration: 1200,
        idealEdgeLength: 70,
        nodeRepulsion: 5000,
        gravity: 0.3
      },
      'cose-bilkent': {
        name: 'cose-bilkent',
        animate: true,
        animationDuration: 1200,
        idealEdgeLength: 90,
        nodeRepulsion: 5500,
        gravity: 0.25
      },
      circle: {
        name: 'circle',
        animate: true,
        radius: 350,
        startAngle: 0
      },
      grid: {
        name: 'grid',
        animate: true,
        rows: Math.ceil(Math.sqrt(elements.nodes.length)),
        avoidOverlap: true,
        padding: 30
      },
      concentric: {
        name: 'concentric',
        animate: true,
        minNodeSpacing: 50,
        concentric: (node) => node.degree(),
        levelWidth: () => 2
      }
    };

    cyRef.current.layout(layouts[layoutName] || layouts.fcose).run();
    setLayout(layoutName);
  };

  const fitView = () => {
    if (cyRef.current) {
      cyRef.current.fit(null, 60);
    }
  };

  const exportPNG = () => {
    if (!cyRef.current) return;
    const png = cyRef.current.png({
      output: 'blob',
      bg: '#ffffff',
      full: true,
      scale: 2.5
    });
    const url = URL.createObjectURL(png);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'sp1nbp_navigation_graph.png';
    link.click();
    URL.revokeObjectURL(url);
  };

  const exportJSON = () => {
    if (!cyRef.current) return;
    const json = JSON.stringify(cyRef.current.json().elements, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'sp1nbp_graph_data.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="diagram-viewer-container">
      {/* Header */}
      <div className="viewer-header">
        <div className="header-left">
          <h1>📊 SP1NBP Navigation Map</h1>
          <span className="file-name">{fileName}</span>
        </div>
        <div className="header-stats">
          <span className="stat-badge">
            <strong>{stats.nodes}</strong> Components
          </span>
          <span className="stat-badge">
            <strong>{stats.edges}</strong> Connections
          </span>
        </div>
      </div>

      {/* Toolbar */}
      <div className="viewer-toolbar">
        <div className="toolbar-section">
          <label>Search:</label>
          <input
            type="text"
            placeholder="Component name, file, or type..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
          {searchTerm && (
            <button onClick={() => setSearchTerm('')} className="clear-btn">✕</button>
          )}
        </div>

        <div className="toolbar-section">
          <label>Layout:</label>
          <select value={layout} onChange={(e) => applyLayout(e.target.value)} className="layout-select">
            <option value="fcose">Force-Directed</option>
            <option value="cose-bilkent">Hierarchical</option>
            <option value="circle">Circular</option>
            <option value="concentric">Concentric</option>
            <option value="grid">Grid</option>
          </select>
        </div>

        <div className="toolbar-section">
          <button onClick={fitView} className="toolbar-btn">
            🎯 Fit View
          </button>
          <button onClick={exportPNG} className="toolbar-btn">
            📷 Export PNG
          </button>
          <button onClick={exportJSON} className="toolbar-btn">
            💾 Export JSON
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="viewer-content">
        <div ref={containerRef} className="cytoscape-canvas" />

        {/* Details Panel */}
        {selectedNode && (
          <div className="details-panel">
            <div className="panel-header">
              <h3>{selectedNode.label || selectedNode.id}</h3>
              <button onClick={() => setSelectedNode(null)} className="close-btn">✕</button>
            </div>
            <div className="panel-content">
              <div className="detail-row">
                <span className="detail-label">Type:</span>
                <span className="detail-value type-badge" style={{
                  background: SP1NBP_STYLES[0].style['background-color']({ data: () => selectedNode.nodeType || selectedNode.type }),
                  color: '#161616',
                  padding: '2px 8px',
                  borderRadius: '4px',
                  fontSize: '12px',
                  fontWeight: '600'
                }}>
                  {selectedNode.nodeType || selectedNode.type || 'Unknown'}
                </span>
              </div>
              <div className="detail-row">
                <span className="detail-label">File:</span>
                <span className="detail-value">{selectedNode.fileName || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Lines:</span>
                <span className="detail-value">{selectedNode.lines || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Complexity:</span>
                <span className="detail-value complexity-badge" data-complexity={selectedNode.complexity}>
                  {selectedNode.complexity || 'N/A'}
                </span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Has UI:</span>
                <span className="detail-value">{selectedNode.hasUI === true || selectedNode.hasUI === 'true' ? '✅ Yes' : '❌ No'}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Has JavaScript:</span>
                <span className="detail-value">{selectedNode.hasJavaScript === true || selectedNode.hasJavaScript === 'true' ? '✅ Yes' : '❌ No'}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Has WebService:</span>
                <span className="detail-value">{selectedNode.hasWebService === true || selectedNode.hasWebService === 'true' ? '✅ Yes' : '❌ No'}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Has Validation:</span>
                <span className="detail-value">{selectedNode.hasValidation === true || selectedNode.hasValidation === 'true' ? '✅ Yes' : '❌ No'}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="legend-panel">
        <h4>Component Types</h4>
        <div className="legend-items">
          <div className="legend-item"><span className="legend-color" style={{background: '#e1f5ff', border: '2px solid #0f62fe'}}></span> Dispatcher</div>
          <div className="legend-item"><span className="legend-color" style={{background: '#a7f0ba', border: '2px solid #24a148'}}></span> WebService</div>
          <div className="legend-item"><span className="legend-color" style={{background: '#d0e2ff', border: '2px solid #0f62fe'}}></span> Browser</div>
          <div className="legend-item"><span className="legend-color" style={{background: '#e0e0e0', border: '2px solid #525252'}}></span> OperacaoFinalizacao</div>
          <div className="legend-item"><span className="legend-color" style={{background: '#ffeed4', border: '2px solid #ec7000'}}></span> VisaoCliente</div>
        </div>
      </div>
    </div>
  );
};

export default DiagramViewer;
