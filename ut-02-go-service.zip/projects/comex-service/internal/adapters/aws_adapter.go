// Package adapters - AWS Adapter (Target State)
//
// This adapter connects to AWS services (Lambda, RDS, etc) for the
// modernized COMEX backend. This is the target state after migration
// from the legacy Oracle systems.
//
// Currently a stub - to be implemented when AWS infrastructure is ready.
package adapters

import (
	"context"
	"fmt"

	"comex-service/internal/domain"
)

// AWSAdapter implements COMEXAdapter for AWS services
type AWSAdapter struct {
	config AWSConfig
}

// NewAWSAdapter creates a new AWS adapter
func NewAWSAdapter(config AWSConfig) *AWSAdapter {
	return &AWSAdapter{config: config}
}

// =============================================================================
// COMPANIES
// =============================================================================

func (a *AWSAdapter) ListCompanies(ctx context.Context, userCPF string) ([]domain.Company, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: ListCompanies")
}

func (a *AWSAdapter) GetCompanyDetails(ctx context.Context, cnpj string) (*domain.Company, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: GetCompanyDetails")
}

// =============================================================================
// BILLING OPERATIONS (BAL1)
// =============================================================================

func (a *AWSAdapter) QueryBillingOperations(ctx context.Context, query domain.BillingQuery) (*domain.BillingQueryResponse, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: QueryBillingOperations")
}

func (a *AWSAdapter) GetBillingOperationDetails(ctx context.Context, id string) (*domain.BillingOperation, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: GetBillingOperationDetails")
}

// =============================================================================
// PAYMENT ORDERS (BAL3)
// =============================================================================

func (a *AWSAdapter) QueryPaymentOrders(ctx context.Context, query domain.PaymentOrderQuery) (*domain.PaymentOrdersResponse, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: QueryPaymentOrders")
}

func (a *AWSAdapter) GetPaymentOrderDetails(ctx context.Context, id string) (*domain.PaymentOrder, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: GetPaymentOrderDetails")
}

func (a *AWSAdapter) GetPaymentOrderStatus(ctx context.Context, id string) (string, error) {
	return "", fmt.Errorf("AWS adapter not implemented: GetPaymentOrderStatus")
}

// =============================================================================
// LETTERS OF CREDIT (BAL7)
// =============================================================================

func (a *AWSAdapter) QueryLettersOfCredit(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: QueryLettersOfCredit")
}

func (a *AWSAdapter) GetLetterOfCreditDetails(ctx context.Context, id string) (*domain.LetterOfCredit, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: GetLetterOfCreditDetails")
}

func (a *AWSAdapter) QueryReceivedLetters(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: QueryReceivedLetters")
}

// =============================================================================
// FX QUOTATIONS (BAEI)
// =============================================================================

func (a *AWSAdapter) QueryFXQuotations(ctx context.Context, query domain.FXQuery) (*domain.FXQueryResponse, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: QueryFXQuotations")
}

func (a *AWSAdapter) GetQuotationDetails(ctx context.Context, id string) (*domain.FXQuotation, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: GetQuotationDetails")
}

func (a *AWSAdapter) GetExchangeRates(ctx context.Context, currencies []string) ([]domain.ExchangeRate, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: GetExchangeRates")
}

func (a *AWSAdapter) SimulateExchange(ctx context.Context, from, to string, amount float64) (*domain.ExchangeSimulation, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: SimulateExchange")
}

// =============================================================================
// SWIFT
// =============================================================================

func (a *AWSAdapter) ListSWIFTMessages(ctx context.Context, status, dateFrom, dateTo string) ([]domain.SWIFTMessage, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: ListSWIFTMessages")
}

func (a *AWSAdapter) GetSWIFTMessageDetails(ctx context.Context, uetr string) (*domain.SWIFTMessage, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: GetSWIFTMessageDetails")
}

func (a *AWSAdapter) SendSWIFTMessage(ctx context.Context, req domain.SWIFTMessageRequest) (*domain.SWIFTMessageResponse, error) {
	return nil, fmt.Errorf("AWS adapter not implemented: SendSWIFTMessage")
}

// =============================================================================
// HEALTH
// =============================================================================

func (a *AWSAdapter) Ping(ctx context.Context) error {
	return fmt.Errorf("AWS adapter not implemented: Ping")
}
