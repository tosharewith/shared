import { useState, useEffect, useCallback } from 'react';
import { TextInput, Tag, Button, InlineNotification } from '@carbon/react';
import { Information, Checkmark, Close, Play } from '@carbon/icons-react';
import { parseTRN } from '../../utils/extractionEngine';
import styles from './TRNInput.module.scss';

/**
 * TRNInput Component
 * Input and parser for TRN (Transaction Reference Number) strings
 * Format: MODULE\SUBPROGRAM\INTERACTION@PARAM0@PARAM1@...
 */
const TRNInput = ({ onTRNParsed, onRunExtraction, disabled = false }) => {
  const [trnValue, setTrnValue] = useState('');
  const [parsedTRN, setParsedTRN] = useState(null);
  const [error, setError] = useState(null);

  // Parse TRN on value change
  useEffect(() => {
    if (!trnValue.trim()) {
      setParsedTRN(null);
      setError(null);
      return;
    }

    const parsed = parseTRN(trnValue);

    if (!parsed || !parsed.module || !parsed.subProgram || !parsed.interaction) {
      setError('Formato inválido. Use: MODULE\\SUBPROGRAM\\INTERACTION@PARAM...');
      setParsedTRN(null);
    } else {
      setError(null);
      setParsedTRN(parsed);
      if (onTRNParsed) {
        onTRNParsed(parsed);
      }
    }
  }, [trnValue, onTRNParsed]);

  const handleChange = useCallback((e) => {
    setTrnValue(e.target.value);
  }, []);

  const handleRunExtraction = useCallback(() => {
    if (parsedTRN && onRunExtraction) {
      onRunExtraction(parsedTRN);
    }
  }, [parsedTRN, onRunExtraction]);

  const handleClear = useCallback(() => {
    setTrnValue('');
    setParsedTRN(null);
    setError(null);
  }, []);

  // Example TRNs for quick selection
  const exampleTRNs = [
    { label: 'PM04 - Swift OPE', value: 'PM01\\SP1NB\\ConsultaCNPJs@PM04@Cópias dos Swift OPE' },
    { label: 'AJ1O - Débito Auto', value: 'AJ1O\\SP2NB\\Tela_AuxToken@C@Cancelamento' },
    { label: 'IL47 - Transferência', value: 'IL47\\SPNB\\Tela_Transferencia@CCCC' }
  ];

  return (
    <div className={styles.trnInputContainer}>
      <div className={styles.inputHeader}>
        <h4>TRN da Transação</h4>
        <div className={styles.helpText}>
          <Information size={16} />
          <span>Formato: MODULE\SUBPROGRAM\INTERACTION@PARAM0@PARAM1...</span>
        </div>
      </div>

      <div className={styles.inputRow}>
        <TextInput
          id="trn-input"
          labelText=""
          placeholder="Ex: PM01\SP1NB\ConsultaCNPJs@PM04@Cópias dos Swift OPE"
          value={trnValue}
          onChange={handleChange}
          invalid={!!error}
          invalidText={error}
          disabled={disabled}
          size="lg"
          className={styles.trnInput}
        />

        {trnValue && (
          <Button
            kind="ghost"
            size="sm"
            hasIconOnly
            renderIcon={Close}
            iconDescription="Limpar"
            onClick={handleClear}
            className={styles.clearButton}
          />
        )}
      </div>

      {/* Example TRNs */}
      <div className={styles.examples}>
        <span className={styles.examplesLabel}>Exemplos:</span>
        {exampleTRNs.map((ex, i) => (
          <Tag
            key={i}
            type="cool-gray"
            size="sm"
            onClick={() => setTrnValue(ex.value)}
            className={styles.exampleTag}
          >
            {ex.label}
          </Tag>
        ))}
      </div>

      {/* Parsed Preview */}
      {parsedTRN && (
        <div className={styles.parsedPreview}>
          <div className={styles.previewHeader}>
            <Checkmark size={16} className={styles.validIcon} />
            <span>TRN Válido</span>
          </div>

          <div className={styles.previewGrid}>
            <div className={styles.previewItem}>
              <span className={styles.previewLabel}>Módulo</span>
              <code>{parsedTRN.module}</code>
            </div>
            <div className={styles.previewItem}>
              <span className={styles.previewLabel}>SubPrograma</span>
              <code>{parsedTRN.subProgram}</code>
            </div>
            <div className={styles.previewItem}>
              <span className={styles.previewLabel}>Interação</span>
              <code>{parsedTRN.interaction}</code>
            </div>
            {parsedTRN.destination && (
              <div className={styles.previewItem}>
                <span className={styles.previewLabel}>Destino</span>
                <Tag type="purple" size="sm">{parsedTRN.destination}</Tag>
              </div>
            )}
            {parsedTRN.title && (
              <div className={`${styles.previewItem} ${styles.previewItemFull}`}>
                <span className={styles.previewLabel}>Título</span>
                <span className={styles.previewTitle}>{parsedTRN.title}</span>
              </div>
            )}
            {parsedTRN.params.length > 0 && (
              <div className={`${styles.previewItem} ${styles.previewItemFull}`}>
                <span className={styles.previewLabel}>Parâmetros</span>
                <div className={styles.paramsList}>
                  {parsedTRN.params.map((param, i) => (
                    <Tag key={i} type="gray" size="sm">@{i}: {param}</Tag>
                  ))}
                </div>
              </div>
            )}
          </div>

          {onRunExtraction && (
            <div className={styles.previewActions}>
              <Button
                kind="primary"
                size="md"
                renderIcon={Play}
                onClick={handleRunExtraction}
                disabled={disabled}
              >
                Executar Extração
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Format Help */}
      {!parsedTRN && !error && (
        <InlineNotification
          kind="info"
          lowContrast
          hideCloseButton
          title="Dica"
          subtitle="O TRN define o ponto de entrada e contexto da transação. Os parâmetros (@) definem variáveis de sessão que controlam o fluxo."
          className={styles.helpNotification}
        />
      )}
    </div>
  );
};

export default TRNInput;
