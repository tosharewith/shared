/**
 * Authentication Middleware
 *
 * Handles JWT token validation and user context extraction.
 * This middleware runs in the BFF layer to protect all routes.
 */

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

// Extend Express Request to include user info
declare global {
  namespace Express {
    interface Request {
      user?: {
        cpf: string;
        name: string;
        email: string;
        permissions: string[];
      };
    }
  }
}

const JWT_SECRET = process.env.JWT_SECRET || 'development-secret-key';

export function authMiddleware(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    res.status(401).json({
      code: 'AUTH_001',
      message: 'Authorization header is required',
    });
    return;
  }

  const [scheme, token] = authHeader.split(' ');

  if (scheme !== 'Bearer' || !token) {
    res.status(401).json({
      code: 'AUTH_002',
      message: 'Invalid authorization format. Use: Bearer <token>',
    });
    return;
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as {
      cpf: string;
      name: string;
      email: string;
      permissions: string[];
    };

    req.user = decoded;
    next();
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      res.status(401).json({
        code: 'AUTH_003',
        message: 'Token expired',
      });
      return;
    }

    res.status(401).json({
      code: 'AUTH_004',
      message: 'Invalid token',
    });
  }
}

/**
 * Permission check middleware factory
 */
export function requirePermission(...permissions: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({
        code: 'AUTH_005',
        message: 'User not authenticated',
      });
      return;
    }

    const hasPermission = permissions.some((p) =>
      req.user!.permissions.includes(p)
    );

    if (!hasPermission) {
      res.status(403).json({
        code: 'AUTH_006',
        message: `Required permissions: ${permissions.join(', ')}`,
      });
      return;
    }

    next();
  };
}
