/**
 * COMEX Service Proxy
 *
 * This proxy forwards requests to the Go COMEX business service.
 * The BFF acts as a bridge, handling:
 * - Authentication/authorization
 * - Request aggregation
 * - Response transformation for frontend
 * - Caching (if needed)
 */

import axios, { AxiosInstance, AxiosError } from 'axios';
import {
  CompanyListResponse,
  Company,
  BillingQuery,
  BillingQueryResponse,
  BillingOperation,
  PaymentOrderQuery,
  PaymentOrdersResponse,
  PaymentOrder,
  LCQuery,
  LCQueryResponse,
  LetterOfCredit,
  FXQuery,
  FXQueryResponse,
  FXQuotation,
  ExchangeRate,
  ExchangeSimulationRequest,
  ExchangeSimulation,
  SWIFTMessage,
  SWIFTMessageRequest,
  SWIFTMessageResponse,
  HealthStatus,
} from '../types/comex.types';

const COMEX_SERVICE_URL = process.env.COMEX_SERVICE_URL || 'http://localhost:8081';

class ComexServiceProxy {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: `${COMEX_SERVICE_URL}/api/v1/comex`,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => response,
      (error: AxiosError) => {
        console.error('COMEX Service Error:', error.message);
        throw error;
      }
    );
  }

  // ===========================================================================
  // COMPANIES
  // ===========================================================================

  async getCompanies(userCPF: string): Promise<CompanyListResponse> {
    const response = await this.client.get<CompanyListResponse>('/companies', {
      headers: { 'X-User-CPF': userCPF },
    });
    return response.data;
  }

  async getCompanyDetails(cnpj: string): Promise<Company> {
    const response = await this.client.get<Company>(`/companies/${cnpj}`);
    return response.data;
  }

  // ===========================================================================
  // BILLING OPERATIONS (BAL1)
  // ===========================================================================

  async queryBillingOperations(query: BillingQuery): Promise<BillingQueryResponse> {
    const response = await this.client.post<BillingQueryResponse>(
      '/export/billing/query',
      query
    );
    return response.data;
  }

  async getBillingOperationDetails(id: string): Promise<BillingOperation> {
    const response = await this.client.get<BillingOperation>(`/export/billing/${id}`);
    return response.data;
  }

  // ===========================================================================
  // PAYMENT ORDERS (BAL3)
  // ===========================================================================

  async queryPaymentOrders(query: PaymentOrderQuery): Promise<PaymentOrdersResponse> {
    const response = await this.client.post<PaymentOrdersResponse>(
      '/payment-orders/query',
      query
    );
    return response.data;
  }

  async getPaymentOrderDetails(id: string): Promise<PaymentOrder> {
    const response = await this.client.get<PaymentOrder>(`/payment-orders/${id}`);
    return response.data;
  }

  async getPaymentOrderStatus(id: string): Promise<{ status: string }> {
    const response = await this.client.get<{ status: string }>(
      `/payment-orders/${id}/status`
    );
    return response.data;
  }

  // ===========================================================================
  // LETTERS OF CREDIT (BAL7)
  // ===========================================================================

  async queryLettersOfCredit(query: LCQuery): Promise<LCQueryResponse> {
    const response = await this.client.post<LCQueryResponse>(
      '/export/letters-of-credit/query',
      query
    );
    return response.data;
  }

  async getLetterOfCreditDetails(id: string): Promise<LetterOfCredit> {
    const response = await this.client.get<LetterOfCredit>(
      `/export/letters-of-credit/${id}`
    );
    return response.data;
  }

  async queryReceivedLetters(query: LCQuery): Promise<LCQueryResponse> {
    const response = await this.client.post<LCQueryResponse>(
      '/export/received-letters/query',
      query
    );
    return response.data;
  }

  // ===========================================================================
  // FX QUOTATIONS (BAEI)
  // ===========================================================================

  async queryFXQuotations(query: FXQuery): Promise<FXQueryResponse> {
    const response = await this.client.post<FXQueryResponse>(
      '/fx/quotations/query',
      query
    );
    return response.data;
  }

  async getQuotationDetails(id: string): Promise<FXQuotation> {
    const response = await this.client.get<FXQuotation>(`/fx/quotations/${id}`);
    return response.data;
  }

  async getExchangeRates(currencies?: string[]): Promise<ExchangeRate[]> {
    const params = currencies ? { currencies: currencies.join(',') } : {};
    const response = await this.client.get<ExchangeRate[]>('/fx/rates', { params });
    return response.data;
  }

  async simulateExchange(request: ExchangeSimulationRequest): Promise<ExchangeSimulation> {
    const response = await this.client.post<ExchangeSimulation>('/fx/simulate', request);
    return response.data;
  }

  // ===========================================================================
  // SWIFT
  // ===========================================================================

  async listSWIFTMessages(
    status?: string,
    dateFrom?: string,
    dateTo?: string
  ): Promise<SWIFTMessage[]> {
    const params = { status, dateFrom, dateTo };
    const response = await this.client.get<SWIFTMessage[]>('/swift/messages', { params });
    return response.data;
  }

  async getSWIFTMessageDetails(uetr: string): Promise<SWIFTMessage> {
    const response = await this.client.get<SWIFTMessage>(`/swift/messages/${uetr}`);
    return response.data;
  }

  async sendSWIFTMessage(request: SWIFTMessageRequest): Promise<SWIFTMessageResponse> {
    const response = await this.client.post<SWIFTMessageResponse>(
      '/swift/messages',
      request
    );
    return response.data;
  }

  // ===========================================================================
  // HEALTH
  // ===========================================================================

  async healthCheck(): Promise<HealthStatus> {
    const response = await this.client.get<HealthStatus>('/health');
    return response.data;
  }
}

// Singleton instance
export const comexService = new ComexServiceProxy();
