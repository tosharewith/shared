#!/usr/bin/env node
/**
 * Bundle project templates into JSON manifests for the visualizer.
 * This allows the browser to access template files at runtime.
 *
 * Run: node scripts/bundle-template.cjs
 * Output: public/templates/*.json
 */

const fs = require('fs');
const path = require('path');

// Template configurations
const TEMPLATES = [
  {
    name: 'mfe-base',
    srcPath: '../../../projects/angular/mfe-base',
    outputFile: 'mfe-base-bundle.json',
    description: 'Angular MFE Base Template with IDS components',
    extensions: ['.ts', '.js', '.json', '.html', '.scss', '.css', '.md'],
    exclude: ['node_modules', '.angular', '.git', 'dist', 'coverage', '.DS_Store', 'package-lock.json']
  },
  {
    name: 'go-service',
    srcPath: '../../../projects/comex-service',
    outputFile: 'go-service-bundle.json',
    description: 'Go Backend Service with adapters (Oracle, MQ, REST)',
    extensions: ['.go', '.json', '.yaml', '.yml', '.md', '.mod', '.sum'],
    exclude: ['vendor', '.git', 'bin', '.DS_Store']
  },
  {
    name: 'java-service',
    srcPath: '../../../projects/comex-service-java',
    outputFile: 'java-service-bundle.json',
    description: 'Java Spring Boot Backend Service',
    extensions: ['.java', '.xml', '.json', '.yaml', '.yml', '.properties', '.md'],
    exclude: ['target', '.git', '.idea', '.DS_Store', '.mvn']
  }
];

const OUTPUT_DIR = path.resolve(__dirname, '../public/templates');

/**
 * Check if a path should be excluded
 */
function shouldExclude(filePath, excludePatterns) {
  return excludePatterns.some(pattern => filePath.includes(pattern));
}

/**
 * Check if a file should be included based on extension
 */
function shouldInclude(filePath, extensions) {
  const ext = path.extname(filePath).toLowerCase();
  return extensions.includes(ext);
}

/**
 * Recursively read all files in a directory
 */
function readDirectory(dirPath, basePath, extensions, exclude) {
  const files = {};

  if (!fs.existsSync(dirPath)) {
    return files;
  }

  const entries = fs.readdirSync(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    const relativePath = path.join(basePath, entry.name);

    if (shouldExclude(fullPath, exclude)) {
      continue;
    }

    if (entry.isDirectory()) {
      const subFiles = readDirectory(fullPath, relativePath, extensions, exclude);
      Object.assign(files, subFiles);
    } else if (entry.isFile() && shouldInclude(fullPath, extensions)) {
      try {
        const content = fs.readFileSync(fullPath, 'utf-8');
        // Normalize path separators to forward slashes
        const normalizedPath = relativePath.replace(/\\/g, '/');
        files[normalizedPath] = content;
      } catch (err) {
        console.warn(`  Warning: Could not read ${fullPath}: ${err.message}`);
      }
    }
  }

  return files;
}

/**
 * Bundle a single template
 */
function bundleTemplate(config) {
  const srcPath = path.resolve(__dirname, config.srcPath);
  const outputFile = path.join(OUTPUT_DIR, config.outputFile);

  console.log(`\nBundling ${config.name}...`);
  console.log(`  Source: ${srcPath}`);

  if (!fs.existsSync(srcPath)) {
    console.log(`  ⚠️  Source not found, skipping`);
    return null;
  }

  const files = readDirectory(srcPath, '', config.extensions, config.exclude);
  const fileCount = Object.keys(files).length;

  if (fileCount === 0) {
    console.log(`  ⚠️  No files found, skipping`);
    return null;
  }

  const bundle = {
    name: config.name,
    version: '1.0.0',
    description: config.description,
    generatedAt: new Date().toISOString(),
    fileCount: fileCount,
    files: files
  };

  fs.writeFileSync(outputFile, JSON.stringify(bundle, null, 2));

  const stats = fs.statSync(outputFile);
  const sizeKB = (stats.size / 1024).toFixed(2);

  console.log(`  ✓ Bundled ${fileCount} files (${sizeKB} KB)`);

  return { name: config.name, fileCount, sizeKB };
}

/**
 * Main bundling function
 */
function main() {
  console.log('='.repeat(60));
  console.log('Template Bundler for Universal Visualizer');
  console.log('='.repeat(60));

  // Ensure output directory exists
  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  }

  const results = [];

  for (const config of TEMPLATES) {
    const result = bundleTemplate(config);
    if (result) {
      results.push(result);
    }
  }

  console.log('\n' + '='.repeat(60));
  console.log('Summary:');
  console.log('='.repeat(60));

  if (results.length === 0) {
    console.log('  No templates bundled');
  } else {
    for (const r of results) {
      console.log(`  ${r.name}: ${r.fileCount} files (${r.sizeKB} KB)`);
    }
    console.log(`\nTotal: ${results.length} templates bundled`);
  }

  console.log('\nDone!');
}

// Run
main();
