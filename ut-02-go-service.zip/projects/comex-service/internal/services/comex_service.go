// Package services contains business logic for COMEX operations
//
// The service layer:
// 1. Implements business rules
// 2. Orchestrates adapter calls
// 3. Handles caching strategies
// 4. Provides transaction boundaries
//
// NO infrastructure details here - that's in the adapter layer.
package services

import (
	"context"
	"fmt"

	"comex-service/internal/adapters"
	"comex-service/internal/domain"
)

// COMEXService defines the business operations for COMEX
type COMEXService interface {
	// Companies
	GetCompanies(ctx context.Context, userCPF string) (*domain.CompanyListResponse, error)
	GetCompanyDetails(ctx context.Context, cnpj string) (*domain.Company, error)

	// Export Billing (BAL1)
	QueryBillingOperations(ctx context.Context, query domain.BillingQuery) (*domain.BillingQueryResponse, error)
	GetBillingOperationDetails(ctx context.Context, id string) (*domain.BillingOperation, error)

	// Payment Orders (BAL3)
	QueryPaymentOrders(ctx context.Context, query domain.PaymentOrderQuery) (*domain.PaymentOrdersResponse, error)
	GetPaymentOrderDetails(ctx context.Context, id string) (*domain.PaymentOrder, error)
	GetPaymentOrderStatus(ctx context.Context, id string) (string, error)

	// Letters of Credit (BAL7)
	QueryLettersOfCredit(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error)
	GetLetterOfCreditDetails(ctx context.Context, id string) (*domain.LetterOfCredit, error)

	// Received Letters (C9RT)
	QueryReceivedLetters(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error)

	// FX Quotations (BAEI)
	QueryFXQuotations(ctx context.Context, query domain.FXQuery) (*domain.FXQueryResponse, error)
	GetQuotationDetails(ctx context.Context, id string) (*domain.FXQuotation, error)
	GetExchangeRates(ctx context.Context, currencies []string) ([]domain.ExchangeRate, error)
	SimulateExchange(ctx context.Context, from, to string, amount float64) (*domain.ExchangeSimulation, error)

	// SWIFT
	ListSWIFTMessages(ctx context.Context, status, dateFrom, dateTo string) ([]domain.SWIFTMessage, error)
	GetSWIFTMessageDetails(ctx context.Context, uetr string) (*domain.SWIFTMessage, error)
	SendSWIFTMessage(ctx context.Context, req domain.SWIFTMessageRequest) (*domain.SWIFTMessageResponse, error)

	// Health
	HealthCheck(ctx context.Context) (*domain.HealthStatus, error)
}

// =============================================================================
// SERVICE IMPLEMENTATION
// =============================================================================

// comexService implements COMEXService
type comexService struct {
	adapterFactory *adapters.AdapterFactory
}

// NewCOMEXService creates a new COMEX service
func NewCOMEXService(factory *adapters.AdapterFactory) COMEXService {
	return &comexService{
		adapterFactory: factory,
	}
}

// =============================================================================
// COMPANIES
// =============================================================================

func (s *comexService) GetCompanies(ctx context.Context, userCPF string) (*domain.CompanyListResponse, error) {
	adapter := s.adapterFactory.GetAdapter("companies")

	companies, err := adapter.ListCompanies(ctx, userCPF)
	if err != nil {
		return nil, fmt.Errorf("failed to list companies: %w", err)
	}

	return &domain.CompanyListResponse{
		Companies:  companies,
		TotalCount: len(companies),
	}, nil
}

func (s *comexService) GetCompanyDetails(ctx context.Context, cnpj string) (*domain.Company, error) {
	adapter := s.adapterFactory.GetAdapter("companies")
	return adapter.GetCompanyDetails(ctx, cnpj)
}

// =============================================================================
// EXPORT BILLING (BAL1)
// =============================================================================

func (s *comexService) QueryBillingOperations(ctx context.Context, query domain.BillingQuery) (*domain.BillingQueryResponse, error) {
	// Validate query
	if err := s.validateBillingQuery(query); err != nil {
		return nil, err
	}

	adapter := s.adapterFactory.GetAdapter("billing")
	return adapter.QueryBillingOperations(ctx, query)
}

func (s *comexService) validateBillingQuery(query domain.BillingQuery) error {
	if query.CNPJ == "" {
		return fmt.Errorf("CNPJ is required")
	}
	// Add more business validations as needed
	return nil
}

func (s *comexService) GetBillingOperationDetails(ctx context.Context, id string) (*domain.BillingOperation, error) {
	adapter := s.adapterFactory.GetAdapter("billing")
	return adapter.GetBillingOperationDetails(ctx, id)
}

// =============================================================================
// PAYMENT ORDERS (BAL3)
// =============================================================================

func (s *comexService) QueryPaymentOrders(ctx context.Context, query domain.PaymentOrderQuery) (*domain.PaymentOrdersResponse, error) {
	if err := s.validatePaymentOrderQuery(query); err != nil {
		return nil, err
	}

	adapter := s.adapterFactory.GetAdapter("payment-orders")
	return adapter.QueryPaymentOrders(ctx, query)
}

func (s *comexService) validatePaymentOrderQuery(query domain.PaymentOrderQuery) error {
	if query.CNPJ == "" {
		return fmt.Errorf("CNPJ is required")
	}
	if query.DateType == "" {
		return fmt.Errorf("DateType is required")
	}
	return nil
}

func (s *comexService) GetPaymentOrderDetails(ctx context.Context, id string) (*domain.PaymentOrder, error) {
	adapter := s.adapterFactory.GetAdapter("payment-orders")
	return adapter.GetPaymentOrderDetails(ctx, id)
}

func (s *comexService) GetPaymentOrderStatus(ctx context.Context, id string) (string, error) {
	adapter := s.adapterFactory.GetAdapter("payment-orders")
	return adapter.GetPaymentOrderStatus(ctx, id)
}

// =============================================================================
// LETTERS OF CREDIT (BAL7)
// =============================================================================

func (s *comexService) QueryLettersOfCredit(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error) {
	if query.CNPJ == "" {
		return nil, fmt.Errorf("CNPJ is required")
	}

	adapter := s.adapterFactory.GetAdapter("letters-of-credit")
	return adapter.QueryLettersOfCredit(ctx, query)
}

func (s *comexService) GetLetterOfCreditDetails(ctx context.Context, id string) (*domain.LetterOfCredit, error) {
	adapter := s.adapterFactory.GetAdapter("letters-of-credit")
	return adapter.GetLetterOfCreditDetails(ctx, id)
}

func (s *comexService) QueryReceivedLetters(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error) {
	if query.CNPJ == "" {
		return nil, fmt.Errorf("CNPJ is required")
	}

	adapter := s.adapterFactory.GetAdapter("received-letters")
	return adapter.QueryReceivedLetters(ctx, query)
}

// =============================================================================
// FX QUOTATIONS (BAEI)
// =============================================================================

func (s *comexService) QueryFXQuotations(ctx context.Context, query domain.FXQuery) (*domain.FXQueryResponse, error) {
	if query.CNPJ == "" {
		return nil, fmt.Errorf("CNPJ is required")
	}

	adapter := s.adapterFactory.GetAdapter("fx")
	return adapter.QueryFXQuotations(ctx, query)
}

func (s *comexService) GetQuotationDetails(ctx context.Context, id string) (*domain.FXQuotation, error) {
	adapter := s.adapterFactory.GetAdapter("fx")
	return adapter.GetQuotationDetails(ctx, id)
}

func (s *comexService) GetExchangeRates(ctx context.Context, currencies []string) ([]domain.ExchangeRate, error) {
	adapter := s.adapterFactory.GetAdapter("fx")
	return adapter.GetExchangeRates(ctx, currencies)
}

func (s *comexService) SimulateExchange(ctx context.Context, from, to string, amount float64) (*domain.ExchangeSimulation, error) {
	if from == "" || to == "" {
		return nil, fmt.Errorf("currency pair is required")
	}
	if amount <= 0 {
		return nil, fmt.Errorf("amount must be greater than zero")
	}

	adapter := s.adapterFactory.GetAdapter("fx")
	return adapter.SimulateExchange(ctx, from, to, amount)
}

// =============================================================================
// SWIFT
// =============================================================================

func (s *comexService) ListSWIFTMessages(ctx context.Context, status, dateFrom, dateTo string) ([]domain.SWIFTMessage, error) {
	adapter := s.adapterFactory.GetAdapter("swift")
	return adapter.ListSWIFTMessages(ctx, status, dateFrom, dateTo)
}

func (s *comexService) GetSWIFTMessageDetails(ctx context.Context, uetr string) (*domain.SWIFTMessage, error) {
	if uetr == "" {
		return nil, fmt.Errorf("UETR is required")
	}

	adapter := s.adapterFactory.GetAdapter("swift")
	return adapter.GetSWIFTMessageDetails(ctx, uetr)
}

func (s *comexService) SendSWIFTMessage(ctx context.Context, req domain.SWIFTMessageRequest) (*domain.SWIFTMessageResponse, error) {
	// Validate SWIFT message request
	if err := s.validateSWIFTRequest(req); err != nil {
		return nil, err
	}

	adapter := s.adapterFactory.GetAdapter("swift")
	return adapter.SendSWIFTMessage(ctx, req)
}

func (s *comexService) validateSWIFTRequest(req domain.SWIFTMessageRequest) error {
	if req.MessageType == "" {
		return fmt.Errorf("message type is required")
	}
	if req.BeneficiaryName == "" {
		return fmt.Errorf("beneficiary name is required")
	}
	if req.Amount <= 0 {
		return fmt.Errorf("amount must be greater than zero")
	}
	return nil
}

// =============================================================================
// HEALTH CHECK
// =============================================================================

func (s *comexService) HealthCheck(ctx context.Context) (*domain.HealthStatus, error) {
	adapter := s.adapterFactory.GetAdapter("health")

	err := adapter.Ping(ctx)
	healthy := err == nil

	status := &domain.HealthStatus{
		Service:   "COMEX",
		Healthy:   healthy,
		Timestamp: "", // Will be set by caller
		Details:   make(map[string]string),
	}

	if err != nil {
		status.Details["error"] = err.Error()
	}

	// Add adapter type info
	status.Details["adapter"] = string(s.adapterFactory.GetAdapterType("health"))

	return status, nil
}
