/**
 * GraphML to Cytoscape Elements converter
 * Parses GraphML XML and converts directly to Cytoscape nodes/edges format with styling
 */

// Node styles for different object types (from styleConfigs.js)
const nodeStyles = {
  // SP1NBP specific types
  'WebService': { color: '#e8daff', borderColor: '#8a3ffc', shape: 'roundrectangle' },
  'Browser_Form': { color: '#d0e2ff', borderColor: '#0f62fe', shape: 'rectangle' },
  'Form': { color: '#d0e2ff', borderColor: '#0f62fe', shape: 'rectangle' },
  'OperacaoFinalizacao': { color: '#ffd9be', borderColor: '#ff832b', shape: 'round-diamond' },
  'Screen': { color: '#a7f0ba', borderColor: '#24a148', shape: 'rectangle' },
  'UI': { color: '#d0e2ff', borderColor: '#0f62fe', shape: 'rectangle' },

  // Valorizacao types (navigation/action nodes - smaller diamonds)
  'Valorizacao_Formulario': { color: '#ffd6e8', borderColor: '#d12771', shape: 'diamond' },
  'Valorizacao_EnvioWS': { color: '#9ef0f0', borderColor: '#009d9a', shape: 'diamond' },
  'Valorizacao_Lista': { color: '#ffb784', borderColor: '#ff832b', shape: 'diamond' },

  // Database types
  'Informix Table': { color: '#d0e2ff', borderColor: '#0f62fe', shape: 'rectangle' },
  'Informix Procedure': { color: '#e8daff', borderColor: '#8a3ffc', shape: 'roundrectangle' },
  'Informix Function': { color: '#ffd6e8', borderColor: '#d12771', shape: 'ellipse' },
  'Informix Trigger': { color: '#9ef0f0', borderColor: '#009d9a', shape: 'diamond' },
  'Table': { color: '#d0e2ff', borderColor: '#0f62fe', shape: 'rectangle' },
  'Procedure': { color: '#e8daff', borderColor: '#8a3ffc', shape: 'roundrectangle' },
  'Function': { color: '#ffd6e8', borderColor: '#d12771', shape: 'ellipse' },
  'Trigger': { color: '#9ef0f0', borderColor: '#009d9a', shape: 'diamond' },
  'View': { color: '#a7f0ba', borderColor: '#24a148', shape: 'round-triangle' },
  'Stored Procedure': { color: '#ffd9be', borderColor: '#ff832b', shape: 'round-diamond' },

  // Generic types
  'Process': { color: '#ffd6e8', borderColor: '#d12771', shape: 'roundrectangle' },
  'Start': { color: '#a7f0ba', borderColor: '#24a148', shape: 'ellipse' },
  'Event': { color: '#d0e2ff', borderColor: '#0f62fe', shape: 'ellipse' },
  'Data': { color: '#ffd9be', borderColor: '#ff832b', shape: 'rectangle' },
  'Unknown': { color: '#e0e0e0', borderColor: '#525252', shape: 'ellipse' },
};

// Edge styles for different link types
const edgeStyles = {
  'SELECT': '#78a9ff',
  'INSERT': '#6fdc8c',
  'UPDATE': '#ffb784',
  'DELETE': '#ff99a2',
  'REFER': '#be95ff',
  'calls': '#82cfff',
  'CALLS': '#82cfff',
  'Reference': '#be95ff',
  'Call': '#82cfff',
  'Execute': '#ffb784',
};

/**
 * Parse GraphML XML string and convert directly to Cytoscape elements
 * @param {string} graphmlString - GraphML XML string
 * @returns {Object} { nodes: [], edges: [] }
 */
export const parseGraphML = (graphmlString) => {
  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(graphmlString, 'text/xml');

  // Check for parsing errors
  const parserError = xmlDoc.querySelector('parsererror');
  if (parserError) {
    throw new Error('Invalid GraphML XML: ' + parserError.textContent);
  }

  const nodeElements = xmlDoc.querySelectorAll('node');
  const edgeElements = xmlDoc.querySelectorAll('edge');

  const Objects = [];
  const Links = [];

  // Parse nodes
  nodeElements.forEach(nodeEl => {
    const nodeId = nodeEl.getAttribute('id');
    const dataElements = nodeEl.querySelectorAll('data');
    const obj = { "Object ID": nodeId };

    // First pass: extract from data elements (format A: graph.graphml)
    dataElements.forEach(data => {
      const key = data.getAttribute('key');
      const value = data.textContent.trim();

      // Skip empty values and graphics data
      if (!value || key === 'nodegraphics') return;

      // Map GraphML keys to expected JSON format
      switch(key) {
        case 'Name':
        case 'text':
        case 'fileName':  // SP1NBP: use fileName as the label
          if (!obj["Object Name"]) {  // Only set if not already set
            obj["Object Name"] = value.replace('.xml', '');  // Remove .xml extension
          }
          obj[key] = value;  // Keep original too
          break;
        case 'FullName':
          obj["Object Full Name"] = value;
          break;
        case 'Type':
        case 'Level':
        case 'Objects':
        case 'nodeType':  // SP1NBP: nodeType is the primary type field
          obj["Object Type"] = value;
          obj[key] = value;  // Keep original
          break;
        case 'InternalType':
          obj["Internal Type"] = value;
          break;
        case 'Application':
        case 'AppDisplayName':
          obj["Application"] = value;
          break;
        case 'AipId':
          obj["AIP ID"] = value;
          break;
        case 'External':
          obj["External"] = value;
          break;
        case 'DrillDown':
          obj["Drill Down"] = value;
          break;
        // SP1NBP specific attributes - keep them
        case 'complexity':
        case 'hasUI':
        case 'hasJavaScript':
        case 'hasWebService':
        case 'hasValidation':
        case 'lines':
          obj[key] = value;
          break;
        // Transaction metadata - NEW
        case 'transactionId':
        case 'transactionName':
        case 'businessLabel':
          obj[key] = value;
          break;
        case 'isEntryPoint':
          obj[key] = value === 'true';  // Convert to boolean
          break;
        // Skip visual/layout attributes
        case 'x':
        case 'y':
        case 'size':
        case 'shape':
        case 'color':
        case 'r':
        case 'g':
        case 'b':
        case 'a':
          // Skip these
          break;
        default:
          // Keep other attributes with their original names
          obj[key] = value;
      }
    });

    // Second pass: if no Object Name found, try yFiles format (format B: DM5336-1.graphml)
    if (!obj["Object Name"]) {
      const nodeLabel = nodeEl.querySelector('y\\:NodeLabel, NodeLabel');
      if (nodeLabel) {
        let labelText = nodeLabel.textContent.trim();

        // Clean up the text - remove template markers and extra whitespace
        labelText = labelText.replace(/<y:LabelModel>[\s\S]*$/i, '').trim();

        // Handle multi-line labels (e.g., "0\nAL04(TEMPDT)")
        // Join all non-empty lines with a space
        const lines = labelText.split('\n')
          .map(line => line.trim())
          .filter(line => line.length > 0);

        if (lines.length > 0) {
          // Join all lines with a space to create a meaningful name
          obj["Object Name"] = lines.join(' ');
        }
      }
    }

    // If still no name, try to get from description attribute
    if (!obj["Object Name"]) {
      const descData = nodeEl.querySelector('data[key="d5"]');
      if (descData && descData.textContent.trim()) {
        obj["Object Name"] = descData.textContent.trim();
      }
    }

    // Filter out version/metadata nodes (commonly used in yFiles for diagram info)
    const isVersionNode = obj["Object Name"] && (
      obj["Object Name"].includes("Version") ||
      obj["Object Name"].includes("Generated On") ||
      obj["Object Name"].includes("generated on") ||
      obj["Object Name"].match(/Version\s+\d+\.\d+/i)
    );

    if (isVersionNode) {
      return; // Skip this node
    }

    // Try to infer type from yFiles shape if not set
    if (!obj["Object Type"]) {
      const shapeNode = nodeEl.querySelector('y\\:ShapeNode, ShapeNode');
      if (shapeNode) {
        const shapeType = shapeNode.querySelector('y\\:Shape, Shape');
        const fillColor = shapeNode.querySelector('y\\:Fill, Fill');

        // Infer type from shape or color
        if (shapeType) {
          const type = shapeType.getAttribute('type');
          if (type === 'roundrectangle') {
            obj["Object Type"] = "Process";
          } else if (type === 'rectangle') {
            obj["Object Type"] = "Data";
          } else if (type === 'circle' || type === 'ellipse') {
            obj["Object Type"] = "Event";
          }
        }

        // Could also infer from color
        if (fillColor && !obj["Object Type"]) {
          const color = fillColor.getAttribute('color');
          if (color === '#CCFFCC') {
            obj["Object Type"] = "Start";
          } else if (color === '#FF33E3' || color === '#ff33e3') {
            obj["Object Type"] = "Process";
          }
        }
      }
    }

    // Set defaults for missing fields
    if (!obj["Object Name"]) {
      // For yFiles diagrams, use node ID but make it more readable
      const cleanId = nodeId.replace(/^n/, 'Node ');
      obj["Object Name"] = cleanId;
    }
    if (!obj["Object Type"]) {
      obj["Object Type"] = "Unknown";
    }
    if (!obj["Object Full Name"]) {
      obj["Object Full Name"] = obj["Object Name"];
    }

    Objects.push(obj);
  });

  // Parse edges
  edgeElements.forEach(edgeEl => {
    const source = edgeEl.getAttribute('source');
    const target = edgeEl.getAttribute('target');
    const dataElements = edgeEl.querySelectorAll('data');
    const link = {
      "Caller Object ID": source,
      "Callee Object ID": target
    };

    // First pass: extract from data elements (format A: graph.graphml)
    dataElements.forEach(data => {
      const key = data.getAttribute('key');
      const value = data.textContent.trim();

      // Skip empty values and graphics data
      if (key === 'edgegraphics') return;

      // Map edge keys
      if (key === 'edge_text' || key === 'Type' || key === 'edge_Type' || key === 'type') {
        link["Link Type"] = value;
      } else if (key === 'Columns') {
        link["Columns"] = value;
      } else if (key === 'Bookmarks') {
        link["Bookmarks"] = value;
      } else if (key === 'Id' || key === 'edge_Id') {
        link["Link ID"] = value;
      } else if (key === 'edge_Count') {
        link["Count"] = value;
      } else if (key === 'condition') {
        link["Condition"] = value;
      } else if (key === 'conditionFull') {
        link["ConditionFull"] = value;
      } else if (key === 'priority') {
        link["Priority"] = value;
      } else if (key === 'flowStep') {
        link["FlowStep"] = value;
      } else if (!key.startsWith('edge_') &&
                 key !== 'r' && key !== 'g' && key !== 'b' && key !== 'a' &&
                 key !== 'edge_size' && key !== 'edge_shape' && key !== 'edge_color') {
        // Keep other meaningful attributes
        link[key] = value;
      }
    });

    // Second pass: if no Link Type found, try yFiles format (format B: DM5336-1.graphml)
    if (!link["Link Type"]) {
      const edgeLabel = edgeEl.querySelector('y\\:EdgeLabel, EdgeLabel');
      if (edgeLabel) {
        const labelText = edgeLabel.textContent.trim();
        // Extract only the first line if multi-line
        const firstLine = labelText.split('\n')[0].trim();
        if (firstLine) {
          link["Link Type"] = firstLine;
        }
      }
    }

    if (!link["Link Type"]) {
      link["Link Type"] = "UNKNOWN";
    }

    Links.push(link);
  });

  // Convert Objects/Links to Cytoscape nodes/edges with styling
  const nodes = Objects.map(obj => {
    const type = obj["Object Type"] || "Unknown";
    const style = nodeStyles[type] || nodeStyles["Unknown"];

    // Calculate node size based on complexity
    let size = 25;
    const complexity = parseInt(obj["Cyclomatic Complexity"] || "0");
    if (complexity > 0) {
      size += Math.min(complexity, 30);
    }

    return {
      group: 'nodes',
      data: {
        id: obj["Object ID"],
        label: obj["Object Name"],
        fullName: obj["Object Full Name"],
        type: type,
        color: style.color,
        borderColor: style.borderColor,
        shape: style.shape,
        width: size,
        height: size,
        original: obj,
      },
    };
  });

  // Build a set of valid node IDs and create placeholders for missing targets
  const validNodeIds = new Set(nodes.map(n => n.data.id));
  const missingNodes = new Set();

  // First pass: find all missing nodes referenced by edges
  Links.forEach(link => {
    const source = link["Caller Object ID"];
    const target = link["Callee Object ID"];

    if (!validNodeIds.has(source)) {
      missingNodes.add(source);
    }
    if (!validNodeIds.has(target)) {
      missingNodes.add(target);
    }
  });

  // Create placeholder nodes for missing targets (likely external screens)
  const placeholderNodes = Array.from(missingNodes).map(nodeId => {
    const style = nodeStyles["Screen"] || nodeStyles["Unknown"];
    return {
      group: 'nodes',
      data: {
        id: nodeId,
        label: nodeId,
        fullName: nodeId + ' (external)',
        type: 'Screen',
        color: style.color,
        borderColor: style.borderColor,
        shape: style.shape,
        width: 30,
        height: 30,
        original: { "Object ID": nodeId, "Object Name": nodeId, "Object Type": "Screen" },
        isPlaceholder: true,  // Mark as placeholder
      },
    };
  });

  console.log(`Created ${placeholderNodes.length} placeholder nodes for missing targets:`, Array.from(missingNodes));

  // Combine real nodes with placeholder nodes
  const allNodes = [...nodes, ...placeholderNodes];

  // Convert Links to edges (all edges are now valid)
  const edges = Links.map((link, index) => {
    const source = link["Caller Object ID"];
    const target = link["Callee Object ID"];
    const type = link["Link Type"] || "Reference";
    const color = edgeStyles[type] || '#999';

    // Build readable label with condition if present
    let label = type;
    let conditionFull = link["Condition"] || link["ConditionFull"] || '';
    const flowStep = link["FlowStep"] || '';

    // Prefix label with flow step number if present
    if (flowStep && flowStep !== '') {
      label = `[${flowStep}] ${label}`;
    }

    if (conditionFull && conditionFull.length > 0) {
      // For conditional edges, show condition more prominently
      if (type.includes('conditional')) {
        // Format condition with line breaks for readability
        const conditionFormatted = conditionFull
          .replace(/\(/g, '\n  (')  // Line break before opening parens
          .replace(/,\s*/g, ',\n    ') // Line break after commas
          .trim();

        // Show just condition (not type) if it's long
        if (conditionFormatted.length > 30) {
          label = flowStep ? `[${flowStep}] ${conditionFormatted.substring(0, 50)}\n...` : conditionFormatted.substring(0, 50) + '\n...';
        } else {
          label = flowStep ? `[${flowStep}] ${type}:\n${conditionFormatted}` : `${type}:\n${conditionFormatted}`;
        }
      } else {
        // For non-conditional edges, show type with short condition
        const conditionPreview = conditionFull.length > 20
          ? conditionFull.substring(0, 20) + '...'
          : conditionFull;
        label = flowStep ? `[${flowStep}] ${type}\n[${conditionPreview}]` : `${type}\n[${conditionPreview}]`;
      }
    }

    return {
      group: 'edges',
      data: {
        id: 'e' + index,
        source: source,
        target: target,
        label: label,
        type: type,
        condition: conditionFull,
        conditionFull: conditionFull, // Full condition for details panel
        priority: link["Priority"] || '0',
        flowStep: flowStep, // Sequential flow step number
        color: color,
        original: link,
      },
    };
  });

  return { nodes: allNodes, edges };
};

/**
 * Extract key definitions from GraphML
 * @param {Document} xmlDoc - Parsed XML document
 * @returns {Object} Key definitions map
 */
const extractKeyDefinitions = (xmlDoc) => {
  const keyDefs = {};
  const keys = xmlDoc.querySelectorAll('key');

  keys.forEach((key) => {
    const id = key.getAttribute('id');
    const attrName = key.getAttribute('attr.name');
    const attrType = key.getAttribute('attr.type');
    const forType = key.getAttribute('for'); // 'node' or 'edge'

    keyDefs[id] = {
      name: attrName,
      type: attrType,
      for: forType,
    };
  });

  return keyDefs;
};

/**
 * Extract data attributes from a node or edge element
 * @param {Element} element - XML element
 * @param {Object} keyDefs - Key definitions
 * @returns {Object} Data attributes
 */
const extractData = (element, keyDefs) => {
  const data = {};
  const dataElements = element.querySelectorAll('data');

  dataElements.forEach((dataEl) => {
    const key = dataEl.getAttribute('key');
    const value = dataEl.textContent.trim();

    if (keyDefs[key]) {
      const attrName = keyDefs[key].name;
      const attrType = keyDefs[key].type;

      // Type conversion
      let typedValue = value;
      if (attrType === 'int' || attrType === 'long') {
        typedValue = parseInt(value, 10);
      } else if (attrType === 'double' || attrType === 'float') {
        typedValue = parseFloat(value);
      } else if (attrType === 'boolean') {
        typedValue = value.toLowerCase() === 'true';
      }

      data[attrName] = typedValue;
    }
  });

  return data;
};

/**
 * Extract nodes from GraphML
 * @param {Document} xmlDoc - Parsed XML document
 * @param {Object} keyDefs - Key definitions
 * @returns {Array} Cytoscape nodes
 */
const extractNodes = (xmlDoc, keyDefs) => {
  const nodes = [];
  const nodeElements = xmlDoc.querySelectorAll('node');

  nodeElements.forEach((nodeEl) => {
    const id = nodeEl.getAttribute('id');
    const data = extractData(nodeEl, keyDefs);

    // Extract shape type from yFiles data for fallback type
    let shapeType = null;
    const shapeNode = nodeEl.querySelector('ShapeNode Shape');
    if (shapeNode) {
      shapeType = shapeNode.getAttribute('type');
    }

    nodes.push({
      group: 'nodes',
      data: {
        id,
        label: data.label || data.name || data['Object Name'] || id,
        type: data['Object Type'] || data.type || shapeType || 'Unknown',
        ...data,
      },
    });
  });

  return nodes;
};

/**
 * Extract edges from GraphML
 * @param {Document} xmlDoc - Parsed XML document
 * @param {Object} keyDefs - Key definitions
 * @returns {Array} Cytoscape edges
 */
const extractEdges = (xmlDoc, keyDefs) => {
  const edges = [];
  const edgeElements = xmlDoc.querySelectorAll('edge');

  edgeElements.forEach((edgeEl, index) => {
    const id = edgeEl.getAttribute('id') || `edge-${index}`;
    const source = edgeEl.getAttribute('source');
    const target = edgeEl.getAttribute('target');
    const data = extractData(edgeEl, keyDefs);

    edges.push({
      group: 'edges',
      data: {
        id,
        source,
        target,
        label: data.label || data.name || '',
        type: data['Link Type'] || data.type || 'Link',
        ...data,
      },
    });
  });

  return edges;
};

/**
 * Validate GraphML format
 * @param {string} graphmlString - GraphML XML string
 * @returns {boolean} True if valid GraphML
 */
export const isValidGraphML = (graphmlString) => {
  try {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(graphmlString, 'text/xml');

    // Check for parser errors
    const parserError = xmlDoc.querySelector('parsererror');
    if (parserError) {
      return false;
    }

    // Check for graphml root element
    const graphml = xmlDoc.querySelector('graphml');
    if (!graphml) {
      return false;
    }

    // Check for at least one graph element
    const graph = xmlDoc.querySelector('graph');
    if (!graph) {
      return false;
    }

    return true;
  } catch (error) {
    return false;
  }
};

/**
 * Convert Cytoscape elements to GraphML
 * @param {Array} elements - Cytoscape elements
 * @returns {string} GraphML XML string
 */
export const elementsToGraphML = (elements) => {
  // Create XML document
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<graphml xmlns="http://graphml.graphdrawing.org/xmlns"\n';
  xml += '    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"\n';
  xml += '    xsi:schemaLocation="http://graphml.graphdrawing.org/xmlns\n';
  xml += '    http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd">\n';

  // Add key definitions
  xml += '  <key id="label" for="all" attr.name="label" attr.type="string"/>\n';
  xml += '  <key id="type" for="all" attr.name="type" attr.type="string"/>\n';

  xml += '  <graph id="G" edgedefault="directed">\n';

  // Add nodes
  elements.forEach((el) => {
    if (el.group === 'nodes') {
      xml += `    <node id="${el.data.id}">\n`;
      if (el.data.label) {
        xml += `      <data key="label">${escapeXml(el.data.label)}</data>\n`;
      }
      if (el.data.type) {
        xml += `      <data key="type">${escapeXml(el.data.type)}</data>\n`;
      }
      xml += '    </node>\n';
    }
  });

  // Add edges
  elements.forEach((el) => {
    if (el.group === 'edges') {
      xml += `    <edge id="${el.data.id}" source="${el.data.source}" target="${el.data.target}">\n`;
      if (el.data.label) {
        xml += `      <data key="label">${escapeXml(el.data.label)}</data>\n`;
      }
      if (el.data.type) {
        xml += `      <data key="type">${escapeXml(el.data.type)}</data>\n`;
      }
      xml += '    </edge>\n';
    }
  });

  xml += '  </graph>\n';
  xml += '</graphml>';

  return xml;
};

/**
 * Escape XML special characters
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 */
const escapeXml = (str) => {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
};
