import { getNodeTypes, getEdgeTypes, getNodeColor, getEdgeColor } from '../utils/styleConfigs';
import styles from './DiagramLegend.module.scss';

/**
 * DiagramLegend Component
 * Displays color legend for node and edge types
 * Legend items are clickable and act as filters
 *
 * @param {Object} props
 * @param {Array} props.elements - Graph elements
 * @param {Object} props.nodeTypeFilters - Node type filter state
 * @param {Object} props.edgeTypeFilters - Edge type filter state
 * @param {Function} props.onNodeTypeFilterChange - Node filter change handler
 * @param {Function} props.onEdgeTypeFilterChange - Edge filter change handler
 */
const DiagramLegend = ({
  elements,
  nodeTypeFilters,
  edgeTypeFilters,
  onNodeTypeFilterChange,
  onEdgeTypeFilterChange,
}) => {
  const nodeTypes = getNodeTypes(elements);
  const edgeTypes = getEdgeTypes(elements);

  if (nodeTypes.length === 0 && edgeTypes.length === 0) {
    return null;
  }

  return (
    <div className={styles.container}>
      <h3 className={styles.title}>Legend (Click to Filter)</h3>

      {nodeTypes.length > 0 && (
        <div className={styles.section}>
          <h4 className={styles.subtitle}>Node Types</h4>
          <div className={styles.items}>
            {nodeTypes.map((type) => {
              const isActive = nodeTypeFilters[type];
              return (
                <div
                  key={type}
                  className={`${styles.item} ${styles.clickable} ${isActive ? styles.active : ''}`}
                  onClick={() => onNodeTypeFilterChange(type, !isActive)}
                >
                  <div
                    className={styles.colorBox}
                    style={{ backgroundColor: getNodeColor(type) }}
                  />
                  <span className={styles.label}>{type}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {edgeTypes.length > 0 && (
        <div className={styles.section}>
          <h4 className={styles.subtitle}>Edge Types</h4>
          <div className={styles.items}>
            {edgeTypes.map((type) => {
              const isActive = edgeTypeFilters[type];
              return (
                <div
                  key={type}
                  className={`${styles.item} ${styles.clickable} ${isActive ? styles.active : ''}`}
                  onClick={() => onEdgeTypeFilterChange(type, !isActive)}
                >
                  <div
                    className={styles.colorLine}
                    style={{ backgroundColor: getEdgeColor(type) }}
                  />
                  <span className={styles.label}>{type}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default DiagramLegend;
