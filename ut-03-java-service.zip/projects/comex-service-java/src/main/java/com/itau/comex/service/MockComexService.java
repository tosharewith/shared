package com.itau.comex.service;

import com.itau.comex.domain.Company;
import com.itau.comex.domain.SwiftMessage;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

/**
 * Mock implementation of ComexService
 * Returns fake data for development and testing
 *
 * Activated when: comex.adapter=MOCK (default)
 */
@Service
@ConditionalOnProperty(name = "comex.adapter", havingValue = "MOCK", matchIfMissing = true)
public class MockComexService implements ComexService {

    // Mock companies data
    private static final List<Company> MOCK_COMPANIES = Arrays.asList(
            Company.builder()
                    .cnpj("12345678000190")
                    .name("Empresa ABC Ltda")
                    .type(Company.CompanyType.NORMAL)
                    .active(true)
                    .build(),
            Company.builder()
                    .cnpj("98765432000121")
                    .name("Empresa XYZ S.A.")
                    .type(Company.CompanyType.NORMAL)
                    .active(true)
                    .build(),
            Company.builder()
                    .cnpj("11222333000144")
                    .name("Offshore Holdings Ltd")
                    .type(Company.CompanyType.OFFSHORE)
                    .active(true)
                    .build(),
            Company.builder()
                    .cnpj("44555666000177")
                    .name("Trading Company Brasil Ltda")
                    .type(Company.CompanyType.NORMAL)
                    .active(true)
                    .build(),
            Company.builder()
                    .cnpj("77888999000122")
                    .name("Importadora Sul Ltda")
                    .type(Company.CompanyType.NORMAL)
                    .active(true)
                    .build(),
            Company.builder()
                    .cnpj("33444555000188")
                    .name("Agro Export Ltda")
                    .type(Company.CompanyType.NORMAL)
                    .active(true)
                    .build()
    );

    // Mock SWIFT messages data
    private static final List<SwiftMessage> MOCK_SWIFT_MESSAGES = Arrays.asList(
            SwiftMessage.builder()
                    .uetr("550e8400-e29b-41d4-a716-446655440000")
                    .messageType("MT103")
                    .senderBic("ITABORJXXXX")
                    .receiverBic("CHABORJXXXX")
                    .amount(new BigDecimal("50000.00"))
                    .currency("USD")
                    .beneficiary("International Corp")
                    .reference("REF-2024-001")
                    .status("DELIVERED")
                    .createdAt(LocalDateTime.of(2024, 2, 1, 10, 30, 0))
                    .deliveredAt(LocalDateTime.of(2024, 2, 1, 10, 31, 0))
                    .build(),
            SwiftMessage.builder()
                    .uetr("550e8400-e29b-41d4-a716-446655440001")
                    .messageType("MT103")
                    .senderBic("ITABORJXXXX")
                    .receiverBic("DEUTDEFFXXX")
                    .amount(new BigDecimal("75000.00"))
                    .currency("EUR")
                    .beneficiary("Euro Trading GmbH")
                    .reference("REF-2024-002")
                    .status("PENDING")
                    .createdAt(LocalDateTime.of(2024, 2, 10, 14, 0, 0))
                    .deliveredAt(null)
                    .build(),
            SwiftMessage.builder()
                    .uetr("550e8400-e29b-41d4-a716-446655440002")
                    .messageType("MT700")
                    .senderBic("ITABORJXXXX")
                    .receiverBic("BABORJXXXX")
                    .amount(new BigDecimal("100000.00"))
                    .currency("USD")
                    .beneficiary("Export Partner Inc")
                    .reference("LC-2024-001")
                    .status("ISSUED")
                    .createdAt(LocalDateTime.of(2024, 2, 15, 9, 15, 0))
                    .deliveredAt(LocalDateTime.of(2024, 2, 15, 9, 16, 0))
                    .build()
    );

    @Override
    public List<Company> getCompanies(String userCpf) {
        // In mock mode, return all companies regardless of userCpf
        return MOCK_COMPANIES;
    }

    @Override
    public Company getCompanyDetails(String cnpj) {
        return MOCK_COMPANIES.stream()
                .filter(c -> c.getCnpj().equals(cnpj))
                .findFirst()
                .orElse(Company.builder()
                        .cnpj(cnpj)
                        .name("Empresa Exemplo Ltda")
                        .type(Company.CompanyType.NORMAL)
                        .active(true)
                        .build());
    }

    @Override
    public List<SwiftMessage> listSwiftMessages(String status, String dateFrom, String dateTo) {
        // In mock mode, return all messages (filtering could be added if needed)
        return MOCK_SWIFT_MESSAGES;
    }

    @Override
    public SwiftMessage getSwiftMessageDetails(String uetr) {
        return MOCK_SWIFT_MESSAGES.stream()
                .filter(m -> m.getUetr().equals(uetr))
                .findFirst()
                .orElse(SwiftMessage.builder()
                        .uetr(uetr)
                        .messageType("MT103")
                        .senderBic("ITABORJXXXX")
                        .receiverBic("UNKNOWNXXX")
                        .amount(new BigDecimal("10000.00"))
                        .currency("USD")
                        .beneficiary("Unknown Beneficiary")
                        .reference("REF-UNKNOWN")
                        .status("UNKNOWN")
                        .createdAt(LocalDateTime.now())
                        .build());
    }
}
