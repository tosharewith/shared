// Package adapters - Oracle Legacy Adapter
//
// This adapter encapsulates ALL knowledge about:
// - wsBankline.asmx WebService
// - XML request/response format
// - Oracle procedures (K_G_COMEXPRESS, BAL1, BAL3, BAL7, BAEI, etc)
// - Connection configuration
//
// NO OTHER CODE should know these details.
package adapters

import (
	"bytes"
	"context"
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"time"

	"comex-service/internal/domain"
)

// OracleAdapter implements COMEXAdapter for Oracle legacy systems
type OracleAdapter struct {
	config     OracleConfig
	httpClient *http.Client
}

// NewOracleAdapter creates a new Oracle adapter
func NewOracleAdapter(config OracleConfig) *OracleAdapter {
	return &OracleAdapter{
		config: config,
		httpClient: &http.Client{
			Timeout: time.Duration(config.Timeout) * time.Second,
		},
	}
}

// =============================================================================
// XML STRUCTURES (from legacy XMLs)
// =============================================================================

// XMLRequest represents the legacy XML request format
type XMLRequest struct {
	XMLName     xml.Name       `xml:"XML"`
	Config      XMLConfig      `xml:"Config"`
	Connections XMLConnections `xml:"Connections"`
	Commands    XMLCommands    `xml:"Commands"`
}

type XMLConfig struct {
	Bankline   string `xml:"Bankline,attr"`
	CdConsulta string `xml:"CdConsulta,attr"`
	CdSistema  string `xml:"CdSistema,attr"`
	CdOperador string `xml:"CdOperador,attr"`
}

type XMLConnections struct {
	Connection []XMLConnection `xml:"Connection"`
}

type XMLConnection struct {
	ConnectionID string `xml:"ConnectionID,attr"`
	Provider     string `xml:"Provider,attr"`
	Server       string `xml:"Server,attr"`
	DB           string `xml:"DB,attr"`
	USR          string `xml:"USR,attr"`
	PWD          string `xml:"PWD,attr"`
}

type XMLCommands struct {
	Command []XMLCommand `xml:"Command"`
}

type XMLCommand struct {
	CommandID     string         `xml:"CommandID,attr"`
	ReturnDataset string         `xml:"ReturnDataset,attr"`
	OracleCursor  string         `xml:"OracleCursor,attr"`
	ConnectionID  string         `xml:"ConnectionID,attr"`
	Name          string         `xml:"Name,attr"`
	Parameters    XMLParameters  `xml:"Parameters"`
}

type XMLParameters struct {
	Parm []XMLParm `xml:"Parm"`
}

type XMLParm struct {
	Name      string `xml:"Name,attr"`
	Direction string `xml:"Direction,attr"`
	Value     string `xml:",chardata"`
}

// XMLResponse represents the legacy XML response format
type XMLResponse struct {
	XMLName  xml.Name    `xml:"RESPOSTA"`
	Dados    XMLDados    `xml:"DADOS"`
	Status   XMLStatus   `xml:"STATUS,omitempty"`
}

type XMLDados struct {
	ListaEmpresas XMLListaEmpresas `xml:"ListaEmpresas,omitempty"`
	// Add other response types as needed
}

type XMLListaEmpresas struct {
	Item []XMLEmpresaItem `xml:"Item"`
}

type XMLEmpresaItem struct {
	SCGCCPF_CLI string `xml:"SCGCCPF_CLI"` // CNPJ
	SNOME_CLI   string `xml:"SNOME_CLI"`   // Company name
}

type XMLStatus struct {
	Codigo   string `xml:"codigo"`
	Mensagem string `xml:"mensagem"`
	Tipo     string `xml:"tipo"`
}

// =============================================================================
// COMPANIES (ConsultaCNPJS.xml)
// =============================================================================

// ListCompanies lists companies with COMEX access
// Calls: K_G_COMEXPRESS.P_G_LST_EMP_COM_ACESSO
func (a *OracleAdapter) ListCompanies(ctx context.Context, userCPF string) ([]domain.Company, error) {
	// Build XML request (same structure as ConsultaCNPJS.xml)
	xmlReq := a.buildCompanyListXML(userCPF)

	// Call wsBankline.asmx
	xmlResp, err := a.callWebService(ctx, xmlReq)
	if err != nil {
		return nil, fmt.Errorf("failed to call legacy webservice: %w", err)
	}

	// Parse response
	var resp XMLResponse
	if err := xml.Unmarshal(xmlResp, &resp); err != nil {
		return nil, fmt.Errorf("failed to parse XML response: %w", err)
	}

	// Convert to domain objects
	companies := make([]domain.Company, 0, len(resp.Dados.ListaEmpresas.Item))
	for _, item := range resp.Dados.ListaEmpresas.Item {
		companies = append(companies, domain.Company{
			CNPJ: item.SCGCCPF_CLI,
			Name: item.SNOME_CLI,
		})
	}

	return companies, nil
}

func (a *OracleAdapter) buildCompanyListXML(userCPF string) []byte {
	req := XMLRequest{
		Config: XMLConfig{
			Bankline:   "TRUE",
			CdConsulta: "ListaEmpComAcesso",
			CdSistema:  "ComExpress",
			CdOperador: userCPF,
		},
		Connections: XMLConnections{
			Connection: []XMLConnection{
				{
					ConnectionID: "ORACLE",
					Provider:     "ORACLE",
					Server:       a.config.Username, // From config
					DB:           "",
					USR:          a.config.Username,
					PWD:          a.config.Password,
				},
			},
		},
		Commands: XMLCommands{
			Command: []XMLCommand{
				{
					CommandID:     "ListaEmpresas",
					ReturnDataset: "True",
					OracleCursor:  "True",
					ConnectionID:  "ORACLE",
					Name:          "BEGIN K_G_COMEXPRESS.P_G_LST_EMP_COM_ACESSO(:sCGCCPF_EMP_IO, :sCPFOPE_IO, :CURSOR); END;",
					Parameters: XMLParameters{
						Parm: []XMLParm{
							{Name: "sCGCCPF_EMP_IO", Direction: "Input", Value: ""},
							{Name: "sCPFOPE_IO", Direction: "Input", Value: userCPF},
						},
					},
				},
			},
		},
	}

	xmlBytes, _ := xml.Marshal(req)
	return xmlBytes
}

// GetCompanyDetails returns details of a specific company
func (a *OracleAdapter) GetCompanyDetails(ctx context.Context, cnpj string) (*domain.Company, error) {
	// Implementation would call specific procedure
	return nil, fmt.Errorf("not implemented")
}

// =============================================================================
// BILLING OPERATIONS (Tela_Entrada_Dados.xml → BAL1)
// =============================================================================

// QueryBillingOperations queries export billing operations
// Calls: BAL1\SP\Passo_M1_010206
func (a *OracleAdapter) QueryBillingOperations(ctx context.Context, query domain.BillingQuery) (*domain.BillingQueryResponse, error) {
	// Build XML request based on Tela_Entrada_Dados.xml template
	xmlReq := a.buildBillingQueryXML(query)

	// Call wsBankline.asmx
	xmlResp, err := a.callWebService(ctx, xmlReq)
	if err != nil {
		return nil, fmt.Errorf("failed to call BAL1 webservice: %w", err)
	}

	// Parse and convert response
	return a.parseBillingResponse(xmlResp)
}

func (a *OracleAdapter) buildBillingQueryXML(query domain.BillingQuery) []byte {
	// Build XML similar to Tela_Entrada_Dados.xml template
	// This encapsulates all legacy XML format knowledge
	req := XMLRequest{
		Config: XMLConfig{
			Bankline:   "TRUE",
			CdConsulta: "CobrancaExportacao",
			CdSistema:  "BAL1",
		},
		Commands: XMLCommands{
			Command: []XMLCommand{
				{
					CommandID:    "Query",
					ConnectionID: "ORACLE",
					Name:         "BAL1\\SP\\Passo_M1_010206",
					Parameters: XMLParameters{
						Parm: []XMLParm{
							{Name: "CNPJ", Direction: "Input", Value: query.CNPJ},
							{Name: "DT_INICIO", Direction: "Input", Value: query.DateFrom},
							{Name: "DT_FIM", Direction: "Input", Value: query.DateTo},
							{Name: "FATURA", Direction: "Input", Value: query.InvoiceNumber},
							{Name: "TIPO_DATA", Direction: "Input", Value: string(query.DateType)},
							{Name: "TIPO_EMPRESA", Direction: "Input", Value: string(query.CompanyType)},
						},
					},
				},
			},
		},
	}

	xmlBytes, _ := xml.Marshal(req)
	return xmlBytes
}

func (a *OracleAdapter) parseBillingResponse(xmlResp []byte) (*domain.BillingQueryResponse, error) {
	// Parse legacy XML response and convert to domain object
	return &domain.BillingQueryResponse{
		Operations: []domain.BillingOperation{},
		TotalCount: 0,
	}, nil
}

// GetBillingOperationDetails returns details of a billing operation
func (a *OracleAdapter) GetBillingOperationDetails(ctx context.Context, id string) (*domain.BillingOperation, error) {
	return nil, fmt.Errorf("not implemented")
}

// =============================================================================
// PAYMENT ORDERS (Tela_Entrada_OPRE.xml → BAL3)
// =============================================================================

// QueryPaymentOrders queries payment orders from abroad
// Calls: BAL3\SP\Passo_M1
func (a *OracleAdapter) QueryPaymentOrders(ctx context.Context, query domain.PaymentOrderQuery) (*domain.PaymentOrdersResponse, error) {
	xmlReq := a.buildPaymentOrdersQueryXML(query)

	xmlResp, err := a.callWebService(ctx, xmlReq)
	if err != nil {
		return nil, fmt.Errorf("failed to call BAL3 webservice: %w", err)
	}

	return a.parsePaymentOrdersResponse(xmlResp)
}

func (a *OracleAdapter) buildPaymentOrdersQueryXML(query domain.PaymentOrderQuery) []byte {
	// Similar to Tela_Entrada_OPRE.xml template
	return []byte{}
}

func (a *OracleAdapter) parsePaymentOrdersResponse(xmlResp []byte) (*domain.PaymentOrdersResponse, error) {
	return &domain.PaymentOrdersResponse{
		Orders:     []domain.PaymentOrder{},
		TotalCount: 0,
	}, nil
}

func (a *OracleAdapter) GetPaymentOrderDetails(ctx context.Context, id string) (*domain.PaymentOrder, error) {
	return nil, fmt.Errorf("not implemented")
}

func (a *OracleAdapter) GetPaymentOrderStatus(ctx context.Context, id string) (string, error) {
	return "", fmt.Errorf("not implemented")
}

// =============================================================================
// LETTERS OF CREDIT (Tela_Lista_CNPJ_BAL7.xml → BAL7)
// =============================================================================

// QueryLettersOfCredit queries negotiated letters of credit
// Calls: BAL7\SP\Passo_M
func (a *OracleAdapter) QueryLettersOfCredit(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error) {
	return &domain.LCQueryResponse{
		Letters:    []domain.LetterOfCredit{},
		TotalCount: 0,
	}, nil
}

func (a *OracleAdapter) GetLetterOfCreditDetails(ctx context.Context, id string) (*domain.LetterOfCredit, error) {
	return nil, fmt.Errorf("not implemented")
}

// QueryReceivedLetters queries received letters of credit
// Calls: C9RT
func (a *OracleAdapter) QueryReceivedLetters(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error) {
	return &domain.LCQueryResponse{
		Letters:    []domain.LetterOfCredit{},
		TotalCount: 0,
	}, nil
}

// =============================================================================
// FX QUOTATIONS (TelaListaCNPJCambio.xml → BAEI)
// =============================================================================

// QueryFXQuotations queries FX quotations
// Calls: BAEI\SPNBP\BAEI01
func (a *OracleAdapter) QueryFXQuotations(ctx context.Context, query domain.FXQuery) (*domain.FXQueryResponse, error) {
	return &domain.FXQueryResponse{
		Quotations: []domain.FXQuotation{},
		TotalCount: 0,
	}, nil
}

func (a *OracleAdapter) GetQuotationDetails(ctx context.Context, id string) (*domain.FXQuotation, error) {
	return nil, fmt.Errorf("not implemented")
}

func (a *OracleAdapter) GetExchangeRates(ctx context.Context, currencies []string) ([]domain.ExchangeRate, error) {
	return []domain.ExchangeRate{}, nil
}

func (a *OracleAdapter) SimulateExchange(ctx context.Context, from, to string, amount float64) (*domain.ExchangeSimulation, error) {
	return nil, fmt.Errorf("not implemented")
}

// =============================================================================
// SWIFT
// =============================================================================

func (a *OracleAdapter) ListSWIFTMessages(ctx context.Context, status, dateFrom, dateTo string) ([]domain.SWIFTMessage, error) {
	return []domain.SWIFTMessage{}, nil
}

func (a *OracleAdapter) GetSWIFTMessageDetails(ctx context.Context, uetr string) (*domain.SWIFTMessage, error) {
	return nil, fmt.Errorf("not implemented")
}

func (a *OracleAdapter) SendSWIFTMessage(ctx context.Context, req domain.SWIFTMessageRequest) (*domain.SWIFTMessageResponse, error) {
	return nil, fmt.Errorf("not implemented")
}

// =============================================================================
// HEALTH CHECK
// =============================================================================

// Ping checks connectivity to Oracle
func (a *OracleAdapter) Ping(ctx context.Context) error {
	// Simple connectivity check
	_, err := a.callWebService(ctx, []byte("<PING/>"))
	return err
}

// =============================================================================
// HTTP CLIENT
// =============================================================================

// callWebService calls the legacy wsBankline.asmx WebService
func (a *OracleAdapter) callWebService(ctx context.Context, xmlRequest []byte) ([]byte, error) {
	// Build form-encoded request (as legacy expects)
	formData := url.Values{}
	formData.Set("input", string(xmlRequest))

	req, err := http.NewRequestWithContext(ctx, "POST", a.config.WSURL+"/ProcessaXML", bytes.NewBufferString(formData.Encode()))
	if err != nil {
		return nil, err
	}

	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := a.httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("webservice returned status %d", resp.StatusCode)
	}

	return io.ReadAll(resp.Body)
}
