import styles from './DiagramFilters.module.scss';

/**
 * DiagramFilters Component
 * Renders checkboxes for filtering nodes or edges by type
 *
 * @param {Object} props
 * @param {string} props.title - Filter section title
 * @param {Array} props.types - Available types to filter
 * @param {Object} props.filters - Current filter state
 * @param {Function} props.onChange - Filter change handler
 */
const DiagramFilters = ({ title, types, filters, onChange }) => {
  if (types.length === 0) return null;

  return (
    <div className={styles.container}>
      <h3 className={styles.title}>{title}</h3>
      <div className={styles.filters}>
        {types.map((type) => (
          <label key={type} className={styles.filterLabel}>
            <input
              type="checkbox"
              id={`filter-${type}`}
              checked={filters[type] || false}
              onChange={(e) => onChange(type, e.target.checked)}
            />
            <span>{type}</span>
          </label>
        ))}
      </div>
    </div>
  );
};

export default DiagramFilters;
