/**
 * XML Parser Service for React
 * Extracts screen definitions and builds navigation flows
 * Based on Angular XmlParserService
 */

const XML_FILES = [
  'ConsultaCNPJS.xml',
  'ConsultaCNPJS_OperacaoFinalizacao.xml',
  'Tela_Entrada_Dados.xml',
  'Tela_Entrada_Dados_OperacaoFinalizacao.xml',
  'Tela_Entrada_OPRE.xml',
  'Tela_Entrada_OPRE_OperacaoFinalizacao.xml',
  'Tela_Lista_CNPJ_BAL7.xml',
  'Tela_Lista_CNPJ_BAL7_OperacaoFinalizacao.xml',
  'Tela_Lista_CNPJ_C9RT.xml',
  'Tela_Lista_CNPJ_C9RT_OperacaoFinalizacao.xml',
  'Tela_Recebe_Param.xml',
  'TelaListaCNPJ.xml',
  'TelaListaCNPJ_OperacaoFinalizacao.xml',
  'TelaListaCNPJCambio.xml',
  'TelaListaCNPJCambio_OperacaoFinalizacao.xml',
  'TelaListaCNPJCHAT.xml',
  'TelaListaCNPJCHAT_OperacaoFinalizacao.xml',
  'TelaListaNCNPJs.xml',
  'TelaListaNCNPJs_OperacaoFinalizacao.xml',
  'VisaoCliente.xml'
];

/**
 * Load all screen definitions from XML files
 */
export async function loadAllScreens() {
  const basePath = '/root';
  const promises = XML_FILES.map(async (file) => {
    try {
      const response = await fetch(`${basePath}/${file}`);
      if (!response.ok) {
        console.warn(`Failed to load ${file}:`, response.status);
        return null;
      }
      const xmlText = await response.text();
      return parseXml(xmlText, file);
    } catch (error) {
      console.warn(`Error loading ${file}:`, error);
      return null;
    }
  });

  const results = await Promise.all(promises);
  return results.filter(r => r !== null);
}

/**
 * Load a specific screen by name
 */
export async function loadScreen(name) {
  const basePath = '/root';
  const fileName = name.endsWith('.xml') ? name : `${name}.xml`;

  const response = await fetch(`${basePath}/${fileName}`);
  const xmlText = await response.text();
  return parseXml(xmlText, fileName);
}

/**
 * Parse XML string into screen definition
 */
export function parseXml(xmlString, fileName) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlString, 'text/xml');

  const browser = doc.querySelector('Browser');
  const webService = doc.querySelector('WebService');
  const vc = doc.querySelector('VC');

  let type = 'Browser';
  let rootElement = browser;

  if (webService) {
    type = 'WebService';
    rootElement = webService;
  } else if (vc) {
    type = 'VC';
    rootElement = vc;
  }

  const config = doc.querySelector('Configuracao');

  // Extract VC interactions for flow
  const vcInteractions = [];
  if (vc) {
    const interacoes = vc.querySelectorAll('INTERACAO');
    interacoes.forEach(int => {
      const passo = int.getAttribute('PASSO');
      if (passo) vcInteractions.push(passo);
    });
  }

  return {
    name: fileName.replace('.xml', ''),
    type,
    logicalName: rootElement?.getAttribute('nomeLogico') || fileName.replace('.xml', ''),
    hasFinalization: config?.getAttribute('possuiFinalizacao') === 'S',
    isFinalStep: rootElement?.getAttribute('passoFinal') === 'Sim',
    updateBalance: rootElement?.getAttribute('atualizaSaldo') === 'Sim',
    template: extractTemplate(rootElement),
    templateFields: extractFields(rootElement),
    valorizations: extractValorizations(rootElement),
    operations: extractOperations(rootElement),
    successors: extractSuccessors(rootElement),
    vcInteractions,
    rawXml: xmlString
  };
}

function extractTemplate(element) {
  if (!element) return '';
  const template = element.querySelector('Template');
  return template?.textContent || '';
}

function extractFields(element) {
  if (!element) return [];
  const fields = [];
  const template = extractTemplate(element);

  // Extract input fields
  const inputMatches = [...template.matchAll(/<input[^>]*name=["']([^"']+)["'][^>]*>/gi)];
  for (const match of inputMatches) {
    const fieldHtml = match[0];
    const name = match[1];

    let type = 'text';
    if (/type=["']?hidden["']?/i.test(fieldHtml)) type = 'hidden';
    else if (/type=["']?radio["']?/i.test(fieldHtml)) type = 'radio';

    const maxLengthMatch = fieldHtml.match(/maxlength=["']?(\d+)["']?/i);
    fields.push({
      name,
      type,
      required: false,
      maxLength: maxLengthMatch ? parseInt(maxLengthMatch[1], 10) : undefined
    });
  }

  // Extract select fields
  const selectMatches = [...template.matchAll(/<select[^>]*name=["']([^"']+)["'][^>]*>/gi)];
  for (const match of selectMatches) {
    fields.push({ name: match[1], type: 'select', required: false });
  }

  return fields;
}

function extractValorizations(element) {
  if (!element) return [];
  const valorizations = [];
  const valElements = element.querySelectorAll('Valorizacao');

  valElements.forEach(val => {
    const formElement = val.querySelector('ValorizacaoFormulario');
    const envioElement = val.querySelector('ValorizacaoEnvioWS');

    valorizations.push({
      logicalName: val.getAttribute('nomeLogico') || '',
      predecessor: val.getAttribute('antecessor') || undefined,
      isBackNavigation: val.getAttribute('valorizacaoVoltar') === 'Sim',
      nextInteraction: formElement?.getAttribute('proximaInteracao') ||
                       envioElement?.getAttribute('proximaInteracao') || undefined,
      lists: extractLists(val),
      layouts: extractLayouts(val)
    });
  });

  return valorizations;
}

function extractLists(element) {
  const lists = [];
  const listElements = element.querySelectorAll('ValorizacaoLista, ValorizacaoListaXml');

  listElements.forEach(list => {
    const path = list.getAttribute('nomeLista') || '';
    const header = list.querySelector('TemplateCabecalho')?.textContent || '';
    const template = list.querySelector('Template')?.textContent || '';

    const fields = [];
    list.querySelectorAll('OrigemTagListaWS, OrigemListaXml').forEach(tag => {
      const fieldName = tag.getAttribute('TextWS') || tag.getAttribute('nomeCampo');
      if (fieldName) fields.push(fieldName);
    });

    lists.push({ path, headerTemplate: header, itemTemplate: template, fields });
  });

  return lists;
}

function extractLayouts(element) {
  const layouts = [];
  element.querySelectorAll('ValorizacaoListaLayout ValorizacaoLayout').forEach(layout => {
    layouts.push({
      name: layout.getAttribute('nomeLogico') || '',
      template: layout.querySelector('Template')?.textContent || ''
    });
  });
  return layouts;
}

function extractOperations(element) {
  if (!element) return [];
  const operations = [];

  element.querySelectorAll('Operacao').forEach(op => {
    const func = op.getAttribute('funcaoSemRetorno');
    if (func) {
      const params = [];
      op.querySelectorAll('OrigemConstante').forEach(param => {
        const val = param.getAttribute('valor');
        if (val) params.push(val);
      });
      operations.push({ function: func, parameters: params });
    }
  });

  return operations;
}

function extractSuccessors(element) {
  if (!element) return [];
  const successors = [];

  // Get TrocaSucessor elements
  element.querySelectorAll('TrocaSucessor').forEach(succ => {
    const nextInteraction = succ.getAttribute('proximaInteracao');
    if (nextInteraction) {
      const conditionElement = succ.querySelector('OrigemFuncaoLogica');
      const condition = extractCondition(conditionElement);
      successors.push({ condition, nextInteraction });
    }
  });

  return successors;
}

function extractCondition(element) {
  if (!element) return '';
  const func = element.getAttribute('funcaoLogica');
  const params = [];

  element.querySelectorAll('OrigemConstante').forEach(p => {
    params.push(p.getAttribute('valor') || '');
  });

  element.querySelectorAll('OrigemFuncaoLogica').forEach(nested => {
    params.push(extractCondition(nested));
  });

  return `${func}(${params.filter(p => p).join(', ')})`;
}

/**
 * Build navigation flow from screens
 */
export function buildNavigationFlow(screens) {
  const nodes = [];
  const connections = [];
  const screenMap = new Map();
  const processedConnections = new Set();

  // Build screen map for quick lookups
  screens.forEach(screen => {
    screenMap.set(screen.name, screen);
    const shortName = screen.name.split('_').pop() || screen.name;
    if (!screenMap.has(shortName)) {
      screenMap.set(shortName, screen);
    }
  });

  // Find VC (View Controller) to get the canonical flow
  const vcScreen = screens.find(s => s.type === 'VC');
  let flowOrder = [];

  if (vcScreen && vcScreen.vcInteractions) {
    flowOrder = vcScreen.vcInteractions.map(path => {
      const parts = path.split('\\');
      return parts[parts.length - 1];
    });
  }

  // Position nodes based on type grouping
  const nodeWidth = 220;
  const nodeHeight = 80;
  const horizontalGap = 60;
  const verticalGap = 40;
  const columnsPerRow = 4;

  // Group screens by type
  const browserScreens = screens.filter(s => s.type === 'Browser');
  const wsScreens = screens.filter(s => s.type === 'WebService');
  const vcScreens = screens.filter(s => s.type === 'VC');

  let currentY = 50;

  // Add VC nodes at top
  vcScreens.forEach((screen, idx) => {
    nodes.push({
      id: screen.name,
      name: screen.logicalName,
      type: screen.type,
      x: 50 + idx * (nodeWidth + horizontalGap),
      y: currentY
    });
  });

  if (vcScreens.length > 0) currentY += nodeHeight + verticalGap * 2;

  // Add WebService nodes
  wsScreens.forEach((screen, idx) => {
    const col = idx % columnsPerRow;
    const row = Math.floor(idx / columnsPerRow);
    nodes.push({
      id: screen.name,
      name: screen.logicalName,
      type: screen.type,
      x: 50 + col * (nodeWidth + horizontalGap),
      y: currentY + row * (nodeHeight + verticalGap)
    });
  });

  if (wsScreens.length > 0) {
    currentY += (Math.ceil(wsScreens.length / columnsPerRow)) * (nodeHeight + verticalGap) + verticalGap;
  }

  // Add Browser nodes
  browserScreens.forEach((screen, idx) => {
    const col = idx % columnsPerRow;
    const row = Math.floor(idx / columnsPerRow);
    nodes.push({
      id: screen.name,
      name: screen.logicalName,
      type: screen.type,
      x: 50 + col * (nodeWidth + horizontalGap),
      y: currentY + row * (nodeHeight + verticalGap)
    });
  });

  // Build connections
  screens.forEach(screen => {
    // 1. Connections from Valorizations
    screen.valorizations.forEach(val => {
      // Predecessor connection
      if (val.predecessor) {
        const fromName = extractScreenName(val.predecessor);
        const connKey = `${fromName}->${screen.name}`;
        if (!processedConnections.has(connKey) && nodeExists(nodes, fromName)) {
          connections.push({
            from: fromName,
            to: screen.name,
            type: val.isBackNavigation ? 'back' : 'normal',
            label: val.isBackNavigation ? 'Voltar' : undefined
          });
          processedConnections.add(connKey);
        }
      }

      // Next interaction connection
      if (val.nextInteraction) {
        const toName = extractScreenName(val.nextInteraction);
        const connKey = `${screen.name}->${toName}`;
        if (!processedConnections.has(connKey) && nodeExists(nodes, toName)) {
          connections.push({
            from: screen.name,
            to: toName,
            type: 'normal'
          });
          processedConnections.add(connKey);
        }
      }
    });

    // 2. Connections from TrocaSucessor (conditional navigation)
    screen.successors.forEach(succ => {
      const toName = extractScreenName(succ.nextInteraction);
      const connKey = `${screen.name}->${toName}:conditional`;
      if (!processedConnections.has(connKey)) {
        const isExternal = !nodeExists(nodes, toName);
        connections.push({
          from: screen.name,
          to: toName,
          type: 'conditional',
          label: simplifyCondition(succ.condition),
          isExternal
        });
        processedConnections.add(connKey);
      }
    });

    // 3. VC interactions define the canonical flow order
    if (screen.type === 'VC' && screen.vcInteractions) {
      for (let i = 0; i < screen.vcInteractions.length - 1; i++) {
        const fromName = extractScreenName(screen.vcInteractions[i]);
        const toName = extractScreenName(screen.vcInteractions[i + 1]);
        const connKey = `vc:${fromName}->${toName}`;
        if (!processedConnections.has(connKey)) {
          connections.push({
            from: fromName,
            to: toName,
            type: 'vc-flow',
            label: `Passo ${i + 1}`
          });
          processedConnections.add(connKey);
        }
      }
    }
  });

  return { screens: nodes, connections };
}

function extractScreenName(path) {
  if (!path) return '';
  const parts = path.split(/[\\\/]/);
  let screenName = parts[parts.length - 1];
  if (['Formulario', 'Resposta', 'Envio', 'FormularioVoltar'].includes(screenName) && parts.length > 1) {
    screenName = parts[parts.length - 2];
  }
  return screenName;
}

function nodeExists(nodes, name) {
  return nodes.some(n =>
    n.id === name ||
    n.id.includes(name) ||
    name.includes(n.id)
  );
}

function simplifyCondition(condition) {
  if (!condition) return '';
  // Simplify Igual conditions to show variable=value format
  const igualMatch = condition.match(/Igual\(\$?(\w+),\s*["']?(\w+)["']?\)/);
  if (igualMatch) return `${igualMatch[1]}=${igualMatch[2]}`;
  if (condition.length > 30) {
    return condition.substring(0, 27) + '...';
  }
  return condition;
}
