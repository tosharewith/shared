/**
 * IDS Mapping Configuration Loader for Visualizer
 *
 * Loads the shared YAML configuration from the config directory.
 * This ensures both the Angular MFE and visualizer use the same mappings.
 *
 * Usage:
 *   import { loadIdsMappingConfig, getConfig, isConfigLoaded } from './idsMappingLoader';
 *   await loadIdsMappingConfig();
 *   const cssMappings = getConfig().cssMapping;
 */

// Since we're in a browser environment without yaml package,
// we'll load the YAML and parse it using a simple parser
// For production use, consider adding the yaml package

let config = null;
let configLoaded = false;

// Fallback config values (used if YAML load fails)
const FALLBACK_CONFIG = {
  version: '1.0',
  cssMapping: {
    typography: {
      TRNtitcampo: 'ids-body-1-semibold',
      TRNcampo: 'ids-body-1',
      TRNtitulo: 'ids-heading-4',
      TRNsubtitulo: 'ids-heading-5'
    },
    layout: {
      TRNfundo: 'ids-background-light',
      TRNbordasup: 'ids-divider'
    },
    buttons: {
      TRNbotao: 'ids-button-container',
      TRNbotaoOK: 'ids-button-primary',
      TRNbotaoVoltar: 'ids-button-secondary'
    }
  },
  fontMapping: {
    generic: {
      Arial: 'ItauTextPro_Rg, Arial, sans-serif',
      default: 'ItauTextPro_Rg, Arial, sans-serif'
    },
    semantic: {
      heading: 'ItauDisplayPro_Rg, Arial, sans-serif',
      body: 'ItauTextPro_Rg, Arial, sans-serif'
    }
  },
  inputTypeMapping: {
    text: 'ids-form-control',
    date: 'ids-datepicker',
    select: 'ids-select',
    checkbox: 'ids-checkbox',
    radio: 'ids-radio-button'
  },
  fieldDetection: [
    { name: 'date', priority: 1, keywords: ['data', 'date', 'dia'], component: 'ids-datepicker' },
    { name: 'dropdown', priority: 2, types: ['ListaReceber', 'ListaMainframe'], component: 'ids-select' },
    { name: 'currency', priority: 4, keywords: ['valor', 'amount', 'saldo'], component: 'ids-currency-field' },
    { name: 'default', priority: 10, component: 'ids-text-field' }
  ],
  buttonPatterns: [
    { pattern: 'continuar|avançar|próximo|enviar|confirmar', action: 'submit', variant: 'primary' },
    { pattern: 'voltar|anterior|cancelar', action: 'back', variant: 'secondary' },
    { pattern: 'limpar|reset', action: 'reset', variant: 'tertiary' }
  ]
};

/**
 * Simple YAML parser for browser (handles basic YAML structures)
 * For complex YAML, consider using the yaml package
 */
function parseSimpleYaml(yamlText) {
  const result = {};
  const lines = yamlText.split('\n');
  const stack = [{ obj: result, indent: -1 }];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Skip empty lines and comments
    if (!line.trim() || line.trim().startsWith('#')) continue;

    // Calculate indentation
    const indent = line.search(/\S/);
    const content = line.trim();

    // Handle array items
    if (content.startsWith('- ')) {
      const parent = stack[stack.length - 1];
      const key = Object.keys(parent.obj).pop();
      if (!Array.isArray(parent.obj[key])) {
        parent.obj[key] = [];
      }
      const value = content.substring(2).trim();
      if (value.includes(':')) {
        const arrayObj = {};
        parseKeyValue(value, arrayObj);
        parent.obj[key].push(arrayObj);
      } else {
        parent.obj[key].push(parseValue(value));
      }
      continue;
    }

    // Handle key: value pairs
    const colonIndex = content.indexOf(':');
    if (colonIndex > 0) {
      const key = content.substring(0, colonIndex).trim();
      const value = content.substring(colonIndex + 1).trim();

      // Pop stack for lower indentation
      while (stack.length > 1 && stack[stack.length - 1].indent >= indent) {
        stack.pop();
      }

      const parent = stack[stack.length - 1];

      if (value === '' || value === '|') {
        // Nested object or multiline string
        parent.obj[key] = {};
        stack.push({ obj: parent.obj[key], indent });
      } else {
        parent.obj[key] = parseValue(value);
      }
    }
  }

  return result;
}

function parseKeyValue(content, obj) {
  const colonIndex = content.indexOf(':');
  if (colonIndex > 0) {
    const key = content.substring(0, colonIndex).trim();
    const value = content.substring(colonIndex + 1).trim();
    obj[key] = parseValue(value);
  }
}

function parseValue(value) {
  // Remove quotes
  if ((value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))) {
    return value.slice(1, -1);
  }
  // Boolean
  if (value === 'true') return true;
  if (value === 'false') return false;
  // Number
  if (/^\d+$/.test(value)) return parseInt(value, 10);
  if (/^\d+\.\d+$/.test(value)) return parseFloat(value);
  // Null
  if (value === 'null' || value === '~') return null;
  // Array inline (simple)
  if (value.startsWith('[') && value.endsWith(']')) {
    return value.slice(1, -1).split(',').map(v => parseValue(v.trim()));
  }
  return value;
}

/**
 * Load the IDS mapping configuration from YAML file.
 * Tries to load from public/config/ first, then falls back to fetching from config/.
 *
 * @returns {Promise<Object>} The parsed configuration object
 */
export async function loadIdsMappingConfig() {
  if (configLoaded && config) {
    return config;
  }

  const configPaths = [
    '/config/ids-mapping-config.yaml',           // Direct from config
    '../../../config/ids-mapping-config.yaml',   // Relative path
  ];

  for (const path of configPaths) {
    try {
      const response = await fetch(path);
      if (response.ok) {
        const yamlText = await response.text();
        config = parseSimpleYaml(yamlText);
        configLoaded = true;
        console.log('[IDS Mapping] Configuration loaded successfully from:', path);
        console.log('[IDS Mapping] Version:', config.version);
        return config;
      }
    } catch (err) {
      console.debug('[IDS Mapping] Could not load from:', path, err.message);
    }
  }

  // Use fallback config if YAML load fails
  console.warn('[IDS Mapping] Using fallback configuration');
  config = FALLBACK_CONFIG;
  configLoaded = true;
  return config;
}

/**
 * Check if configuration is loaded.
 */
export function isConfigLoaded() {
  return configLoaded;
}

/**
 * Get the loaded configuration.
 * @returns {Object} The configuration object
 */
export function getConfig() {
  if (!configLoaded) {
    console.warn('[IDS Mapping] Config not loaded, using fallback');
    return FALLBACK_CONFIG;
  }
  return config;
}

/**
 * Get all CSS mappings as a flat object.
 */
export function getAllCssMappings() {
  const cfg = getConfig();
  const flat = {};
  if (cfg.cssMapping) {
    for (const category of Object.values(cfg.cssMapping)) {
      Object.assign(flat, category);
    }
  }
  return flat;
}

/**
 * Get CSS mapping for a legacy class.
 */
export function getCssMapping(legacyClass) {
  return getAllCssMappings()[legacyClass];
}

/**
 * Get font mapping.
 */
export function getFontMapping(font) {
  const cfg = getConfig();
  const generic = cfg.fontMapping?.generic || {};
  const semantic = cfg.fontMapping?.semantic || {};
  return generic[font] || semantic[font] || generic.default;
}

/**
 * Get input type mapping.
 */
export function getInputTypeMapping(inputType) {
  const cfg = getConfig();
  return cfg.inputTypeMapping?.[inputType] || 'ids-form-control';
}

/**
 * Get field detection rules sorted by priority.
 * Handles both array format (from proper YAML parser) and object format (from simple parser)
 */
export function getFieldDetectionRules() {
  const cfg = getConfig();
  let rules = cfg.fieldDetection;

  // Handle case where simple YAML parser returns object instead of array
  if (rules && !Array.isArray(rules)) {
    // Convert object to array if needed
    rules = Object.entries(rules).map(([key, value]) => {
      if (typeof value === 'object' && value !== null) {
        return { name: key, ...value };
      }
      return { name: key };
    });
  }

  return (rules || []).sort((a, b) => (a.priority || 10) - (b.priority || 10));
}

/**
 * Get button patterns.
 * Handles both array format (from proper YAML parser) and object format (from simple parser)
 */
export function getButtonPatterns() {
  const cfg = getConfig();
  let patterns = cfg.buttonPatterns;

  // Handle case where simple YAML parser returns object instead of array
  if (patterns && !Array.isArray(patterns)) {
    patterns = Object.entries(patterns).map(([key, value]) => {
      if (typeof value === 'object' && value !== null) {
        return { pattern: key, ...value };
      }
      return { pattern: key };
    });
  }

  return patterns || [];
}

/**
 * Get i18n defaults for a locale.
 */
export function getI18nDefaults(locale = 'pt_BR') {
  const cfg = getConfig();
  return cfg.i18nDefaults?.[locale];
}

/**
 * Get CSS variables (theme).
 */
export function getCssVariables() {
  const cfg = getConfig();
  return cfg.cssVariables || {};
}

/**
 * Get template by name.
 */
export function getTemplate(templateName) {
  const cfg = getConfig();
  return cfg.templates?.[templateName];
}

/**
 * Helper to ensure a value is an array (handles simple YAML parser issues)
 */
function ensureArray(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  if (typeof value === 'object') return Object.values(value);
  return [value];
}

/**
 * Detect field type based on field properties using configured rules.
 */
export function detectFieldType(fieldName, fieldType, fieldSource, fieldSize, defaultValue) {
  const rules = getFieldDetectionRules();
  const nameLower = (fieldName || '').toLowerCase();

  for (const rule of rules) {
    // Convert potential objects to arrays for safe iteration
    const keywords = ensureArray(rule.keywords);
    const types = ensureArray(rule.types);
    const sources = ensureArray(rule.sources);

    // Check keywords
    if (keywords.length > 0 && keywords.some(kw => nameLower.includes(String(kw).toLowerCase()))) {
      return { ...rule, ruleName: rule.name };
    }

    // Check types
    if (types.length > 0 && fieldType && types.includes(fieldType)) {
      return { ...rule, ruleName: rule.name };
    }

    // Check sources
    if (sources.length > 0 && fieldSource && sources.includes(fieldSource)) {
      return { ...rule, ruleName: rule.name };
    }

    // Check size constraints
    if (rule.minSize && fieldSize && fieldSize >= rule.minSize) {
      return { ...rule, ruleName: rule.name };
    }

    // Default rule
    if (rule.name === 'default') {
      return { ...rule, ruleName: rule.name };
    }
  }

  return null;
}

/**
 * Detect button type based on text using configured patterns.
 */
export function detectButtonType(buttonText) {
  const patterns = getButtonPatterns();
  const textLower = (buttonText || '').toLowerCase();

  for (const pattern of patterns) {
    const regex = new RegExp(pattern.pattern, 'i');
    if (regex.test(textLower)) {
      return {
        text: buttonText,
        action: pattern.action,
        variant: pattern.variant,
        icon: pattern.icon
      };
    }
  }

  return null;
}

export default {
  loadIdsMappingConfig,
  isConfigLoaded,
  getConfig,
  getAllCssMappings,
  getCssMapping,
  getFontMapping,
  getInputTypeMapping,
  getFieldDetectionRules,
  getButtonPatterns,
  getI18nDefaults,
  getCssVariables,
  getTemplate,
  detectFieldType,
  detectButtonType
};
