import { Header, HeaderName, HeaderGlobalBar, HeaderGlobalAction } from '@carbon/react';
import { Information } from '@carbon/icons-react';
import styles from './AppHeader.module.scss';

/**
 * AppHeader Component
 * Top navigation bar with IBM Carbon Design
 */
const AppHeader = () => {
  return (
    <Header aria-label="Universal Legacy Navigation">
      <HeaderName prefix="IBM">
        Universal Legacy Visualizer
      </HeaderName>

      <HeaderGlobalBar>
        <HeaderGlobalAction
          aria-label="Information"
          tooltipAlignment="end"
          onClick={() => {
            window.open('https://www.ibm.com', '_blank');
          }}
        >
          <Information size={20} />
        </HeaderGlobalAction>
      </HeaderGlobalBar>
    </Header>
  );
};

export default AppHeader;
