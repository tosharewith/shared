/**
 * Project Generation Service
 *
 * Handles server-side ZIP generation for Angular MFE, Go, and Java projects.
 *
 * Flow:
 * 1. Receives customization parameters from frontend
 * 2. Reads base template files from disk
 * 3. Applies variable substitutions
 * 4. Overlays custom generated code
 * 5. Creates and streams ZIP back to client
 */

import * as fs from 'fs';
import * as path from 'path';
import archiver from 'archiver';
import { Writable } from 'stream';
import { logger } from '../middleware/logger';

// Template types supported
export type TemplateType = 'angular' | 'go' | 'java';

// Template configuration
const TEMPLATE_PATHS: Record<TemplateType, string> = {
  angular: path.resolve(__dirname, '../../../projects/angular/mfe-base'),
  go: path.resolve(__dirname, '../../../projects/comex-service'),
  java: path.resolve(__dirname, '../../../projects/comex-service-java'),
};

// Files/directories to exclude from templates
const EXCLUDE_PATTERNS = [
  'node_modules',
  'dist',
  '.git',
  '.DS_Store',
  '__pycache__',
  '*.pyc',
  '.idea',
  '.vscode',
  'target',
  'build',
  '.angular',
];

export interface ProjectGenerationRequest {
  templateType: TemplateType;
  projectName: string;
  mfePort?: number;
  customFiles?: Record<string, string>;
  variables?: Record<string, string>;
}

export interface TemplateVariables {
  mfeName: string;
  mfeNamePascal: string;
  mfeNameCamel: string;
  mfePort: string;
  serviceName: string;
  serviceNamePascal: string;
  serviceNameCamel: string;
  serviceNameSnake: string;
  [key: string]: string;
}

/**
 * Convert string to kebab-case
 */
function toKebabCase(str: string): string {
  return str
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '');
}

/**
 * Convert string to PascalCase
 */
function toPascalCase(str: string): string {
  return str
    .split(/[-\s]+/)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join('');
}

/**
 * Convert string to camelCase
 */
function toCamelCase(str: string): string {
  const pascal = toPascalCase(str);
  return pascal.charAt(0).toLowerCase() + pascal.slice(1);
}

/**
 * Convert string to snake_case
 */
function toSnakeCase(str: string): string {
  return str
    .toLowerCase()
    .replace(/[-\s]+/g, '_')
    .replace(/[^a-z0-9_]/g, '');
}

/**
 * Build template variables from project name
 */
function buildTemplateVariables(projectName: string, mfePort: number = 5002, templateType: TemplateType = 'angular'): TemplateVariables {
  const mfeName = toKebabCase(projectName);
  const mfeNamePascal = toPascalCase(projectName);
  const mfeNameCamel = toCamelCase(projectName);
  const serviceNameSnake = toSnakeCase(projectName);

  // Determine container port based on template type
  const containerPort = templateType === 'angular' ? '80' : '8080';

  return {
    mfeName,
    mfeNamePascal,
    mfeNameCamel,
    mfePort: String(mfePort),
    serviceName: `${mfeName}-service`,
    serviceNamePascal: `${mfeNamePascal}Service`,
    serviceNameCamel: `${mfeNameCamel}Service`,
    serviceNameSnake,
    // K8s specific variables
    projectName: mfeName,
    imageName: templateType === 'angular' ? `mf-${mfeName}` : `${mfeName}-service`,
    containerPort,
    servicePort: '80',
    namespace: 'default',
  };
}

/**
 * Apply variable substitutions to content based on template type
 */
function applySubstitutions(content: string, vars: TemplateVariables, templateType: TemplateType): string {
  let result = content;

  if (templateType === 'angular') {
    result = result.replace(/mfe-base/g, vars.mfeName);
    result = result.replace(/MfeBase/g, vars.mfeNamePascal);
    result = result.replace(/mfeBase/g, vars.mfeNameCamel);
    result = result.replace(/5001/g, vars.mfePort);
  } else if (templateType === 'go') {
    result = result.replace(/comex-service/g, vars.serviceName);
    result = result.replace(/ComexService/g, vars.serviceNamePascal);
    result = result.replace(/comexService/g, vars.serviceNameCamel);
    result = result.replace(/com\/itau\/comex/g, `com/itau/${vars.serviceNameSnake}`);
  } else if (templateType === 'java') {
    result = result.replace(/comex-service-java/g, vars.serviceName);
    result = result.replace(/com\.itau\.comex/g, `com.itau.${vars.serviceNameSnake}`);
    result = result.replace(/com\/itau\/comex/g, `com/itau/${vars.serviceNameSnake}`);
    result = result.replace(/ComexService/g, vars.serviceNamePascal);
    result = result.replace(/comexService/g, vars.serviceNameCamel);
    result = result.replace(/<artifactId>comex<\/artifactId>/g, `<artifactId>${vars.serviceNameSnake}</artifactId>`);
    result = result.replace(/<name>comex<\/name>/g, `<name>${vars.serviceName}</name>`);
  }

  // Apply any additional custom variables (${key} pattern)
  for (const [key, value] of Object.entries(vars)) {
    const placeholder = new RegExp(`\\$\\{${key}\\}`, 'g');
    result = result.replace(placeholder, value);
  }

  // Apply K8s template variables ({{KEY}} pattern - uppercase)
  result = result.replace(/\{\{PROJECT_NAME\}\}/g, vars.projectName || vars.mfeName);
  result = result.replace(/\{\{MFE_NAME\}\}/g, vars.mfeName);
  result = result.replace(/\{\{IMAGE_NAME\}\}/g, vars.imageName || `mf-${vars.mfeName}`);
  result = result.replace(/\{\{CONTAINER_PORT\}\}/g, vars.containerPort || '8080');
  result = result.replace(/\{\{SERVICE_PORT\}\}/g, vars.servicePort || '80');
  result = result.replace(/\{\{NAMESPACE\}\}/g, vars.namespace || 'default');
  result = result.replace(/\{\{MFE_PORT\}\}/g, vars.mfePort);

  return result;
}

/**
 * Check if a path should be excluded
 */
function shouldExclude(filePath: string): boolean {
  const fileName = path.basename(filePath);
  return EXCLUDE_PATTERNS.some(pattern => {
    if (pattern.includes('*')) {
      const regex = new RegExp('^' + pattern.replace('*', '.*') + '$');
      return regex.test(fileName);
    }
    return fileName === pattern || filePath.includes(`/${pattern}/`);
  });
}

/**
 * Recursively get all files in a directory
 */
function getAllFiles(dirPath: string, basePath: string = dirPath): string[] {
  const files: string[] = [];

  if (!fs.existsSync(dirPath)) {
    return files;
  }

  const entries = fs.readdirSync(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    const relativePath = path.relative(basePath, fullPath);

    if (shouldExclude(fullPath)) {
      continue;
    }

    if (entry.isDirectory()) {
      files.push(...getAllFiles(fullPath, basePath));
    } else {
      files.push(relativePath);
    }
  }

  return files;
}

/**
 * Check if file is binary
 */
function isBinaryFile(filePath: string): boolean {
  const binaryExtensions = [
    '.png', '.jpg', '.jpeg', '.gif', '.ico', '.svg',
    '.woff', '.woff2', '.ttf', '.eot',
    '.pdf', '.zip', '.gz', '.tar',
    '.exe', '.dll', '.so', '.dylib',
  ];
  const ext = path.extname(filePath).toLowerCase();
  return binaryExtensions.includes(ext);
}

/**
 * Generate ZIP archive with project files
 */
export async function generateProjectZip(
  request: ProjectGenerationRequest,
  outputStream: Writable
): Promise<void> {
  const { templateType, projectName, mfePort = 5002, customFiles = {} } = request;

  const templatePath = TEMPLATE_PATHS[templateType];
  if (!templatePath || !fs.existsSync(templatePath)) {
    throw new Error(`Template not found for type: ${templateType}`);
  }

  const vars = buildTemplateVariables(projectName, mfePort, templateType);

  // Merge any custom variables
  if (request.variables) {
    Object.assign(vars, request.variables);
  }

  logger.info('Generating project ZIP', {
    templateType,
    projectName,
    templatePath,
    customFilesCount: Object.keys(customFiles).length,
  });

  // Create ZIP archive
  const archive = archiver('zip', {
    zlib: { level: 9 }, // Maximum compression
  });

  // Pipe to output stream
  archive.pipe(outputStream);

  // Handle archive errors
  archive.on('error', (err) => {
    logger.error('Archive error', { error: err.message });
    throw err;
  });

  // Get all template files
  const templateFiles = getAllFiles(templatePath);
  const customFilePaths = new Set(Object.keys(customFiles));

  logger.info('Processing template files', {
    templateFilesCount: templateFiles.length,
    customFilesCount: customFilePaths.size,
  });

  // Add template files (excluding those that have custom versions)
  for (const relativePath of templateFiles) {
    // Skip if we have a custom version
    if (customFilePaths.has(relativePath)) {
      continue;
    }

    const fullPath = path.join(templatePath, relativePath);

    if (isBinaryFile(relativePath)) {
      // Add binary files as-is
      archive.file(fullPath, { name: relativePath });
    } else {
      // Read and apply substitutions to text files
      const content = fs.readFileSync(fullPath, 'utf-8');
      const processedContent = applySubstitutions(content, vars, templateType);
      archive.append(processedContent, { name: relativePath });
    }
  }

  // Add custom files (overlay on top of template)
  for (const [filePath, content] of Object.entries(customFiles)) {
    archive.append(content, { name: filePath });
  }

  // Finalize archive
  await archive.finalize();

  logger.info('ZIP generation complete', {
    templateType,
    projectName,
    totalFiles: templateFiles.length + Object.keys(customFiles).length,
  });
}

/**
 * Get list of available templates
 */
export function getAvailableTemplates(): { id: TemplateType; name: string; path: string; exists: boolean }[] {
  return [
    {
      id: 'angular',
      name: 'Angular MFE',
      path: TEMPLATE_PATHS.angular,
      exists: fs.existsSync(TEMPLATE_PATHS.angular),
    },
    {
      id: 'go',
      name: 'Go Service',
      path: TEMPLATE_PATHS.go,
      exists: fs.existsSync(TEMPLATE_PATHS.go),
    },
    {
      id: 'java',
      name: 'Java Spring Boot',
      path: TEMPLATE_PATHS.java,
      exists: fs.existsSync(TEMPLATE_PATHS.java),
    },
  ];
}
