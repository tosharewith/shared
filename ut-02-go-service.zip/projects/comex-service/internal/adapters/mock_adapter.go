// Package adapters - Mock Adapter for Development/Testing
//
// This adapter returns fake data for development and testing purposes.
// Use ADAPTER_DEFAULT=MOCK environment variable to enable.
package adapters

import (
	"context"
	"time"

	"comex-service/internal/domain"
)

// MockAdapter implements COMEXAdapter with fake data
type MockAdapter struct{}

// NewMockAdapter creates a new mock adapter
func NewMockAdapter() *MockAdapter {
	return &MockAdapter{}
}

// =============================================================================
// COMPANIES
// =============================================================================

func (a *MockAdapter) ListCompanies(ctx context.Context, userCPF string) ([]domain.Company, error) {
	return []domain.Company{
		{CNPJ: "12345678000190", Name: "Empresa ABC Ltda", Type: domain.CompanyTypeNormal, Active: true},
		{CNPJ: "98765432000121", Name: "Empresa XYZ S.A.", Type: domain.CompanyTypeNormal, Active: true},
		{CNPJ: "11222333000144", Name: "Offshore Holdings Ltd", Type: domain.CompanyTypeOffshore, Active: true},
	}, nil
}

func (a *MockAdapter) GetCompanyDetails(ctx context.Context, cnpj string) (*domain.Company, error) {
	return &domain.Company{
		CNPJ:   cnpj,
		Name:   "Empresa Exemplo Ltda",
		Type:   domain.CompanyTypeNormal,
		Active: true,
	}, nil
}

// =============================================================================
// BILLING OPERATIONS (BAL1)
// =============================================================================

func (a *MockAdapter) QueryBillingOperations(ctx context.Context, query domain.BillingQuery) (*domain.BillingQueryResponse, error) {
	return &domain.BillingQueryResponse{
		Operations: []domain.BillingOperation{
			{
				ID:               "BAL1-001",
				CNPJ:             query.CNPJ,
				CompanyName:      "Empresa ABC Ltda",
				RegistrationDate: "2024-01-15",
				MaturityDate:     "2024-04-15",
				InvoiceNumber:    "INV-2024-001",
				Amount:           50000.00,
				Currency:         "USD",
				Status:           domain.OperationStatusOpen,
			},
			{
				ID:               "BAL1-002",
				CNPJ:             query.CNPJ,
				CompanyName:      "Empresa ABC Ltda",
				RegistrationDate: "2024-01-20",
				MaturityDate:     "2024-04-20",
				InvoiceNumber:    "INV-2024-002",
				Amount:           75000.00,
				Currency:         "EUR",
				Status:           domain.OperationStatusOpen,
			},
		},
		TotalCount: 2,
		Summary: &domain.BillingSummary{
			TotalAmount: 125000.00,
			Currency:    "USD",
		},
	}, nil
}

func (a *MockAdapter) GetBillingOperationDetails(ctx context.Context, id string) (*domain.BillingOperation, error) {
	return &domain.BillingOperation{
		ID:               id,
		CNPJ:             "12345678000190",
		CompanyName:      "Empresa ABC Ltda",
		RegistrationDate: "2024-01-15",
		MaturityDate:     "2024-04-15",
		InvoiceNumber:    "INV-2024-001",
		Amount:           50000.00,
		Currency:         "USD",
		Status:           domain.OperationStatusOpen,
	}, nil
}

// =============================================================================
// PAYMENT ORDERS (BAL3)
// =============================================================================

func (a *MockAdapter) QueryPaymentOrders(ctx context.Context, query domain.PaymentOrderQuery) (*domain.PaymentOrdersResponse, error) {
	return &domain.PaymentOrdersResponse{
		Orders: []domain.PaymentOrder{
			{
				ID:              "OPRE-001",
				CNPJ:            query.CNPJ,
				CompanyName:     "Empresa ABC Ltda",
				OrderDate:       "2024-02-01",
				LiquidationDate: "",
				Amount:          25000.00,
				Currency:        "USD",
				Beneficiary:     "International Corp",
				Status:          domain.OperationStatusOpen,
			},
		},
		TotalCount: 1,
	}, nil
}

func (a *MockAdapter) GetPaymentOrderDetails(ctx context.Context, id string) (*domain.PaymentOrder, error) {
	return &domain.PaymentOrder{
		ID:          id,
		CNPJ:        "12345678000190",
		CompanyName: "Empresa ABC Ltda",
		OrderDate:   "2024-02-01",
		Amount:      25000.00,
		Currency:    "USD",
		Beneficiary: "International Corp",
		Status:      domain.OperationStatusOpen,
	}, nil
}

func (a *MockAdapter) GetPaymentOrderStatus(ctx context.Context, id string) (string, error) {
	return "OPEN", nil
}

// =============================================================================
// LETTERS OF CREDIT (BAL7)
// =============================================================================

func (a *MockAdapter) QueryLettersOfCredit(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error) {
	return &domain.LCQueryResponse{
		Letters: []domain.LetterOfCredit{
			{
				ID:          "LC-001",
				CNPJ:        query.CNPJ,
				CompanyName: "Empresa ABC Ltda",
				IssueDate:   "2024-01-10",
				ExpiryDate:  "2024-07-10",
				Amount:      100000.00,
				Currency:    "USD",
				Beneficiary: "Export Partner Inc",
				Status:      domain.LCStatusIssued,
			},
		},
		TotalCount: 1,
	}, nil
}

func (a *MockAdapter) GetLetterOfCreditDetails(ctx context.Context, id string) (*domain.LetterOfCredit, error) {
	return &domain.LetterOfCredit{
		ID:          id,
		CNPJ:        "12345678000190",
		CompanyName: "Empresa ABC Ltda",
		IssueDate:   "2024-01-10",
		ExpiryDate:  "2024-07-10",
		Amount:      100000.00,
		Currency:    "USD",
		Beneficiary: "Export Partner Inc",
		Status:      domain.LCStatusIssued,
	}, nil
}

func (a *MockAdapter) QueryReceivedLetters(ctx context.Context, query domain.LCQuery) (*domain.LCQueryResponse, error) {
	return &domain.LCQueryResponse{
		Letters:    []domain.LetterOfCredit{},
		TotalCount: 0,
	}, nil
}

// =============================================================================
// FX QUOTATIONS (BAEI)
// =============================================================================

func (a *MockAdapter) QueryFXQuotations(ctx context.Context, query domain.FXQuery) (*domain.FXQueryResponse, error) {
	return &domain.FXQueryResponse{
		Quotations: []domain.FXQuotation{
			{
				ID:           "FX-001",
				CNPJ:         query.CNPJ,
				CompanyName:  "Empresa ABC Ltda",
				QuoteDate:    "2024-02-15",
				CurrencyPair: "USD/BRL",
				Rate:         4.95,
				Amount:       50000.00,
				Status:       domain.FXStatusEdited,
			},
		},
		TotalCount: 1,
	}, nil
}

func (a *MockAdapter) GetQuotationDetails(ctx context.Context, id string) (*domain.FXQuotation, error) {
	return &domain.FXQuotation{
		ID:           id,
		CNPJ:         "12345678000190",
		CompanyName:  "Empresa ABC Ltda",
		QuoteDate:    "2024-02-15",
		CurrencyPair: "USD/BRL",
		Rate:         4.95,
		Amount:       50000.00,
		Status:       domain.FXStatusEdited,
	}, nil
}

func (a *MockAdapter) GetExchangeRates(ctx context.Context, currencies []string) ([]domain.ExchangeRate, error) {
	now := time.Now().Format(time.RFC3339)
	return []domain.ExchangeRate{
		{CurrencyPair: "USD/BRL", Bid: 4.93, Ask: 4.97, Timestamp: now},
		{CurrencyPair: "EUR/BRL", Bid: 5.35, Ask: 5.40, Timestamp: now},
		{CurrencyPair: "GBP/BRL", Bid: 6.25, Ask: 6.30, Timestamp: now},
	}, nil
}

func (a *MockAdapter) SimulateExchange(ctx context.Context, from, to string, amount float64) (*domain.ExchangeSimulation, error) {
	rate := 4.95
	result := amount * rate
	return &domain.ExchangeSimulation{
		FromCurrency: from,
		ToCurrency:   to,
		Amount:       amount,
		Rate:         rate,
		Result:       result,
		Fee:          result * 0.001, // 0.1% fee
		ValidUntil:   time.Now().Add(5 * time.Minute).Format(time.RFC3339),
	}, nil
}

// =============================================================================
// SWIFT
// =============================================================================

func (a *MockAdapter) ListSWIFTMessages(ctx context.Context, status, dateFrom, dateTo string) ([]domain.SWIFTMessage, error) {
	return []domain.SWIFTMessage{
		{
			UETR:        "550e8400-e29b-41d4-a716-446655440000",
			MessageType: "MT103",
			SenderBIC:   "ITABORJXXXX",
			ReceiverBIC: "CHABORJXXXX",
			Amount:      50000.00,
			Currency:    "USD",
			Beneficiary: "International Corp",
			Reference:   "REF-2024-001",
			Status:      "DELIVERED",
			CreatedAt:   "2024-02-01T10:30:00Z",
			DeliveredAt: "2024-02-01T10:31:00Z",
		},
	}, nil
}

func (a *MockAdapter) GetSWIFTMessageDetails(ctx context.Context, uetr string) (*domain.SWIFTMessage, error) {
	return &domain.SWIFTMessage{
		UETR:        uetr,
		MessageType: "MT103",
		SenderBIC:   "ITABORJXXXX",
		ReceiverBIC: "CHABORJXXXX",
		Amount:      50000.00,
		Currency:    "USD",
		Beneficiary: "International Corp",
		Reference:   "REF-2024-001",
		Status:      "DELIVERED",
		CreatedAt:   "2024-02-01T10:30:00Z",
		DeliveredAt: "2024-02-01T10:31:00Z",
	}, nil
}

func (a *MockAdapter) SendSWIFTMessage(ctx context.Context, req domain.SWIFTMessageRequest) (*domain.SWIFTMessageResponse, error) {
	return &domain.SWIFTMessageResponse{
		UETR:    "550e8400-e29b-41d4-a716-446655440001",
		Status:  "ACCEPTED",
		Message: "Message queued for delivery",
	}, nil
}

// =============================================================================
// HEALTH
// =============================================================================

func (a *MockAdapter) Ping(ctx context.Context) error {
	return nil // Always healthy in mock
}
