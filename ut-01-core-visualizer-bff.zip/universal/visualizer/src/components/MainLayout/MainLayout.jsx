import { useState } from 'react';
import AppHeader from '../AppHeader/AppHeader';
import MenuExplorer from '../MenuExplorer/MenuExplorer';
import TransactionViewer from '../TransactionViewer/TransactionViewer';
import styles from './MainLayout.module.scss';

/**
 * MainLayout Component
 * Application layout with menu navigation and transaction visualization
 * Upload functionality is now integrated into the MenuExplorer's _Custom section
 */
const MainLayout = () => {
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const handleTransactionSelect = (transaction) => {
    console.log('Selected transaction:', transaction);
    setSelectedTransaction(transaction);
  };

  const handleCloseTransaction = () => {
    setSelectedTransaction(null);
  };

  const handleToggleSidebar = () => {
    setIsSidebarCollapsed(prev => !prev);
  };

  return (
    <div className={styles.mainLayout}>
      <AppHeader />

      <div className={styles.contentArea}>
        <MenuExplorer
          onTransactionSelect={handleTransactionSelect}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={handleToggleSidebar}
        />

        <main className={styles.mainContent}>
          {selectedTransaction ? (
            <TransactionViewer
              transaction={selectedTransaction}
              onClose={handleCloseTransaction}
            />
          ) : (
            <div className={styles.welcome}>
              <div className={styles.welcomeContent}>
                <h1>Universal Menu Visualizer</h1>
                <p>Selecione um canal e uma transação no menu lateral para visualizar o fluxo completo.</p>

                <div className={styles.features}>
                  <div className={styles.feature}>
                    <h3>Navegação por Canais</h3>
                    <p>24 canais bancários disponíveis para exploração</p>
                  </div>
                  <div className={styles.feature}>
                    <h3>Fluxo de Transações</h3>
                    <p>Visualização gráfica interativa do fluxo de cada transação</p>
                  </div>
                  <div className={styles.feature}>
                    <h3>Detalhes de Interações</h3>
                    <p>Browser, WebService, ADO, Mainframe e mais</p>
                  </div>
                  <div className={styles.feature}>
                    <h3>Sugestões Angular</h3>
                    <p>Mapeamento para componentes e rotas Angular</p>
                  </div>
                </div>

                <div className={styles.instructions}>
                  <h3>Como usar:</h3>
                  <ol>
                    <li>Use a seção <strong>_Custom</strong> no menu para upload de XMLs</li>
                    <li>Ou expanda um canal existente (ex: EmpPlus Empresa)</li>
                    <li>Navegue pela hierarquia de pastas do menu</li>
                    <li>Clique em uma transação para visualizar seu fluxo</li>
                    <li>Explore as abas: Fluxo Visual, Interações, Entry Points, Angular</li>
                  </ol>
                </div>

                <div className={styles.uploadHint}>
                  <p>Use a seção <strong>_Custom</strong> no menu lateral para carregar seus próprios arquivos QuickWeb.</p>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default MainLayout;
