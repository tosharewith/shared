/**
 * Cytoscape.js style configurations
 * Matching the HTML visualizer's IBM Carbon Design System colors and styles
 */

/**
 * Node styles for different object types (from HTML visualizer)
 * Professional pastel colors with darker borders
 */
export const nodeStyles = {
  'Informix Table': { color: '#d0e2ff', borderColor: '#0043ce', shape: 'rectangle' },
  'Informix Procedure': { color: '#e8daff', borderColor: '#6929c4', shape: 'roundrectangle' },
  'Informix Function': { color: '#ffd6e8', borderColor: '#9f1853', shape: 'ellipse' },
  'Informix Trigger': { color: '#9ef0f0', borderColor: '#005d5d', shape: 'diamond' },
  // yFiles format types
  'Process': { color: '#ffd6e8', borderColor: '#9f1853', shape: 'roundrectangle' },
  'Start': { color: '#a7f0ba', borderColor: '#0e6027', shape: 'ellipse' },
  'Event': { color: '#d0e2ff', borderColor: '#0043ce', shape: 'ellipse' },
  'Data': { color: '#ffd9be', borderColor: '#ba4e00', shape: 'rectangle' },
  // Generic types (for compatibility)
  'Table': { color: '#d0e2ff', borderColor: '#0043ce', shape: 'rectangle' },
  'Procedure': { color: '#e8daff', borderColor: '#6929c4', shape: 'roundrectangle' },
  'Function': { color: '#ffd6e8', borderColor: '#9f1853', shape: 'ellipse' },
  'Trigger': { color: '#9ef0f0', borderColor: '#005d5d', shape: 'diamond' },
  'View': { color: '#a7f0ba', borderColor: '#0e6027', shape: 'round-triangle' },
  'Stored Procedure': { color: '#ffd9be', borderColor: '#ba4e00', shape: 'round-diamond' },
  'Unknown': { color: '#e0e0e0', borderColor: '#393939', shape: 'ellipse' },
};

/**
 * Edge styles for different link types (from HTML visualizer)
 * IBM Carbon Design Color System
 */
export const edgeStyles = {
  'SELECT': '#78a9ff',  // IBM Blue 40
  'INSERT': '#6fdc8c',  // IBM Green 40
  'UPDATE': '#ffb784',  // IBM Orange 40
  'DELETE': '#ff99a2',  // IBM Red 40
  'REFER': '#be95ff',   // IBM Purple 40
  'calls': '#82cfff',   // IBM Blue 30
  'CALLS': '#82cfff',   // IBM Blue 30
  'Reference': '#be95ff', // IBM Purple 40
  'Call': '#82cfff',    // IBM Blue 30
  'Execute': '#ffb784',  // IBM Orange 40
  // SP1NBP specific edge types
  'has_valorizacao': '#8a3ffc',  // IBM Purple 50 - component to valorizacao
  'has_finalization': '#da1e28', // IBM Red 60 - component to finalization
  'workflow_step': '#00539a',    // IBM Blue 90 - VisaoCliente to workflow step
  'EnvioWS': '#0f62fe',          // IBM Blue 60 - WebService call
  'Formulario': '#24a148',       // IBM Green 50 - Form submission
  'Lista': '#ff832b',            // IBM Orange 50 - List navigation
  'Formulario_conditional': '#198038', // IBM Green 60 - Conditional form
  'EnvioWS_conditional': '#002d9c',    // IBM Blue 80 - Conditional WS
  'Lista_conditional': '#ba4e00',      // IBM Orange 70 - Conditional list
};

/**
 * Base Cytoscape styles matching HTML visualizer
 */
export const cytoscapeStyles = [
  // Node styles - matching HTML visualizer exactly
  {
    selector: 'node',
    style: {
      'background-color': 'data(color)',
      'label': 'data(label)',
      'width': 'data(width)',
      'height': 'data(height)',
      'text-valign': 'bottom',     // Text below node (not center)
      'text-halign': 'center',
      'font-family': 'IBM Plex Sans, sans-serif',
      'font-size': '11px',
      'font-weight': 500,
      'text-wrap': 'wrap',
      'text-max-width': '80px',
      'shape': 'data(shape)',
      'text-outline-width': 0,
      'color': '#000000',          // Pure black for maximum contrast (was #161616)
      'text-margin-y': 6,
      'border-width': 3,
      'border-color': 'data(borderColor)',
      'border-opacity': 1,
    },
  },

  // Selected node
  {
    selector: 'node:selected',
    style: {
      'border-width': 4,
      'border-color': '#0f62fe',
      'overlay-color': '#0f62fe',
      'overlay-opacity': 0.2,
      'overlay-padding': 10,
    },
  },

  // Highlighted node (search results)
  {
    selector: 'node.highlighted',
    style: {
      'border-width': 4,
      'border-color': '#f1c21b', // IBM Yellow for search highlight
      'border-opacity': 1,
      opacity: 1,
      'z-index': 999,
    },
  },

  // Dimmed/faded node (when others are highlighted)
  {
    selector: 'node.faded',
    style: {
      opacity: 0.3,
    },
  },

  // Hidden node (filtered out)
  {
    selector: 'node.hidden',
    style: {
      display: 'none',
    },
  },

  // Edge styles - matching HTML visualizer
  {
    selector: 'edge',
    style: {
      'width': (ele) => {
        const count = ele.data('count') || 1;
        return Math.min(2 + count * 0.5, 6);
      },
      'line-color': 'data(color)',
      'curve-style': 'bezier',
      'target-arrow-color': 'data(color)',
      'target-arrow-shape': 'triangle',
      'arrow-scale': 1.2,
      'label': 'data(label)',  // Show edge labels to display navigation types
      'font-family': 'IBM Plex Mono, monospace', // Monospace for better readability
      'font-size': '12px', // Increased from 9px for better visibility
      'font-weight': 600, // Bolder for better contrast
      'text-rotation': 'autorotate',
      'text-background-opacity': 0.98, // More opaque background
      'text-background-color': '#ffffff',
      'text-background-padding': '5px', // More padding around text
      'text-background-shape': 'roundrectangle',
      'color': '#000000', // Pure black for maximum contrast
      'text-outline-color': '#ffffff',
      'text-outline-width': '1px',
      'opacity': (ele) => {
        const count = ele.data('count') || 1;
        return Math.min(0.7 + count * 0.05, 1);
      },
    },
  },

  // Edge with label (when enabled)
  {
    selector: 'edge.show-label',
    style: {
      'label': 'data(label)',
    },
  },

  // Hover effect on edges - Shows they're clickable
  {
    selector: 'edge:active',
    style: {
      'width': 4,
      'overlay-color': '#0f62fe',
      'overlay-opacity': 0.15,
      'overlay-padding': 3,
    },
  },

  // Selected edge - Make it very prominent
  {
    selector: 'edge:selected',
    style: {
      'width': 5,
      'line-color': '#0f62fe', // IBM Blue
      'target-arrow-color': '#0f62fe',
      'overlay-color': '#0f62fe',
      'overlay-opacity': 0.3,
      'overlay-padding': 6,
      'font-size': '14px', // Larger font when selected
      'font-weight': 700, // Extra bold
      'text-background-color': '#d0e2ff', // Light blue background
      'text-background-padding': '6px',
      'z-index': 1000,
    },
  },

  // Highlighted edge (connected to highlighted node)
  {
    selector: 'edge.highlighted',
    style: {
      'width': 4,
      'line-color': '#0f62fe',
      'target-arrow-color': '#0f62fe',
      opacity: 1,
      'z-index': 999,
    },
  },

  // Dimmed/faded edge
  {
    selector: 'edge.faded',
    style: {
      opacity: 0.15,
    },
  },

  // Hidden edge (filtered out)
  {
    selector: 'edge.hidden',
    style: {
      display: 'none',
    },
  },

  // Sequential flow edge (has flowStep attribute)
  {
    selector: 'edge[flowStep]',
    style: {
      'width': 3,
      'line-color': '#24a148', // IBM Green for flow edges
      'target-arrow-color': '#24a148',
      'line-style': 'solid',
      'opacity': 0.9,
      'z-index': 100, // Higher than regular edges
    },
  },
];

/**
 * Create Cytoscape-compatible elements from Objects and Links
 * @param {Array} objects - Array of objects with properties
 * @param {Array} links - Array of links between objects
 * @returns {Object} - { nodes: [], edges: [] }
 */
export function createCytoscapeElements(objects, links) {
  // Create nodes from objects
  const nodes = objects.map(obj => {
    const type = obj["Object Type"] || "Unknown";
    const style = nodeStyles[type] || nodeStyles["Unknown"];

    // Calculate node size based on complexity
    let size = 18;
    const complexity = parseInt(obj["Cyclomatic Complexity"] || "0");
    if (complexity > 0) {
      size += Math.min(complexity * 0.5, 15);
    }

    return {
      group: 'nodes',
      data: {
        id: obj["Object ID"],
        label: obj["Object Name"],
        fullName: obj["Object Full Name"],
        type: type,
        color: style.color,
        borderColor: style.borderColor,
        shape: style.shape,
        width: size,
        height: size,
        original: obj,
      },
    };
  });

  // Create edges from links
  const edges = links.map((link, index) => {
    const source = link["Caller Object ID"];
    const target = link["Callee Object ID"];
    const type = link["Link Type"] || "Reference";
    const color = edgeStyles[type] || '#999';

    return {
      group: 'edges',
      data: {
        id: 'e' + index,
        source: source,
        target: target,
        label: type,
        type: type,
        color: color,
        original: link,
      },
    };
  });

  return { nodes, edges };
}

/**
 * Get color for node type
 * @param {string} type - Node type
 * @returns {string} Hex color
 */
export const getNodeColor = (type) => {
  return nodeStyles[type]?.color || nodeStyles["Unknown"].color;
};

/**
 * Get color for edge type
 * @param {string} type - Edge type
 * @returns {string} Hex color
 */
export const getEdgeColor = (type) => {
  return edgeStyles[type] || '#999';
};

/**
 * Filter badge pastel color schemes (matching HTML visualizer)
 * Each type has: background (light pastel), border (medium), text (dark)
 */
export const nodeFilterColors = {
  'Informix Table': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Informix Procedure': { bg: '#e8daff', border: '#be95ff', text: '#491d8b' },
  'Informix Function': { bg: '#ffd6e8', border: '#ff7eb6', text: '#740937' },
  'Informix Trigger': { bg: '#9ef0f0', border: '#3ddbd9', text: '#004144' },
  'Table': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Procedure': { bg: '#e8daff', border: '#be95ff', text: '#491d8b' },
  'Function': { bg: '#ffd6e8', border: '#ff7eb6', text: '#740937' },
  'Trigger': { bg: '#9ef0f0', border: '#3ddbd9', text: '#004144' },
  'Process': { bg: '#ffd6e8', border: '#ff7eb6', text: '#740937' },
  'Start': { bg: '#a7f0ba', border: '#6fdc8c', text: '#044317' },
  'Event': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Data': { bg: '#ffd9be', border: '#ffb784', text: '#8a3800' },
  'View': { bg: '#a7f0ba', border: '#6fdc8c', text: '#044317' },
  'Stored Procedure': { bg: '#ffd9be', border: '#ffb784', text: '#8a3800' },
  'Unknown': { bg: '#e0e0e0', border: '#a8a8a8', text: '#161616' },
};

export const edgeFilterColors = {
  'SELECT': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'INSERT': { bg: '#a7f0ba', border: '#6fdc8c', text: '#044317' },
  'UPDATE': { bg: '#ffd9be', border: '#ffb784', text: '#8a3800' },
  'DELETE': { bg: '#ffd7d9', border: '#ff99a2', text: '#750e13' },
  'REFER': { bg: '#e8daff', border: '#be95ff', text: '#491d8b' },
  'calls': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'CALLS': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Reference': { bg: '#e8daff', border: '#be95ff', text: '#491d8b' },
  'Call': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Execute': { bg: '#ffd9be', border: '#ffb784', text: '#8a3800' },
  // SP1NBP edge types
  'has_valorizacao': { bg: '#e8daff', border: '#be95ff', text: '#491d8b' },
  'has_finalization': { bg: '#ffd7d9', border: '#ff8389', text: '#750e13' },
  'workflow_step': { bg: '#bae6ff', border: '#00539a', text: '#001d32' },
  'EnvioWS': { bg: '#d0e2ff', border: '#78a9ff', text: '#002d9c' },
  'Formulario': { bg: '#a7f0ba', border: '#6fdc8c', text: '#044317' },
  'Lista': { bg: '#ffd9be', border: '#ffb784', text: '#8a3800' },
  'Formulario_conditional': { bg: '#a7f0ba', border: '#42be65', text: '#044317' },
  'EnvioWS_conditional': { bg: '#d0e2ff', border: '#4589ff', text: '#002d9c' },
  'Lista_conditional': { bg: '#ffd9be', border: '#ff832b', text: '#8a3800' },
};

/**
 * Get filter badge colors for node type (pastel scheme)
 * @param {string} type - Node type
 * @returns {Object} { bg, border, text }
 */
export const getNodeFilterColors = (type) => {
  return nodeFilterColors[type] || nodeFilterColors['Unknown'];
};

/**
 * Get filter badge colors for edge type (pastel scheme)
 * @param {string} type - Edge type
 * @returns {Object} { bg, border, text }
 */
export const getEdgeFilterColors = (type) => {
  return edgeFilterColors[type] || { bg: '#e0e0e0', border: '#a8a8a8', text: '#525252' };
};

/**
 * Get all unique node types from elements
 * @param {Array} elements - Cytoscape elements (nodes and edges)
 * @returns {Array} Unique node types
 */
export const getNodeTypes = (elements) => {
  const types = new Set();
  elements.forEach((el) => {
    if (el.group === 'nodes' && el.data.type) {
      types.add(el.data.type);
    }
  });
  return Array.from(types).sort();
};

/**
 * Get all unique edge types from elements
 * @param {Array} elements - Cytoscape elements (nodes and edges)
 * @returns {Array} Unique edge types
 */
export const getEdgeTypes = (elements) => {
  const types = new Set();
  elements.forEach((el) => {
    if (el.group === 'edges' && el.data.type) {
      types.add(el.data.type);
    }
  });
  return Array.from(types).sort();
};
