# COMEX Service (Go)

Go backend service for COMEX operations. Provides REST API endpoints for companies, billing, payments, letters of credit, FX quotations, and SWIFT messages.

## Quick Start

### Prerequisites

- Go 1.21+
- Docker (optional, for containerization)
- kubectl (optional, for Kubernetes deployment)

### Local Development

```bash
# Install dependencies
go mod download

# Run with mock adapter (development)
make run

# Or directly:
ADAPTER_DEFAULT=MOCK go run ./cmd/main.go
```

Service runs at: http://localhost:8080

### Build

```bash
# Build binary
make build

# Binary location: bin/comex-service
```

### Test

```bash
# Run tests
make test

# Run tests with coverage
make test-coverage
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check |
| GET | `/api/v1/comex/companies` | List companies |
| GET | `/api/v1/comex/companies/:cnpj` | Get company details |
| POST | `/api/v1/comex/export/billing/query` | Query billing operations |
| POST | `/api/v1/comex/payment-orders/query` | Query payment orders |
| POST | `/api/v1/comex/export/letters-of-credit/query` | Query letters of credit |
| POST | `/api/v1/comex/fx/quotations/query` | Query FX quotations |
| GET | `/api/v1/comex/fx/rates` | Get exchange rates |
| GET | `/api/v1/comex/swift/messages` | List SWIFT messages |
| GET | `/api/v1/comex/swift/messages/:uetr` | Get SWIFT message details |

## Configuration

Environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `8080` | Server port |
| `ADAPTER_DEFAULT` | `MOCK` | Backend adapter (MOCK, ORACLE, AWS, MQ) |
| `ORACLE_WS_URL` | - | Oracle wsBankline URL |
| `ORACLE_USERNAME` | - | Oracle username |
| `ORACLE_PASSWORD` | - | Oracle password |
| `AWS_REGION` | - | AWS region |
| `AWS_LAMBDA_FUNCTION` | - | AWS Lambda function name |

## Docker

```bash
# Build image
make docker-build

# Run container
make docker-run

# Or manually:
docker build -t comex-service .
docker run -p 8080:8080 -e ADAPTER_DEFAULT=MOCK comex-service
```

## Kubernetes Deployment

```bash
# Apply manifests
make k8s-apply

# Or with kubectl:
kubectl apply -k k8s/

# Check status
kubectl get pods -l app=comex-service

# View logs
make k8s-logs
```

## Project Structure

```
.
├── cmd/
│   └── main.go              # Entry point
├── internal/
│   ├── adapters/            # Backend adapters
│   │   ├── comex_adapter.go # Interface + factory
│   │   ├── mock_adapter.go  # Mock implementation
│   │   ├── oracle_adapter.go
│   │   ├── aws_adapter.go
│   │   └── mq_adapter.go
│   ├── domain/
│   │   └── types.go         # Domain models
│   ├── handlers/
│   │   └── comex_handler.go # HTTP handlers
│   ├── routes/
│   │   └── comex_routes.go  # Route definitions
│   └── services/
│       └── comex_service.go # Business logic
├── k8s/                     # Kubernetes manifests
├── Dockerfile
├── Makefile
└── go.mod
```

## License

Internal use only - Itaú Unibanco
