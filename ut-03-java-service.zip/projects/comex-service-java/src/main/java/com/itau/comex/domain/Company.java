package com.itau.comex.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Company domain model
 * Represents a company with COMEX access (from ConsultaCNPJS.xml)
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Company {
    private String cnpj;
    private String name;
    private CompanyType type;
    private boolean active;

    public enum CompanyType {
        NORMAL("N"),
        OFFSHORE("S");

        private final String code;

        CompanyType(String code) {
            this.code = code;
        }

        public String getCode() {
            return code;
        }
    }
}
