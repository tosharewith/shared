// Package domain contains domain types for COMEX
//
// These types are used throughout the application and are
// independent of any infrastructure (database, API format, etc).
package domain

// =============================================================================
// ENUMS
// =============================================================================

// DateType represents the type of date filter
type DateType string

const (
	DateTypeRegistration DateType = "R" // Registro
	DateTypeMaturity     DateType = "V" // Vencimento
	DateTypeLiquidation  DateType = "L" // Liquidação
)

// CompanyType represents the company type filter
type CompanyType string

const (
	CompanyTypeAll      CompanyType = " " // Todas
	CompanyTypeNormal   CompanyType = "N" // Normal
	CompanyTypeOffshore CompanyType = "S" // OffShore
)

// OperationStatus represents operation status
type OperationStatus string

const (
	OperationStatusOpen      OperationStatus = "OPEN"
	OperationStatusClosed    OperationStatus = "CLOSED"
	OperationStatusCancelled OperationStatus = "CANCELLED"
	OperationStatusPending   OperationStatus = "PENDING"
	OperationStatusLiquidated OperationStatus = "LIQUIDATED"
)

// FXStatus represents FX quotation status
type FXStatus string

const (
	FXStatusAwaiting FXStatus = "0" // Aguardando Dados Adicionais
	FXStatusPartial  FXStatus = "2" // Parcialmente Editada
	FXStatusEdited   FXStatus = "3" // Editada
	FXStatusAll      FXStatus = "5" // Todas
)

// =============================================================================
// COMPANY (from ConsultaCNPJS.xml)
// =============================================================================

// Company represents a company with COMEX access
type Company struct {
	CNPJ   string      `json:"cnpj"`
	Name   string      `json:"name"`
	Type   CompanyType `json:"type,omitempty"`
	Active bool        `json:"active,omitempty"`
}

// CompanyListResponse contains list of companies
type CompanyListResponse struct {
	Companies  []Company `json:"companies"`
	TotalCount int       `json:"totalCount"`
}

// =============================================================================
// BILLING OPERATIONS (from Tela_Entrada_Dados.xml → BAL1)
// =============================================================================

// BillingQuery represents query parameters for billing operations
type BillingQuery struct {
	CNPJ          string      `json:"cnpj"`
	DateFrom      string      `json:"dateFrom,omitempty"`
	DateTo        string      `json:"dateTo,omitempty"`
	InvoiceNumber string      `json:"invoiceNumber,omitempty"`
	DateType      DateType    `json:"dateType,omitempty"`
	CompanyType   CompanyType `json:"companyType,omitempty"`
}

// BillingOperation represents an export billing operation
type BillingOperation struct {
	ID               string          `json:"id"`
	CNPJ             string          `json:"cnpj"`
	CompanyName      string          `json:"companyName"`
	RegistrationDate string          `json:"registrationDate"`
	MaturityDate     string          `json:"maturityDate"`
	InvoiceNumber    string          `json:"invoiceNumber"`
	Amount           float64         `json:"amount"`
	Currency         string          `json:"currency"`
	Status           OperationStatus `json:"status"`
}

// BillingQueryResponse contains billing query results
type BillingQueryResponse struct {
	Operations []BillingOperation `json:"operations"`
	TotalCount int                `json:"totalCount"`
	Summary    *BillingSummary    `json:"summary,omitempty"`
}

// BillingSummary contains aggregated billing data
type BillingSummary struct {
	TotalAmount float64 `json:"totalAmount"`
	Currency    string  `json:"currency"`
}

// =============================================================================
// PAYMENT ORDERS (from Tela_Entrada_OPRE.xml → BAL3)
// =============================================================================

// PaymentOrderQuery represents query parameters for payment orders
type PaymentOrderQuery struct {
	CNPJ     string   `json:"cnpj"`
	DateFrom string   `json:"dateFrom,omitempty"`
	DateTo   string   `json:"dateTo,omitempty"`
	DateType DateType `json:"dateType"`
	Status   string   `json:"status,omitempty"` // 01=Open, 02=Liquidated
}

// PaymentOrder represents a payment order from abroad
type PaymentOrder struct {
	ID              string          `json:"id"`
	CNPJ            string          `json:"cnpj"`
	CompanyName     string          `json:"companyName"`
	OrderDate       string          `json:"orderDate"`
	LiquidationDate string          `json:"liquidationDate,omitempty"`
	Amount          float64         `json:"amount"`
	Currency        string          `json:"currency"`
	Beneficiary     string          `json:"beneficiary"`
	Status          OperationStatus `json:"status"`
}

// PaymentOrdersResponse contains payment orders query results
type PaymentOrdersResponse struct {
	Orders     []PaymentOrder `json:"orders"`
	TotalCount int            `json:"totalCount"`
}

// =============================================================================
// LETTERS OF CREDIT (from Tela_Lista_CNPJ_BAL7.xml → BAL7)
// =============================================================================

// LCQuery represents query parameters for letters of credit
type LCQuery struct {
	CNPJ        string      `json:"cnpj"`
	DateFrom    string      `json:"dateFrom,omitempty"`
	DateTo      string      `json:"dateTo,omitempty"`
	DateType    DateType    `json:"dateType,omitempty"`
	CompanyType CompanyType `json:"companyType,omitempty"`
}

// LCStatus represents letter of credit status
type LCStatus string

const (
	LCStatusDraft      LCStatus = "DRAFT"
	LCStatusIssued     LCStatus = "ISSUED"
	LCStatusNegotiated LCStatus = "NEGOTIATED"
	LCStatusExpired    LCStatus = "EXPIRED"
)

// LetterOfCredit represents a letter of credit
type LetterOfCredit struct {
	ID          string   `json:"id"`
	CNPJ        string   `json:"cnpj"`
	CompanyName string   `json:"companyName"`
	IssueDate   string   `json:"issueDate"`
	ExpiryDate  string   `json:"expiryDate"`
	Amount      float64  `json:"amount"`
	Currency    string   `json:"currency"`
	Beneficiary string   `json:"beneficiary"`
	Status      LCStatus `json:"status"`
}

// LCQueryResponse contains letters of credit query results
type LCQueryResponse struct {
	Letters    []LetterOfCredit `json:"letters"`
	TotalCount int              `json:"totalCount"`
}

// =============================================================================
// FX QUOTATIONS (from TelaListaCNPJCambio.xml → BAEI)
// =============================================================================

// FXQuery represents query parameters for FX quotations
type FXQuery struct {
	CNPJ     string `json:"cnpj"`
	DateFrom string `json:"dateFrom,omitempty"`
	DateTo   string `json:"dateTo,omitempty"`
	Status   string `json:"status,omitempty"` // 0, 2, 3, 5
}

// FXQuotation represents an FX quotation
type FXQuotation struct {
	ID           string   `json:"id"`
	CNPJ         string   `json:"cnpj"`
	CompanyName  string   `json:"companyName"`
	QuoteDate    string   `json:"quoteDate"`
	CurrencyPair string   `json:"currencyPair"`
	Rate         float64  `json:"rate"`
	Amount       float64  `json:"amount"`
	Status       FXStatus `json:"status"`
}

// FXQueryResponse contains FX quotations query results
type FXQueryResponse struct {
	Quotations []FXQuotation `json:"quotations"`
	TotalCount int           `json:"totalCount"`
}

// ExchangeRate represents current exchange rate
type ExchangeRate struct {
	CurrencyPair string  `json:"currencyPair"`
	Bid          float64 `json:"bid"`
	Ask          float64 `json:"ask"`
	Timestamp    string  `json:"timestamp"`
}

// ExchangeSimulation represents exchange simulation result
type ExchangeSimulation struct {
	FromCurrency string  `json:"fromCurrency"`
	ToCurrency   string  `json:"toCurrency"`
	Amount       float64 `json:"amount"`
	Rate         float64 `json:"rate"`
	Result       float64 `json:"result"`
	Fee          float64 `json:"fee,omitempty"`
	ValidUntil   string  `json:"validUntil"`
}

// =============================================================================
// SWIFT
// =============================================================================

// SWIFTMessage represents a SWIFT message
type SWIFTMessage struct {
	UETR            string `json:"uetr"`
	MessageType     string `json:"messageType"` // MT103, MT700, etc
	SenderBIC       string `json:"senderBIC"`
	ReceiverBIC     string `json:"receiverBIC"`
	Amount          float64 `json:"amount"`
	Currency        string `json:"currency"`
	Beneficiary     string `json:"beneficiary"`
	Reference       string `json:"reference"`
	Status          string `json:"status"`
	CreatedAt       string `json:"createdAt"`
	DeliveredAt     string `json:"deliveredAt,omitempty"`
}

// SWIFTMessageRequest represents a request to send SWIFT message
type SWIFTMessageRequest struct {
	MessageType      string  `json:"messageType"`
	BeneficiaryName  string  `json:"beneficiaryName"`
	BeneficiaryAccount string `json:"beneficiaryAccount"`
	BeneficiaryBank  string  `json:"beneficiaryBank"`
	Amount           float64 `json:"amount"`
	Currency         string  `json:"currency"`
	Reference        string  `json:"reference,omitempty"`
}

// SWIFTMessageResponse represents response after sending SWIFT message
type SWIFTMessageResponse struct {
	UETR    string `json:"uetr"`
	Status  string `json:"status"`
	Message string `json:"message,omitempty"`
}

// =============================================================================
// HEALTH
// =============================================================================

// HealthStatus represents service health status
type HealthStatus struct {
	Service   string            `json:"service"`
	Healthy   bool              `json:"healthy"`
	Timestamp string            `json:"timestamp"`
	Details   map[string]string `json:"details,omitempty"`
}
