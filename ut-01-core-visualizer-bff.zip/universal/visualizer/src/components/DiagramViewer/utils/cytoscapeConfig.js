/**
 * Cytoscape.js configuration and initialization
 */

import cytoscape from 'cytoscape';

/**
 * Default Cytoscape configuration
 */
export const defaultCytoscapeConfig = {
  wheelSensitivity: 0.1,
  minZoom: 0.1,
  maxZoom: 3,
  boxSelectionEnabled: true,
  autounselectify: false,
  autoungrabify: false,
};

/**
 * Initialize Cytoscape instance
 * @param {HTMLElement} container - DOM element to render into
 * @param {Array} elements - Cytoscape elements (nodes and edges)
 * @param {Object} styleConfig - Node and edge styles
 * @returns {Object} Cytoscape instance
 */
export const initializeCytoscape = (container, elements = [], styleConfig = []) => {
  return cytoscape({
    container,
    elements,
    style: styleConfig,
    ...defaultCytoscapeConfig,
  });
};

/**
 * Fit graph to viewport
 * @param {Object} cy - Cytoscape instance
 * @param {number} padding - Padding around graph
 */
export const fitGraph = (cy, padding = 50) => {
  cy.fit(cy.elements(), padding);
};

/**
 * Center graph in viewport
 * @param {Object} cy - Cytoscape instance
 */
export const centerGraph = (cy) => {
  cy.center();
};

/**
 * Reset zoom to 100%
 * @param {Object} cy - Cytoscape instance
 */
export const resetZoom = (cy) => {
  cy.zoom(1);
  cy.center();
};

/**
 * Highlight node and its neighbors
 * @param {Object} cy - Cytoscape instance
 * @param {string} nodeId - Node ID to highlight
 */
export const highlightNode = (cy, nodeId) => {
  cy.elements().removeClass('highlighted faded');

  const node = cy.getElementById(nodeId);
  if (!node.length) return;

  const neighborhood = node.closedNeighborhood();
  neighborhood.addClass('highlighted');

  cy.elements().not(neighborhood).addClass('faded');
};

/**
 * Clear all highlights
 * @param {Object} cy - Cytoscape instance
 */
export const clearHighlights = (cy) => {
  cy.elements().removeClass('highlighted faded');
};

/**
 * Export graph as PNG
 * @param {Object} cy - Cytoscape instance
 * @param {string} filename - Output filename
 */
export const exportAsPNG = (cy, filename = 'diagram.png') => {
  const png = cy.png({ full: true, scale: 2 });
  const link = document.createElement('a');
  link.href = png;
  link.download = filename;
  link.click();
};

/**
 * Export graph data as JSON
 * @param {Object} cy - Cytoscape instance
 * @param {string} filename - Output filename
 */
export const exportAsJSON = (cy, filename = 'diagram.json') => {
  const json = cy.json();
  const dataStr = JSON.stringify(json, null, 2);
  const blob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
};
