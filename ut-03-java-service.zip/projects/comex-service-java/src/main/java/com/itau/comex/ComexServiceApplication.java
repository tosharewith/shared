package com.itau.comex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * COMEX Business Service - Java Spring Boot Version
 *
 * This microservice handles all COMEX (Câmbio e Comércio Exterior) business logic.
 * It exposes REST APIs consumed by the Angular MFE.
 *
 * Architecture:
 *   Angular MFE → This Service (Spring Boot) → Adapters → Backends (Oracle, AWS, MQ)
 *
 * Endpoints:
 *   - GET  /api/comex/empresas - List companies (Angular compatibility)
 *   - GET  /api/v1/comex/companies - List companies (v1 API)
 *   - GET  /api/v1/comex/swift/messages - List SWIFT messages
 *   - POST /api/v1/comex/export/billing/query - Query billing operations
 */
@SpringBootApplication
public class ComexServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ComexServiceApplication.class, args);
    }
}
