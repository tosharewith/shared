// Package main - COMEX Business Service
//
// This microservice handles all COMEX (Câmbio e Comércio Exterior) business logic.
// It exposes REST APIs consumed by the BFF layer.
//
// Architecture:
//
//	BFF (Node.js) → This Service (Go) → Adapters → Backends (Oracle, AWS, MQ)
package main

import (
	"log"
	"os"

	"github.com/gin-gonic/gin"

	"comex-service/internal/adapters"
	"comex-service/internal/handlers"
	"comex-service/internal/routes"
	"comex-service/internal/services"
)

func main() {
	// Load configuration
	config := loadConfig()

	// Create adapter factory
	adapterFactory := adapters.NewAdapterFactory(config.Adapters)

	// Create service
	comexService := services.NewCOMEXService(adapterFactory)

	// Create handler
	handler := handlers.NewCOMEXHandler(comexService)

	// Setup router
	router := gin.Default()

	// CORS middleware for development
	router.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Content-Type, Authorization, x-cnpj-empresa, x-cpf-operador")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	})

	// Dev middleware: Set default user_cpf for mock mode (no auth required)
	router.Use(func(c *gin.Context) {
		if c.GetString("user_cpf") == "" {
			c.Set("user_cpf", "12345678900") // Default CPF for development
		}
		c.Next()
	})

	// Health check (no auth required)
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "healthy", "service": "comex-service"})
	})

	// Setup COMEX routes (v1 API)
	routes.SetupCOMEXRoutes(router, handler)

	// ================================================================
	// COMPATIBILITY ROUTES for Angular MFE
	// Angular expects: /api/comex/empresas
	// Go v1 API uses: /api/v1/comex/companies
	// ================================================================
	api := router.Group("/api")
	{
		comex := api.Group("/comex")
		{
			// GET /api/comex/empresas - Angular compatibility endpoint
			comex.GET("/empresas", func(c *gin.Context) {
				userCPF := c.GetString("user_cpf")
				companies, err := comexService.GetCompanies(c.Request.Context(), userCPF)
				if err != nil {
					c.JSON(500, gin.H{"error": err.Error()})
					return
				}

				// Transform to format Angular expects (RESPOSTA/DADOS/ListaEmpresas/Item)
				items := make([]gin.H, len(companies.Companies))
				for i, co := range companies.Companies {
					items[i] = gin.H{
						"SCGCCPF_CLI": co.CNPJ,
						"SNOME_CLI":   co.Name,
					}
				}

				c.JSON(200, gin.H{
					"RESPOSTA": gin.H{
						"DADOS": gin.H{
							"ListaEmpresas": gin.H{
								"Item": items,
							},
						},
					},
				})
			})

			// GET /api/comex/swift/messages - Angular compatibility
			comex.GET("/swift/messages", func(c *gin.Context) {
				messages, err := comexService.ListSWIFTMessages(c.Request.Context(), "", "", "")
				if err != nil {
					c.JSON(500, gin.H{"error": err.Error()})
					return
				}
				c.JSON(200, messages)
			})
		}
	}

	// Get port from environment or default to 8080 (Angular expects this)
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	log.Printf("COMEX Service starting on port %s (Mock mode: %s)", port, config.Adapters.Default)
	if err := router.Run(":" + port); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}

// Config holds application configuration
type Config struct {
	Adapters adapters.AdapterConfig
}

func loadConfig() Config {
	// Load from environment variables
	return Config{
		Adapters: adapters.AdapterConfig{
			Default: adapters.AdapterType(getEnv("ADAPTER_DEFAULT", "MOCK")),
			Oracle: adapters.OracleConfig{
				WSURL:    getEnv("ORACLE_WS_URL", "http://localhost:8080/wsBankline.asmx"),
				Timeout:  30,
				Username: getEnv("ORACLE_USERNAME", ""),
				Password: getEnv("ORACLE_PASSWORD", ""),
			},
			AWS: adapters.AWSConfig{
				Region:         getEnv("AWS_REGION", "us-east-1"),
				LambdaFunction: getEnv("AWS_LAMBDA_FUNCTION", "comex-handler"),
			},
			MQ: adapters.MQConfig{
				QueueManager: getEnv("MQ_QUEUE_MANAGER", ""),
				RequestQueue: getEnv("MQ_REQUEST_QUEUE", ""),
				ReplyQueue:   getEnv("MQ_REPLY_QUEUE", ""),
				Timeout:      60,
			},
		},
	}
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}
