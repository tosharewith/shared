import { useMemo, useState, useCallback, useEffect } from 'react';
import { Tag, Accordion, AccordionItem, Button, InlineLoading, TextInput as CarbonTextInput, NumberInput } from '@carbon/react';
import {
  Screen,
  Api,
  DataBase,
  Terminal,
  CheckmarkFilled,
  ArrowRight,
  Settings,
  FolderDetails,
  Code,
  Application,
  Renew,
  Calendar,
  StringText,
  ChevronDown,
  ListBoxes,
  Currency,
  Locked,
  Copy,
  Checkmark,
  Download,
  Edit,
  Folder
} from '@carbon/icons-react';
import JSZip from 'jszip';
import styles from './AngularArchitecture.module.scss';
import {
  loadIdsMappingConfig,
  isConfigLoaded,
  getConfig,
  getFieldDetectionRules,
  getButtonPatterns,
  detectFieldType,
  detectButtonType
} from '../../utils/idsMappingLoader';

// Helper to convert field name to camelCase
const toCamelCase = (str) => {
  return (str || 'field')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // Remove accents
    .replace(/[^a-zA-Z0-9\s]/g, '') // Remove special chars
    .split(/\s+/)
    .map((word, i) => i === 0
      ? word.toLowerCase()
      : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    )
    .join('');
};

// Icon component map (using Carbon icons for field type display)
const IconMap = {
  Calendar,
  TextInput: StringText,  // Use StringText icon for text inputs
  Select: ListBoxes,      // Use ListBoxes icon for selects
  ListBoxes,
  Currency,
  Locked
};

/**
 * Official IDS v2 Icon Names (Bank Itaú)
 *
 * Convention: {name}_base (outline) or {name}_variant (filled)
 * Source: Official IDS v2 Migration Table
 *
 * @see config/IDS_OFFICIAL_ICONS.md for complete reference
 */
const IDS_OFFICIAL_ICONS = {
  // Navigation
  arrowDown: 'arrow_down_base',
  arrowUp: 'arrow_up_base',
  arrowLeft: 'arrow_left_base',
  arrowRight: 'arrow_right_base',
  arrowFlatDown: 'arrow_flat_down_base',
  arrowFlatUp: 'arrow_flat_up_base',
  chevronDown: 'arrow_flat_down_base',  // chevron → arrow_flat
  chevronUp: 'arrow_flat_up_base',
  externalLink: 'external_link_base',

  // Actions
  add: 'add_circle_base',
  plus: 'plus_base',
  close: 'close_base',
  edit: 'edit_base',
  trash: 'trash_base',
  copy: 'copy_base',
  share: 'share_base',
  download: 'download_base',
  reload: 'reload_base',
  search: 'search_base',
  filter: 'filter_base',

  // Status
  check: 'check_base',
  checkCircle: 'check_circle_base',
  error: 'error_circle_base',
  warning: 'warning_base',
  info: 'information_base',

  // Financial
  pix: 'pix_base',
  card: 'card_base',
  money: 'money_base',
  wallet: 'wallet_base',
  receipt: 'receipt_base',
  barcode: 'bar_code_base',

  // Calendar
  calendar: 'calendar_day_base',
  calendarMonth: 'calendar_month_base',
  clock: 'clock_base',

  // User
  user: 'user_base',
  lock: 'lock_base',

  // System
  home: 'home_base',
  menu: 'menu_base',
  settings: 'configuration_base',
  help: 'help_base',
  exit: 'exit_base',

  // Visibility
  eyeOpen: 'visibility_on_base',
  eyeClosed: 'visibility_off_variant',
};

/**
 * IDS v2 Web Components Map (@ids/web)
 *
 * All components use idsw-* prefix (Web Components from @ids/web package)
 * Import pattern: import '@ids/web/{component}';
 *
 * Available v2 Components (48 total):
 * - Forms: idsw-text-field, idsw-text-area, idsw-password, idsw-datepicker,
 *          idsw-select, idsw-checkbox, idsw-radio-button, idsw-switch,
 *          idsw-currency, idsw-autocomplete, idsw-search-field
 * - Buttons: idsw-button (variant="primary|secondary|tertiary|icon|floating")
 * - Display: idsw-icon, idsw-table, idsw-list, idsw-accordion, idsw-tabs
 * - Feedback: idsw-alert, idsw-loading-circle, idsw-snackbar, idsw-tooltip
 * - Layout: idsw-modal, idsw-dialog, idsw-bottom-sheet
 *
 * @see config/ids-mapping-config.yaml for shared configuration
 */
const IDS_COMPONENT_MAP = {
  // Date picker - Single date mode
  date: {
    component: 'idsw-datepicker',
    wrapper: null,
    template: 'date',
    mode: 'date',  // idsw-datepicker mode="date" for single date selection
    icon: 'calendar_day_base',
    imports: ["import '@ids/web/datepicker';"],
    webImports: ["@ids/web/datepicker"],
    props: {
      mode: 'date',
      language: 'pt-BR',
      hasConfirmation: true
    }
  },
  // Date range: idsw-datepicker with mode="range" (returns Date[] with [startDate, endDate])
  dateRange: {
    component: 'idsw-datepicker',
    wrapper: null,
    template: 'dateRange',
    mode: 'range',  // idsw-datepicker mode="range" for date range selection
    icon: 'calendar_day_base',
    imports: ["import '@ids/web/datepicker';"],
    webImports: ["@ids/web/datepicker"],
    props: {
      mode: 'range',
      language: 'pt-BR',
      hasConfirmation: true
    },
    note: 'idsw-datepicker mode="range" returns Date[] with [startDate, endDate]'
  },
  // Individual start date (for paired date fields that need separate controls)
  dateStart: {
    component: 'idsw-datepicker',
    wrapper: null,
    template: 'dateStart',
    mode: 'date',
    dateType: 'start',
    icon: 'calendar_day_base',
    imports: ["import '@ids/web/datepicker';"],
    webImports: ["@ids/web/datepicker"],
    props: {
      mode: 'date',
      language: 'pt-BR',
      label: 'Data Inicial'
    }
  },
  // Individual end date (for paired date fields that need separate controls)
  dateEnd: {
    component: 'idsw-datepicker',
    wrapper: null,
    template: 'dateEnd',
    mode: 'date',
    dateType: 'end',
    icon: 'calendar_day_base',
    imports: ["import '@ids/web/datepicker';"],
    webImports: ["@ids/web/datepicker"],
    props: {
      mode: 'date',
      language: 'pt-BR',
      label: 'Data Final'
    }
  },
  // Select - MIGRATED to v2
  select: {
    component: 'idsw-select',
    wrapper: null,
    template: 'select',
    icon: 'arrow_flat_down_base',
    imports: ["import '@ids/web/select';", "import '@ids/web/option';"],
    webImports: ["@ids/web/select", "@ids/web/option"]
  },
  // Table - MIGRATED to v2
  table: {
    component: 'idsw-table',
    wrapper: null,
    template: 'dataTable',
    icon: 'list_base',
    imports: ["import '@ids/web/table';"],
    webImports: ["@ids/web/table"]
  },
  // Currency - MIGRATED to v2
  currency: {
    component: 'idsw-currency',
    wrapper: null,
    template: 'currency',
    icon: 'money_base',
    imports: ["import '@ids/web/currency';"],
    webImports: ["@ids/web/currency"]
  },
  // Text input - MIGRATED to v2
  text: {
    component: 'idsw-text-field',
    wrapper: null,
    template: 'text',
    icon: 'edit_base',
    imports: ["import '@ids/web/text-field';"],
    webImports: ["@ids/web/text-field"]
  },
  // Textarea - MIGRATED to v2
  textarea: {
    component: 'idsw-text-area',
    wrapper: null,
    template: 'textarea',
    icon: 'doc_base',
    imports: ["import '@ids/web/text-area';"],
    webImports: ["@ids/web/text-area"]
  },
  // Readonly/display field - use disabled text-field
  readonly: {
    component: 'idsw-text-field',
    wrapper: null,
    template: 'readonly',
    icon: 'lock_base',
    imports: ["import '@ids/web/text-field';"],
    webImports: ["@ids/web/text-field"],
    props: { disabled: true, readonly: true }
  },
  // Checkbox - MIGRATED to v2
  checkbox: {
    component: 'idsw-checkbox',
    wrapper: null,
    template: 'checkbox',
    icon: 'check_circle_base',
    imports: ["import '@ids/web/checkbox';"],
    webImports: ["@ids/web/checkbox"]
  },
  // Radio - MIGRATED to v2
  radio: {
    component: 'idsw-radio-button',
    wrapper: null,
    template: 'radio',
    icon: 'circle_base',
    imports: ["import '@ids/web/radio-button';"],
    webImports: ["@ids/web/radio-button"]
  },
  // Switch - NEW in v2
  switch: {
    component: 'idsw-switch',
    wrapper: null,
    template: 'switch',
    icon: 'check_base',
    imports: ["import '@ids/web/switch';"],
    webImports: ["@ids/web/switch"]
  },
  // Button - MIGRATED to v2 (consolidated)
  button: {
    component: 'idsw-button',
    wrapper: null,
    template: 'button',
    icon: 'arrow_right_base',
    imports: ["import '@ids/web/button';"],
    webImports: ["@ids/web/button"],
    variants: {
      primary: 'variant="primary"',
      secondary: 'variant="secondary"',
      tertiary: 'variant="tertiary"',
      icon: 'variant="icon"',
      floating: 'variant="floating"'
    }
  },
  // Icon - MIGRATED to v2
  // Official naming: {name}_base (outline) or {name}_variant (filled)
  icon: {
    component: 'idsw-icon',
    wrapper: null,
    template: 'icon',
    imports: ["import '@ids/web/icon';"],
    webImports: ["@ids/web/icon"]
  },
  // Loading - MIGRATED to v2 (now loading-circle or loading-linear)
  loading: {
    component: 'idsw-loading-circle',
    wrapper: null,
    template: 'loading',
    imports: ["import '@ids/web/loading-circle';"],
    webImports: ["@ids/web/loading-circle"]
  },
  // Tooltip - MIGRATED to v2
  tooltip: {
    component: 'idsw-tooltip',
    wrapper: null,
    template: 'tooltip',
    imports: ["import '@ids/web/tooltip';"],
    webImports: ["@ids/web/tooltip"]
  },
  // Password - MIGRATED to v2
  password: {
    component: 'idsw-password',
    wrapper: null,
    template: 'password',
    icon: 'lock_base',
    imports: ["import '@ids/web/password';"],
    webImports: ["@ids/web/password"]
  },
  // Search - NEW in v2
  search: {
    component: 'idsw-search-field',
    wrapper: null,
    template: 'search',
    icon: 'search_base',
    imports: ["import '@ids/web/search-field';"],
    webImports: ["@ids/web/search-field"]
  },
  // Autocomplete - NEW in v2
  autocomplete: {
    component: 'idsw-autocomplete',
    wrapper: null,
    template: 'autocomplete',
    icon: 'search_base',
    imports: ["import '@ids/web/autocomplete';"],
    webImports: ["@ids/web/autocomplete"]
  },
  // List - MIGRATED to v2
  list: {
    component: 'idsw-list',
    wrapper: null,
    template: 'list',
    imports: ["import '@ids/web/list';"],
    webImports: ["@ids/web/list"]
  },
  // Accordion - MIGRATED to v2
  accordion: {
    component: 'idsw-accordion',
    wrapper: null,
    template: 'accordion',
    imports: ["import '@ids/web/accordion';", "import '@ids/web/accordion-item';"],
    webImports: ["@ids/web/accordion", "@ids/web/accordion-item"]
  },
  // Tabs - MIGRATED to v2
  tabs: {
    component: 'idsw-tabs',
    wrapper: null,
    template: 'tabs',
    imports: ["import '@ids/web/tabs';", "import '@ids/web/tab-item';", "import '@ids/web/tab-panel';"],
    webImports: ["@ids/web/tabs", "@ids/web/tab-item", "@ids/web/tab-panel"]
  },
  // Alert - MIGRATED to v2
  alert: {
    component: 'idsw-alert',
    wrapper: null,
    template: 'alert',
    icon: 'warning_base',
    imports: ["import '@ids/web/alert';"],
    webImports: ["@ids/web/alert"]
  },
  // Modal - MIGRATED to v2
  modal: {
    component: 'idsw-modal',
    wrapper: null,
    template: 'modal',
    imports: ["import '@ids/web/modal';"],
    webImports: ["@ids/web/modal"]
  },
  // Snackbar - NEW in v2
  snackbar: {
    component: 'idsw-snackbar',
    wrapper: null,
    template: 'snackbar',
    imports: ["import '@ids/web/snackbar';"],
    webImports: ["@ids/web/snackbar"]
  },
  // Progress bar - MIGRATED to v2
  progressBar: {
    component: 'idsw-progress-bar',
    wrapper: null,
    template: 'progressBar',
    imports: ["import '@ids/web/progress-bar';"],
    webImports: ["@ids/web/progress-bar"]
  },
  // Shimmer (skeleton) - MIGRATED to v2
  shimmer: {
    component: 'idsw-shimmer',
    wrapper: null,
    template: 'shimmer',
    imports: ["import '@ids/web/shimmer';"],
    webImports: ["@ids/web/shimmer"]
  }
};

/**
 * Maps field metadata to IDS component types
 * Uses explicit format metadata when available (e.g., DD_MM_AAAA from JSON)
 *
 * Configuration priority:
 * 1. Explicit format metadata from JSON (fieldGroups)
 * 2. YAML configuration rules (from config/ids-mapping-config.yaml)
 * 3. Hardcoded fallback logic
 *
 * @see config/ids-mapping-config.yaml for shared configuration
 */
const mapFieldToIDSComponent = (field, inputAllFields = [], fieldGroups = []) => {
  // Ensure allFields is always an array
  const allFields = Array.isArray(inputAllFields) ? inputAllFields : Object.values(inputAllFields || {});
  const name = (field.name || '').toLowerCase();
  const source = field.source || '';
  const type = field.type || '';
  const size = parseInt(field.size) || 0;

  // Try YAML-based detection first (if config is loaded)
  if (isConfigLoaded()) {
    const yamlDetected = detectFieldType(field.name, type, source, size, field.defaultValue);
    if (yamlDetected && yamlDetected.component) {
      // Map YAML component to IDS_COMPONENT_MAP entry
      // Handle idsw-* components by extracting the key (e.g., idsw-datepicker → datepicker)
      let componentKey = yamlDetected.component
        .replace('idsw-', '')
        .replace('ids-', '')
        .replace(/-/g, '')
        .replace('field', '');

      // Special handling for datepicker modes
      if (yamlDetected.component === 'idsw-datepicker') {
        if (yamlDetected.mode === 'range') {
          componentKey = 'dateRange';
        } else if (yamlDetected.dateType === 'start') {
          componentKey = 'dateStart';
        } else if (yamlDetected.dateType === 'end') {
          componentKey = 'dateEnd';
        } else {
          componentKey = 'date';
        }
      }

      const mappedComponent = IDS_COMPONENT_MAP[componentKey] ||
                             IDS_COMPONENT_MAP.text;
      return {
        ...mappedComponent,
        props: { ...mappedComponent.props, ...yamlDetected.props },
        mode: yamlDetected.mode || mappedComponent.mode,
        dateType: yamlDetected.dateType,
        icon: yamlDetected.icon || mappedComponent.icon,
        reason: `YAML config: ${yamlDetected.ruleName} rule applied (mode=${yamlDetected.mode || 'default'})`
      };
    }
  }

  // Priority 1: Check if field is in a fieldGroup with explicit format
  // Note: Date grouping is handled at the groupDateFields level
  // Individual date fields (Dia, Mes, Ano) are skipped here - they get grouped
  const dateGroup = fieldGroups.find(g =>
    g.type === 'date' && g.fields?.some(f => f.toLowerCase() === name)
  );
  if (dateGroup) {
    // Determine if this is a start/end date based on field name patterns
    const isStartDate = name.includes('inicial') || name.includes('inicio') || name.includes('_de');
    const isEndDate = name.includes('final') || name.includes('fim') || name.includes('_ate');

    // Use dateStart/dateEnd for paired fields, otherwise single date
    const dateMapKey = isStartDate ? 'dateStart' : (isEndDate ? 'dateEnd' : 'date');

    return {
      ...IDS_COMPONENT_MAP[dateMapKey],
      props: {
        ...IDS_COMPONENT_MAP[dateMapKey].props,
        format: dateGroup.format || 'DD_MM_AAAA'
      },
      mode: 'date',  // Individual date fields use mode="date"
      dateType: isStartDate ? 'start' : (isEndDate ? 'end' : undefined),
      reason: `Date field from fieldGroup (format: ${dateGroup.format}, type: ${dateMapKey})`
    };
  }

  // Priority 2: Explicit format metadata on field
  if (field.format === 'DD_MM_AAAA' || field.groupType === 'date') {
    return {
      ...IDS_COMPONENT_MAP.date,
      props: { ...IDS_COMPONENT_MAP.date.props },
      mode: 'date',
      reason: `Date field via format="${field.format}"`
    };
  }

  // Priority 3: Date detection via Dia/Mes/Ano patterns (will be grouped later)
  if (name.includes('dia') || name.includes('mes') || name.includes('ano')) {
    const hasDay = allFields.some(f => f.name?.toLowerCase().includes('dia'));
    const hasMonth = allFields.some(f => f.name?.toLowerCase().includes('mes'));
    const hasYear = allFields.some(f => f.name?.toLowerCase().includes('ano'));

    if (hasDay && hasMonth && hasYear) {
      // Detect if this is part of a date range (has inicial/final pairs)
      const isStartDate = name.includes('inicial') || name.includes('inicio') || name.includes('_de') || name.includes('de_');
      const isEndDate = name.includes('final') || name.includes('fim') || name.includes('_ate') || name.includes('ate_');

      const dateMapKey = isStartDate ? 'dateStart' : (isEndDate ? 'dateEnd' : 'date');

      return {
        ...IDS_COMPONENT_MAP[dateMapKey],
        props: { ...IDS_COMPONENT_MAP[dateMapKey].props },
        mode: 'date',
        dateType: isStartDate ? 'start' : (isEndDate ? 'end' : undefined),
        reason: `Date field (Dia/Mes/Ano pattern, type: ${dateMapKey}) - will be grouped`
      };
    }
  }

  // Data/Date in field name (output field, not date picker)
  if (name.includes('data') && !name.includes('dia') && !name.includes('mes') && !name.includes('ano')) {
    return {
      ...IDS_COMPONENT_MAP.readonly,
      props: { format: 'DD/MM/AAAA' },
      reason: 'Date display field (read-only)'
    };
  }

  // Dropdown: ListaReceber type indicates select/dropdown
  if (type === 'ListaReceber' || type === 'ListaMainframe' || source === 'ValorizacaoLista') {
    return {
      ...IDS_COMPONENT_MAP.select,
      props: { placeholder: 'Selecione...' },
      reason: `Dropdown detected (type=${type}, source=${source})`
    };
  }

  // Table/Grid: OrigemListaXml source indicates data table
  if (source === 'OrigemListaXml') {
    return {
      ...IDS_COMPONENT_MAP.table,
      props: { sortable: true, paginated: true, pageSize: 10 },
      reason: 'Table detected (source=OrigemListaXml)'
    };
  }

  // Currency: Valor/Amount/Saldo in name + larger size
  if ((name.includes('valor') || name.includes('amount') || name.includes('saldo')) && size >= 10) {
    return {
      ...IDS_COMPONENT_MAP.currency,
      props: { currency: 'BRL', locale: 'pt-BR', mask: 'currency' },
      reason: `Currency field detected (name contains valor/amount, size=${size})`
    };
  }

  // Checkbox: Boolean fields
  if (type === 'Checkbox' || (size === 1 && ['S', 'N', '0', '1'].includes(field.defaultValue || ''))) {
    return {
      ...IDS_COMPONENT_MAP.checkbox,
      props: {},
      reason: `Checkbox detected (type=${type})`
    };
  }

  // Readonly/Hidden: ValorizacaoFormulario or ValorizacaoCampo source
  if (source === 'ValorizacaoFormulario' || source === 'ValorizacaoCampo') {
    return {
      ...IDS_COMPONENT_MAP.readonly,
      props: { readonly: true },
      reason: `Read-only field (source=${source})`
    };
  }

  // CNPJ/CPF field
  if (name.includes('cnpj') || name.includes('cpf') || name.includes('cgc')) {
    return {
      ...IDS_COMPONENT_MAP.text,
      props: { maxLength: 18, mask: 'cnpj-cpf' },
      directive: 'idsMask',
      reason: 'CNPJ/CPF field detected'
    };
  }

  // Code field: small size + codigo in name
  if (name.includes('codigo') || name.includes('code')) {
    return {
      ...IDS_COMPONENT_MAP.text,
      props: { maxLength: size || 10, uppercase: true },
      reason: 'Code input field detected'
    };
  }

  // Default text input
  return {
    ...IDS_COMPONENT_MAP.text,
    props: { maxLength: size || 100 },
    reason: 'Default text input'
  };
};

/**
 * Extracts fieldGroups from interaction data
 * These contain explicit groupings like date fields with format metadata
 */
const extractFieldGroups = (interaction) => {
  const groups = [];

  // Check for explicit fieldGroups in the interaction
  if (interaction.fields?.fieldGroups) {
    groups.push(...interaction.fields.fieldGroups);
  }

  // Parse HTML template for date field patterns
  const template = interaction.templates?.main || '';

  // Look for date patterns in HTML (e.g., Dia_Inicio, Mes_Inicio, Ano_Inicio)
  const datePatterns = [
    { regex: /Dia_Inicio.*Mes_Inicio.*Ano_Inicio/i, suffix: 'Inicial', format: 'DD_MM_AAAA' },
    { regex: /Dia_Final.*Mes_Final.*Ano_Final/i, suffix: 'Final', format: 'DD_MM_AAAA' },
    { regex: /diaInicial.*mesInicial.*anoInicial/i, suffix: 'Inicial', format: 'DD_MM_AAAA' },
    { regex: /diaFinal.*mesFinal.*anoFinal/i, suffix: 'Final', format: 'DD_MM_AAAA' },
    { regex: /diade2.*mesde2.*anode2/i, suffix: 'De', format: 'DD_MM_AAAA' },
    { regex: /diafim2.*mesfim2.*anofim2/i, suffix: 'Fim', format: 'DD_MM_AAAA' }
  ];

  for (const pattern of datePatterns) {
    if (pattern.regex.test(template)) {
      // Check if this group already exists
      const exists = groups.some(g =>
        g.type === 'date' && g.fields?.some(f => f.toLowerCase().includes(pattern.suffix.toLowerCase()))
      );
      if (!exists) {
        groups.push({
          type: 'date',
          format: pattern.format,
          fields: [`dia${pattern.suffix}`, `mes${pattern.suffix}`, `ano${pattern.suffix}`],
          labels: [`Data ${pattern.suffix}`]
        });
      }
    }
  }

  return groups;
};

/**
 * Groups date fields (Dia, Mes, Ano) into DateRangePicker or single date components
 * Uses explicit fieldGroups when available
 *
 * IDS v2 idsw-datepicker modes:
 * - mode="date": Single date selection (default)
 * - mode="range": Date range selection (returns Date[] with [startDate, endDate])
 *
 * Pattern detection:
 * - Date range: Finds Inicial/Final pairs → uses idsw-datepicker mode="range"
 * - Single date: Dia/Mes/Ano group without pair → uses idsw-datepicker mode="date"
 */
const groupDateFields = (inputFields, fieldGroups = []) => {
  // Ensure fields is always an array
  const fields = Array.isArray(inputFields) ? inputFields : Object.values(inputFields || {});
  const grouped = [];
  const processed = new Set();

  // Detect paired date groups (Inicial + Final) for date range picker
  const dateGroups = fieldGroups.filter(g => g.type === 'date');
  const inicialGroup = dateGroups.find(g =>
    g.name?.toLowerCase().includes('inicial') ||
    g.fields?.some(f => f.toLowerCase().includes('inicial') || f.toLowerCase().includes('inicio'))
  );
  const finalGroup = dateGroups.find(g =>
    g.name?.toLowerCase().includes('final') ||
    g.fields?.some(f => f.toLowerCase().includes('final') || f.toLowerCase().includes('fim'))
  );

  // If we have a date range pair, combine them into single idsw-datepicker mode="range"
  if (inicialGroup && finalGroup) {
    const allDateFields = [...(inicialGroup.fields || []), ...(finalGroup.fields || [])];
    const relatedFields = fields.filter(f =>
      allDateFields.some(df => df.toLowerCase() === (f.name || '').toLowerCase())
    );

    relatedFields.forEach(f => processed.add(f.name));

    // Mark all fields in the groups as processed
    allDateFields.forEach(f => processed.add(f));

    grouped.push({
      name: 'Período de Consulta',
      _isGrouped: true,
      _isDateRange: true,
      _groupedFields: relatedFields.map(f => f.name),
      _htmlFields: {
        inicial: inicialGroup.htmlFields || ['diaInicial', 'mesInicial', 'anoInicial'],
        final: finalGroup.htmlFields || ['diaFinal', 'mesFinal', 'anoFinal']
      },
      _format: inicialGroup.format || 'DD_MM_AAAA',
      _idsMapping: {
        ...IDS_COMPONENT_MAP.dateRange,
        mode: 'range',  // idsw-datepicker mode="range" for date range selection
        props: {
          ...IDS_COMPONENT_MAP.dateRange.props,
          opcional: true,
          showWarning: true,
          maxDays: 90
        },
        reason: `Date range (mode="range") from fieldGroups: ${inicialGroup.name} + ${finalGroup.name}`,
        note: 'idsw-datepicker mode="range" returns Date[] with [startDate, endDate]'
      }
    });
  } else {
    // Process individual date groups that aren't paired
    for (const group of dateGroups) {
      if (group.type === 'date' && group.fields) {
        const groupedFieldNames = group.fields.map(f => f.toLowerCase());
        const relatedFields = fields.filter(f =>
          groupedFieldNames.includes((f.name || '').toLowerCase())
        );

        if (relatedFields.length > 0 && !relatedFields.every(f => processed.has(f.name))) {
          relatedFields.forEach(f => processed.add(f.name));

          // Create single date picker from group using idsw-datepicker mode="date"
          const label = group.name || group.labels?.[0]?.replace(/^Dia\s+(para|de)\s+/i, '') ||
            `Data ${group.fields[0]?.replace(/^dia/i, '') || ''}`;

          // Detect if this is a start or end date
          const isStartDate = groupedFieldNames.some(f => f.includes('inicial') || f.includes('inicio') || f.includes('_de'));
          const isEndDate = groupedFieldNames.some(f => f.includes('final') || f.includes('fim') || f.includes('_ate'));
          const dateMapKey = isStartDate ? 'dateStart' : (isEndDate ? 'dateEnd' : 'date');

          grouped.push({
            name: label.trim(),
            _isGrouped: true,
            _isSingleDate: true,
            _groupedFields: relatedFields.map(f => f.name),
            _htmlFields: group.htmlFields || relatedFields.map(f => toCamelCase(f.name)),
            _format: group.format,
            _idsMapping: {
              ...IDS_COMPONENT_MAP[dateMapKey],
              mode: 'date',  // idsw-datepicker mode="date" for single date selection
              dateType: isStartDate ? 'start' : (isEndDate ? 'end' : undefined),
              props: {
                ...IDS_COMPONENT_MAP[dateMapKey].props,
                format: group.format
              },
              reason: `Single date (mode="date", type=${dateMapKey}) from fieldGroups (format: ${group.format})`
            }
          });
        }
      }
    }
  }

  // Then process remaining fields with pattern-based detection
  for (const field of fields) {
    if (processed.has(field.name)) continue;

    const name = (field.name || '').toLowerCase();

    // Check for date component pattern
    if (name.includes('dia') || name.includes('mes') || name.includes('ano')) {
      // Extract base name (e.g., "Inicial" or "Final")
      const suffix = name.match(/(inicial|final|inicio|fim|de|ate)/i)?.[0] || '';
      const baseName = name.replace(/^(dia|mes|ano)/i, '').replace(/^_/, '');

      // Find related fields with same suffix
      const relatedFields = fields.filter(f => {
        const fName = (f.name || '').toLowerCase();
        const fBaseName = fName.replace(/^(dia|mes|ano)/i, '').replace(/^_/, '');
        return (fName.includes('dia') || fName.includes('mes') || fName.includes('ano')) &&
               fBaseName === baseName &&
               !processed.has(f.name);
      });

      if (relatedFields.length >= 2) {
        // Group as date picker using idsw-datepicker mode="date"
        relatedFields.forEach(f => processed.add(f.name));

        // Determine if this is a start/end date based on the suffix
        const isStartDate = ['inicial', 'inicio', 'de'].includes(suffix.toLowerCase());
        const isEndDate = ['final', 'fim', 'ate'].includes(suffix.toLowerCase());
        const dateMapKey = isStartDate ? 'dateStart' : (isEndDate ? 'dateEnd' : 'date');

        const label = baseName
          ? `Data ${baseName.charAt(0).toUpperCase() + baseName.slice(1)}`
          : 'Data';

        grouped.push({
          name: label,
          _isGrouped: true,
          _groupedFields: relatedFields.map(f => f.name),
          _htmlFields: relatedFields.map(f => toCamelCase(f.name)),
          _idsMapping: {
            ...IDS_COMPONENT_MAP[dateMapKey],
            mode: 'date',  // idsw-datepicker mode="date" for single date
            dateType: isStartDate ? 'start' : (isEndDate ? 'end' : undefined),
            props: { ...IDS_COMPONENT_MAP[dateMapKey].props },
            reason: `Grouped from pattern (mode="date", type=${dateMapKey}): ${relatedFields.map(f => f.name).join(', ')}`
          }
        });
        continue;
      }
    }

    processed.add(field.name);
    grouped.push({
      ...field,
      _idsMapping: mapFieldToIDSComponent(field, fields, fieldGroups)
    });
  }

  return grouped;
};

/**
 * Dynamically generates Angular architecture recommendations
 * based on the legacy transaction flow analysis.
 */
const AngularArchitecture = ({ transactionData }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCode, setGeneratedCode] = useState(null);
  const [copiedField, setCopiedField] = useState(null);
  const [customRouteName, setCustomRouteName] = useState('');
  const [mfePort, setMfePort] = useState(5002);
  const [isDownloading, setIsDownloading] = useState(false);
  const [editingRoute, setEditingRoute] = useState(false);
  const [configLoaded, setConfigLoaded] = useState(false);
  const [templateBundles, setTemplateBundles] = useState({
    angular: null,
    go: null,
    java: null
  });

  // Load shared YAML configuration on mount
  useEffect(() => {
    loadIdsMappingConfig()
      .then(() => {
        setConfigLoaded(true);
        console.log('[AngularArchitecture] YAML configuration loaded');
      })
      .catch(err => {
        console.warn('[AngularArchitecture] Using fallback config:', err.message);
        setConfigLoaded(true); // Use fallback config
      });
  }, []);

  // Load template bundles for ZIP generation
  useEffect(() => {
    const loadBundles = async () => {
      const bundles = {};
      const templateConfigs = [
        { id: 'angular', url: '/templates/mfe-base-bundle.json' },
        { id: 'go', url: '/templates/go-service-bundle.json' },
        { id: 'java', url: '/templates/java-service-bundle.json' }
      ];

      for (const config of templateConfigs) {
        try {
          const response = await fetch(config.url);
          if (response.ok) {
            const bundle = await response.json();
            bundles[config.id] = bundle;
            console.log(`[AngularArchitecture] Loaded ${config.id} template: ${bundle.fileCount} files`);
          }
        } catch (err) {
          console.warn(`[AngularArchitecture] Failed to load ${config.id} template:`, err.message);
        }
      }
      setTemplateBundles(bundles);
    };
    loadBundles();
  }, []);

  const architecture = useMemo(() => {
    if (!transactionData?.flow) return null;

    const interactions = transactionData.flow.interactions || [];
    const flowGraph = transactionData.flow.flowGraph || {};
    const scenarios = transactionData.flow.scenarios || [];
    const mainPath = transactionData.flow.mainPath || [];
    const menuItem = transactionData.menuItem || {};

    // Analyze screens
    const screens = interactions.filter(i => i.type === 'Browser' || i.type === 'Formulario');
    const services = interactions.filter(i => i.type === 'WebService');
    const databases = interactions.filter(i => i.type?.includes('ADO'));
    const mainframes = interactions.filter(i => i.type?.includes('Mainframe'));

    // Identify decision points (nodes with multiple screen targets)
    const decisionPoints = [];
    for (const interaction of interactions) {
      const navs = interaction.navigations || [];
      const screenTargets = new Set();

      for (const nav of navs) {
        const targetInt = interactions.find(i => i.path === nav.target);
        if (targetInt?.type === 'Browser' || targetInt?.classification?.isExit) {
          screenTargets.add(nav.target);
        }
      }

      if (screenTargets.size > 1) {
        decisionPoints.push({
          path: interaction.path,
          name: interaction.name || interaction.path.split('\\').pop(),
          targets: [...screenTargets],
          conditions: navs
            .filter(n => n.condition?.function)
            .map(n => n.condition.function)
        });
      }
    }

    // Group screens by FLOW POSITION rather than name patterns
    // This creates more accurate Angular component groupings
    const screenClusters = [];
    const assignedScreens = new Set();

    // Build flow graph: which screens come before/after web services
    const screenFlowOrder = new Map();
    const screensBeforeWS = new Set();
    const screensAfterWS = new Set();
    const screensWithDetails = new Set();

    // Analyze flow to determine screen positions
    for (const interaction of interactions) {
      const isWS = interaction.type === 'WS' || interaction.type === 'WebService' ||
                   interaction.classification?.isWebService;
      const isScreen = interaction.type === 'Browser' || interaction.classification?.isScreen;

      if (interaction.navigation) {
        for (const nav of interaction.navigation) {
          const sourceInt = interactions.find(i => i.path === interaction.path);
          const targetInt = interactions.find(i => i.path === nav.target);

          // Screen → WS means screen is BEFORE web service (entry/selection)
          if (isScreen && (targetInt?.type === 'WS' || targetInt?.classification?.isWebService)) {
            screensBeforeWS.add(interaction.path);
          }

          // WS → Screen means screen is AFTER web service (results)
          if (isWS && (targetInt?.type === 'Browser' || targetInt?.classification?.isScreen)) {
            screensAfterWS.add(nav.target);
          }
        }
      }
    }

    // Categorize screens based on content and flow position
    for (const screen of screens) {
      const name = (screen.name || '').toLowerCase();
      // Ensure fields is always an array
      const rawFields = screen.fields || screen.campos || [];
      const fields = Array.isArray(rawFields) ? rawFields : Object.values(rawFields || {});
      // Ensure lists is always an array
      const rawLists = screen.lists || screen.listas || [];
      const lists = Array.isArray(rawLists) ? rawLists : Object.values(rawLists || {});

      // Check field characteristics
      const hasDateFields = fields.some(f => {
        const fieldName = (f.name || f.nome || '').toLowerCase();
        return fieldName.includes('dia') || fieldName.includes('mes') || fieldName.includes('ano') ||
               fieldName.includes('data') || fieldName.includes('date');
      });
      const hasCnpjFields = fields.some(f => {
        const fieldName = (f.name || f.nome || '').toLowerCase();
        return fieldName.includes('cnpj') || fieldName.includes('cpf');
      });
      const hasListColumns = lists.length > 0 && lists.some(l => (l.columns || l.colunas || []).length > 2);

      // Screens that are entry points (before WS, have selection/filter fields)
      const isEntryScreen = screensBeforeWS.has(screen.path) ||
                           (hasDateFields && hasCnpjFields) ||
                           (name.includes('selec') || name.includes('param') || name.includes('inicial'));

      // Screens that show results (after WS, have multi-column lists)
      const isResultsScreen = screensAfterWS.has(screen.path) && hasListColumns;

      // Screens that show individual record details
      const isDetailScreen = (name.includes('swift') && !name.includes('lista')) ||
                            name.includes('detalhe') || name.includes('detail') ||
                            name.includes('visualiz');

      screen._flowCategory = isEntryScreen ? 'entry' :
                            isResultsScreen ? 'results' :
                            isDetailScreen ? 'detail' : 'other';
    }

    // Cluster 1: Entry/Selection screens (CNPJ selection, date filters, parameters)
    const entryScreens = screens.filter(s => {
      const name = (s.name || '').toLowerCase();
      const isEntry = s._flowCategory === 'entry';
      const isFirstListScreen = name.includes('listacnpj') || name.includes('listancnpj') ||
                                (name.includes('lista') && (name.includes('cnpj') || name.includes('inicial')));
      return isEntry || isFirstListScreen;
    });
    if (entryScreens.length > 0) {
      screenClusters.push({
        name: 'Selection',
        angularName: 'SelectionComponent',
        purpose: 'Entry point, data selection, parameters',
        screens: entryScreens,
        route: '/select'
      });
      entryScreens.forEach(s => assignedScreens.add(s.path));
    }

    // Cluster 2: Results/List screens (show data FROM web services)
    const resultsScreens = screens.filter(s => {
      if (assignedScreens.has(s.path)) return false;
      const name = (s.name || '').toLowerCase();
      const isResults = s._flowCategory === 'results';
      // Results screens typically have "lista" + specific domain term (OPE, MSG, etc.)
      const isResultsList = name.includes('lista') &&
                           (name.includes('ope') || name.includes('msg') || name.includes('resultado'));
      return isResults || isResultsList;
    });
    if (resultsScreens.length > 0) {
      screenClusters.push({
        name: 'Results',
        angularName: 'ResultsComponent',
        purpose: 'Display results from service calls',
        screens: resultsScreens,
        route: '/results'
      });
      resultsScreens.forEach(s => assignedScreens.add(s.path));
    }

    // Cluster 3: Detail screens (individual record view)
    const detailScreens = screens.filter(s => {
      if (assignedScreens.has(s.path)) return false;
      const name = (s.name || '').toLowerCase();
      const isDetail = s._flowCategory === 'detail';
      const hasDetailPattern = name.includes('swift') || name.includes('detalhe') ||
                              name.includes('detail') || name.includes('visualiz') ||
                              name.includes('perfil');
      return isDetail || hasDetailPattern;
    });
    if (detailScreens.length > 0) {
      screenClusters.push({
        name: 'Detail',
        angularName: 'DetailComponent',
        purpose: 'View individual record details',
        screens: detailScreens,
        route: '/detail/:id'
      });
      detailScreens.forEach(s => assignedScreens.add(s.path));
    }

    // Cluster 4: Final/Confirmation screens
    const finalScreens = screens.filter(s => {
      if (assignedScreens.has(s.path)) return false;
      const name = (s.name || '').toLowerCase();
      const classification = s.classification || {};
      return classification.isFinal || name.includes('final') || name.includes('confirm') ||
             name.includes('sucesso') || name.includes('complet');
    });
    if (finalScreens.length > 0) {
      screenClusters.push({
        name: 'Complete',
        angularName: 'CompleteComponent',
        purpose: 'Success confirmation, next actions',
        screens: finalScreens,
        route: '/complete'
      });
      finalScreens.forEach(s => assignedScreens.add(s.path));
    }

    // Cluster 5: Remaining screens (utility, auxiliary)
    const remainingScreens = screens.filter(s => !assignedScreens.has(s.path) && !s.classification?.isExit);
    if (remainingScreens.length > 0) {
      screenClusters.push({
        name: 'Auxiliary',
        angularName: 'AuxiliaryComponent',
        purpose: 'Additional views and utilities',
        screens: remainingScreens,
        route: '/aux/:view'
      });
    }

    // Generate route name from menu item
    const routeName = (menuItem.nomeLogico || 'feature')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, '-')
      .substring(0, 30);

    // Generate service methods based on backend calls
    const serviceMethods = [];

    // Add methods for each unique service
    const uniqueServices = new Map();
    for (const svc of services) {
      const name = svc.name || svc.path.split('\\').pop();
      if (!uniqueServices.has(name)) {
        uniqueServices.set(name, svc);
        serviceMethods.push({
          name: `get${name.replace(/[^a-zA-Z]/g, '')}`,
          description: `Call ${name} WebService`,
          returns: 'Observable<Response>'
        });
      }
    }

    // Add CRUD methods if there are database operations
    if (databases.length > 0) {
      serviceMethods.push(
        { name: 'query', description: 'Query data from database', returns: 'Observable<T[]>' },
        { name: 'save', description: 'Save/update record', returns: 'Observable<T>' }
      );
    }

    // Generate guards based on decision points
    const guards = decisionPoints.map((dp, i) => ({
      name: `${routeName}Guard${i + 1}`,
      purpose: `Check ${dp.conditions.join(', ') || 'navigation condition'}`,
      decisionPoint: dp.name
    }));

    // State management recommendation
    const stateComplexity = scenarios.length > 3 ? 'complex' : 'simple';
    const stateRecommendation = stateComplexity === 'complex'
      ? { type: 'NgRx', reason: 'Multiple scenarios and complex branching' }
      : { type: 'BehaviorSubject', reason: 'Linear flow with simple state' };

    return {
      moduleName: routeName,
      basePath: `/${routeName}`,
      screens: {
        legacy: screens.length,
        angular: screenClusters.length
      },
      components: screenClusters,
      service: {
        name: `${routeName.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('')}Service`,
        methods: serviceMethods
      },
      guards,
      stateManagement: stateRecommendation,
      decisionPoints,
      summary: {
        legacyScreens: screens.length,
        angularComponents: screenClusters.length,
        decisionPoints: decisionPoints.length,
        scenarios: scenarios.length,
        backendServices: services.length + databases.length + mainframes.length
      }
    };
  }, [transactionData]);

  // Initialize custom route name from architecture
  useEffect(() => {
    if (architecture?.moduleName && !customRouteName) {
      setCustomRouteName(architecture.moduleName);
    }
  }, [architecture?.moduleName]);

  // Get effective route name (custom or default)
  const effectiveRouteName = customRouteName || architecture?.moduleName || 'feature';

  // Convert to different cases for templating
  const toKebabCase = (str) => str.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
  const toPascalCase = (str) => str.split(/[-\s]+/).map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
  const toCamelCaseStr = (str) => {
    const pascal = toPascalCase(str);
    return pascal.charAt(0).toLowerCase() + pascal.slice(1);
  };

  // Apply template variable substitution for Angular
  const applyTemplateVars = useCallback((content, vars) => {
    if (typeof content !== 'string') return content;
    let result = content;
    result = result.replace(/mfe-base/g, vars.mfeName);
    result = result.replace(/MfeBase/g, vars.mfeNamePascal);
    result = result.replace(/mfeBase/g, vars.mfeNameCamel);
    result = result.replace(/5001/g, vars.mfePort);
    return result;
  }, []);

  // Apply Go template variable substitution
  const applyGoTemplateVars = useCallback((content, vars) => {
    if (typeof content !== 'string') return content;
    let result = content;
    result = result.replace(/comex-service/g, vars.serviceName);
    result = result.replace(/ComexService/g, vars.serviceNamePascal);
    result = result.replace(/comexService/g, vars.serviceNameCamel);
    result = result.replace(/com\/itau\/comex/g, `com/itau/${vars.serviceNameSnake}`);
    return result;
  }, []);

  // Apply Java template variable substitution
  const applyJavaTemplateVars = useCallback((content, vars) => {
    if (typeof content !== 'string') return content;
    let result = content;
    result = result.replace(/comex-service-java/g, vars.serviceName);
    result = result.replace(/com\.itau\.comex/g, `com.itau.${vars.serviceNameSnake}`);
    result = result.replace(/com\/itau\/comex/g, `com/itau/${vars.serviceNameSnake}`);
    result = result.replace(/ComexService/g, vars.serviceNamePascal);
    result = result.replace(/comexService/g, vars.serviceNameCamel);
    result = result.replace(/<artifactId>comex<\/artifactId>/g, `<artifactId>${vars.serviceNameSnake}</artifactId>`);
    result = result.replace(/<name>comex<\/name>/g, `<name>${vars.serviceName}</name>`);
    return result;
  }, []);

  // BFF endpoint for project generation
  const BFF_URL = import.meta.env.VITE_BFF_URL || 'http://localhost:3001';

  // Download files as ZIP via BFF (server-side generation)
  const downloadAsZip = useCallback(async (projectName, customFiles, templateType = 'angular') => {
    const mfeName = toKebabCase(effectiveRouteName);

    console.log(`[downloadAsZip] Requesting ${templateType} project from BFF`, {
      projectName: mfeName,
      customFilesCount: Object.keys(customFiles).length
    });

    try {
      const response = await fetch(`${BFF_URL}/api/v1/project/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          templateType,
          projectName: mfeName,
          mfePort,
          customFiles
        })
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({ error: 'Unknown error' }));
        throw new Error(error.error || `HTTP ${response.status}`);
      }

      // Get the ZIP blob from response
      const blob = await response.blob();

      // Extract filename from Content-Disposition header or use default
      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = `${projectName}.zip`;
      if (contentDisposition) {
        const match = contentDisposition.match(/filename="?([^"]+)"?/);
        if (match) filename = match[1];
      }

      // Trigger download
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      console.log(`[downloadAsZip] Download complete: ${filename}`);
    } catch (error) {
      console.error('[downloadAsZip] BFF request failed:', error);
      // Fallback to client-side generation if BFF is unavailable
      console.log('[downloadAsZip] Falling back to client-side ZIP generation');
      await downloadAsZipClientSide(projectName, customFiles, templateType);
    }
  }, [effectiveRouteName, mfePort]);

  // Fallback client-side ZIP generation (when BFF is unavailable)
  const downloadAsZipClientSide = useCallback(async (projectName, customFiles, templateType = 'angular') => {
    const zip = new JSZip();
    const mfeName = toKebabCase(effectiveRouteName);
    const mfeNamePascal = toPascalCase(effectiveRouteName);
    const mfeNameCamel = mfeNamePascal.charAt(0).toLowerCase() + mfeNamePascal.slice(1);
    const serviceNameSnake = mfeName.replace(/-/g, '_');

    const templateVars = {
      mfeName,
      mfeNamePascal,
      mfeNameCamel,
      mfePort: String(mfePort),
      serviceName: `${mfeName}-service`,
      serviceNamePascal: `${mfeNamePascal}Service`,
      serviceNameCamel: `${mfeNameCamel}Service`,
      serviceNameSnake
    };

    // Determine which template bundle to use
    const bundle = templateBundles[templateType];

    // Files to skip from template (we'll use generated versions)
    const skipFiles = new Set(Object.keys(customFiles));

    // Add template bundle files first (if available)
    if (bundle?.files) {
      for (const [filePath, content] of Object.entries(bundle.files)) {
        if (skipFiles.has(filePath)) continue;

        let processedContent = content;
        if (templateType === 'angular') {
          processedContent = applyTemplateVars(content, templateVars);
        } else if (templateType === 'go') {
          processedContent = applyGoTemplateVars(content, templateVars);
        } else if (templateType === 'java') {
          processedContent = applyJavaTemplateVars(content, templateVars);
        }
        zip.file(filePath, processedContent);
      }
    }

    // Add/overlay custom generated files
    for (const [filePath, content] of Object.entries(customFiles)) {
      zip.file(filePath, content);
    }

    // Generate ZIP blob and trigger download
    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${projectName}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [templateBundles, effectiveRouteName, mfePort, applyTemplateVars, applyGoTemplateVars, applyJavaTemplateVars]);

  // Generate downloadable MFE project
  const handleDownloadProject = useCallback(async () => {
    if (!generatedCode || !architecture) return;

    setIsDownloading(true);

    try {
      const mfeName = toKebabCase(effectiveRouteName);
      const mfeNamePascal = toPascalCase(effectiveRouteName);
      const mfeNameCamel = toCamelCaseStr(effectiveRouteName);
      const transactionCode = transactionData?.menuItem?.trn?.idMBkl || 'TRN';
      const transactionTitle = transactionData?.menuItem?.nomeLogico || 'Transação';
      const transactionModule = transactionData?.menuItem?.trn?.module || 'TRN';

      // Extract context variable from flowContext (dynamic - not hardcoded ProgDestinoCOMEX)
      const flowContext = transactionData?.menuItem?.flowContext || transactionData?.flowContext || {};
      const contextVarName = Object.keys(flowContext)[0] || '_TRN_PARAM_0';
      const contextVarValue = flowContext[contextVarName] || '';

      // Generate project files
      const projectFiles = generateProjectFiles({
        mfeName,
        mfeNamePascal,
        mfeNameCamel,
        mfePort,
        transactionCode,
        transactionTitle,
        transactionModule,
        contextVarName,
        contextVarValue,
        generatedCode,
        architecture
      });

      // Create and download ZIP with full Angular template
      await downloadAsZip(`mf-${mfeName}`, projectFiles, 'angular');
    } catch (error) {
      console.error('Error generating project:', error);
    } finally {
      setIsDownloading(false);
    }
  }, [generatedCode, architecture, effectiveRouteName, mfePort, transactionData, downloadAsZip]);

  // Generate project files for download
  const generateProjectFiles = ({ mfeName, mfeNamePascal, mfeNameCamel, mfePort, transactionCode, transactionTitle, transactionModule, contextVarName, contextVarValue, generatedCode, architecture }) => {
    const files = {};

    // package.json
    files['package.json'] = JSON.stringify({
      name: `mf-${mfeName}`,
      version: '1.0.0',
      description: `Microfrontend ${mfeNamePascal} - ${transactionTitle}`,
      scripts: {
        ng: 'ng',
        start: `ng serve --port ${mfePort}`,
        'start:dev': `ng serve --configuration=development --port ${mfePort}`,
        build: 'ng build',
        'build:prod': 'ng build --configuration=production',
        test: 'jest --no-cache --coverage',
        lint: 'ng lint'
      },
      dependencies: {
        '@angular/animations': '15.2.10',
        '@angular/cdk': '15.2.9',
        '@angular/common': '15.2.10',
        '@angular/compiler': '15.2.10',
        '@angular/core': '15.2.10',
        '@angular/elements': '15.2.10',
        '@angular/forms': '15.2.10',
        '@angular/platform-browser': '15.2.10',
        '@angular/platform-browser-dynamic': '15.2.10',
        '@angular/router': '15.2.10',
        '@ngneat/until-destroy': '10.0.0',
        '@ngx-translate/core': '14.0.0',
        '@ngx-translate/http-loader': '7.0.0',
        rxjs: '~7.8.0',
        tslib: '^2.3.0',
        'zone.js': '~0.12.0'
      },
      devDependencies: {
        '@angular-architects/module-federation': '15.0.3',
        '@angular-devkit/build-angular': '15.2.11',
        '@angular/cli': '15.2.11',
        '@angular/compiler-cli': '15.2.10',
        typescript: '~4.9.5'
      }
    }, null, 2);

    // webpack.config.js
    files['webpack.config.js'] = `/**
 * Module Federation Remote Configuration - ${mfeNamePascal}
 * Port: ${mfePort}
 */
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");

module.exports = {
  output: {
    uniqueName: "mf${mfeNamePascal}",
    publicPath: "auto",
    scriptType: "text/javascript"
  },
  optimization: {
    runtimeChunk: false
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "mf${mfeNamePascal}",
      filename: "remoteEntry.js",
      exposes: {
        "./routes": "./src/app/app.routes.ts",
        "./Module": "./src/bootstrap.ts"
      },
      shared: {
        "@angular/core": { singleton: true, strictVersion: true, requiredVersion: "15.2.10" },
        "@angular/common": { singleton: true, strictVersion: true, requiredVersion: "15.2.10" },
        "@angular/router": { singleton: true, strictVersion: true, requiredVersion: "15.2.10" },
        "@angular/forms": { singleton: true, strictVersion: true, requiredVersion: "15.2.10" },
        "rxjs": { singleton: true, strictVersion: false, requiredVersion: "^7.8.0" },
        "@ngx-translate/core": { singleton: true, strictVersion: true, requiredVersion: "14.0.0" }
      }
    })
  ]
};`;

    // angular.json
    files['angular.json'] = JSON.stringify({
      $schema: './node_modules/@angular/cli/lib/config/schema.json',
      version: 1,
      projects: {
        [`mf-${mfeName}`]: {
          projectType: 'application',
          root: '',
          sourceRoot: 'src',
          prefix: 'app',
          architect: {
            build: {
              builder: 'ngx-build-plus:browser',
              options: {
                outputPath: `dist/mf-${mfeName}`,
                index: 'src/index.html',
                main: 'src/main.ts',
                polyfills: ['zone.js'],
                tsConfig: 'tsconfig.app.json',
                extraWebpackConfig: 'webpack.config.js'
              }
            },
            serve: {
              builder: 'ngx-build-plus:dev-server',
              options: { port: mfePort },
              configurations: {
                development: { browserTarget: `mf-${mfeName}:build:development` }
              }
            }
          }
        }
      }
    }, null, 2);

    // src/index.html
    files['src/index.html'] = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>MF ${mfeNamePascal}</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
  <mf-${mfeName}-root></mf-${mfeName}-root>
</body>
</html>`;

    // src/main.ts
    files['src/main.ts'] = `import('./bootstrap').catch(err => console.error(err));`;

    // src/bootstrap.ts
    files['src/bootstrap.ts'] = `import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';

bootstrapApplication(AppComponent, appConfig)
  .catch(err => console.error(err));`;

    // src/app/app.component.ts
    files['src/app/app.component.ts'] = `import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'mf-${mfeName}-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  template: \`
    <div class="mfe-container">
      <header class="mfe-header">
        <h1>${transactionTitle}</h1>
        <span class="trn-code">${transactionCode}</span>
      </header>
      <main class="mfe-content">
        <router-outlet></router-outlet>
      </main>
    </div>
  \`,
  styles: [\`
    .mfe-container { padding: 1rem; }
    .mfe-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem; }
    .mfe-header h1 { font-size: 1.25rem; margin: 0; }
    .trn-code { background: #e0e0e0; padding: 0.25rem 0.5rem; border-radius: 4px; font-family: monospace; }
  \`]
})
export class AppComponent {}`;

    // src/app/app.config.ts
    files['src/app/app.config.ts'] = `import { ApplicationConfig } from '@angular/core';
import { provideRouter, withHashLocation } from '@angular/router';
import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes, withHashLocation())
  ]
};`;

    // src/app/app.routes.ts with generated components
    const routeImports = generatedCode.screens.map((s, i) =>
      `import { ${s.name}Component } from './features/${s.name.toLowerCase()}/${s.name.toLowerCase()}.component';`
    ).join('\\n');

    const routeDefinitions = generatedCode.screens.map((s, i) =>
      `  { path: '${s.name.toLowerCase()}', component: ${s.name}Component }`
    ).join(',\\n');

    files['src/app/app.routes.ts'] = `import { Routes } from '@angular/router';
${routeImports}

/**
 * Route Configuration for ${transactionTitle}
 * Transaction: ${transactionModule} (${transactionCode})
 * Context Variable: ${contextVarName} = "${contextVarValue}"
 */
export const routes: Routes = [
  { path: '', redirectTo: '${generatedCode.screens[0]?.name.toLowerCase() || 'home'}', pathMatch: 'full' },
${routeDefinitions}
];

/**
 * Transaction Flow Configuration
 * The context variable "${contextVarName}" determines the flow variation
 */
export const TRANSACTION_FLOW = [
${generatedCode.screens.map(s => `  '${s.name.toLowerCase()}'`).join(',\\n')}
];

/**
 * Context Configuration
 * Note: This uses the actual routing variable from the legacy system
 * instead of hardcoded "ProgDestinoCOMEX" (which is COMEX-specific)
 */
export const CONTEXT_VAR_NAME = '${contextVarName}';
export const CONTEXT_VAR_VALUE = '${contextVarValue}';

export const NAVIGATION_MAP: Record<string, string> = {
  '${contextVarValue}': '${generatedCode.screens[0]?.name.toLowerCase() || 'home'}'
};

export const TITLE_MAP: Record<string, string> = {
  '${contextVarValue}': '${transactionTitle}'
};`;

    // Generate feature components
    generatedCode.screens.forEach(screen => {
      const compPath = `src/app/features/${screen.name.toLowerCase()}/${screen.name.toLowerCase()}.component.ts`;
      files[compPath] = `import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-${screen.name.toLowerCase()}',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: \`
${screen.template.split('\\n').map(line => '    ' + line).join('\\n')}
  \`,
  styles: [\`
    :host { display: block; padding: 1rem; }
  \`]
})
export class ${screen.name}Component implements OnInit {
  form: any = {};

  ngOnInit() {
    console.log('${screen.name}Component initialized');
  }
}`;
    });

    // Core services - Navigation Service with dynamic context variable
    files['src/app/core/services/navigation.service.ts'] = `import { Injectable, inject } from '@angular/core';
import { Router } from '@angular/router';
import { SessionService } from './session.service';
import { CONTEXT_VAR_NAME, TRANSACTION_FLOW, NAVIGATION_MAP, TITLE_MAP } from '../../app.routes';

/**
 * Navigation Service - ${transactionTitle}
 *
 * Context Variable: ${contextVarName} (discovered from legacy XML)
 * Unlike hardcoded "ProgDestinoCOMEX", this uses the actual routing variable
 * from the transaction's flowContext.
 */
@Injectable({ providedIn: 'root' })
export class NavigationService {
  private readonly router = inject(Router);
  private readonly sessionService = inject(SessionService);
  private navigationHistory: string[] = [];

  /**
   * Navigate to next screen in flow
   */
  navigateNext(): void {
    const contextValue = this.sessionService.getAttribute(CONTEXT_VAR_NAME) || '${contextVarValue}';
    const currentPath = this.router.url.split('/').pop() || '';
    const currentIndex = TRANSACTION_FLOW.indexOf(currentPath);
    const nextIndex = currentIndex + 1;

    if (nextIndex < TRANSACTION_FLOW.length) {
      this.navigationHistory.push(this.router.url);
      this.router.navigate([TRANSACTION_FLOW[nextIndex]]);
    }
  }

  /**
   * Navigate to a specific route
   */
  navigateTo(route: string, saveHistory = true): void {
    if (saveHistory) {
      this.navigationHistory.push(this.router.url);
    }
    this.router.navigate([route]);
  }

  /**
   * Navigate back
   */
  navigateBack(): void {
    const previousRoute = this.navigationHistory.pop();
    if (previousRoute) {
      this.router.navigate([previousRoute]);
    } else {
      const currentPath = this.router.url.split('/').pop() || '';
      const currentIndex = TRANSACTION_FLOW.indexOf(currentPath);
      if (currentIndex > 0) {
        this.router.navigate([TRANSACTION_FLOW[currentIndex - 1]]);
      }
    }
  }

  /**
   * Get title for current transaction
   */
  getTitle(): string {
    const contextValue = this.sessionService.getAttribute(CONTEXT_VAR_NAME);
    return TITLE_MAP[contextValue] || '${transactionTitle}';
  }

  /**
   * Get the context variable name used for routing
   */
  getContextVarName(): string {
    return CONTEXT_VAR_NAME;
  }

  clearHistory(): void {
    this.navigationHistory = [];
  }
}`;

    // Core services - Session Service
    files['src/app/core/services/session.service.ts'] = `import { Injectable } from '@angular/core';

/**
 * Session Service - ${transactionTitle}
 *
 * Manages session state and context variables.
 * Primary context variable: ${contextVarName}
 */
@Injectable({ providedIn: 'root' })
export class SessionService {
  private attributes: Map<string, string> = new Map();
  private fieldValues: Map<string, Map<string, string>> = new Map();

  /**
   * Set session attribute
   */
  setAttribute(key: string, value: string): void {
    this.attributes.set(key, value);
  }

  /**
   * Get session attribute
   */
  getAttribute(key: string): string {
    return this.attributes.get(key) || '';
  }

  /**
   * Save field value for a screen
   */
  saveField(transaction: string, sp: string, screen: string, field: string, value: string): void {
    const key = \`\${transaction}|\${sp}|\${screen}\`;
    if (!this.fieldValues.has(key)) {
      this.fieldValues.set(key, new Map());
    }
    this.fieldValues.get(key)!.set(field, value);
  }

  /**
   * Get field value from a screen
   */
  getField(transaction: string, sp: string, screen: string, field: string): string {
    const key = \`\${transaction}|\${sp}|\${screen}\`;
    return this.fieldValues.get(key)?.get(field) || '';
  }

  /**
   * Clear all session data
   */
  clear(): void {
    this.attributes.clear();
    this.fieldValues.clear();
  }
}`;

    // tsconfig files
    files['tsconfig.json'] = JSON.stringify({
      compileOnSave: false,
      compilerOptions: {
        baseUrl: './',
        outDir: './dist/out-tsc',
        strict: true,
        noImplicitOverride: true,
        noPropertyAccessFromIndexSignature: true,
        noImplicitReturns: true,
        noFallthroughCasesInSwitch: true,
        sourceMap: true,
        declaration: false,
        downlevelIteration: true,
        experimentalDecorators: true,
        moduleResolution: 'node',
        importHelpers: true,
        target: 'ES2022',
        module: 'ES2022',
        useDefineForClassFields: false,
        lib: ['ES2022', 'dom'],
        paths: {
          '@core/*': ['src/app/core/*'],
          '@shared/*': ['src/app/shared/*'],
          '@features/*': ['src/app/features/*']
        }
      },
      angularCompilerOptions: {
        enableI18nLegacyMessageIdFormat: false,
        strictInjectionParameters: true,
        strictInputAccessModifiers: true,
        strictTemplates: true
      }
    }, null, 2);

    files['tsconfig.app.json'] = JSON.stringify({
      extends: './tsconfig.json',
      compilerOptions: { outDir: './out-tsc/app' },
      files: ['src/main.ts'],
      include: ['src/**/*.d.ts']
    }, null, 2);

    // README
    files['README.md'] = `# MF ${mfeNamePascal}

Angular Microfrontend generated from legacy transaction: ${transactionCode}

## Transaction Information

| Property | Value |
|----------|-------|
| Module | ${transactionModule} |
| Transaction Code | ${transactionCode} |
| Title | ${transactionTitle} |
| Context Variable | \`${contextVarName}\` |
| Context Value | \`${contextVarValue}\` |

## Context Variable

This MFE uses **\`${contextVarName}\`** as the routing context variable.

> **Note:** Unlike COMEX transactions that use \`ProgDestinoCOMEX\`, this transaction
> uses a different context variable discovered from the legacy XML extraction.
> The navigation service is configured to use this variable dynamically.

## Development

\`\`\`bash
npm install
npm start
\`\`\`

Server runs at: http://localhost:${mfePort}

## Build

\`\`\`bash
npm run build:prod
\`\`\`

## Integration

Add to shell's federation config:
\`\`\`javascript
{
  type: 'script',
  remoteEntry: 'http://localhost:${mfePort}/remoteEntry.js',
  remoteName: 'mf${mfeNamePascal}',
  exposedModule: './routes'
}
\`\`\`
`;

    return files;
  };

  /**
   * Generate Go backend project files
   * Creates a complete Go microservice with adapters for WebService, ADO, Mainframe
   */
  const generateGoProjectFiles = ({ serviceName, serviceNamePascal, transactionCode, transactionTitle, transactionModule, architecture }) => {
    const files = {};

    // go.mod
    files['go.mod'] = `module github.com/itau/${serviceName}

go 1.21

require (
	github.com/gin-gonic/gin v1.9.1
	github.com/spf13/viper v1.18.2
	go.uber.org/zap v1.26.0
	github.com/prometheus/client_golang v1.18.0
)
`;

    // main.go
    files['cmd/server/main.go'] = `package main

import (
	"log"
	"github.com/itau/${serviceName}/internal/config"
	"github.com/itau/${serviceName}/internal/handler"
	"github.com/itau/${serviceName}/internal/service"
	"github.com/gin-gonic/gin"
)

// ${serviceNamePascal} - ${transactionTitle}
// Transaction: ${transactionModule}
// Generated with IDS v2 Web Components architecture

func main() {
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}

	svc := service.New${serviceNamePascal}Service(cfg)
	h := handler.New${serviceNamePascal}Handler(svc)

	r := gin.Default()

	// Health check
	r.GET("/health", h.Health)

	// API routes
	api := r.Group("/api/v1/${serviceName}")
	{
		api.GET("/", h.List)
		api.GET("/:id", h.Get)
		api.POST("/", h.Create)
		api.PUT("/:id", h.Update)
	}

	if err := r.Run(cfg.ServerPort); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}
`;

    // Config
    files['internal/config/config.go'] = `package config

import "github.com/spf13/viper"

type Config struct {
	ServerPort    string
	DatabaseURL   string
	MainframeHost string
	MainframePort int
	WebServiceURL string
}

func Load() (*Config, error) {
	viper.SetDefault("SERVER_PORT", ":8080")
	viper.AutomaticEnv()

	return &Config{
		ServerPort:    viper.GetString("SERVER_PORT"),
		DatabaseURL:   viper.GetString("DATABASE_URL"),
		MainframeHost: viper.GetString("MAINFRAME_HOST"),
		MainframePort: viper.GetInt("MAINFRAME_PORT"),
		WebServiceURL: viper.GetString("WEB_SERVICE_URL"),
	}, nil
}
`;

    // Domain model
    files['internal/domain/model.go'] = `package domain

import "time"

// ${serviceNamePascal}Request - Request from ${transactionTitle}
type ${serviceNamePascal}Request struct {
${architecture?.components?.map(c =>
  c.fields?.slice(0, 5).map(f => `\t${toPascalCase(f.name)} string \`json:"${toCamelCase(f.name)}"\``).join('\n')
).join('\n') || '\tID string `json:"id"`'}
}

// ${serviceNamePascal}Response - Response for ${transactionTitle}
type ${serviceNamePascal}Response struct {
	ID        string    \`json:"id"\`
	Status    string    \`json:"status"\`
	Message   string    \`json:"message,omitempty"\`
	Data      any       \`json:"data,omitempty"\`
	Timestamp time.Time \`json:"timestamp"\`
}
`;

    // Service interface
    files['internal/service/service.go'] = `package service

import (
	"context"
	"github.com/itau/${serviceName}/internal/domain"
	"github.com/itau/${serviceName}/internal/config"
)

type ${serviceNamePascal}Service interface {
	List(ctx context.Context) ([]domain.${serviceNamePascal}Response, error)
	Get(ctx context.Context, id string) (*domain.${serviceNamePascal}Response, error)
	Create(ctx context.Context, req domain.${serviceNamePascal}Request) (*domain.${serviceNamePascal}Response, error)
	Update(ctx context.Context, id string, req domain.${serviceNamePascal}Request) (*domain.${serviceNamePascal}Response, error)
}

type ${serviceName}Service struct {
	cfg *config.Config
}

func New${serviceNamePascal}Service(cfg *config.Config) ${serviceNamePascal}Service {
	return &${serviceName}Service{cfg: cfg}
}

func (s *${serviceName}Service) List(ctx context.Context) ([]domain.${serviceNamePascal}Response, error) {
	// TODO: Implement list logic
	return []domain.${serviceNamePascal}Response{}, nil
}

func (s *${serviceName}Service) Get(ctx context.Context, id string) (*domain.${serviceNamePascal}Response, error) {
	// TODO: Implement get logic
	return &domain.${serviceNamePascal}Response{ID: id}, nil
}

func (s *${serviceName}Service) Create(ctx context.Context, req domain.${serviceNamePascal}Request) (*domain.${serviceNamePascal}Response, error) {
	// TODO: Implement create logic
	return &domain.${serviceNamePascal}Response{Status: "created"}, nil
}

func (s *${serviceName}Service) Update(ctx context.Context, id string, req domain.${serviceNamePascal}Request) (*domain.${serviceNamePascal}Response, error) {
	// TODO: Implement update logic
	return &domain.${serviceNamePascal}Response{ID: id, Status: "updated"}, nil
}
`;

    // Handler
    files['internal/handler/handler.go'] = `package handler

import (
	"net/http"
	"github.com/gin-gonic/gin"
	"github.com/itau/${serviceName}/internal/service"
	"github.com/itau/${serviceName}/internal/domain"
)

type ${serviceNamePascal}Handler struct {
	svc service.${serviceNamePascal}Service
}

func New${serviceNamePascal}Handler(svc service.${serviceNamePascal}Service) *${serviceNamePascal}Handler {
	return &${serviceNamePascal}Handler{svc: svc}
}

func (h *${serviceNamePascal}Handler) Health(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"status": "healthy"})
}

func (h *${serviceNamePascal}Handler) List(c *gin.Context) {
	result, err := h.svc.List(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, result)
}

func (h *${serviceNamePascal}Handler) Get(c *gin.Context) {
	id := c.Param("id")
	result, err := h.svc.Get(c.Request.Context(), id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, result)
}

func (h *${serviceNamePascal}Handler) Create(c *gin.Context) {
	var req domain.${serviceNamePascal}Request
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	result, err := h.svc.Create(c.Request.Context(), req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, result)
}

func (h *${serviceNamePascal}Handler) Update(c *gin.Context) {
	id := c.Param("id")
	var req domain.${serviceNamePascal}Request
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	result, err := h.svc.Update(c.Request.Context(), id, req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, result)
}
`;

    // Dockerfile
    files['Dockerfile'] = `FROM golang:1.21-alpine AS builder

WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 GOOS=linux go build -o /server ./cmd/server

FROM alpine:3.19
COPY --from=builder /server /server
EXPOSE 8080
CMD ["/server"]
`;

    // README
    files['README.md'] = `# ${serviceNamePascal} Go Service

Backend service for ${transactionTitle} (${transactionModule})

## Generated for IDS v2 Web Components

## Build

\`\`\`bash
go build -o server ./cmd/server
\`\`\`

## Run

\`\`\`bash
./server
\`\`\`

## Docker

\`\`\`bash
docker build -t ${serviceName} .
docker run -p 8080:8080 ${serviceName}
\`\`\`
`;

    return files;
  };

  /**
   * Generate Java Spring Boot project files
   * Creates a complete Spring Boot microservice with adapters
   */
  const generateJavaProjectFiles = ({ serviceName, serviceNamePascal, transactionCode, transactionTitle, transactionModule, architecture }) => {
    const files = {};
    const packagePath = `com/itau/${serviceName.replace(/-/g, '')}`;

    // pom.xml
    files['pom.xml'] = `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.1</version>
        <relativePath/>
    </parent>

    <groupId>com.itau</groupId>
    <artifactId>${serviceName}</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <name>${serviceNamePascal}</name>
    <description>${transactionTitle} - ${transactionModule}</description>

    <properties>
        <java.version>17</java.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
`;

    // Application.java
    files[`src/main/java/${packagePath}/${serviceNamePascal}Application.java`] = `package com.itau.${serviceName.replace(/-/g, '')};

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * ${serviceNamePascal} Application
 * ${transactionTitle} - ${transactionModule}
 * Generated with IDS v2 Web Components architecture
 */
@SpringBootApplication
public class ${serviceNamePascal}Application {
    public static void main(String[] args) {
        SpringApplication.run(${serviceNamePascal}Application.class, args);
    }
}
`;

    // DTO Request
    files[`src/main/java/${packagePath}/dto/${serviceNamePascal}Request.java`] = `package com.itau.${serviceName.replace(/-/g, '')}.dto;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;

@Data
public class ${serviceNamePascal}Request {
${architecture?.components?.slice(0, 1).map(c =>
  c.fields?.slice(0, 5).map(f => `    @NotBlank\n    private String ${toCamelCase(f.name)};`).join('\n\n')
).join('\n\n') || '    @NotBlank\n    private String id;'}
}
`;

    // DTO Response
    files[`src/main/java/${packagePath}/dto/${serviceNamePascal}Response.java`] = `package com.itau.${serviceName.replace(/-/g, '')}.dto;

import lombok.Data;
import lombok.Builder;
import java.time.LocalDateTime;

@Data
@Builder
public class ${serviceNamePascal}Response {
    private String id;
    private String status;
    private String message;
    private Object data;
    private LocalDateTime timestamp;
}
`;

    // Service interface
    files[`src/main/java/${packagePath}/service/${serviceNamePascal}Service.java`] = `package com.itau.${serviceName.replace(/-/g, '')}.service;

import com.itau.${serviceName.replace(/-/g, '')}.dto.*;
import java.util.List;

public interface ${serviceNamePascal}Service {
    List<${serviceNamePascal}Response> list();
    ${serviceNamePascal}Response get(String id);
    ${serviceNamePascal}Response create(${serviceNamePascal}Request request);
    ${serviceNamePascal}Response update(String id, ${serviceNamePascal}Request request);
}
`;

    // Service implementation
    files[`src/main/java/${packagePath}/service/impl/${serviceNamePascal}ServiceImpl.java`] = `package com.itau.${serviceName.replace(/-/g, '')}.service.impl;

import com.itau.${serviceName.replace(/-/g, '')}.dto.*;
import com.itau.${serviceName.replace(/-/g, '')}.service.${serviceNamePascal}Service;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

@Service
public class ${serviceNamePascal}ServiceImpl implements ${serviceNamePascal}Service {

    @Override
    public List<${serviceNamePascal}Response> list() {
        // TODO: Implement list logic
        return new ArrayList<>();
    }

    @Override
    public ${serviceNamePascal}Response get(String id) {
        // TODO: Implement get logic
        return ${serviceNamePascal}Response.builder()
            .id(id)
            .timestamp(LocalDateTime.now())
            .build();
    }

    @Override
    public ${serviceNamePascal}Response create(${serviceNamePascal}Request request) {
        // TODO: Implement create logic
        return ${serviceNamePascal}Response.builder()
            .status("created")
            .timestamp(LocalDateTime.now())
            .build();
    }

    @Override
    public ${serviceNamePascal}Response update(String id, ${serviceNamePascal}Request request) {
        // TODO: Implement update logic
        return ${serviceNamePascal}Response.builder()
            .id(id)
            .status("updated")
            .timestamp(LocalDateTime.now())
            .build();
    }
}
`;

    // Controller
    files[`src/main/java/${packagePath}/controller/${serviceNamePascal}Controller.java`] = `package com.itau.${serviceName.replace(/-/g, '')}.controller;

import com.itau.${serviceName.replace(/-/g, '')}.dto.*;
import com.itau.${serviceName.replace(/-/g, '')}.service.${serviceNamePascal}Service;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/${serviceName}")
@RequiredArgsConstructor
public class ${serviceNamePascal}Controller {

    private final ${serviceNamePascal}Service service;

    @GetMapping
    public ResponseEntity<List<${serviceNamePascal}Response>> list() {
        return ResponseEntity.ok(service.list());
    }

    @GetMapping("/{id}")
    public ResponseEntity<${serviceNamePascal}Response> get(@PathVariable String id) {
        return ResponseEntity.ok(service.get(id));
    }

    @PostMapping
    public ResponseEntity<${serviceNamePascal}Response> create(@Valid @RequestBody ${serviceNamePascal}Request request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<${serviceNamePascal}Response> update(
            @PathVariable String id,
            @Valid @RequestBody ${serviceNamePascal}Request request) {
        return ResponseEntity.ok(service.update(id, request));
    }
}
`;

    // application.yml
    files['src/main/resources/application.yml'] = `server:
  port: 8080

spring:
  application:
    name: ${serviceName}

management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics
`;

    // Dockerfile
    files['Dockerfile'] = `FROM eclipse-temurin:17-jdk-alpine AS builder
WORKDIR /app
COPY pom.xml .
COPY src ./src
RUN ./mvnw clean package -DskipTests

FROM eclipse-temurin:17-jre-alpine
COPY --from=builder /app/target/*.jar /app/app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "/app/app.jar"]
`;

    // README
    files['README.md'] = `# ${serviceNamePascal} Java Service

Spring Boot backend service for ${transactionTitle} (${transactionModule})

## Generated for IDS v2 Web Components

## Build

\`\`\`bash
./mvnw clean package
\`\`\`

## Run

\`\`\`bash
./mvnw spring-boot:run
\`\`\`

## Docker

\`\`\`bash
docker build -t ${serviceName} .
docker run -p 8080:8080 ${serviceName}
\`\`\`
`;

    return files;
  };

  // Download Go project
  const handleDownloadGoProject = useCallback(async () => {
    if (!architecture) return;
    setIsDownloading(true);

    try {
      const serviceName = toKebabCase(effectiveRouteName);
      const serviceNamePascal = toPascalCase(effectiveRouteName);
      const transactionCode = transactionData?.menuItem?.trn?.idMBkl || 'TRN';
      const transactionTitle = transactionData?.menuItem?.nomeLogico || 'Transação';
      const transactionModule = transactionData?.menuItem?.trn?.module || 'TRN';

      const goFiles = generateGoProjectFiles({
        serviceName,
        serviceNamePascal,
        transactionCode,
        transactionTitle,
        transactionModule,
        architecture
      });

      await downloadAsZip(`${serviceName}-go`, goFiles, 'go');
    } finally {
      setIsDownloading(false);
    }
  }, [architecture, effectiveRouteName, transactionData, downloadAsZip]);

  // Download Java project
  const handleDownloadJavaProject = useCallback(async () => {
    if (!architecture) return;
    setIsDownloading(true);

    try {
      const serviceName = toKebabCase(effectiveRouteName);
      const serviceNamePascal = toPascalCase(effectiveRouteName);
      const transactionCode = transactionData?.menuItem?.trn?.idMBkl || 'TRN';
      const transactionTitle = transactionData?.menuItem?.nomeLogico || 'Transação';
      const transactionModule = transactionData?.menuItem?.trn?.module || 'TRN';

      const javaFiles = generateJavaProjectFiles({
        serviceName,
        serviceNamePascal,
        transactionCode,
        transactionTitle,
        transactionModule,
        architecture
      });

      await downloadAsZip(`${serviceName}-java`, javaFiles, 'java');
    } finally {
      setIsDownloading(false);
    }
  }, [architecture, effectiveRouteName, transactionData, downloadAsZip]);

  // Generate IDS components from field metadata
  const handleGenerate = useCallback(() => {
    if (!transactionData?.flow?.interactions) return;

    setIsGenerating(true);

    // Simulate processing delay for UX
    setTimeout(() => {
      const interactions = transactionData.flow.interactions || [];
      const generatedScreens = [];
      const transactionCode = transactionData.menuItem?.trn?.module || 'TRN';

      for (const interaction of interactions) {
        if (interaction.type !== 'Browser' && interaction.type !== 'Formulario') continue;

        const fields = interaction.fields || {};
        const allFields = [
          ...(fields.wsInputs || []),
          ...(fields.inputs || []),
          ...(fields.lists || []),
          ...(fields.bindings || [])
        ];

        // Extract fieldGroups from interaction (explicit date/select groups)
        const fieldGroups = extractFieldGroups(interaction);

        // Group and map fields to IDS components with fieldGroups support
        const mappedFields = groupDateFields(allFields, fieldGroups);

        // Generate component template
        const componentName = (interaction.name || interaction.path.split('\\').pop())
          .replace(/[^a-zA-Z0-9]/g, '')
          .replace(/^./, c => c.toUpperCase());

        // Generate i18n key prefix
        const i18nPrefix = `${transactionCode.toLowerCase()}.${componentName.toLowerCase()}`;

        generatedScreens.push({
          name: componentName,
          legacyPath: interaction.path,
          legacyName: interaction.name,
          fields: mappedFields,
          fieldGroups,
          template: generateTemplate(componentName, mappedFields, i18nPrefix),
          typescript: generateTypeScript(componentName, mappedFields),
          i18n: generateI18nDefaults(componentName, mappedFields, i18nPrefix)
        });
      }

      // Count component types for stats
      const allFields = generatedScreens.flatMap(s => s.fields);
      setGeneratedCode({
        screens: generatedScreens,
        totalFields: allFields.length,
        componentStats: {
          // IDS v2 migrated components
          buttons: 2, // voltar + enviar per screen
          icons: allFields.filter(f => f._idsMapping?.template === 'select').length, // chevron icons
          // Date components (shared)
          datePickers: allFields.filter(f => f._idsMapping?.template === 'dateRange' || f._idsMapping?.template === 'dateSingle').length,
          // Pending v2 - using native + tokens
          selects: allFields.filter(f => f._idsMapping?.template === 'select').length,
          tables: allFields.filter(f => f._idsMapping?.template === 'table').length,
          textFields: allFields.filter(f => f._idsMapping?.template === 'text' || f._idsMapping?.template === 'readonly').length,
          currencyFields: allFields.filter(f => f._idsMapping?.template === 'currency').length,
          checkboxes: allFields.filter(f => f._idsMapping?.template === 'checkbox').length,
          radios: allFields.filter(f => f._idsMapping?.template === 'radio').length
        },
        v2Status: {
          migrated: ['idsw-button', 'idsw-icon', 'idsw-loading', 'idsw-tooltip', 'idsw-password'],
          pendingV2: ['select', 'table', 'checkbox', 'radio', 'modal', 'tabs'],
          usingTokens: ['form-field', 'input', 'date-inputs']
        }
      });

      setIsGenerating(false);
    }, 500);
  }, [transactionData]);

  /**
   * Generate Angular template HTML using IDS v2 Web Components
   *
   * IDS v2 MIGRATION:
   * - Buttons: ids-main-button → idsw-button with variant="primary|secondary|tertiary"
   * - Icons: ids-icon → idsw-icon (naming: {name}_base for outline, {name}_variant for filled)
   * - Loading: ids-loading → idsw-loading
   * - Pending components use native HTML + IDS tokens (via CSS variables)
   *
   * Official icon examples: pix_base, calendar_day_base, arrow_flat_down_base
   * @see config/IDS_OFFICIAL_ICONS.md for complete reference
   *
   * Uses Reactive Forms (formControlName) and i18n keys with TranslateModule
   */
  const generateTemplate = (componentName, fields, i18nPrefix = '') => {
    const lines = [
      `<!-- IDS v2 Web Components Template -->`,
      `<!-- Note: Import Web Components in component: import '@ids/web/button'; -->`,
      `<form [formGroup]="form" (ngSubmit)="onSubmit()">`,
      `  <div class="${componentName.toLowerCase()}-container ids-layout-container">`
    ];

    for (const field of fields) {
      const mapping = field._idsMapping || {};
      const props = mapping.props || {};
      const label = field.name || 'Campo';
      const formControlName = toCamelCase(label);
      const i18nKey = i18nPrefix ? `${i18nPrefix}.fields.${formControlName}` : label;

      switch (mapping.template) {
        case 'dateRange':
          // Date range using shared DateRangePickerComponent
          lines.push(`    <!-- Date Range: ${label} -->`);
          lines.push(`    <div class="date-section ids-spacing-mb-4">`);
          lines.push(`      <app-date-range-picker`);
          lines.push(`        [form]="dateForm"`);
          lines.push(`        [opcional]="${props.opcional !== false}"`);
          lines.push(`        [showWarning]="${props.showWarning !== false}"`);
          lines.push(`        [maxDays]="${props.maxDays || 90}">`);
          lines.push(`      </app-date-range-picker>`);
          lines.push(`    </div>`);
          break;

        case 'dateSingle':
          // Single date using inline DD/MM/AAAA inputs with IDS tokens styling
          lines.push(`    <!-- Single Date: ${label} -->`);
          lines.push(`    <div class="form-field ids-spacing-mb-3">`);
          lines.push(`      <label class="ids-typography-label-01 ids-spacing-mb-1">{{ '${i18nKey}' | translate }}</label>`);
          lines.push(`      <div class="date-inputs-group">`);
          lines.push(`        <input type="text" formControlName="${formControlName}Dia" maxlength="2"`);
          lines.push(`          placeholder="DD" class="date-input ids-input-base" />`);
          lines.push(`        <span class="date-separator">/</span>`);
          lines.push(`        <input type="text" formControlName="${formControlName}Mes" maxlength="2"`);
          lines.push(`          placeholder="MM" class="date-input ids-input-base" />`);
          lines.push(`        <span class="date-separator">/</span>`);
          lines.push(`        <input type="text" formControlName="${formControlName}Ano" maxlength="4"`);
          lines.push(`          placeholder="AAAA" class="date-input date-year ids-input-base" />`);
          lines.push(`      </div>`);
          lines.push(`    </div>`);
          break;

        case 'select':
          // Native select with IDS tokens (pending v2 migration)
          lines.push(`    <!-- Select: ${label} (pending idsw-select in v2) -->`);
          lines.push(`    <div class="form-field ids-spacing-mb-3">`);
          lines.push(`      <label class="ids-typography-label-01 ids-spacing-mb-1">{{ '${i18nKey}' | translate }}</label>`);
          lines.push(`      <select formControlName="${formControlName}" class="ids-select-base">`);
          lines.push(`        <option value="">Selecione...</option>`);
          lines.push(`        <option *ngFor="let opt of ${formControlName}Options" [value]="opt.value">`);
          lines.push(`          {{ opt.label }}`);
          lines.push(`        </option>`);
          lines.push(`      </select>`);
          lines.push(`      <idsw-icon name="arrow_flat_down_base" size="small" class="select-icon"></idsw-icon>`);
          lines.push(`    </div>`);
          break;

        case 'table':
          // Native table with IDS tokens (pending v2 migration)
          lines.push(`    <!-- Data Table: ${label} (pending idsw-table in v2) -->`);
          lines.push(`    <div class="table-container ids-spacing-mb-3">`);
          lines.push(`      <table class="ids-table-base">`);
          lines.push(`        <thead>`);
          lines.push(`          <tr>`);
          lines.push(`            <!-- Define columns here -->`);
          lines.push(`          </tr>`);
          lines.push(`        </thead>`);
          lines.push(`        <tbody>`);
          lines.push(`          <tr *ngFor="let row of ${formControlName}Data">`);
          lines.push(`            <!-- Define cells here -->`);
          lines.push(`          </tr>`);
          lines.push(`        </tbody>`);
          lines.push(`      </table>`);
          lines.push(`    </div>`);
          break;

        case 'currency':
          // Native input with currency mask + IDS tokens
          lines.push(`    <!-- Currency: ${label} -->`);
          lines.push(`    <div class="form-field ids-spacing-mb-3">`);
          lines.push(`      <label class="ids-typography-label-01 ids-spacing-mb-1">{{ '${i18nKey}' | translate }}</label>`);
          lines.push(`      <input type="text"`);
          lines.push(`        formControlName="${formControlName}"`);
          lines.push(`        [currencyMask]="currencyMaskConfig"`);
          lines.push(`        inputmode="decimal"`);
          lines.push(`        class="ids-input-base ids-input-currency" />`);
          lines.push(`    </div>`);
          break;

        case 'checkbox':
          // Native checkbox with IDS tokens (pending v2 migration)
          lines.push(`    <!-- Checkbox: ${label} (pending idsw-checkbox in v2) -->`);
          lines.push(`    <label class="checkbox-field ids-spacing-mb-3">`);
          lines.push(`      <input type="checkbox" formControlName="${formControlName}" class="ids-checkbox-base" />`);
          lines.push(`      <span class="checkbox-label ids-typography-body-01">{{ '${i18nKey}' | translate }}</span>`);
          lines.push(`    </label>`);
          break;

        case 'radio':
          // Native radio with IDS tokens (pending v2 migration)
          lines.push(`    <!-- Radio Group: ${label} (pending idsw-radio in v2) -->`);
          lines.push(`    <div class="form-field ids-spacing-mb-3">`);
          lines.push(`      <label class="ids-typography-label-01 ids-spacing-mb-1">{{ '${i18nKey}' | translate }}</label>`);
          lines.push(`      <div class="radio-group">`);
          lines.push(`        <label *ngFor="let opt of ${formControlName}Options" class="radio-option">`);
          lines.push(`          <input type="radio" formControlName="${formControlName}" [value]="opt.value" class="ids-radio-base" />`);
          lines.push(`          <span class="radio-label ids-typography-body-01">{{ opt.label }}</span>`);
          lines.push(`        </label>`);
          lines.push(`      </div>`);
          lines.push(`    </div>`);
          break;

        case 'readonly':
          // Native readonly input with IDS tokens
          lines.push(`    <!-- Read-only: ${label} -->`);
          lines.push(`    <div class="form-field ids-spacing-mb-3">`);
          lines.push(`      <label class="ids-typography-label-01 ids-spacing-mb-1">{{ '${i18nKey}' | translate }}</label>`);
          lines.push(`      <input type="text"`);
          lines.push(`        formControlName="${formControlName}"`);
          lines.push(`        readonly`);
          lines.push(`        class="ids-input-base ids-input-readonly" />`);
          lines.push(`    </div>`);
          break;

        case 'password':
          // IDS v2 password component
          lines.push(`    <!-- Password: ${label} (idsw-password v2) -->`);
          lines.push(`    <div class="form-field ids-spacing-mb-3">`);
          lines.push(`      <label class="ids-typography-label-01 ids-spacing-mb-1">{{ '${i18nKey}' | translate }}</label>`);
          lines.push(`      <idsw-password`);
          lines.push(`        formControlName="${formControlName}"`);
          lines.push(`        placeholder="{{ '${i18nKey}.placeholder' | translate }}">`);
          lines.push(`      </idsw-password>`);
          lines.push(`    </div>`);
          break;

        default: // text
          // Native text input with IDS tokens
          lines.push(`    <!-- Text Input: ${label} -->`);
          lines.push(`    <div class="form-field ids-spacing-mb-3">`);
          lines.push(`      <label class="ids-typography-label-01 ids-spacing-mb-1">{{ '${i18nKey}' | translate }}</label>`);
          lines.push(`      <input type="text"`);
          lines.push(`        formControlName="${formControlName}"`);
          if (props.maxLength) lines.push(`        maxlength="${props.maxLength}"`);
          lines.push(`        placeholder="{{ '${i18nKey}.placeholder' | translate }}"`);
          lines.push(`        class="ids-input-base" />`);
          lines.push(`    </div>`);
      }
      lines.push('');
    }

    // Add action buttons using IDS v2 idsw-button
    lines.push(`    <!-- Action Buttons (IDS v2: idsw-button) -->`);
    lines.push(`    <div class="button-group ids-spacing-mt-4">`);
    lines.push(`      <idsw-button variant="tertiary" type="button" @click="onVoltar()">`);
    lines.push(`        {{ '${i18nPrefix}.buttons.voltar' | translate }}`);
    lines.push(`      </idsw-button>`);
    lines.push(`      <idsw-button variant="primary" type="submit" [disabled]="form.invalid">`);
    lines.push(`        {{ '${i18nPrefix}.buttons.enviar' | translate }}`);
    lines.push(`      </idsw-button>`);
    lines.push(`    </div>`);

    lines.push('  </div>');
    lines.push('</form>');
    return lines.join('\n');
  };

  /**
   * Generate i18n translation defaults (pt-BR)
   */
  const generateI18nDefaults = (componentName, fields, i18nPrefix) => {
    const translations = {
      title: humanizeLabel(componentName),
      fields: {},
      buttons: {
        enviar: 'Enviar',
        continuar: 'Continuar',
        voltar: 'Voltar',
        limpar: 'Limpar',
        cancelar: 'Cancelar'
      },
      validation: {
        required: 'Este campo é obrigatório',
        invalidDate: 'Data inválida',
        invalidFormat: 'Formato inválido'
      }
    };

    for (const field of fields) {
      const formControlName = toCamelCase(field.name || 'field');
      translations.fields[formControlName] = humanizeLabel(field.name || 'Campo');
      translations.fields[`${formControlName}_placeholder`] = `Digite ${humanizeLabel(field.name || 'valor').toLowerCase()}`;
    }

    return translations;
  };

  /**
   * Humanize a label (camelCase/snake_case -> Title Case)
   */
  const humanizeLabel = (name) => {
    return (name || 'Campo')
      .replace(/([A-Z])/g, ' $1')
      .replace(/_/g, ' ')
      .replace(/^\s+/, '')
      .replace(/\b\w/g, c => c.toUpperCase())
      .replace(/\bCnpj\b/g, 'CNPJ')
      .replace(/\bCpf\b/g, 'CPF')
      .trim();
  };

  /**
   * Generate TypeScript component using IDS v2 Web Components
   *
   * IDS v2 Import Pattern:
   * - Side-effect imports: import '@ids/web/button';
   * - CUSTOM_ELEMENTS_SCHEMA required for Web Components
   * - Web Components use native event listeners (not Angular @Output)
   */
  const generateTypeScript = (componentName, inputFields) => {
    // Ensure fields is always an array
    const fields = Array.isArray(inputFields) ? inputFields : Object.values(inputFields || {});
    const hasDateRange = fields.some(f => f._idsMapping?.template === 'dateRange');
    const hasSingleDate = fields.some(f => f._idsMapping?.template === 'dateSingle');
    const hasSelect = fields.some(f => f._idsMapping?.template === 'select');
    const hasPassword = fields.some(f => f._idsMapping?.template === 'password');

    const lines = [];

    // Angular imports
    lines.push(`import { Component, OnInit, inject, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';`);
    lines.push(`import { CommonModule } from '@angular/common';`);
    lines.push(`import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';`);
    lines.push(`import { TranslateModule, TranslateService } from '@ngx-translate/core';`);
    lines.push(``);

    // IDS v2 Web Components imports (side-effect)
    lines.push(`// IDS v2 Web Components - Side-effect imports`);
    lines.push(`import '@ids/web/button';   // idsw-button`);
    lines.push(`import '@ids/web/icon';     // idsw-icon`);
    if (hasPassword) {
      lines.push(`import '@ids/web/password'; // idsw-password`);
    }
    lines.push(``);

    // Core services
    lines.push(`// Core services`);
    lines.push(`import { SessionService } from '../core/services/session.service';`);
    lines.push(`import { NavigationService } from '../core/services/navigation.service';`);
    if (hasDateRange) {
      lines.push(`// Shared components`);
      lines.push(`import { DateRangePickerComponent } from '../shared/components/date-range-picker/date-range-picker.component';`);
    }
    lines.push(``);

    // Form interface
    const interfaceName = `${componentName}Form`;
    lines.push(`export interface ${interfaceName} {`);

    for (const field of fields) {
      const mapping = field._idsMapping || {};
      const propName = toCamelCase(field.name || 'field');
      let tsType = 'string';

      switch (mapping.template) {
        case 'dateRange':
          // Date range uses separate dateForm, skip in main form
          continue;
        case 'dateSingle':
          // Single date has 3 fields: Dia, Mes, Ano
          lines.push(`  ${propName}Dia: string;`);
          lines.push(`  ${propName}Mes: string;`);
          lines.push(`  ${propName}Ano: string;`);
          continue;
        case 'currency':
          tsType = 'number';
          break;
        case 'table':
          tsType = 'any[]';
          break;
        case 'checkbox':
          tsType = 'boolean';
          break;
        case 'select':
        case 'radio':
        case 'text':
        case 'readonly':
        default:
          tsType = 'string';
      }

      lines.push(`  ${propName}: ${tsType};`);
    }
    lines.push('}');
    lines.push(``);

    // If has date range, add date form interface
    if (hasDateRange) {
      lines.push(`// Date form for DateRangePickerComponent`);
      lines.push(`export interface DateForm {`);
      lines.push(`  diaInicial: string;`);
      lines.push(`  mesInicial: string;`);
      lines.push(`  anoInicial: string;`);
      lines.push(`  diaFinal: string;`);
      lines.push(`  mesFinal: string;`);
      lines.push(`  anoFinal: string;`);
      lines.push(`}`);
      lines.push(``);
    }

    // Component class skeleton
    lines.push(`/**`);
    lines.push(` * ${componentName} Component`);
    lines.push(` * Generated for IDS v2 Web Components`);
    lines.push(` *`);
    lines.push(` * IDS v2 Migration Notes:`);
    lines.push(` * - Uses CUSTOM_ELEMENTS_SCHEMA for Web Components`);
    lines.push(` * - Buttons: <idsw-button variant="primary|secondary|tertiary">`);
    lines.push(` * - Icons: <idsw-icon name="pix_base" size="medium"> (official naming: {name}_base or {name}_variant)`);
    lines.push(` * - Tokens via CDN: https://ids-dev.cloud.itau.com.br/cdn/tokens/v2.0.0/varejo/tokens.css`);
    lines.push(` */`);
    lines.push(`@Component({`);
    lines.push(`  selector: 'app-${componentName.toLowerCase()}',`);
    lines.push(`  standalone: true,`);
    lines.push(`  imports: [`);
    lines.push(`    CommonModule,`);
    lines.push(`    ReactiveFormsModule,`);
    lines.push(`    TranslateModule,`);
    if (hasDateRange) {
      lines.push(`    DateRangePickerComponent,`);
    }
    lines.push(`  ],`);
    lines.push(`  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Required for IDS v2 Web Components`);
    lines.push(`  templateUrl: './${componentName.toLowerCase()}.component.html',`);
    lines.push(`  styleUrls: ['./${componentName.toLowerCase()}.component.scss']`);
    lines.push(`})`);
    lines.push(`export class ${componentName}Component implements OnInit {`);
    lines.push(`  private readonly fb = inject(FormBuilder);`);
    lines.push(`  private readonly sessionService = inject(SessionService);`);
    lines.push(`  private readonly navigationService = inject(NavigationService);`);
    lines.push(``);
    lines.push(`  form!: FormGroup;`);
    if (hasDateRange) {
      lines.push(`  dateForm!: FormGroup;`);
    }
    lines.push(``);

    // Options for select/radio fields
    const selectFields = fields.filter(f => f._idsMapping?.template === 'select' || f._idsMapping?.template === 'radio');
    if (selectFields.length > 0) {
      lines.push(`  // Options for select/radio fields`);
      for (const field of selectFields) {
        const propName = toCamelCase(field.name || 'field');
        lines.push(`  ${propName}Options: Array<{ value: string; label: string }> = [];`);
      }
      lines.push(``);
    }

    // Currency mask config
    const hasCurrency = fields.some(f => f._idsMapping?.template === 'currency');
    if (hasCurrency) {
      lines.push(`  // Currency mask configuration`);
      lines.push(`  currencyMaskConfig = {`);
      lines.push(`    prefix: 'R$ ',`);
      lines.push(`    thousands: '.',`);
      lines.push(`    decimal: ',',`);
      lines.push(`    precision: 2`);
      lines.push(`  };`);
      lines.push(``);
    }

    lines.push(`  ngOnInit(): void {`);
    lines.push(`    this.initForm();`);
    lines.push(`    this.loadOptions();`);
    lines.push(`  }`);
    lines.push(``);
    lines.push(`  private initForm(): void {`);
    lines.push(`    this.form = this.fb.group({`);
    for (const field of fields) {
      const mapping = field._idsMapping || {};
      const propName = toCamelCase(field.name || 'field');
      if (mapping.template === 'dateRange') continue;
      if (mapping.template === 'dateSingle') {
        lines.push(`      ${propName}Dia: [''],`);
        lines.push(`      ${propName}Mes: [''],`);
        lines.push(`      ${propName}Ano: [''],`);
        continue;
      }
      lines.push(`      ${propName}: [''],`);
    }
    lines.push(`    });`);
    if (hasDateRange) {
      lines.push(``);
      lines.push(`    this.dateForm = this.fb.group({`);
      lines.push(`      diaInicial: [''],`);
      lines.push(`      mesInicial: [''],`);
      lines.push(`      anoInicial: [''],`);
      lines.push(`      diaFinal: [''],`);
      lines.push(`      mesFinal: [''],`);
      lines.push(`      anoFinal: ['']`);
      lines.push(`    });`);
    }
    lines.push(`  }`);
    lines.push(``);
    lines.push(`  private loadOptions(): void {`);
    lines.push(`    // TODO: Load select/radio options from service`);
    lines.push(`  }`);
    lines.push(``);
    lines.push(`  onSubmit(): void {`);
    lines.push(`    if (this.form.valid) {`);
    lines.push(`      const formData = this.form.value;`);
    if (hasDateRange) {
      lines.push(`      const dateData = this.dateForm.value;`);
    }
    lines.push(`      // TODO: Submit form data`);
    lines.push(`    }`);
    lines.push(`  }`);
    lines.push(``);
    lines.push(`  onVoltar(): void {`);
    lines.push(`    this.navigationService.navigateBack();`);
    lines.push(`  }`);
    lines.push(`}`);

    return lines.join('\n');
  };

  // Copy to clipboard helper
  const handleCopy = useCallback((text, fieldId) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldId);
    setTimeout(() => setCopiedField(null), 2000);
  }, []);

  if (!architecture) {
    return <div className={styles.noData}>No architecture data available</div>;
  }

  return (
    <div className={styles.container}>
      {/* Header */}
      <div className={styles.header}>
        <h3>Angular Architecture Generator</h3>
        <p>Dynamic TO-BE architecture based on legacy flow analysis</p>

        {/* Route Configuration */}
        <div className={styles.routeConfig}>
          <div className={styles.routeInputGroup}>
            <label>Nome da Rota (MFE):</label>
            {editingRoute ? (
              <div className={styles.routeEditRow}>
                <CarbonTextInput
                  id="route-name"
                  size="sm"
                  value={customRouteName}
                  onChange={(e) => setCustomRouteName(e.target.value)}
                  placeholder="ex: carta-credito"
                />
                <Button
                  kind="ghost"
                  size="sm"
                  hasIconOnly
                  renderIcon={Checkmark}
                  iconDescription="Confirmar"
                  onClick={() => setEditingRoute(false)}
                />
              </div>
            ) : (
              <div className={styles.routeDisplayRow}>
                <code className={styles.routeValue}>mf-{effectiveRouteName}</code>
                <Button
                  kind="ghost"
                  size="sm"
                  hasIconOnly
                  renderIcon={Edit}
                  iconDescription="Editar"
                  onClick={() => setEditingRoute(true)}
                />
              </div>
            )}
          </div>
          <div className={styles.routeInputGroup}>
            <label>Porta:</label>
            <NumberInput
              id="mfe-port"
              size="sm"
              min={5000}
              max={6000}
              value={mfePort}
              onChange={(e, { value }) => setMfePort(value)}
              hideSteppers
              className={styles.portInput}
            />
          </div>
        </div>

        <div className={styles.headerActions}>
          <div className={styles.modulePath}>
            <FolderDetails size={16} />
            <code>src/app/features/{effectiveRouteName}/</code>
          </div>
          <div className={styles.actionButtons}>
            <Button
              kind="primary"
              size="sm"
              renderIcon={isGenerating ? InlineLoading : Renew}
              onClick={handleGenerate}
              disabled={isGenerating}
            >
              {isGenerating ? 'Gerando...' : 'Gerar Componentes IDS v2'}
            </Button>
            {generatedCode && (
              <>
                <Button
                  kind="tertiary"
                  size="sm"
                  renderIcon={isDownloading ? InlineLoading : Download}
                  onClick={handleDownloadProject}
                  disabled={isDownloading}
                  title="Baixar projeto Angular MFE com IDS v2 Web Components"
                >
                  Angular MFE
                </Button>
                <Button
                  kind="secondary"
                  size="sm"
                  renderIcon={isDownloading ? InlineLoading : Terminal}
                  onClick={handleDownloadGoProject}
                  disabled={isDownloading}
                  title="Baixar projeto Go backend service"
                >
                  Go Service
                </Button>
                <Button
                  kind="secondary"
                  size="sm"
                  renderIcon={isDownloading ? InlineLoading : Code}
                  onClick={handleDownloadJavaProject}
                  disabled={isDownloading}
                  title="Baixar projeto Java Spring Boot"
                >
                  Java Spring
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className={styles.summaryCards}>
        <div className={styles.summaryCard}>
          <div className={styles.cardValue}>{architecture.summary.legacyScreens}</div>
          <div className={styles.cardLabel}>Legacy Screens</div>
          <ArrowRight size={16} className={styles.cardArrow} />
        </div>
        <div className={styles.summaryCard} style={{ borderColor: '#198038' }}>
          <div className={styles.cardValue} style={{ color: '#198038' }}>{architecture.summary.angularComponents}</div>
          <div className={styles.cardLabel}>Angular Components</div>
        </div>
        <div className={styles.summaryCard}>
          <div className={styles.cardValue}>{architecture.summary.decisionPoints}</div>
          <div className={styles.cardLabel}>Decision Points</div>
        </div>
        <div className={styles.summaryCard}>
          <div className={styles.cardValue}>{architecture.summary.scenarios}</div>
          <div className={styles.cardLabel}>Flow Scenarios</div>
        </div>
      </div>

      {/* Architecture Sections */}
      <Accordion>
        {/* Components */}
        <AccordionItem title={`Components (${architecture.components.length})`} open>
          <div className={styles.componentsList}>
            {architecture.components.map((comp, i) => (
              <div key={i} className={styles.componentCard}>
                <div className={styles.componentHeader}>
                  <Screen size={20} />
                  <strong>{comp.angularName}</strong>
                  <Tag type="blue" size="sm">{comp.route}</Tag>
                </div>
                <p className={styles.componentPurpose}>{comp.purpose}</p>
                <div className={styles.legacyMapping}>
                  <span className={styles.mappingLabel}>Consolidates:</span>
                  <div className={styles.mappingTags}>
                    {comp.screens.map((s, j) => (
                      <Tag key={j} type="gray" size="sm">
                        {s.name || s.path.split('\\').pop()}
                      </Tag>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </AccordionItem>

        {/* Service */}
        <AccordionItem title="Service Layer">
          <div className={styles.serviceCard}>
            <div className={styles.serviceHeader}>
              <Api size={20} />
              <strong>{architecture.service.name}</strong>
            </div>
            <div className={styles.serviceMethods}>
              {architecture.service.methods.map((method, i) => (
                <div key={i} className={styles.methodItem}>
                  <code>{method.name}()</code>
                  <span>{method.description}</span>
                  <Tag type="outline" size="sm">{method.returns}</Tag>
                </div>
              ))}
            </div>
          </div>
        </AccordionItem>

        {/* Decision Points / Guards */}
        {architecture.decisionPoints.length > 0 && (
          <AccordionItem title={`Decision Points & Guards (${architecture.decisionPoints.length})`}>
            <div className={styles.decisionsList}>
              {architecture.decisionPoints.map((dp, i) => (
                <div key={i} className={styles.decisionCard}>
                  <div className={styles.decisionHeader}>
                    <Settings size={16} />
                    <strong>{dp.name}</strong>
                  </div>
                  <div className={styles.decisionInfo}>
                    <div className={styles.conditionsList}>
                      <span>Conditions:</span>
                      {dp.conditions.length > 0 ? (
                        dp.conditions.map((c, j) => <Tag key={j} type="purple" size="sm">{c}</Tag>)
                      ) : (
                        <Tag type="gray" size="sm">Response-based</Tag>
                      )}
                    </div>
                    <div className={styles.targetsList}>
                      <span>Targets:</span>
                      {dp.targets.map((t, j) => (
                        <Tag key={j} type="outline" size="sm">{t.split('\\').pop()}</Tag>
                      ))}
                    </div>
                  </div>
                  <div className={styles.guardRecommendation}>
                    <Code size={14} />
                    <code>@Injectable() {architecture.guards[i]?.name || 'Guard'}</code>
                  </div>
                </div>
              ))}
            </div>
          </AccordionItem>
        )}

        {/* State Management */}
        <AccordionItem title="State Management">
          <div className={styles.stateCard}>
            <div className={styles.stateRecommendation}>
              <Application size={24} />
              <div>
                <strong>Recommendation: {architecture.stateManagement.type}</strong>
                <p>{architecture.stateManagement.reason}</p>
              </div>
            </div>
            {architecture.stateManagement.type === 'NgRx' ? (
              <div className={styles.stateStructure}>
                <code>
                  {`// ${architecture.moduleName}.state.ts
interface ${architecture.moduleName.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('')}State {
  currentStep: 'selection' | 'list' | 'complete';
  selectedId: string | null;
  data: any[];
  loading: boolean;
  error: string | null;
}`}
                </code>
              </div>
            ) : (
              <div className={styles.stateStructure}>
                <code>
                  {`// ${architecture.moduleName}.state.ts
@Injectable({ providedIn: 'root' })
export class ${architecture.moduleName.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('')}StateService {
  private state$ = new BehaviorSubject<State>(initialState);

  get currentState() { return this.state$.asObservable(); }

  updateStep(step: string) { ... }
  setSelectedId(id: string) { ... }
}`}
                </code>
              </div>
            )}
          </div>
        </AccordionItem>

        {/* Routes */}
        <AccordionItem title="Routing Configuration">
          <div className={styles.routesCard}>
            <code className={styles.routesCode}>
              {`// ${architecture.moduleName}.routes.ts
export const ${architecture.moduleName.toUpperCase().replace(/-/g, '_')}_ROUTES: Routes = [
  {
    path: '',
    component: ${architecture.moduleName.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('')}ContainerComponent,
    children: [
${architecture.components.map(c => `      {
        path: '${c.route.replace('/', '').replace(':id', ':id')}',
        component: ${c.angularName},
        ${architecture.guards.length > 0 ? `canActivate: [${architecture.guards[0]?.name}]` : '// no guard needed'}
      }`).join(',\n')}
    ]
  }
];`}
            </code>
          </div>
        </AccordionItem>

        {/* File Structure */}
        <AccordionItem title="File Structure">
          <div className={styles.fileStructure}>
            <pre>
              {`src/app/features/${architecture.moduleName}/
├── ${architecture.moduleName}.routes.ts
├── ${architecture.moduleName}.module.ts
├── services/
│   └── ${architecture.moduleName}.service.ts
├── state/
│   └── ${architecture.moduleName}.state.ts
├── guards/
${architecture.guards.map(g => `│   └── ${g.name.toLowerCase().replace(/guard/g, '.guard')}.ts`).join('\n')}
└── components/
${architecture.components.map(c => `    ├── ${c.name.toLowerCase()}/
    │   ├── ${c.name.toLowerCase()}.component.ts
    │   ├── ${c.name.toLowerCase()}.component.html
    │   └── ${c.name.toLowerCase()}.component.scss`).join('\n')}`}
            </pre>
          </div>
        </AccordionItem>

        {/* Generated IDS v2 Components */}
        {generatedCode && (
          <AccordionItem
            title={`IDS v2 Web Components (${generatedCode.screens.length} telas, ${generatedCode.totalFields} campos)`}
            open
          >
            <div className={styles.generatedSection}>
              {/* V2 Migration Status */}
              <div className={styles.v2StatusBanner}>
                <div className={styles.v2StatusHeader}>
                  <CheckmarkFilled size={16} />
                  <span>IDS v2 Web Components</span>
                </div>
                <div className={styles.v2StatusTags}>
                  <Tag type="green" size="sm">idsw-button ✓</Tag>
                  <Tag type="green" size="sm">idsw-icon ✓</Tag>
                  <Tag type="green" size="sm">idsw-loading ✓</Tag>
                  <Tag type="outline" size="sm">select (tokens)</Tag>
                  <Tag type="outline" size="sm">table (tokens)</Tag>
                </div>
              </div>

              {/* Stats Summary */}
              <div className={styles.generatedStats}>
                <div className={styles.statItem}>
                  <Calendar size={16} />
                  <span>{generatedCode.componentStats.datePickers} DatePickers</span>
                </div>
                <div className={styles.statItem}>
                  <ChevronDown size={16} />
                  <span>{generatedCode.componentStats.selects} Selects</span>
                </div>
                <div className={styles.statItem}>
                  <ListBoxes size={16} />
                  <span>{generatedCode.componentStats.tables} DataTables</span>
                </div>
                <div className={styles.statItem}>
                  <StringText size={16} />
                  <span>{generatedCode.componentStats.textFields} TextFields</span>
                </div>
                <div className={styles.statItem}>
                  <Currency size={16} />
                  <span>{generatedCode.componentStats.currencyFields} CurrencyFields</span>
                </div>
              </div>

              {/* Generated Screens */}
              {generatedCode.screens.map((screen, i) => (
                <div key={i} className={styles.generatedScreen}>
                  <div className={styles.screenHeader}>
                    <div className={styles.screenTitle}>
                      <Screen size={18} />
                      <strong>{screen.name}</strong>
                      <Tag type="gray" size="sm">{screen.legacyName || screen.legacyPath}</Tag>
                    </div>
                    <span className={styles.fieldCount}>{screen.fields.length} campos</span>
                  </div>

                  {/* Field Mapping Table */}
                  <div className={styles.fieldMappingTable}>
                    <div className={styles.tableHeader}>
                      <span>Campo Legacy</span>
                      <span>Componente IDS</span>
                      <span>Razão</span>
                    </div>
                    {screen.fields.map((field, j) => {
                      const IconComponent = IconMap[field._idsMapping?.icon] || StringText;
                      return (
                        <div key={j} className={styles.tableRow}>
                          <span className={styles.fieldName}>{field.name}</span>
                          <span className={styles.idsComponent}>
                            <IconComponent size={14} />
                            <code>{field._idsMapping?.component}</code>
                          </span>
                          <span className={styles.mappingReason}>{field._idsMapping?.reason}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Generated Template */}
                  <div className={styles.codeSection}>
                    <div className={styles.codeSectionHeader}>
                      <span>Template HTML ({screen.name.toLowerCase()}.component.html)</span>
                      <Button
                        kind="ghost"
                        size="sm"
                        hasIconOnly
                        renderIcon={copiedField === `template-${i}` ? Checkmark : Copy}
                        iconDescription="Copiar"
                        onClick={() => handleCopy(screen.template, `template-${i}`)}
                      />
                    </div>
                    <pre className={styles.codeBlock}>{screen.template}</pre>
                  </div>

                  {/* Generated TypeScript Interface */}
                  <div className={styles.codeSection}>
                    <div className={styles.codeSectionHeader}>
                      <span>Interface TypeScript ({screen.name.toLowerCase()}.model.ts)</span>
                      <Button
                        kind="ghost"
                        size="sm"
                        hasIconOnly
                        renderIcon={copiedField === `ts-${i}` ? Checkmark : Copy}
                        iconDescription="Copiar"
                        onClick={() => handleCopy(screen.typescript, `ts-${i}`)}
                      />
                    </div>
                    <pre className={styles.codeBlock}>{screen.typescript}</pre>
                  </div>
                </div>
              ))}
            </div>
          </AccordionItem>
        )}
      </Accordion>
    </div>
  );
};

export default AngularArchitecture;
