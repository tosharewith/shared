// Package routes defines HTTP routes for the COMEX Business Service
//
// This service is called by the BFF layer, NOT directly by the frontend.
//
// XML → REST Endpoint Mapping:
//
//	| XML                      | HTTP Method | Endpoint                              |
//	|--------------------------|-------------|---------------------------------------|
//	| ConsultaCNPJS.xml        | GET         | /api/v1/comex/companies               |
//	| Tela_Entrada_Dados.xml   | POST        | /api/v1/comex/export/billing/query    |
//	| Tela_Entrada_OPRE.xml    | POST        | /api/v1/comex/payment-orders/query    |
//	| Tela_Lista_CNPJ_BAL7.xml | POST        | /api/v1/comex/letters-of-credit/query |
//	| TelaListaCNPJCambio.xml  | POST        | /api/v1/comex/fx/quotations/query     |
package routes

import (
	"github.com/gin-gonic/gin"
	"comex-service/internal/handlers"
)

// COMEXRouteConfig holds route metadata
type COMEXRouteConfig struct {
	Method      string
	Path        string
	Handler     gin.HandlerFunc
	XMLSource   string // Original XML file
	Backend     string // Backend service (BAL1, BAL3, etc)
	Description string
	RateLimit   int // requests per minute
}

// SetupCOMEXRoutes configures all COMEX routes
//
// Architecture (called by BFF, not frontend):
//
//	BFF (Node.js) → This Service → Handler → Service → Adapter → Backend
//
// Auth/Rate limiting is handled by the BFF layer.
func SetupCOMEXRoutes(r *gin.Engine, h *handlers.COMEXHandler) {
	// API v1 group (no middleware - handled by BFF)
	v1 := r.Group("/api/v1")

	// COMEX group
	comex := v1.Group("/comex")

	// ===========================================================================
	// COMPANIES (ConsultaCNPJS.xml)
	// ===========================================================================
	companies := comex.Group("/companies")
	{
		// GET /api/v1/comex/companies
		// Lists all companies the user has COMEX access to
		// XML: ConsultaCNPJS.xml
		// Backend: K_G_COMEXPRESS.P_G_LST_EMP_COM_ACESSO
		companies.GET("", h.GetCompanies)

		// GET /api/v1/comex/companies/:cnpj
		// Get company details
		companies.GET("/:cnpj", h.GetCompanyDetails)
	}

	// ===========================================================================
	// EXPORT - BILLING (Tela_Entrada_Dados.xml → BAL1)
	// ===========================================================================
	export := comex.Group("/export")
	{
		billing := export.Group("/billing")
		{
			// POST /api/v1/comex/export/billing/query
			// Query billing operations (Cobrança e Remessa de Exportação)
			// XML: Tela_Entrada_Dados.xml
			// Backend: BAL1\SP\Passo_M1_010206
			billing.POST("/query", h.QueryBillingOperations)

			// GET /api/v1/comex/export/billing/:id
			// Get billing operation details
			billing.GET("/:id", h.GetBillingOperationDetails)
		}

		// Letters of Credit (Cartas de Crédito)
		lc := export.Group("/letters-of-credit")
		{
			// POST /api/v1/comex/export/letters-of-credit/query
			// Query negotiated letters of credit
			// XML: Tela_Lista_CNPJ_BAL7.xml
			// Backend: BAL7\SP\Passo_M
			lc.POST("/query", h.QueryLettersOfCredit)

			// GET /api/v1/comex/export/letters-of-credit/:id
			lc.GET("/:id", h.GetLetterOfCreditDetails)
		}

		// Received Letters (Cartas Recebidas)
		received := export.Group("/received-letters")
		{
			// POST /api/v1/comex/export/received-letters/query
			// XML: Tela_Lista_CNPJ_C9RT.xml
			// Backend: C9RT
			received.POST("/query", h.QueryReceivedLetters)
		}
	}

	// ===========================================================================
	// PAYMENT ORDERS (Tela_Entrada_OPRE.xml → BAL3)
	// ===========================================================================
	paymentOrders := comex.Group("/payment-orders")
	{
		// POST /api/v1/comex/payment-orders/query
		// Query payment orders received from abroad (OPRE)
		// XML: Tela_Entrada_OPRE.xml
		// Backend: BAL3\SP\Passo_M1
		paymentOrders.POST("/query", h.QueryPaymentOrders)

		// GET /api/v1/comex/payment-orders/:id
		paymentOrders.GET("/:id", h.GetPaymentOrderDetails)

		// GET /api/v1/comex/payment-orders/:id/status
		paymentOrders.GET("/:id/status", h.GetPaymentOrderStatus)
	}

	// ===========================================================================
	// FX - FOREIGN EXCHANGE (TelaListaCNPJCambio.xml → BAEI)
	// ===========================================================================
	fx := comex.Group("/fx")
	{
		quotations := fx.Group("/quotations")
		{
			// POST /api/v1/comex/fx/quotations/query
			// Query FX quotations
			// XML: TelaListaCNPJCambio.xml
			// Backend: BAEI\SPNBP\BAEI01
			quotations.POST("/query", h.QueryFXQuotations)

			// GET /api/v1/comex/fx/quotations/:id
			quotations.GET("/:id", h.GetQuotationDetails)
		}

		// GET /api/v1/comex/fx/rates
		// Get current exchange rates
		fx.GET("/rates", h.GetExchangeRates)

		// POST /api/v1/comex/fx/simulate
		// Simulate exchange operation
		fx.POST("/simulate", h.SimulateExchange)
	}

	// ===========================================================================
	// SWIFT (PM04)
	// ===========================================================================
	swift := comex.Group("/swift")
	{
		// GET /api/v1/comex/swift/messages
		// List SWIFT messages
		swift.GET("/messages", h.ListSWIFTMessages)

		// GET /api/v1/comex/swift/messages/:uetr
		// Get SWIFT message details
		swift.GET("/messages/:uetr", h.GetSWIFTMessageDetails)

		// POST /api/v1/comex/swift/messages
		// Send SWIFT message (MT103, MT700)
		swift.POST("/messages", h.SendSWIFTMessage)
	}

	// ===========================================================================
	// HEALTH CHECK
	// ===========================================================================
	comex.GET("/health", h.HealthCheck)
}

// GetRouteConfigs returns all route configurations for documentation
func GetRouteConfigs() []COMEXRouteConfig {
	return []COMEXRouteConfig{
		{
			Method:      "GET",
			Path:        "/api/v1/comex/companies",
			XMLSource:   "ConsultaCNPJS.xml",
			Backend:     "K_G_COMEXPRESS",
			Description: "List companies with COMEX access",
			RateLimit:   30,
		},
		{
			Method:      "POST",
			Path:        "/api/v1/comex/export/billing/query",
			XMLSource:   "Tela_Entrada_Dados.xml",
			Backend:     "BAL1",
			Description: "Query export billing operations",
			RateLimit:   30,
		},
		{
			Method:      "POST",
			Path:        "/api/v1/comex/payment-orders/query",
			XMLSource:   "Tela_Entrada_OPRE.xml",
			Backend:     "BAL3",
			Description: "Query payment orders from abroad",
			RateLimit:   30,
		},
		{
			Method:      "POST",
			Path:        "/api/v1/comex/export/letters-of-credit/query",
			XMLSource:   "Tela_Lista_CNPJ_BAL7.xml",
			Backend:     "BAL7",
			Description: "Query negotiated letters of credit",
			RateLimit:   30,
		},
		{
			Method:      "POST",
			Path:        "/api/v1/comex/fx/quotations/query",
			XMLSource:   "TelaListaCNPJCambio.xml",
			Backend:     "BAEI",
			Description: "Query FX quotations",
			RateLimit:   30,
		},
	}
}
