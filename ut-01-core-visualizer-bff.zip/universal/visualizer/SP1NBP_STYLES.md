# SP1NBP Visualizer - Node & Edge Styles

## Node Colors por Tipo de Componente

### Componentes Principais

```javascript
const SP1NBP_NODE_STYLES = {
  // UI Components (Blue tones - Itaú Blue)
  'Dispatcher': {
    color: '#e1f5ff',
    borderColor: '#0f62fe',
    shape: 'diamond',
    description: 'Roteador de entrada'
  },
  'Browser_Radio': {
    color: '#d0e2ff',
    borderColor: '#0f62fe',
    shape: 'roundrectangle',
    description: 'Tela de seleção (Radio)'
  },
  'Browser_Checkbox': {
    color: '#a6c8ff',
    borderColor: '#0043ce',
    shape: 'roundrectangle',
    description: 'Tela de seleção (Checkbox)'
  },
  'Browser_Form': {
    color: '#d0e2ff',
    borderColor: '#0f62fe',
    shape: 'roundrectangle',
    description: 'Formulário de entrada'
  },

  // Backend Components (Green tones)
  'WebService': {
    color: '#a7f0ba',
    borderColor: '#24a148',
    shape: 'hexagon',
    description: 'Integração Oracle WebService'
  },
  'OperacaoFinalizacao': {
    color: '#e0e0e0',
    borderColor: '#525252',
    shape: 'rectangle',
    description: 'Processamento backend'
  },

  // Configuration (Orange tones - Itaú Orange)
  'VisaoCliente': {
    color: '#ffeed4',
    borderColor: '#ec7000',
    shape: 'ellipse',
    description: 'Configuração'
  },

  // External Systems (Purple tones)
  'External': {
    color: '#e8daff',
    borderColor: '#8a3ffc',
    shape: 'octagon',
    description: 'Sistema externo'
  },

  // Unknown
  'Unknown': {
    color: '#f4f4f4',
    borderColor: '#8d8d8d',
    shape: 'ellipse',
    description: 'Tipo desconhecido'
  }
};
```

## Complexity-based Size

```javascript
const calculateNodeSize = (complexity) => {
  const sizes = {
    'Low': 20,      // < 50 lines
    'Medium': 30,   // 50-200 lines
    'High': 40,     // 200-400 lines
    'VeryHigh': 55  // > 400 lines
  };
  return sizes[complexity] || 25;
};
```

## Edge Colors por Tipo de Navegação

```javascript
const SP1NBP_EDGE_STYLES = {
  // Navigation types
  'default': {
    color: '#78a9ff',
    width: 2,
    style: 'solid',
    description: 'Navegação padrão'
  },
  'conditional': {
    color: '#ffb784',
    width: 2,
    style: 'dashed',
    description: 'Navegação condicional (TrocaSucessor)'
  },
  'voltar': {
    color: '#be95ff',
    width: 1.5,
    style: 'dotted',
    description: 'Botão voltar'
  },

  // Special navigation
  'validation_error': {
    color: '#ff99a2',
    width: 2,
    style: 'solid',
    description: 'Erro de validação'
  },
  'user_validation': {
    color: '#82cfff',
    width: 2,
    style: 'dashed',
    description: 'Validação de usuário (ILTL, ILUE)'
  }
};
```

## Node Labels

```javascript
// Format node labels based on component data
const formatNodeLabel = (node) => {
  const { type, lines, hasValidation, hasJavaScript } = node.data;

  let label = node.data.label || node.data.id;

  // Add badges
  const badges = [];
  if (hasValidation) badges.push('✓');
  if (hasJavaScript) badges.push('JS');

  if (badges.length > 0) {
    label += ` [${badges.join(' ')}]`;
  }

  // Add line count for complex components
  if (lines > 200) {
    label += `\n(${lines}L)`;
  }

  return label;
};
```

## Cytoscape Style Config

```javascript
const SP1NBP_CYTOSCAPE_STYLES = [
  // Node styles
  {
    selector: 'node',
    style: {
      'background-color': 'data(color)',
      'border-color': 'data(borderColor)',
      'border-width': 2,
      'shape': 'data(shape)',
      'width': 'data(width)',
      'height': 'data(height)',
      'label': 'data(label)',
      'text-valign': 'center',
      'text-halign': 'center',
      'font-size': 10,
      'font-family': 'IBM Plex Sans, sans-serif',
      'text-wrap': 'wrap',
      'text-max-width': '80px',
      'overlay-padding': '5px',
      'z-index': 10
    }
  },

  // Complexity-based border width
  {
    selector: 'node[complexity = "VeryHigh"]',
    style: {
      'border-width': 4
    }
  },
  {
    selector: 'node[complexity = "High"]',
    style: {
      'border-width': 3
    }
  },

  // Has validation badge
  {
    selector: 'node[hasValidation = true]',
    style: {
      'border-style': 'double'
    }
  },

  // Has JavaScript badge
  {
    selector: 'node[hasJavaScript = true]',
    style: {
      'background-opacity': 0.8
    }
  },

  // Edge styles
  {
    selector: 'edge',
    style: {
      'width': 'data(width)',
      'line-color': 'data(color)',
      'line-style': 'data(style)',
      'target-arrow-color': 'data(color)',
      'target-arrow-shape': 'triangle',
      'curve-style': 'bezier',
      'label': 'data(label)',
      'font-size': 8,
      'text-rotation': 'autorotate',
      'text-margin-y': -10,
      'font-family': 'IBM Plex Mono, monospace'
    }
  },

  // Highlighted nodes
  {
    selector: 'node.highlighted',
    style: {
      'border-width': 4,
      'border-color': '#ec7000', // Itaú Orange
      'z-index': 999
    }
  },

  // Selected nodes
  {
    selector: 'node:selected',
    style: {
      'background-color': '#ffe8d0',
      'border-color': '#ec7000',
      'border-width': 4,
      'overlay-padding': '10px',
      'overlay-color': '#ec7000',
      'overlay-opacity': 0.2
    }
  },

  // Dimmed nodes (when filtering)
  {
    selector: 'node.dimmed',
    style: {
      'opacity': 0.2
    }
  },
  {
    selector: 'edge.dimmed',
    style: {
      'opacity': 0.1
    }
  },

  // Hidden nodes
  {
    selector: 'node.hidden',
    style: {
      'display': 'none'
    }
  },
  {
    selector: 'edge.hidden',
    style: {
      'display': 'none'
    }
  }
];
```

## Layout Configurations

### Hierarchical (Top to Bottom)

```javascript
const hierarchicalLayout = {
  name: 'cose-bilkent',
  animate: 'end',
  animationDuration: 500,
  idealEdgeLength: 80,
  nodeRepulsion: 4500,
  gravity: 0.25,
  numIter: 2500,
  tile: true,
  tilingPaddingVertical: 30,
  tilingPaddingHorizontal: 30,
  gravityRange: 2.0,
  gravityCompound: 1.0,
  gravityRangeCompound: 1.5
};
```

### Force-directed (Organic)

```javascript
const forceDirectedLayout = {
  name: 'fcose',
  animate: 'end',
  animationDuration: 1000,
  quality: 'default',
  randomize: false,
  idealEdgeLength: 60,
  edgeElasticity: 0.45,
  nestingFactor: 0.1,
  gravity: 0.25,
  numIter: 2500,
  tile: true,
  tilingPaddingVertical: 20,
  tilingPaddingHorizontal: 20
};
```

### Circular

```javascript
const circularLayout = {
  name: 'circle',
  animate: true,
  animationDuration: 500,
  radius: 300,
  startAngle: 0,
  sweep: Math.PI * 2,
  clockwise: true,
  spacingFactor: 1.5
};
```

## Filter Configurations

### Component Type Filters

```javascript
const COMPONENT_TYPE_FILTERS = [
  { id: 'Dispatcher', label: 'Dispatcher', color: '#0f62fe', count: 0 },
  { id: 'Browser_Radio', label: 'Seleção Radio', color: '#0f62fe', count: 0 },
  { id: 'Browser_Checkbox', label: 'Seleção Checkbox', color: '#0043ce', count: 0 },
  { id: 'Browser_Form', label: 'Formulário', color: '#0f62fe', count: 0 },
  { id: 'WebService', label: 'WebService', color: '#24a148', count: 0 },
  { id: 'OperacaoFinalizacao', label: 'OperacaoFinalizacao', color: '#525252', count: 0 },
  { id: 'VisaoCliente', label: 'VisaoCliente', color: '#ec7000', count: 0 },
  { id: 'External', label: 'Sistema Externo', color: '#8a3ffc', count: 0 },
  { id: 'Unknown', label: 'Desconhecido', color: '#8d8d8d', count: 0 }
];
```

### Complexity Filters

```javascript
const COMPLEXITY_FILTERS = [
  { id: 'Low', label: 'Baixa (< 50 linhas)', color: '#a7f0ba', count: 0 },
  { id: 'Medium', label: 'Média (50-200 linhas)', color: '#ffd6e8', count: 0 },
  { id: 'High', label: 'Alta (200-400 linhas)', color: '#ffb784', count: 0 },
  { id: 'VeryHigh', label: 'Muito Alta (> 400 linhas)', color: '#ff99a2', count: 0 }
];
```

### Attribute Filters

```javascript
const ATTRIBUTE_FILTERS = [
  { id: 'hasUI', label: 'Com Interface UI', icon: '🖥️', count: 0 },
  { id: 'hasJavaScript', label: 'Com JavaScript', icon: 'JS', count: 0 },
  { id: 'hasWebService', label: 'Com WebService', icon: '🔧', count: 0 },
  { id: 'hasValidation', label: 'Com Validação', icon: '✓', count: 0 }
];
```

## Search Highlighting

```javascript
const highlightSearchResults = (cy, searchTerm) => {
  if (!searchTerm) {
    cy.elements().removeClass('highlighted dimmed');
    return;
  }

  const term = searchTerm.toLowerCase();

  cy.nodes().forEach(node => {
    const label = (node.data('label') || '').toLowerCase();
    const fileName = (node.data('fileName') || '').toLowerCase();
    const type = (node.data('type') || '').toLowerCase();

    const matches = label.includes(term) ||
                   fileName.includes(term) ||
                   type.includes(term);

    if (matches) {
      node.removeClass('dimmed').addClass('highlighted');
    } else {
      node.removeClass('highlighted').addClass('dimmed');
    }
  });

  // Dim edges connected to dimmed nodes
  cy.edges().forEach(edge => {
    const source = edge.source();
    const target = edge.target();

    if (source.hasClass('dimmed') || target.hasClass('dimmed')) {
      edge.addClass('dimmed');
    } else {
      edge.removeClass('dimmed');
    }
  });
};
```

## Export Options

### Export as PNG

```javascript
const exportAsPNG = (cy) => {
  const png = cy.png({
    output: 'blob',
    bg: '#ffffff',
    full: true,
    scale: 2
  });

  const url = URL.createObjectURL(png);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'sp1nbp_navigation_graph.png';
  link.click();
  URL.revokeObjectURL(url);
};
```

### Export as JSON

```javascript
const exportAsJSON = (cy) => {
  const elements = cy.json().elements;
  const json = JSON.stringify(elements, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'sp1nbp_graph_data.json';
  link.click();
  URL.revokeObjectURL(url);
};
```

## Usage Example

```javascript
import cytoscape from 'cytoscape';
import { parseGraphML } from './utils/graphmlParser';
import { SP1NBP_CYTOSCAPE_STYLES, SP1NBP_NODE_STYLES } from './SP1NBP_STYLES';

// Load GraphML
const graphmlContent = await fetch('../parser/output/navigation_graph.graphml').then(r => r.text());
const elements = parseGraphML(graphmlContent);

// Initialize Cytoscape
const cy = cytoscape({
  container: document.getElementById('cy'),
  elements: elements,
  style: SP1NBP_CYTOSCAPE_STYLES,
  layout: hierarchicalLayout
});

// Add event listeners
cy.on('tap', 'node', (evt) => {
  const node = evt.target;
  console.log('Selected:', node.data());
  showDetailsPanel(node.data());
});
```

## Color Palette Reference

### Itaú Colors
- **Primary Orange**: #EC7000
- **Primary Blue**: #003366
- **Secondary Blue**: #0F62FE

### IBM Carbon Colors
- **Blue 20**: #E1F5FF
- **Blue 50**: #78A9FF
- **Green 20**: #A7F0BA
- **Green 50**: #42BE65
- **Orange 20**: #FFEED4
- **Orange 50**: #FF832B
- **Purple 20**: #E8DAFF
- **Purple 50**: #BE95FF
- **Red 20**: #FFE1E1
- **Red 50**: #FF99A2
- **Gray 20**: #E0E0E0
- **Gray 50**: #8D8D8D

---

**Status**: Estilos definidos para integração com visualizador
**Próximo passo**: Aplicar estilos no DiagramViewer adaptado
