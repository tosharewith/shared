/**
 * Layout algorithm configurations for Cytoscape.js
 */

/**
 * Available layout configurations
 */
export const layoutConfigs = {
  cose: {
    name: 'cose',
    animate: true,
    animationDuration: 500,
    fit: true,
    padding: 50,
    nodeDimensionsIncludeLabels: true,
    randomize: false,
    componentSpacing: 60,
    nodeRepulsion: 300000,
    nodeOverlap: 15,
    idealEdgeLength: 60,
    edgeElasticity: 100,
    nestingFactor: 5,
    gravity: 80,
    numIter: 1000,
    initialTemp: 200,
    coolingFactor: 0.95,
    minTemp: 1.0,
  },

  'cose-bilkent': {
    name: 'cose-bilkent',
    animate: true,
    animationDuration: 500,
    fit: true,
    padding: 50,
    nodeDimensionsIncludeLabels: true,
    randomize: false,
    nodeRepulsion: 3500,
    idealEdgeLength: 60,
    edgeElasticity: 0.45,
    nestingFactor: 0.1,
    gravity: 0.5,
    numIter: 2500,
    tile: true,
    tilingPaddingVertical: 8,
    tilingPaddingHorizontal: 8,
    gravityRangeCompound: 1.5,
    gravityCompound: 1.0,
    gravityRange: 3.8,
  },

  fcose: {
    name: 'fcose',
    animate: true,
    animationDuration: 500,
    fit: true,
    padding: 50,
    nodeDimensionsIncludeLabels: true,
    randomize: false,
    nodeRepulsion: 3500,
    idealEdgeLength: 60,
    edgeElasticity: 0.45,
    nestingFactor: 0.1,
    numIter: 2500,
    tile: true,
    tilingPaddingVertical: 8,
    tilingPaddingHorizontal: 8,
    gravity: 0.3,
    gravityRange: 3.8,
    initialEnergyOnIncremental: 0.3,
  },

  grid: {
    name: 'grid',
    animate: true,
    animationDuration: 500,
    fit: true,
    padding: 50,
    avoidOverlap: true,
    avoidOverlapPadding: 5,
    nodeDimensionsIncludeLabels: true,
    spacingFactor: 1.0,
    condense: false,
    rows: undefined,
    cols: undefined,
  },

  breadthfirst: {
    name: 'breadthfirst',
    animate: true,
    animationDuration: 500,
    fit: true,
    padding: 50,
    directed: true,
    spacingFactor: 1.2,
    avoidOverlap: true,
    nodeDimensionsIncludeLabels: true,
    maximal: false,
    circle: false,
  },
};

/**
 * Layout display names for UI
 */
export const layoutNames = {
  'cose-bilkent': 'CoSE Bilkent (Recommended)',
  fcose: 'fCoSE (Fast)',
  cose: 'CoSE',
  grid: 'Grid',
  breadthfirst: 'Hierarchical',
};

/**
 * Default layout
 */
export const defaultLayout = 'cose-bilkent';

/**
 * Apply layout to Cytoscape instance
 * @param {Object} cy - Cytoscape instance
 * @param {string} layoutName - Layout name
 * @returns {Promise} Layout run promise
 */
export const applyLayout = (cy, layoutName = defaultLayout) => {
  const config = layoutConfigs[layoutName] || layoutConfigs[defaultLayout];
  return cy.layout(config).run();
};
