#!/usr/bin/env node
/**
 * Extract individual SVG icons from IDS SVG sprite file.
 *
 * This script parses the Ids_Itau_Icons-defs.svg sprite file and extracts
 * each <symbol> as a standalone SVG file for local development use.
 *
 * Run: node scripts/extract-icons.cjs
 * Output: public/icons/v2/*.svg
 */

const fs = require('fs');
const path = require('path');

// Configuration
const SPRITE_PATH = path.resolve(__dirname, '../../../projects/angular/mfe-base/src/assets/Ids_Itau_Icons-defs.svg');
// Path must match IDS expected URL: ${baseUrl}/ids/assets/icons/v2/{name}.svg
const OUTPUT_DIR = path.resolve(__dirname, '../public/ids/assets/icons/v2');

/**
 * Parse SVG sprite and extract symbols
 */
function extractSymbols(svgContent) {
  const symbols = [];

  // Match all <symbol> elements with their content
  const symbolRegex = /<symbol\s+viewBox="([^"]+)"\s+id="([^"]+)">([\s\S]*?)<\/symbol>/g;

  let match;
  while ((match = symbolRegex.exec(svgContent)) !== null) {
    const viewBox = match[1];
    const id = match[2];
    const content = match[3].trim();

    symbols.push({
      id,
      viewBox,
      content
    });
  }

  return symbols;
}

/**
 * Convert symbol to standalone SVG
 */
function symbolToSvg(symbol) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${symbol.viewBox}" fill="currentColor">
${symbol.content}
</svg>`;
}

/**
 * Main extraction function
 */
function main() {
  console.log('='.repeat(60));
  console.log('IDS Icon Extractor for Local Development');
  console.log('='.repeat(60));

  // Check source file
  if (!fs.existsSync(SPRITE_PATH)) {
    console.error(`\nError: Source sprite not found at:\n  ${SPRITE_PATH}`);
    process.exit(1);
  }

  console.log(`\nSource: ${SPRITE_PATH}`);
  console.log(`Output: ${OUTPUT_DIR}`);

  // Read sprite file
  const spriteContent = fs.readFileSync(SPRITE_PATH, 'utf-8');

  // Extract symbols
  const symbols = extractSymbols(spriteContent);
  console.log(`\nFound ${symbols.length} icons in sprite`);

  if (symbols.length === 0) {
    console.error('No symbols found in sprite file');
    process.exit(1);
  }

  // Ensure output directory exists
  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
    console.log(`Created output directory: ${OUTPUT_DIR}`);
  }

  // Extract each symbol as individual SVG
  let successCount = 0;
  const errors = [];

  for (const symbol of symbols) {
    try {
      const svgContent = symbolToSvg(symbol);
      const outputPath = path.join(OUTPUT_DIR, `${symbol.id}.svg`);

      fs.writeFileSync(outputPath, svgContent);
      successCount++;
    } catch (err) {
      errors.push({ id: symbol.id, error: err.message });
    }
  }

  // Generate icon manifest for quick reference
  const manifest = {
    generatedAt: new Date().toISOString(),
    sourceFile: 'Ids_Itau_Icons-defs.svg',
    totalIcons: symbols.length,
    icons: symbols.map(s => s.id).sort()
  };

  const manifestPath = path.join(OUTPUT_DIR, 'manifest.json');
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));

  // Summary
  console.log('\n' + '='.repeat(60));
  console.log('Summary:');
  console.log('='.repeat(60));
  console.log(`  ✓ Extracted: ${successCount} icons`);

  if (errors.length > 0) {
    console.log(`  ✗ Errors: ${errors.length}`);
    errors.forEach(e => console.log(`    - ${e.id}: ${e.error}`));
  }

  console.log(`  ✓ Manifest: ${manifestPath}`);
  console.log('\nIcons available at: /icons/v2/{name}.svg');
  console.log('\nDone!');
}

// Run
main();
