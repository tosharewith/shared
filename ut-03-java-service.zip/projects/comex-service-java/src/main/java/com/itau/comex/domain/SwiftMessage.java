package com.itau.comex.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * SWIFT Message domain model
 * Represents a SWIFT payment message (MT103, MT700, etc.)
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SwiftMessage {
    private String uetr;           // Unique End-to-End Transaction Reference
    private String messageType;    // MT103, MT700, etc.
    private String senderBic;
    private String receiverBic;
    private BigDecimal amount;
    private String currency;
    private String beneficiary;
    private String reference;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime deliveredAt;
}
