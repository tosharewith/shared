package com.itau.comex.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response DTO for Angular compatibility
 * Matches the XML response format: RESPOSTA/DADOS/ListaEmpresas/Item
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmpresaResponse {

    @JsonProperty("RESPOSTA")
    private Resposta resposta;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Resposta {
        @JsonProperty("DADOS")
        private Dados dados;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Dados {
        @JsonProperty("ListaEmpresas")
        private ListaEmpresas listaEmpresas;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ListaEmpresas {
        @JsonProperty("Item")
        private List<EmpresaItem> items;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class EmpresaItem {
        @JsonProperty("SCGCCPF_CLI")
        private String cnpj;

        @JsonProperty("SNOME_CLI")
        private String nome;
    }

    /**
     * Factory method to create response from company list
     */
    public static EmpresaResponse from(List<EmpresaItem> items) {
        return EmpresaResponse.builder()
                .resposta(Resposta.builder()
                        .dados(Dados.builder()
                                .listaEmpresas(ListaEmpresas.builder()
                                        .items(items)
                                        .build())
                                .build())
                        .build())
                .build();
    }
}
