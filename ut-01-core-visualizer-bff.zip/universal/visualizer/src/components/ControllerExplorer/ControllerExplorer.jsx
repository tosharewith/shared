import { useState, useEffect } from 'react';
import { ContainedList, ContainedListItem } from '@carbon/react';
import { Folder, Document, ChevronRight, View, ChartNetwork, ChevronLeft } from '@carbon/icons-react';
import styles from './ControllerExplorer.module.scss';

/**
 * ControllerExplorer Component
 * File tree navigation for browsing and selecting controllers
 * Based on mmjc-frontend FileExplorer structure
 */
const ControllerExplorer = ({ onControllerSelect, isCollapsed, onToggleCollapse }) => {
  const [controllers, setControllers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedController, setSelectedController] = useState(null);
  const [expandedNodes, setExpandedNodes] = useState({});

  useEffect(() => {
    loadControllers();
  }, []);

  const loadControllers = async () => {
    try {
      setLoading(true);

      // Try to load directory index (if available)
      const response = await fetch('/controllers_index.json');
      if (response.ok) {
        const data = await response.json();
        setControllers(data.controllers || []);
      } else {
        // Fallback: Use default controller list
        setControllers([
          {
            id: 'SP1NBP',
            name: 'SP1NBP',
            type: 'controller',
            xmlCount: 20,
            path: 'root',
            hierarchy: {
              Workflow: ['VisaoCliente.xml'],
              Screens: ['ConsultaCNPJS.xml'],
              Operations: []
            }
          }
        ]);
      }
    } catch (error) {
      console.error('Error loading controllers:', error);
      setControllers([]);
    } finally {
      setLoading(false);
    }
  };

  const toggleExpand = (path) => {
    setExpandedNodes(prev => ({
      ...prev,
      [path]: !prev[path]
    }));
  };

  const handleControllerClick = (controller) => {
    setSelectedController(controller.id);
    toggleExpand(controller.id);
  };

  const handleLoadGraph = (controller) => {
    console.log('Loading graph for controller:', controller);
    onControllerSelect(controller);
  };

  const handleFileClick = (controller, category, file) => {
    console.log('File clicked:', { controller: controller.name, category, file });
    // Load graph when clicking on Workflow files
    if (category === 'Workflow') {
      setSelectedController(controller.id);
      onControllerSelect({
        ...controller,
        selectedFile: file,
        category: category
      });
    }
  };

  if (loading) {
    return (
      <div className={styles.explorer}>
        <div className={styles.header}>
          <h3>Controllers</h3>
        </div>
        <div className={styles.loading}>Loading controllers...</div>
      </div>
    );
  }

  return (
    <div className={`${styles.explorer} ${isCollapsed ? styles.collapsed : ''}`}>
      <div className={styles.header}>
        <div className={styles.headerContent}>
          {!isCollapsed && (
            <>
              <h3>Controllers</h3>
              <p className={styles.subtitle}>{controllers.length} controller(s)</p>
            </>
          )}
        </div>
        <button
          className={styles.collapseButton}
          onClick={onToggleCollapse}
          title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <ChevronLeft size={20} className={isCollapsed ? styles.chevronCollapsed : ''} />
        </button>
      </div>

      {!isCollapsed && (
        <>

      <div className={styles.listContainer}>
        <ContainedList className={styles.column}>
          {controllers.map((controller) => (
            <div key={controller.id}>
              {/* Controller Row */}
              <ContainedListItem
                className={`${styles.row} ${expandedNodes[controller.id] ? styles.expanded : ''}`}
                renderIcon={Folder}
                onClick={() => handleControllerClick(controller)}
              >
                <span className={styles.listItemContent}>
                  <span className={styles.name}>{controller.name}</span>
                  <span className={styles.metadata}>
                    <span className={styles.xmlCount}>{controller.xmlCount} XMLs</span>
                    <ChevronRight className={expandedNodes[controller.id] ? styles.chevronExpanded : ''} />
                  </span>
                </span>
              </ContainedListItem>

              {/* Expanded content */}
              {expandedNodes[controller.id] && (
                <div className={styles.expandedContent}>
                  {/* Load Graph Button */}
                  <ContainedListItem
                    className={`${styles.row} ${styles.actionRow} ${selectedController === controller.id ? styles.active : ''}`}
                    renderIcon={ChartNetwork}
                    onClick={() => handleLoadGraph(controller)}
                  >
                    <span className={styles.listItemContent}>
                      <span className={styles.actionName}>Load Graph</span>
                      <View />
                    </span>
                  </ContainedListItem>

                  {/* Hierarchical structure */}
                  {controller.hierarchy && Object.entries(controller.hierarchy).map(([category, files]) => (
                    <div key={`${controller.id}-${category}`}>
                      {/* Category Row */}
                      <ContainedListItem
                        className={`${styles.row} ${styles.categoryRow} ${expandedNodes[`${controller.id}-${category}`] ? styles.expanded : ''}`}
                        renderIcon={Folder}
                        onClick={() => toggleExpand(`${controller.id}-${category}`)}
                      >
                        <span className={styles.listItemContent}>
                          <span className={styles.name}>{category}</span>
                          <span className={styles.metadata}>
                            <span className={styles.fileCount}>({files.length})</span>
                            <ChevronRight className={expandedNodes[`${controller.id}-${category}`] ? styles.chevronExpanded : ''} />
                          </span>
                        </span>
                      </ContainedListItem>

                      {/* Files in Category */}
                      {expandedNodes[`${controller.id}-${category}`] && files.map((file, index) => (
                        <ContainedListItem
                          key={`${controller.id}-${category}-${file}-${index}`}
                          className={`${styles.row} ${styles.fileRow} ${category === 'Workflow' ? styles.clickableFile : ''}`}
                          renderIcon={Document}
                          onClick={() => handleFileClick(controller, category, file)}
                        >
                          <span className={styles.listItemContent}>
                            <span className={styles.name}>{file}</span>
                            {category === 'Workflow' && <View size={16} />}
                          </span>
                        </ContainedListItem>
                      ))}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </ContainedList>
      </div>

      <div className={styles.footer}>
        <button
          className={styles.refreshButton}
          onClick={loadControllers}
        >
          Refresh Controllers
        </button>
      </div>
      </>
      )}
    </div>
  );
};

export default ControllerExplorer;
