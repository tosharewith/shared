import { useState, useEffect, useRef } from 'react';
import { loadAllScreens, buildNavigationFlow } from '../../utils/xmlParser';
import styles from './FlowViewer.module.scss';

/**
 * FlowViewer Component
 * Visual SVG-based navigation flow diagram
 * Based on Angular flow-viewer component
 */
const FlowViewer = () => {
  const [screens, setScreens] = useState([]);
  const [flow, setFlow] = useState({ screens: [], connections: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const canvasRef = useRef(null);
  const [canvasWidth, setCanvasWidth] = useState(1200);
  const [canvasHeight, setCanvasHeight] = useState(900);
  const [nodePositions, setNodePositions] = useState(new Map());

  useEffect(() => {
    loadFlowData();
  }, []);

  const loadFlowData = async () => {
    try {
      setLoading(true);
      const loadedScreens = await loadAllScreens();
      console.log('Loaded screens:', loadedScreens.length);

      const navigationFlow = buildNavigationFlow(loadedScreens);
      console.log('Navigation flow:', navigationFlow);

      // Calculate canvas size
      const maxX = Math.max(...navigationFlow.screens.map(n => n.x), 0) + 300;
      const maxY = Math.max(...navigationFlow.screens.map(n => n.y), 0) + 200;
      setCanvasWidth(Math.max(1200, maxX));
      setCanvasHeight(Math.max(900, maxY));

      // Initialize node positions
      const positions = new Map();
      navigationFlow.screens.forEach(node => {
        positions.set(node.id, { x: node.x + 90, y: node.y + 35 });
      });
      setNodePositions(positions);

      setScreens(loadedScreens);
      setFlow(navigationFlow);
      setLoading(false);
    } catch (err) {
      console.error('Error loading flow:', err);
      setError('Failed to load navigation flow');
      setLoading(false);
    }
  };

  const getNodeCenter = (nodeId) => {
    // Try exact match first
    let pos = nodePositions.get(nodeId);
    if (pos) return pos;

    // Try partial match
    for (const [key, value] of nodePositions) {
      if (key.includes(nodeId) || nodeId.includes(key)) {
        return value;
      }
    }

    return { x: 0, y: 0 };
  };

  const getNodeConnectionCount = (nodeId) => {
    return flow.connections.filter(c =>
      c.from === nodeId || c.to === nodeId ||
      c.from.includes(nodeId) || c.to.includes(nodeId) ||
      nodeId.includes(c.from) || nodeId.includes(c.to)
    ).length;
  };

  const getMarker = (type) => {
    switch (type) {
      case 'conditional': return 'url(#arrowhead-orange)';
      case 'vc-flow': return 'url(#arrowhead-green)';
      case 'back': return 'url(#arrowhead-yellow)';
      default: return 'url(#arrowhead)';
    }
  };

  const getBadgeClass = (type) => {
    switch (type) {
      case 'Browser': return styles.badgeBlue;
      case 'WebService': return styles.badgeGreen;
      case 'VC': return styles.badgePurple;
      default: return styles.badgeGray;
    }
  };

  const getConnectionTypeName = (type) => {
    switch (type) {
      case 'normal': return 'Normal';
      case 'conditional': return 'Condicional';
      case 'vc-flow': return 'Fluxo VC';
      case 'back': return 'Voltar';
      default: return type;
    }
  };

  const getConnectionBadgeClass = (type) => {
    switch (type) {
      case 'normal': return styles.badgeGray;
      case 'conditional': return styles.badgeOrange;
      case 'vc-flow': return styles.badgeGreen;
      case 'back': return styles.badgePurple;
      default: return styles.badgeGray;
    }
  };

  const visibleConnections = flow.connections.filter(conn => {
    const fromExists = nodePositions.has(conn.from) ||
                       flow.screens.some(n => n.id.includes(conn.from) || conn.from.includes(n.id));
    const toExists = nodePositions.has(conn.to) ||
                     flow.screens.some(n => n.id.includes(conn.to) || conn.to.includes(n.id)) ||
                     conn.isExternal;
    return fromExists && toExists;
  });

  const internalConnections = flow.connections.filter(c => !c.isExternal).length;
  const externalConnections = flow.connections.filter(c => c.isExternal).length;

  if (loading) {
    return (
      <div className={styles.container}>
        <div className={styles.loadingState}>
          <div className={styles.spinner}></div>
          <span>Loading navigation flow...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.container}>
        <div className={styles.error}>{error}</div>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      {/* Header */}
      <div className={styles.header}>
        <h1 className={styles.title}>Navigation Flow</h1>
        <p className={styles.subtitle}>Visual representation of screen navigation and connections</p>
      </div>

      {/* Legend Card */}
      <div className={styles.legendCard}>
        <h3 className={styles.cardTitle}>Legend</h3>
        <div className={styles.legendItems}>
          <div className={styles.legendItem}>
            <div className={`${styles.legendNode} ${styles.browser}`}></div>
            <span>Browser Screen</span>
          </div>
          <div className={styles.legendItem}>
            <div className={`${styles.legendNode} ${styles.webservice}`}></div>
            <span>Web Service</span>
          </div>
          <div className={styles.legendItem}>
            <div className={`${styles.legendNode} ${styles.vc}`}></div>
            <span>View Controller</span>
          </div>
          <div className={styles.legendItem}>
            <div className={`${styles.legendLine} ${styles.normal}`}></div>
            <span>Normal Navigation</span>
          </div>
          <div className={styles.legendItem}>
            <div className={`${styles.legendLine} ${styles.conditional}`}></div>
            <span>Conditional Connection</span>
          </div>
          <div className={styles.legendItem}>
            <div className={`${styles.legendLine} ${styles.vcFlow}`}></div>
            <span>VC Flow (Steps)</span>
          </div>
          <div className={styles.legendItem}>
            <div className={`${styles.legendLine} ${styles.back}`}></div>
            <span>Back Navigation</span>
          </div>
        </div>

        {/* Stats */}
        <div className={styles.flowStats}>
          <span className={styles.stat}>
            <strong>{flow.screens.length}</strong> Screens
          </span>
          <span className={styles.stat}>
            <strong>{flow.connections.length}</strong> Connections
          </span>
          <span className={styles.stat}>
            <strong>{internalConnections}</strong> Internal
          </span>
          <span className={styles.stat}>
            <strong>{externalConnections}</strong> External
          </span>
        </div>
      </div>

      {/* Flow Diagram */}
      <div className={styles.flowContainer}>
        <div className={styles.flowCanvas} ref={canvasRef}>
          {/* SVG for connections */}
          <svg className={styles.connectionsSvg} width={canvasWidth} height={canvasHeight}>
            <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#78909C"/>
              </marker>
              <marker id="arrowhead-orange" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#EC7000"/>
              </marker>
              <marker id="arrowhead-green" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#00A86B"/>
              </marker>
              <marker id="arrowhead-yellow" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#FFB800"/>
              </marker>
            </defs>

            {visibleConnections.map((conn, idx) => {
              const from = getNodeCenter(conn.from);
              const to = getNodeCenter(conn.to);
              return (
                <g key={idx} className={`${styles.connection} ${styles[conn.type]}`}>
                  <line
                    x1={from.x}
                    y1={from.y}
                    x2={to.x}
                    y2={to.y}
                    markerEnd={getMarker(conn.type)}
                    className={styles[conn.type]}
                  />
                  {conn.label && (
                    <text
                      x={(from.x + to.x) / 2}
                      y={(from.y + to.y) / 2 - 8}
                      className={styles.connectionLabel}
                      textAnchor="middle">
                      {conn.label}
                    </text>
                  )}
                </g>
              );
            })}
          </svg>

          {/* Nodes */}
          {flow.screens.map(node => (
            <div
              key={node.id}
              className={`${styles.flowNode} ${styles[node.type.toLowerCase()]}`}
              style={{ left: `${node.x}px`, top: `${node.y}px` }}>
              <span className={styles.nodeType}>{node.type}</span>
              <span className={styles.nodeName}>{node.name}</span>
              <span className={styles.nodeConnections}>
                {getNodeConnectionCount(node.id)} connections
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Connection Details Table */}
      <div className={styles.connectionsSection}>
        <h3 className={styles.cardTitle}>Connection Details ({flow.connections.length})</h3>
        <div className={styles.tableContainer}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>From</th>
                <th>To</th>
                <th>Type</th>
                <th>Condition/Label</th>
              </tr>
            </thead>
            <tbody>
              {flow.connections.map((conn, idx) => (
                <tr key={idx} className={conn.isExternal ? styles.externalRow : ''}>
                  <td className={styles.screenLink}>{conn.from}</td>
                  <td>
                    {conn.isExternal ? (
                      <span className={styles.externalRef}>{conn.to} (external)</span>
                    ) : (
                      <span className={styles.screenLink}>{conn.to}</span>
                    )}
                  </td>
                  <td>
                    <span className={`${styles.badge} ${getConnectionBadgeClass(conn.type)}`}>
                      {getConnectionTypeName(conn.type)}
                    </span>
                  </td>
                  <td>
                    {conn.label ? (
                      <code className={styles.code}>{conn.label}</code>
                    ) : (
                      <span className={styles.textMuted}>-</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Screens List */}
      <div className={styles.screensSection}>
        <h3 className={styles.cardTitle}>All Screens ({screens.length})</h3>
        <div className={styles.tableContainer}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Final Step</th>
                <th>Finalization</th>
                <th>Valorizations</th>
                <th>Successors</th>
              </tr>
            </thead>
            <tbody>
              {screens.map(screen => (
                <tr key={screen.name}>
                  <td>{screen.logicalName}</td>
                  <td>
                    <span className={`${styles.badge} ${getBadgeClass(screen.type)}`}>
                      {screen.type}
                    </span>
                  </td>
                  <td className={screen.isFinalStep ? styles.textSuccess : styles.textMuted}>
                    {screen.isFinalStep ? 'Yes' : 'No'}
                  </td>
                  <td className={screen.hasFinalization ? styles.textSuccess : styles.textMuted}>
                    {screen.hasFinalization ? 'Yes' : 'No'}
                  </td>
                  <td>{screen.valorizations.length}</td>
                  <td>{screen.successors.length}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FlowViewer;
