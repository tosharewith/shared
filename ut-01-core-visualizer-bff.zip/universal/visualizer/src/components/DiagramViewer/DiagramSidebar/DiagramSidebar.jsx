import { useMemo, useState } from 'react';
import { getNodeTypes, getEdgeTypes, getNodeFilterColors, getEdgeFilterColors, nodeStyles } from '../utils/styleConfigs';
import { layoutNames } from '../utils/layoutConfigs';
import styles from './DiagramSidebar.module.scss';

/**
 * DiagramSidebar Component
 * Contains search, filters, layout selector, and statistics
 */
const DiagramSidebar = ({
  elements,
  searchTerm,
  onSearch,
  onSearchResultSelect,
  nodeTypeFilters,
  edgeTypeFilters,
  onNodeTypeFilterChange,
  onEdgeTypeFilterChange,
  showSequentialFlowOnly,
  onSequentialFlowFilterChange,
  selectedLayout,
  onLayoutChange,
  onApplyLayout,
  stats,
  layoutParams,
  onLayoutParamsChange,
}) => {
  const [layoutParamsExpanded, setLayoutParamsExpanded] = useState(false);

  // Extract unique types
  const allElements = [...elements.nodes, ...elements.edges];
  const nodeTypes = getNodeTypes(allElements);
  const edgeTypes = getEdgeTypes(allElements);

  // Search results - filter nodes by label or fullName
  const searchResults = useMemo(() => {
    if (!searchTerm || searchTerm.length < 2) return [];

    const query = searchTerm.toLowerCase();
    const results = elements.nodes.filter(node => {
      const label = node.data?.label?.toLowerCase() || '';
      const fullName = node.data?.fullName?.toLowerCase() || '';
      return label.includes(query) || fullName.includes(query);
    });

    // Return max 10 results
    return results.slice(0, 10);
  }, [searchTerm, elements.nodes]);

  // Layout options
  const layoutOptions = Object.entries(layoutNames).map(([value, label]) => ({
    value,
    label,
  }));

  // Helper to get shape icon HTML
  const getShapeIcon = (shape, color) => {
    const commonStyle = {
      width: '16px',
      height: '16px',
      backgroundColor: color,
      flexShrink: 0,
    };

    if (shape === 'rectangle') {
      return <div style={commonStyle} />;
    } else if (shape === 'roundrectangle') {
      return <div style={{ ...commonStyle, borderRadius: '4px' }} />;
    } else if (shape === 'ellipse') {
      return <div style={{ ...commonStyle, borderRadius: '50%' }} />;
    } else if (shape === 'diamond') {
      return <div style={{ ...commonStyle, width: '12px', height: '12px', transform: 'rotate(45deg)' }} />;
    } else {
      return <div style={{ ...commonStyle, borderRadius: '50%' }} />;
    }
  };

  return (
    <div className={styles.sidebar}>
      <div className={styles.section}>
        <h3 className={styles.sectionTitle}>Buscar</h3>
        <div className={styles.searchContainer}>
          <div className={styles.searchInputWrapper}>
            <input
              type="text"
              className={styles.searchInput}
              placeholder="Buscar nós..."
              value={searchTerm}
              onChange={(e) => onSearch(e.target.value)}
            />
            {searchTerm && (
              <button
                className={styles.searchClear}
                onClick={() => onSearch('')}
                title="Limpar busca"
              >
                ✕
              </button>
            )}
          </div>
          {/* Search Results Dropdown */}
          {searchResults.length > 0 && (
            <div className={styles.searchResults}>
              <ul className={styles.searchResultsList}>
                {searchResults.map((node) => {
                  const nodeData = node.data;
                  const style = nodeStyles[nodeData.type] || nodeStyles['Unknown'];

                  return (
                    <li
                      key={nodeData.id}
                      className={styles.searchResultItem}
                      onClick={() => {
                        onSearchResultSelect(nodeData.id);
                        onSearch(''); // Clear search after selection
                      }}
                    >
                      <div className={styles.searchResultContent}>
                        {getShapeIcon(style.shape, style.color)}
                        <div className={styles.searchResultText}>
                          <div className={styles.searchResultName}>{nodeData.label}</div>
                          <div className={styles.searchResultFullName}>{nodeData.fullName}</div>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </div>
      </div>

      <div className={styles.section}>
        <h3 className={styles.sectionTitle}>Layout</h3>
        <select
          className={styles.layoutSelect}
          value={selectedLayout}
          onChange={(e) => onLayoutChange(e.target.value)}
        >
          {layoutOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <button
          className={styles.applyButton}
          onClick={onApplyLayout}
        >
          Aplicar Layout
        </button>

        {/* Layout Parameters (Collapsible) */}
        {layoutParams && onLayoutParamsChange && (
          <div className={styles.layoutParams}>
            <button
              className={styles.layoutParamsToggle}
              onClick={() => setLayoutParamsExpanded(!layoutParamsExpanded)}
            >
              <span className={layoutParamsExpanded ? styles.iconExpanded : ''}>▼</span>
              <span>Parâmetros de Layout (Opcional)</span>
            </button>
            {layoutParamsExpanded && (
              <div className={styles.paramSliders}>
                <div className={styles.sliderGroup}>
                  <label>
                    Comprimento da Aresta
                    <input
                      type="range"
                      min="30"
                      max="150"
                      step="10"
                      value={layoutParams.edgeLength || 60}
                      onChange={(e) => onLayoutParamsChange({ ...layoutParams, edgeLength: parseInt(e.target.value) })}
                      className={styles.slider}
                    />
                    <span className={styles.sliderValue}>{layoutParams.edgeLength || 60}</span>
                  </label>
                </div>
                <div className={styles.sliderGroup}>
                  <label>
                    Espaçamento de Nós
                    <input
                      type="range"
                      min="0.5"
                      max="2.0"
                      step="0.1"
                      value={layoutParams.nodeSpacing || 1.0}
                      onChange={(e) => onLayoutParamsChange({ ...layoutParams, nodeSpacing: parseFloat(e.target.value) })}
                      className={styles.slider}
                    />
                    <span className={styles.sliderValue}>{(layoutParams.nodeSpacing || 1.0).toFixed(1)}</span>
                  </label>
                </div>
                <div className={styles.sliderGroup}>
                  <label>
                    Gravidade (Puxar para o Centro)
                    <input
                      type="range"
                      min="0"
                      max="100"
                      step="5"
                      value={layoutParams.gravity || 50}
                      onChange={(e) => onLayoutParamsChange({ ...layoutParams, gravity: parseInt(e.target.value) })}
                      className={styles.slider}
                    />
                    <span className={styles.sliderValue}>{layoutParams.gravity || 50}</span>
                  </label>
                </div>
                <div className={styles.sliderGroup}>
                  <label>
                    Repulsão de Nós
                    <input
                      type="range"
                      min="1000"
                      max="10000"
                      step="500"
                      value={layoutParams.nodeRepulsion || 3500}
                      onChange={(e) => onLayoutParamsChange({ ...layoutParams, nodeRepulsion: parseInt(e.target.value) })}
                      className={styles.slider}
                    />
                    <span className={styles.sliderValue}>{layoutParams.nodeRepulsion || 3500}</span>
                  </label>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Combined Filters Section (matching HTML visualizer design) */}
      <div className={styles.section}>
        <h3 className={styles.sectionTitle}>Filtros</h3>

        {/* Sequential Flow Filter Toggle */}
        <div className={styles.filterGroup}>
          <label className={styles.flowFilterToggle}>
            <input
              type="checkbox"
              checked={showSequentialFlowOnly}
              onChange={(e) => onSequentialFlowFilterChange(e.target.checked)}
              className={styles.flowFilterCheckbox}
            />
            <span className={styles.flowFilterLabel}>
              🔀 Mostrar Apenas Fluxo Sequencial
            </span>
          </label>
          {showSequentialFlowOnly && (
            <div className={styles.flowFilterHint}>
              Mostrando apenas arestas com números de passo (fluxo de navegação)
            </div>
          )}
        </div>

        {/* Object Types (Node Types) */}
        {nodeTypes.length > 0 && (
          <div className={styles.filterGroup}>
            <div className={styles.filterGroupTitle}>Tipos de Objeto:</div>
            <div className={styles.filterGrid}>
              {nodeTypes.map((type) => {
                const colors = getNodeFilterColors(type);
                const isChecked = nodeTypeFilters[type] !== undefined ? nodeTypeFilters[type] : true;
                return (
                  <label
                    key={type}
                    htmlFor={`node-filter-${type}`}
                    className={styles.filterTag}
                    style={{
                      backgroundColor: colors.bg,
                      borderColor: colors.border,
                      color: colors.text,
                    }}
                  >
                    <input
                      type="checkbox"
                      id={`node-filter-${type}`}
                      checked={isChecked}
                      onChange={(e) => onNodeTypeFilterChange(type, e.target.checked)}
                    />
                    <span>{type}</span>
                  </label>
                );
              })}
            </div>
          </div>
        )}

        {/* Relationship Types (Edge Types) */}
        {edgeTypes.length > 0 && (
          <div className={styles.filterGroup}>
            <div className={styles.filterGroupTitle}>Tipos de Relacionamento:</div>
            <div className={styles.filterGrid}>
              {edgeTypes.map((type) => {
                const colors = getEdgeFilterColors(type);
                const isChecked = edgeTypeFilters[type] !== undefined ? edgeTypeFilters[type] : true;
                return (
                  <label
                    key={type}
                    htmlFor={`edge-filter-${type}`}
                    className={styles.filterTag}
                    style={{
                      backgroundColor: colors.bg,
                      borderColor: colors.border,
                      color: colors.text,
                    }}
                  >
                    <input
                      type="checkbox"
                      id={`edge-filter-${type}`}
                      checked={isChecked}
                      onChange={(e) => onEdgeTypeFilterChange(type, e.target.checked)}
                    />
                    <span>{type}</span>
                  </label>
                );
              })}
            </div>
          </div>
        )}
      </div>

      <div className={styles.section}>
        <h3 className={styles.sectionTitle}>Estatísticas</h3>
        <div className={styles.stats}>
          <div className={styles.statItem}>
            <span className={styles.statLabel}>Total de Nós:</span>
            <span className={styles.statValue}>{stats.nodes}</span>
          </div>
          <div className={styles.statItem}>
            <span className={styles.statLabel}>Arestas:</span>
            <span className={styles.statValue}>{stats.edges}</span>
          </div>
          {stats.selectedNodes !== undefined && stats.selectedNodes > 0 && (
            <div className={styles.statItem}>
              <span className={styles.statLabel}>Selecionados:</span>
              <span className={styles.statValue}>{stats.selectedNodes}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DiagramSidebar;
