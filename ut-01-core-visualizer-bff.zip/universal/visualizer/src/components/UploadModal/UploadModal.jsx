import { useState, useCallback, useRef, useEffect } from 'react';
import {
  Modal,
  Button,
  InlineLoading,
  Tag,
  ProgressIndicator,
  ProgressStep
} from '@carbon/react';
import {
  FolderAdd,
  CheckmarkFilled,
  ErrorFilled,
  DocumentBlank,
  Folder,
  Zip,
  WarningAlt,
  Download
} from '@carbon/icons-react';
import JSZip from 'jszip';
import TRNInput from '../TRNInput';
import JSONViewer from '../JSONViewer';
import { runExtraction, parseInteractionXml } from '../../utils/extractionEngine';
import styles from './UploadModal.module.scss';

/**
 * UploadModal Component
 * Modal workflow for uploading XMLs, entering TRN, and extracting JSON
 */
const UploadModal = ({ isOpen, onClose, onTransactionExtracted }) => {
  // State
  const [currentStep, setCurrentStep] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [parsedXmlFiles, setParsedXmlFiles] = useState([]);
  const [parseResults, setParseResults] = useState(null);
  const [parsedTRN, setParsedTRN] = useState(null);
  const [extractedJSON, setExtractedJSON] = useState(null);
  const [error, setError] = useState(null);

  const folderInputRef = useRef(null);
  const jsonInputRef = useRef(null);
  const zipInputRef = useRef(null);

  // Parse XML content
  const parseXML = useCallback((content, filename, relativePath) => {
    return parseInteractionXml(content, filename, relativePath);
  }, []);

  // Process uploaded files
  const processFiles = async (files) => {
    setIsProcessing(true);
    setError(null);

    const results = {
      screens: [],
      services: [],
      configs: [],
      errors: [],
      totalFiles: 0
    };

    const xmlFilesData = [];
    const fileList = [];

    for (const file of files) {
      if (file.name.endsWith('.xml') || file.name.endsWith('.XML')) {
        results.totalFiles++;

        try {
          const content = await file.text();
          const relativePath = file.webkitRelativePath || file.name;
          const parsed = parseXML(content, file.name, relativePath);

          xmlFilesData.push({
            filename: file.name,
            path: relativePath,
            content,
            ...parsed
          });

          fileList.push({
            name: file.name,
            path: relativePath,
            size: file.size,
            parsed: parsed.success,
            data: parsed,
            error: parsed.error
          });

          if (parsed.success) {
            if (parsed.type === 'Browser' || parsed.fields?.inputs?.length > 0) {
              results.screens.push({ filename: file.name, path: relativePath, ...parsed });
            } else if (parsed.type === 'WebService') {
              results.services.push({ filename: file.name, path: relativePath, ...parsed });
            } else {
              results.configs.push({ filename: file.name, path: relativePath, ...parsed });
            }
          } else {
            results.errors.push({ filename: file.name, path: relativePath, error: parsed.error });
          }
        } catch (err) {
          results.errors.push({ filename: file.name, error: err.message });
        }
      }
    }

    setUploadedFiles(fileList);
    setParsedXmlFiles(xmlFilesData);
    setParseResults(results);
    setIsProcessing(false);

    if (results.screens.length > 0 || results.services.length > 0) {
      setCurrentStep(1);
    }
  };

  // Handle JSON file upload for direct visualization
  const processJsonFile = async (file) => {
    setIsProcessing(true);
    setError(null);

    try {
      const content = await file.text();
      const json = JSON.parse(content);

      if (json.schemaType !== 'transaction-context-aware') {
        throw new Error('JSON deve ser do tipo "transaction-context-aware"');
      }

      setExtractedJSON(json);
      setCurrentStep(2);
    } catch (err) {
      setError(`Erro ao processar JSON: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle ZIP file upload
  const processZipFile = async (file) => {
    setIsProcessing(true);
    setError(null);

    try {
      const zip = await JSZip.loadAsync(file);
      const results = {
        screens: [],
        services: [],
        configs: [],
        errors: [],
        totalFiles: 0
      };

      const xmlFilesData = [];
      const fileList = [];

      // Extract all XML files from ZIP
      const xmlEntries = Object.entries(zip.files).filter(([path]) =>
        path.toLowerCase().endsWith('.xml') && !path.startsWith('__MACOSX')
      );

      // Debug: log all paths found in ZIP
      console.log('[UploadModal] ZIP file paths found:', xmlEntries.map(([p]) => p));

      // Collect unique folders for debugging
      const folders = new Set();
      for (const [path] of xmlEntries) {
        const parts = path.split('/');
        for (let i = 1; i < parts.length; i++) {
          folders.add(parts.slice(0, i).join('/'));
        }
      }
      console.log('[UploadModal] Folders in ZIP:', Array.from(folders));

      for (const [relativePath, zipEntry] of xmlEntries) {
        if (zipEntry.dir) continue;

        results.totalFiles++;
        const filename = relativePath.split('/').pop();

        try {
          const content = await zipEntry.async('text');
          const parsed = parseXML(content, filename, relativePath);

          xmlFilesData.push({
            filename,
            path: relativePath,
            content,
            ...parsed
          });

          fileList.push({
            name: filename,
            path: relativePath,
            size: content.length,
            parsed: parsed.success,
            data: parsed,
            error: parsed.error
          });

          if (parsed.success) {
            if (parsed.type === 'Browser' || parsed.fields?.inputs?.length > 0) {
              results.screens.push({ filename, path: relativePath, ...parsed });
            } else if (parsed.type === 'WebService') {
              results.services.push({ filename, path: relativePath, ...parsed });
            } else {
              results.configs.push({ filename, path: relativePath, ...parsed });
            }
          } else {
            results.errors.push({ filename, path: relativePath, error: parsed.error });
          }
        } catch (err) {
          results.errors.push({ filename, error: err.message });
        }
      }

      if (results.totalFiles === 0) {
        throw new Error('Nenhum arquivo XML encontrado no ZIP');
      }

      // Debug: Group files by module
      const moduleGroups = {};
      for (const f of xmlFilesData) {
        const mod = f.module || 'unknown';
        if (!moduleGroups[mod]) moduleGroups[mod] = [];
        moduleGroups[mod].push(f.name);
      }
      console.log('[UploadModal] Files by module:', moduleGroups);

      setUploadedFiles(fileList);
      setParsedXmlFiles(xmlFilesData);
      setParseResults(results);

      if (results.screens.length > 0 || results.services.length > 0 || results.configs.length > 0) {
        setCurrentStep(1);
      }
    } catch (err) {
      setError(`Erro ao processar ZIP: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle extraction
  const handleRunExtraction = useCallback((trn) => {
    setIsProcessing(true);
    setError(null);

    try {
      const trnString = trn.full || `${trn.module}\\${trn.subProgram}\\${trn.interaction}@${trn.params.join('@')}`;
      const json = runExtraction(parsedXmlFiles, trnString);
      setExtractedJSON(json);
      setCurrentStep(2);
    } catch (err) {
      setError(`Erro na extração: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  }, [parsedXmlFiles]);

  // Handle TRN parsed
  const handleTRNParsed = useCallback((trn) => {
    setParsedTRN(trn);
  }, []);

  // Handle drag events
  const handleDragEnter = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  // Handle file drop
  const handleDrop = useCallback(async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const items = e.dataTransfer.items;
    const files = [];

    const readDirectory = async (entry, path = '') => {
      if (entry.isFile) {
        return new Promise((resolve) => {
          entry.file((file) => {
            Object.defineProperty(file, 'webkitRelativePath', {
              value: path + file.name,
              writable: false
            });
            files.push(file);
            resolve();
          });
        });
      } else if (entry.isDirectory) {
        const dirReader = entry.createReader();
        return new Promise((resolve) => {
          const readEntries = () => {
            dirReader.readEntries(async (entries) => {
              if (entries.length === 0) {
                resolve();
              } else {
                for (const childEntry of entries) {
                  await readDirectory(childEntry, path + entry.name + '/');
                }
                readEntries();
              }
            });
          };
          readEntries();
        });
      }
    };

    const promises = [];
    for (const item of items) {
      const entry = item.webkitGetAsEntry?.();
      if (entry) {
        promises.push(readDirectory(entry));
      }
    }

    await Promise.all(promises);

    // Check for ZIP files first (from direct file drop)
    const droppedFiles = Array.from(e.dataTransfer.files);
    const zipFiles = droppedFiles.filter(f => f.name.toLowerCase().endsWith('.zip'));

    if (zipFiles.length > 0) {
      processZipFile(zipFiles[0]);
      return;
    }

    const jsonFiles = files.filter(f => f.name.endsWith('.json'));
    const xmlFiles = files.filter(f => f.name.endsWith('.xml') || f.name.endsWith('.XML'));

    if (jsonFiles.length > 0 && xmlFiles.length === 0) {
      processJsonFile(jsonFiles[0]);
    } else if (xmlFiles.length > 0) {
      processFiles(xmlFiles);
    }
  }, []);

  // Handle file input changes
  const handleFolderChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) processFiles(files);
  };

  const handleJsonChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) processJsonFile(files[0]);
  };

  const handleZipChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) processZipFile(files[0]);
  };

  // Save and close
  const handleSaveTransaction = () => {
    if (extractedJSON && onTransactionExtracted) {
      onTransactionExtracted(extractedJSON);
    }
    handleReset();
    onClose();
  };

  // Reset
  const handleReset = () => {
    setCurrentStep(0);
    setUploadedFiles([]);
    setParsedXmlFiles([]);
    setParseResults(null);
    setParsedTRN(null);
    setExtractedJSON(null);
    setError(null);
    if (folderInputRef.current) folderInputRef.current.value = '';
    if (jsonInputRef.current) jsonInputRef.current.value = '';
    if (zipInputRef.current) zipInputRef.current.value = '';
  };

  const goToStep = (step) => {
    if (step >= 0 && step <= 2) setCurrentStep(step);
  };

  // Download missing paths as text file
  const handleDownloadMissingPaths = () => {
    const missingPaths = extractedJSON?.flow?.missingPaths || [];
    if (missingPaths.length === 0) return;

    const content = [
      '# Missing Paths Report',
      `# Generated: ${new Date().toISOString()}`,
      `# TRN: ${extractedJSON?.menuItem?.trn?.full || 'N/A'}`,
      `# Total Missing: ${missingPaths.length}`,
      '',
      '# Missing interaction paths (not found in uploaded XMLs):',
      '',
      ...missingPaths.map((p, i) => `${i + 1}. ${p}`)
    ].join('\n');

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `missing-paths-${extractedJSON?.menuItem?.trn?.module || 'export'}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <Modal
      open={isOpen}
      onRequestClose={onClose}
      modalHeading="Upload & Extração de Transação"
      primaryButtonText={currentStep === 2 ? "Salvar Transação" : undefined}
      secondaryButtonText="Cancelar"
      onRequestSubmit={currentStep === 2 ? handleSaveTransaction : undefined}
      size="lg"
      className={styles.modal}
      passiveModal={currentStep !== 2}
    >
      <div className={styles.modalContent}>
        {/* Progress Indicator */}
        <ProgressIndicator currentIndex={currentStep} className={styles.progressIndicator}>
          <ProgressStep
            label="Upload"
            description="Arquivos XML/JSON"
            onClick={() => currentStep > 0 && goToStep(0)}
          />
          <ProgressStep
            label="TRN"
            description="Ponto de entrada"
            disabled={parsedXmlFiles.length === 0}
            onClick={() => currentStep > 1 && goToStep(1)}
          />
          <ProgressStep
            label="Resultado"
            description="JSON extraído"
            disabled={!extractedJSON}
          />
        </ProgressIndicator>

        {/* Step 0: Upload */}
        {currentStep === 0 && (
          <div
            className={`${styles.dropZone} ${isDragging ? styles.dragging : ''}`}
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          >
            {isProcessing ? (
              <div className={styles.processing}>
                <InlineLoading description="Processando arquivos..." />
              </div>
            ) : (
              <>
                <FolderAdd size={40} className={styles.uploadIcon} />
                <h4>Arraste uma pasta, ZIP ou arquivo</h4>
                <p>XMLs, ZIP com XMLs, ou JSON extraído</p>

                <div className={styles.uploadButtons}>
                  <input
                    ref={folderInputRef}
                    type="file"
                    webkitdirectory="true"
                    directory="true"
                    multiple
                    onChange={handleFolderChange}
                    style={{ display: 'none' }}
                  />
                  <Button
                    kind="primary"
                    size="sm"
                    renderIcon={Folder}
                    onClick={() => folderInputRef.current?.click()}
                  >
                    Pasta
                  </Button>

                  <input
                    ref={zipInputRef}
                    type="file"
                    accept=".zip"
                    onChange={handleZipChange}
                    style={{ display: 'none' }}
                  />
                  <Button
                    kind="secondary"
                    size="sm"
                    renderIcon={Zip}
                    onClick={() => zipInputRef.current?.click()}
                  >
                    ZIP
                  </Button>

                  <input
                    ref={jsonInputRef}
                    type="file"
                    accept=".json"
                    onChange={handleJsonChange}
                    style={{ display: 'none' }}
                  />
                  <Button
                    kind="tertiary"
                    size="sm"
                    renderIcon={DocumentBlank}
                    onClick={() => jsonInputRef.current?.click()}
                  >
                    JSON
                  </Button>
                </div>
              </>
            )}
          </div>
        )}

        {/* Step 1: TRN Input */}
        {currentStep === 1 && (
          <div className={styles.trnStep}>
            <div className={styles.filesSummary}>
              <CheckmarkFilled size={20} className={styles.successIcon} />
              <div>
                <h4>{parseResults?.totalFiles} arquivos XML carregados</h4>
                <p>
                  {parseResults?.screens?.length} telas, {parseResults?.services?.length} serviços
                  {parsedXmlFiles.length > 0 && (
                    <span style={{ marginLeft: '8px' }}>
                      | Módulos: {[...new Set(parsedXmlFiles.map(f => f.module).filter(Boolean))].join(', ') || 'N/A'}
                    </span>
                  )}
                </p>
              </div>
              <Button kind="ghost" size="sm" onClick={() => goToStep(0)}>
                Alterar
              </Button>
            </div>

            <TRNInput
              onTRNParsed={handleTRNParsed}
              onRunExtraction={handleRunExtraction}
              disabled={isProcessing}
            />

            {isProcessing && (
              <div className={styles.extractionProgress}>
                <InlineLoading description="Executando extração..." />
              </div>
            )}
          </div>
        )}

        {/* Step 2: Results */}
        {currentStep === 2 && extractedJSON && (
          <div className={styles.resultsStep}>
            {/* Missing Paths Warning */}
            {extractedJSON?.flow?.missingPaths?.length > 0 && (
              <div className={styles.missingPathsWarning}>
                <div className={styles.warningHeader}>
                  <WarningAlt size={20} />
                  <div>
                    <h4>{extractedJSON.flow.missingPaths.length} caminho(s) não encontrado(s)</h4>
                    <p>Alguns XMLs referenciados na navegação não foram encontrados nos arquivos carregados.</p>
                  </div>
                  <Button
                    kind="ghost"
                    size="sm"
                    renderIcon={Download}
                    onClick={handleDownloadMissingPaths}
                  >
                    Baixar lista
                  </Button>
                </div>
                <div className={styles.missingPathsList}>
                  {extractedJSON.flow.missingPaths.slice(0, 5).map((path, idx) => (
                    <Tag key={idx} type="warm-gray" size="sm">
                      {path}
                    </Tag>
                  ))}
                  {extractedJSON.flow.missingPaths.length > 5 && (
                    <Tag type="gray" size="sm">
                      +{extractedJSON.flow.missingPaths.length - 5} mais
                    </Tag>
                  )}
                </div>
              </div>
            )}

            {/* Extraction Summary */}
            <div className={styles.extractionSummary}>
              <CheckmarkFilled size={20} className={styles.successIcon} />
              <span>
                <strong>{extractedJSON?.flow?.interactionCount || 0}</strong> interação(ões) extraída(s)
              </span>
            </div>

            <JSONViewer
              jsonData={extractedJSON}
              onDownload={() => console.log('Downloaded')}
              compact
            />
          </div>
        )}

        {error && (
          <div className={styles.errorMessage}>
            <ErrorFilled size={20} />
            <span>{error}</span>
          </div>
        )}
      </div>
    </Modal>
  );
};

export default UploadModal;
