/**
 * Project Generation Routes
 *
 * API endpoints for generating project ZIP files
 */

import { Router, Request, Response } from 'express';
import { generateProjectZip, getAvailableTemplates, ProjectGenerationRequest, TemplateType } from '../services/project.service';
import { logger } from '../middleware/logger';

const router = Router();

/**
 * GET /api/v1/project/templates
 * List available project templates
 */
router.get('/templates', (_req: Request, res: Response) => {
  try {
    const templates = getAvailableTemplates();
    res.json({
      success: true,
      templates,
    });
  } catch (error) {
    logger.error('Error listing templates', { error: (error as Error).message });
    res.status(500).json({
      success: false,
      error: 'Failed to list templates',
    });
  }
});

/**
 * POST /api/v1/project/generate
 * Generate and download project ZIP
 *
 * Request body:
 * {
 *   templateType: 'angular' | 'go' | 'java',
 *   projectName: string,
 *   mfePort?: number,
 *   customFiles?: Record<string, string>,
 *   variables?: Record<string, string>
 * }
 */
router.post('/generate', async (req: Request, res: Response) => {
  try {
    const { templateType, projectName, mfePort, customFiles, variables } = req.body;

    // Validate required fields
    if (!templateType || !projectName) {
      res.status(400).json({
        success: false,
        error: 'Missing required fields: templateType and projectName are required',
      });
      return;
    }

    // Validate template type
    const validTypes: TemplateType[] = ['angular', 'go', 'java'];
    if (!validTypes.includes(templateType)) {
      res.status(400).json({
        success: false,
        error: `Invalid templateType. Must be one of: ${validTypes.join(', ')}`,
      });
      return;
    }

    logger.info('Project generation requested', {
      templateType,
      projectName,
      mfePort,
      customFilesCount: customFiles ? Object.keys(customFiles).length : 0,
    });

    // Build request
    const request: ProjectGenerationRequest = {
      templateType,
      projectName,
      mfePort: mfePort || 5002,
      customFiles: customFiles || {},
      variables: variables || {},
    };

    // Determine filename
    let filename: string;
    if (templateType === 'angular') {
      filename = `mf-${projectName.toLowerCase().replace(/\s+/g, '-')}.zip`;
    } else {
      filename = `${projectName.toLowerCase().replace(/\s+/g, '-')}-${templateType}.zip`;
    }

    // Set response headers for file download
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Cache-Control', 'no-cache');

    // Generate and stream ZIP
    await generateProjectZip(request, res);

  } catch (error) {
    logger.error('Error generating project', { error: (error as Error).message, stack: (error as Error).stack });

    // Only send error response if headers haven't been sent
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate project ZIP',
        details: (error as Error).message,
      });
    }
  }
});

/**
 * GET /api/v1/project/health
 * Health check for project service
 */
router.get('/health', (_req: Request, res: Response) => {
  const templates = getAvailableTemplates();
  const allAvailable = templates.every(t => t.exists);

  res.json({
    service: 'project-generator',
    healthy: allAvailable,
    templates: templates.map(t => ({ id: t.id, name: t.name, available: t.exists })),
  });
});

export default router;
