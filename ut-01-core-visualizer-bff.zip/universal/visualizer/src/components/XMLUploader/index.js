export { default } from './XMLUploader';
