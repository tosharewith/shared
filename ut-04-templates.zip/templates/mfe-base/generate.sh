#!/bin/bash
# MFE Generator Script
# Usage: ./generate.sh <mfe-name> <mfe-title> <component-name>
# Example: ./generate.sh mfe-ope-copia-swift "MFE OPE Cópia SWIFT" swift-ope-list

set -e

MFE_NAME="${1:-mfe-example}"
MFE_TITLE="${2:-MFE Example}"
MFE_DESCRIPTION="${3:-MFE Example Description}"
COMPONENT_NAME="${4:-main-list}"
COMPONENT_PATH="${COMPONENT_NAME}"
COMPONENT_CLASS=$(echo "${COMPONENT_NAME}" | sed -E 's/(^|-)([a-z])/\U\2/g')Component

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TEMPLATE_DIR="${SCRIPT_DIR}/angular"
OUTPUT_DIR="${SCRIPT_DIR}/../../generated/${MFE_NAME}/angular"

echo "Generating MFE: ${MFE_NAME}"
echo "  Title: ${MFE_TITLE}"
echo "  Component: ${COMPONENT_NAME} -> ${COMPONENT_CLASS}"
echo "  Output: ${OUTPUT_DIR}"

# Create output directory
mkdir -p "${OUTPUT_DIR}/src/app/components/${COMPONENT_PATH}"
mkdir -p "${OUTPUT_DIR}/src/app/services"
mkdir -p "${OUTPUT_DIR}/src/app/models"
mkdir -p "${OUTPUT_DIR}/src/assets"
mkdir -p "${OUTPUT_DIR}/libs"

# Copy and process template files
process_template() {
  local src="$1"
  local dest="$2"

  sed -e "s/{{MFE_NAME}}/${MFE_NAME}/g" \
      -e "s/{{MFE_TITLE}}/${MFE_TITLE}/g" \
      -e "s/{{MFE_DESCRIPTION}}/${MFE_DESCRIPTION}/g" \
      -e "s/{{COMPONENT_NAME}}/${COMPONENT_NAME}/g" \
      -e "s/{{COMPONENT_PATH}}/${COMPONENT_PATH}/g" \
      -e "s/{{COMPONENT_CLASS}}/${COMPONENT_CLASS}/g" \
      "$src" > "$dest"
}

# Process all template files
process_template "${TEMPLATE_DIR}/package.json" "${OUTPUT_DIR}/package.json"
process_template "${TEMPLATE_DIR}/angular.json" "${OUTPUT_DIR}/angular.json"
process_template "${TEMPLATE_DIR}/tsconfig.json" "${OUTPUT_DIR}/tsconfig.json"
process_template "${TEMPLATE_DIR}/tsconfig.app.json" "${OUTPUT_DIR}/tsconfig.app.json"
process_template "${TEMPLATE_DIR}/tsconfig.spec.json" "${OUTPUT_DIR}/tsconfig.spec.json"
process_template "${TEMPLATE_DIR}/src/main.ts" "${OUTPUT_DIR}/src/main.ts"
process_template "${TEMPLATE_DIR}/src/index.html" "${OUTPUT_DIR}/src/index.html"
process_template "${TEMPLATE_DIR}/src/styles.scss" "${OUTPUT_DIR}/src/styles.scss"
process_template "${TEMPLATE_DIR}/src/app/app.component.ts" "${OUTPUT_DIR}/src/app/app.component.ts"
process_template "${TEMPLATE_DIR}/src/app/app.routes.ts" "${OUTPUT_DIR}/src/app/app.routes.ts"

# Copy IDS libs if they exist
if [ -d "${SCRIPT_DIR}/libs" ]; then
  cp -r "${SCRIPT_DIR}/libs/"* "${OUTPUT_DIR}/libs/"
fi

echo ""
echo "MFE generated successfully!"
echo ""
echo "Next steps:"
echo "  1. Create component: ${OUTPUT_DIR}/src/app/components/${COMPONENT_PATH}/${COMPONENT_NAME}.component.ts"
echo "  2. Create service:   ${OUTPUT_DIR}/src/app/services/${COMPONENT_NAME}.service.ts"
echo "  3. Create model:     ${OUTPUT_DIR}/src/app/models/${COMPONENT_NAME}.model.ts"
echo "  4. Run: cd ${OUTPUT_DIR} && npm install && npm start"
