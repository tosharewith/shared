import Graph from 'graphology';
import louvain from 'graphology-communities-louvain';

/**
 * Detects communities in a Cytoscape graph using Louvain algorithm
 * @param {Object} cy - Cytoscape instance
 * @param {Object} options - Clustering options
 * @returns {Object} - { communities: Map<nodeId, communityId>, stats: Array }
 */
export function detectCommunities(cy, options = {}) {
  if (!cy) return null;

  const {
    resolution = 1, // Higher values create more smaller communities
  } = options;

  // Create a graphology graph from Cytoscape
  const graph = new Graph({ multi: false, type: 'undirected' });

  // Add nodes
  cy.nodes().forEach(node => {
    graph.addNode(node.id());
  });

  // Add edges
  cy.edges().forEach(edge => {
    const source = edge.source().id();
    const target = edge.target().id();

    // Skip self-loops and check if nodes exist
    if (source !== target && graph.hasNode(source) && graph.hasNode(target)) {
      try {
        // Avoid duplicate edges in undirected graph
        if (!graph.hasEdge(source, target) && !graph.hasEdge(target, source)) {
          graph.addEdge(source, target);
        }
      } catch (err) {
        // console.warn('Edge already exists:', source, target);
      }
    }
  });

  // Run Louvain algorithm
  const communities = louvain(graph, { resolution });

  // Convert to Map for easier lookup
  const communityMap = new Map();
  Object.entries(communities).forEach(([nodeId, communityId]) => {
    communityMap.set(nodeId, communityId);
  });

  // Calculate statistics
  const stats = calculateCommunityStats(communityMap);

  return {
    communities: communityMap,
    stats,
  };
}

/**
 * Calculate statistics for detected communities
 * @param {Map} communityMap - Map of nodeId to communityId
 * @returns {Array} - Array of community statistics
 */
function calculateCommunityStats(communityMap) {
  const stats = new Map();

  communityMap.forEach((communityId, nodeId) => {
    if (!stats.has(communityId)) {
      stats.set(communityId, {
        id: communityId,
        size: 0,
        nodes: [],
      });
    }
    const community = stats.get(communityId);
    community.size++;
    community.nodes.push(nodeId);
  });

  // Convert to array and sort by size
  return Array.from(stats.values()).sort((a, b) => b.size - a.size);
}

/**
 * Generate distinct colors for communities
 * @param {number} count - Number of colors needed
 * @returns {Array<string>} - Array of color strings
 */
export function generateCommunityColors(count) {
  const colors = [
    '#0f62fe', // Blue
    '#24a148', // Green
    '#8a3ffc', // Purple
    '#ff832b', // Orange
    '#da1e28', // Red
    '#1192e8', // Light blue
    '#198038', // Dark green
    '#6929c4', // Dark purple
    '#fa4d56', // Pink
    '#002d9c', // Navy
    '#005d5d', // Teal
    '#570408', // Maroon
    '#a56eff', // Light purple
    '#08bdba', // Cyan
    '#ba4e00', // Dark orange
  ];

  // If we need more colors than predefined, generate them
  if (count > colors.length) {
    const additional = count - colors.length;
    for (let i = 0; i < additional; i++) {
      const hue = (i * 137.508) % 360; // Golden angle for good distribution
      colors.push(`hsl(${hue}, 70%, 50%)`);
    }
  }

  return colors.slice(0, count);
}

/**
 * Apply community colors to Cytoscape nodes
 * @param {Object} cy - Cytoscape instance
 * @param {Map} communityMap - Map of nodeId to communityId
 * @param {Array<string>} colors - Array of colors
 */
export function applyCommunityColors(cy, communityMap, colors) {
  if (!cy || !communityMap) return;

  cy.nodes().forEach(node => {
    const communityId = communityMap.get(node.id());
    if (communityId !== undefined) {
      const color = colors[communityId % colors.length];
      node.style('background-color', color);
      node.data('community', communityId);
      node.data('communityColor', color);
    }
  });
}

/**
 * Reset node colors to original
 * @param {Object} cy - Cytoscape instance
 */
export function resetNodeColors(cy) {
  if (!cy) return;

  cy.nodes().forEach(node => {
    node.removeStyle('background-color');
    node.removeData('community');
    node.removeData('communityColor');
  });
}

/**
 * Calculate convex hull points for a set of nodes
 * @param {Array} nodes - Array of Cytoscape nodes
 * @returns {Array<{x: number, y: number}>} - Hull points
 */
export function calculateConvexHull(nodes) {
  if (!nodes || nodes.length === 0) return [];

  // Get positions with padding
  const positions = nodes.map(node => {
    const pos = node.position();
    return { x: pos.x, y: pos.y, node };
  });

  if (positions.length === 1) {
    // Single node - create a circle
    const { x, y } = positions[0];
    const radius = 40;
    const points = [];
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      points.push({
        x: x + Math.cos(angle) * radius,
        y: y + Math.sin(angle) * radius,
      });
    }
    return points;
  }

  if (positions.length === 2) {
    // Two nodes - create a pill shape
    const [p1, p2] = positions;
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const nx = -dy / dist;
    const ny = dx / dist;
    const radius = 30;

    return [
      { x: p1.x + nx * radius, y: p1.y + ny * radius },
      { x: p2.x + nx * radius, y: p2.y + ny * radius },
      { x: p2.x - nx * radius, y: p2.y - ny * radius },
      { x: p1.x - nx * radius, y: p1.y - ny * radius },
    ];
  }

  // For 3+ nodes, use Graham scan algorithm for convex hull
  return grahamScan(positions);
}

/**
 * Graham scan algorithm for convex hull
 * @param {Array} points - Array of {x, y} points
 * @returns {Array} - Convex hull points
 */
function grahamScan(points) {
  if (points.length < 3) return points;

  // Add padding to each point
  const padding = 30;
  const paddedPoints = points.map(p => ({ ...p }));

  // Find the bottom-most point (or left-most if tie)
  let bottom = paddedPoints[0];
  for (let i = 1; i < paddedPoints.length; i++) {
    if (paddedPoints[i].y < bottom.y || (paddedPoints[i].y === bottom.y && paddedPoints[i].x < bottom.x)) {
      bottom = paddedPoints[i];
    }
  }

  // Sort points by polar angle with respect to bottom point
  const sorted = paddedPoints.filter(p => p !== bottom).sort((a, b) => {
    const angleA = Math.atan2(a.y - bottom.y, a.x - bottom.x);
    const angleB = Math.atan2(b.y - bottom.y, b.x - bottom.x);
    return angleA - angleB;
  });

  sorted.unshift(bottom);

  // Build hull
  const hull = [sorted[0], sorted[1]];

  for (let i = 2; i < sorted.length; i++) {
    let top = hull[hull.length - 1];
    let nextToTop = hull[hull.length - 2];

    while (hull.length > 1 && crossProduct(nextToTop, top, sorted[i]) <= 0) {
      hull.pop();
      top = hull[hull.length - 1];
      nextToTop = hull[hull.length - 2];
    }

    hull.push(sorted[i]);
  }

  // Expand hull outward by padding
  const center = {
    x: hull.reduce((sum, p) => sum + p.x, 0) / hull.length,
    y: hull.reduce((sum, p) => sum + p.y, 0) / hull.length,
  };

  return hull.map(p => {
    const dx = p.x - center.x;
    const dy = p.y - center.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const scale = (dist + padding) / dist;
    return {
      x: center.x + dx * scale,
      y: center.y + dy * scale,
    };
  });
}

/**
 * Calculate cross product for three points
 */
function crossProduct(p1, p2, p3) {
  return (p2.x - p1.x) * (p3.y - p1.y) - (p2.y - p1.y) * (p3.x - p1.x);
}
